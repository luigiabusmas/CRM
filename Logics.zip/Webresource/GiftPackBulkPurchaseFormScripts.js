if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.GiftPackBulkPurchase) === "undefined") { RHSScripts.GiftPackBulkPurchase = {}; }

RHSScripts.GiftPackBulkPurchase.OnLoad = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    RHSScripts.GiftPackBulkPurchase.showNotificationforEu(executionContext);

}

RHSScripts.GiftPackBulkPurchase.OnSave = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

}

RHSScripts.GiftPackBulkPurchase.HideShowConsentsTab = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    if (formContext.ui.getFormType() === 1) {
        formContext.ui.tabs.get("tab_consents").setVisible(false);
        return;
    }

    var channelsToHide = [120000003, 120000004, 120000005];
    var channel = formContext.getAttribute("rhs_channel").getValue();
    var purchasedBy = formContext.getAttribute("rhs_purchasedby").getValue();

    if (channel !== null && purchasedBy != null) {
        if (channelsToHide.includes(channel) || purchasedBy[0].entityType !== "contact") {
            formContext.ui.tabs.get("tab_consents").setVisible(false);
        }
        else {
            formContext.ui.tabs.get("tab_consents").setVisible(true);
        }

    } else {
        formContext.ui.tabs.get("tab_consents").setVisible(false);
    }
}
// This function builds and applies the custom filter to the rhs_deliverycontact field
RHSScripts.GiftPackBulkPurchase.deliveryContactFilter = function (contactIds, rhsDeliveryContactField) {
    return function () {
        console.log("Running presearch for rhs_deliverycontact");

        if (contactIds.length > 0) {
            var filterConditions = "<filter type='or'>";
            contactIds.forEach(function (contactId) {
                console.log("Adding dynamic filter for contact GUID:", contactId);
                filterConditions += `<condition attribute="contactid" operator="eq" value="${contactId}" />`;
            });
            filterConditions += "</filter>";

            rhsDeliveryContactField.addCustomFilter(filterConditions);
            console.log("Applied dynamic filters for contact GUIDs.");
        }
    };
}

// This variable holds the reference to the current presearch handler
RHSScripts.GiftPackBulkPurchase.deliveryContactPreSearchHandler = null;

// Main function to populate and filter the delivery contact field
RHSScripts.GiftPackBulkPurchase.populateDeliveryContact = function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();
    var purchasedByOrgField = formContext.getAttribute("rhs_purchasedbyorganisation");
    var purchasedByOrg = purchasedByOrgField.getValue();
    var deliveryContactAttr = formContext.getAttribute("rhs_deliverycontact");
    var deliveryContactVal = deliveryContactAttr.getValue();
    var rhsDeliveryContactField = formContext.getControl("rhs_deliverycontact");

    if (!purchasedByOrg || purchasedByOrg.length === 0) {
        console.log("No organization selected.");
        if (deliveryContactAttr) {
            deliveryContactAttr.setValue(null);
            deliveryContactAttr.setSubmitMode("always");
        }
        return;
    }

    var orgId = purchasedByOrg[0].id.toLowerCase();
    var contactId = deliveryContactVal && deliveryContactVal.length > 0 ? deliveryContactVal[0].id.toLowerCase() : null;
    console.log("Selected Organization ID:", orgId);

    if (orgId && contactId) {
        var contactValidate = [
            "<fetch>",
            "   <entity name='rhs_position'>",
            "   <filter type='and'>",
            `       <condition attribute='rhs_contact' operator='eq' value='${contactId}' />`,
            `       <condition attribute='rhs_organisation' operator='eq' value='${orgId}'/>`,
            "   </filter>",
            "   </entity>",
            "</fetch>"
        ];

        Xrm.WebApi.retrieveMultipleRecords("rhs_position", `?fetchXml=${encodeURIComponent(contactValidate.join(""))}`).then(
            function (response) {
                if (response.entities.length === 0) {
                    console.log("No matching contact found for the selected organization.");
                    if (deliveryContactAttr) {
                        deliveryContactAttr.setValue(null);
                        deliveryContactAttr.setSubmitMode("always");
                    }
                } else {
                    console.log("Matching contact found for the selected organization.");
                }
            },
            function (error) {
                console.error("Error retrieving data:", error);
            }
        );
    }

    var fetchXml = [
        "<fetch>",
        "  <entity name='rhs_position'>",
        "    <filter>",
        `      <condition attribute='rhs_organisation' operator='eq' value='${orgId}'/>`,
        "    </filter>",
        "    <link-entity name='contact' from='contactid' to='rhs_contact' link-type='inner' alias='contact1'/>",
        "  </entity>",
        "</fetch>"
    ].join("");

    console.log("Generated FetchXML for organization contacts:", fetchXml);

    Xrm.WebApi.retrieveMultipleRecords("rhs_position", `?fetchXml=${encodeURIComponent(fetchXml)}`).then(
        function (response) {
            var contactIds = response.entities
                .map(position => position["_rhs_contact_value"])
                .filter(Boolean);

            console.log("Extracted Contact GUIDs:", contactIds);

            if (rhsDeliveryContactField) {
                rhsDeliveryContactField.setEntityTypes(["contact"]);

                var deliveryContactPreSearchHandler = null
                // Remove previous presearch handler if it exists
                if (RHSScripts.GiftPackBulkPurchase.deliveryContactPreSearchHandler) {
                    rhsDeliveryContactField.removePreSearch(RHSScripts.GiftPackBulkPurchase.deliveryContactPreSearchHandler);
                }

                // Set and store new presearch handler
                RHSScripts.GiftPackBulkPurchase.deliveryContactPreSearchHandler =
                    RHSScripts.GiftPackBulkPurchase.deliveryContactFilter(contactIds, rhsDeliveryContactField);

                rhsDeliveryContactField.addPreSearch(RHSScripts.GiftPackBulkPurchase.deliveryContactPreSearchHandler);
            }
        },
        function (error) {
            console.error("Error retrieving data:", error);
        }
    );
}
RHSScripts.GiftPackBulkPurchase.showNotificationforEu = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    formContext.ui.setFormNotification(
        "Gift Packs cannot be sent to countries within the European Union (EU). Please verify the Delivery Contact's home address before proceeding.",
        "WARNING",
        "GP_EU_Notification"
    );

}