//Subscription Command Script edit today
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Subscription) === "undefined") { RHSScripts.Subscription = {}; }

const SUBMITTING_PAYMENT_NOTIFICATION_ID = "SubmittingPaymentNotification";
const SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID = "SubscriptionTransactionSuccessfulNotification";
const SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID = "SubscriptionTransactionFailedNotification";
const CIRRUS_PAYMENT_SUBSCRIPTION_NOTIFICATION = "CirrusPaymentNotification";

//#region Command Functions
RHSScripts.Subscription.MakePaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let subscriptionId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let product = formContext.getAttribute("rhs_subscriptionproduct").getValue()[0];

    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let payer = formContext.getAttribute("rhs_subscriptionpayer").getValue()[0];
    let isContinuousPayment = formContext.getAttribute("rhs_iscontinuouspayment").getValue();
    let paymentFrequency = formContext.getAttribute("rhs_billingfrequency").getValue();
    let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
    let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();

    let checkoutURL = formContext.getAttribute("rhs_checkouturl").getValue();
    let checkoutSessionId = formContext.getAttribute("rhs_checkoutsessionid").getValue();

    try {
        let isSubmitPayment = formContext.getAttribute("rhs_ispaymentsubmitted").getValue();
        let isPaymentReceived = formContext.getAttribute("rhs_ispaymentreceived").getValue();

        if (isPaymentReceived != true) {
            //#region  Prepare the subscription for payment submission
            Xrm.Utility.showProgressIndicator("Submitting payment. Please wait...");
            formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
            formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Submitting payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);

            // await RHSScripts.Subscription.SetStartDateEndDateAndPayoutDate(formContext); // Date calculation logic moved to SubscriptionUpdatePreOpsPlugin

            formContext.getAttribute("rhs_ispaymentsubmitted").setValue(true); // Trigger date field population on plugin.
            formContext.getAttribute("rhs_ispaymentsubmitted").fireOnChange();
            await formContext.data.save();
            await formContext.data.refresh(true);
            //#endregion

            //#region  Generate transaction, payments and payment schedule
            let transaction = await RHSScripts.Subscription.RetrieveActiveSubscriptionTransaction(subscriptionId);
            let firstPayment = await RHSScripts.Subscription.RetrieveActiveSubscriptionFirstPayment(subscriptionId);

            let isSubscriptionChanged = await RHSScripts.Subscription.CheckIfSubscriptionWasChangedFromLastTransaction(formContext, transaction);
            let isFirstDDPaymentDueDateElapsed = paymentMethod == 120000002/*DD*/ && firstPayment?.rhs_duedate && new Date(firstPayment.rhs_duedate) < new Date();
            if (isSubscriptionChanged || isFirstDDPaymentDueDateElapsed) {
                await RHSScripts.Subscription.CancelTransactionAndAssociatedRecords(transaction);
            }

            if (!transaction || isSubscriptionChanged || isFirstDDPaymentDueDateElapsed) {
                let [transactionid, paymentid, payementscheduleid] = await RHSScripts.Subscription.ExecuteSubmitPaymentCustomAPIForSubscription(
                    paymentMethod, subscriptionId, payer, isContinuousPayment, paymentFrequency, totalAmount, outstandingAmount
                );
                await formContext.data.refresh(true);

                if (transactionid == null && paymentid == null && payementscheduleid == null)
                    throw new Error("Subscription transaction failed.");
            }
            //#endregion

            //#region  Make/Submit Payment
            if (paymentMethod != 120000014/*Credit Card (Phone) */) {
                if (paymentMethod == 844060000/*Cash*/ || paymentMethod == 844060001/*Cheque*/ || paymentMethod == 844060004/*CAF*/ ||
                    paymentMethod == 844060003/*PWAC*/ || paymentMethod == 120000003/*Third Parties*/
                ) {
                    let payments = await RHSScripts.Subscription.RetrieveActiveSubscriptionPayments(subscriptionId);
                    for (let ctr = 0; ctr < payments.length; ctr++)
                        await RHSScripts.Subscription.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);
                } else if (paymentMethod == 120000002/*DD*/) {
                    if (await RHSScripts.Subscription.ValidateIfLinkedSubscriptionPaymentMethodIsDirectDebit(formContext)) {
                        let linkedSubscriptionId = formContext.getAttribute("rhs_linkedsubscription").getValue()[0].id.replace("{", "").replace("}", "").toLowerCase();
                        await RHSScripts.Subscription.ContinueUsingSameDirectDebitForSubscription(linkedSubscriptionId, subscriptionId);
                    } else {
                        await RHSScripts.Subscription.MakePTXPayment(subscriptionId, paymentFrequency, payer);
                    }
                }
                await RHSScripts.Subscription.ActivateSubscription(subscriptionId);
            } else if (paymentMethod == 120000014/*Credit Card (Phone) */) {
                await RHSScripts.Subscription.MakeCirrusPCIpaymentURL(subscriptionId, payer, totalAmount, false);
            }

            await formContext.data.refresh(true);
            //#endregion

            //#region  Ending payment submission
            Xrm.Utility.closeProgressIndicator();
            formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Subscription transaction successful.", "INFO", SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            Xrm.Navigation.openAlertDialog({ title: "Success", text: "Payment successful." });

            //#endregion
        }
    } catch (error) {
        formContext.getAttribute("rhs_ispaymentsubmitted").setValue(false);
        formContext.getAttribute("rhs_ispaymentsubmitted").fireOnChange();
        await formContext.data.save();
        await formContext.data.refresh(true);

        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Subscription transaction failed. Please try again", "ERROR", SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Payment failed.  \n\nDetails: " + error.message });
    }
}

RHSScripts.Subscription.CancelSubscriptionCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    formContext.ui.tabs.get("General").sections.get("Administration").setVisible(true);
    formContext.getAttribute("rhs_cancelsubscription").setValue(true);
    formContext.getAttribute("rhs_cancellationdate").setValue(new Date());
    formContext.getAttribute("rhs_subscriptioncancellationtype").setValue(120000000);
    formContext.getAttribute("statecode").setValue(1);
    formContext.getAttribute("statuscode").setValue(2);
    Xrm.Page.getAttribute("rhs_subscriptioncancellationtype").setRequiredLevel("required");
    Xrm.Page.getAttribute("rhs_cancellationreason").setRequiredLevel("required");
}

RHSScripts.Subscription.RenewSubscriptionEarlyCommand = async function (primaryControl) {
    'use strict';

    try {
        let formContext = primaryControl;
        const poundSymbol = "\u00A3";
        // Check if outstanding amount exists
        if (formContext.getAttribute("rhs_outstandingamount")) {
            let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
            let paymentFrequency = formContext.getAttribute("rhs_billingfrequency")?.getValue() || null;
            let paymentSchedule = formContext.getAttribute("rhs_paymentschedule")?.getValue() || null;

            if (outstandingAmount === 0) {
                let confirmOptions = { text: "Customer is not in renewal, and balance is \u00A30. Confirm advance payment.", title: "Confirm Renewal" };

                let response = await Xrm.Navigation.openConfirmDialog(confirmOptions);
                if (response.confirmed) {
                    Xrm.Utility.showProgressIndicator("Renewing subscription early. Please wait...");

                    formContext.getAttribute("rhs_inrenewalsstage")?.setValue(true);

                    // formContext.getAttribute("rhs_startdate")?.setValue(new Date());
                    // formContext.getAttribute("rhs_renewalbillingfrequency")?.setValue(paymentFrequency);
                    // formContext.getAttribute("rhs_renewalpaymentschedule")?.setValue(paymentSchedule);

                    try {
                        // **Wait for the save operation to complete**
                        await formContext.data.save();

                        // **API Call after successful save**
                        let apiCallResult = await RHSScripts.Subscription.CallSubscriptionRenewalsCustomAPI(formContext, true);

                        if (!apiCallResult || apiCallResult.status !== "success") {
                            formContext.getAttribute("rhs_inrenewalsstage")?.setValue(false);
                            await formContext.data.save();

                            Xrm.Utility.closeProgressIndicator();
                            await Xrm.Navigation.openAlertDialog({ text: "API call failed. Renewal cannot continue." });
                            return;
                        }

                        // **Show success message and refresh form**
                        await Xrm.Navigation.openAlertDialog({ text: "Subscription renewed successfully!" });
                        await formContext.data.save();
                        await formContext.data.refresh(true);

                        // **Show renewal sections**
                        await RHSScripts.Subscription.ShowRenewalSections(formContext);
                    } catch (saveError) {
                        await Xrm.Navigation.openAlertDialog({ text: "Error: Unable to save the record. Try again." });
                    }

                    Xrm.Utility.closeProgressIndicator();
                } else {
                    await Xrm.Navigation.openAlertDialog({ text: "Action canceled." });
                }
            } else {
                await Xrm.Navigation.openAlertDialog({ text: "Customer balance is not \u00A30. Renewal cannot proceed." });
            }
        } else {
            await Xrm.Navigation.openAlertDialog({ text: "Error: Outstanding amount field is missing." });
        }

    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openAlertDialog({ text: "An unexpected error occurred: " + error.message });
    }
}

RHSScripts.Subscription.TakeRenewalPaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let currentSubscriptionId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let currentSubscriptionPaymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let currentSubscriptionStatusReason = formContext.getAttribute("statuscode").getValue();

    try {
        //#region  Prepare the subscription for renewal payment submission
        Xrm.Utility.showProgressIndicator("Submitting renewal payment. Please wait...");
        formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
        formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Submitting renewal payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);
        //#endregion

        //#region Retrieve/Create a new Subscription Instance
        let newSubscription = await RHSScripts.Subscription.RetrieveRenewalSubscription(currentSubscriptionId);
        let newSubscriptionId = null;

        if (newSubscription == null) {
            newSubscriptionId = await RHSScripts.Subscription.ExecuteCreateSubscriptionOnRenewalsCustomAPI(currentSubscriptionId);
            newSubscription = await Xrm.WebApi.retrieveRecord("rhs_subscription", newSubscriptionId);
        } else {
            newSubscriptionId = newSubscription["rhs_subscriptionid"];
        }

        let newSubscriptionPayer = {
            "id": newSubscription["_rhs_subscriptionpayer_value"],
            "entityType": newSubscription["_rhs_subscriptionpayer_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
            "name": newSubscription["_rhs_subscriptionpayer_value@OData.Community.Display.V1.FormattedValue"]
        };
        let newSubscriptionProduct = {
            "id": newSubscription["_rhs_subscriptionproduct_value"],
            "entityType": newSubscription["_rhs_subscriptionproduct_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
            "name": newSubscription["_rhs_subscriptionproduct_value@OData.Community.Display.V1.FormattedValue"]
        };
        let newSubscriptionStartDate = newSubscription.rhs_startdate;
        let newSubscriptionPaymentMethod = newSubscription.rhs_paymentmethodcode;
        let newSubscriptionIsContinuousPayment = newSubscription.rhs_iscontinuouspayment;
        let newSubscriptionPaymentFrequency = newSubscription.rhs_billingfrequency;
        let newSubscriptionTotalAmount = newSubscription.rhs_totalamount;
        let newSubscriptionOutstandingAmount = newSubscription.rhs_outstandingamount;
        let newSubscriptionCheckoutUrl = newSubscription.rhs_checkouturl;
        let newSubscriptionCheckoutSessionId = newSubscription.rhs_checkoutsessionid;
        //#endregion

        //#region Generate transaction, payments and payment schedule for new Subscription Instance
        if (newSubscriptionPaymentMethod != 844060005/*Gift Pack*/) {
            let transaction = await RHSScripts.Subscription.RetrieveActiveSubscriptionTransaction(newSubscriptionId);
            if (transaction == null) {
                let [transactionid, paymentid, payementscheduleid] = await RHSScripts.Subscription.ExecuteSubmitPaymentCustomAPIForSubscription(
                    newSubscriptionPaymentMethod,
                    newSubscriptionId,
                    newSubscriptionPayer,
                    newSubscriptionIsContinuousPayment,
                    newSubscriptionPaymentFrequency,
                    newSubscriptionTotalAmount,
                    newSubscriptionOutstandingAmount
                );
                if (transactionid == null && paymentid == null && payementscheduleid == null)
                    throw new Error("Subscription renewal transaction failed.");
            }
        }
        //#endregion

        //#region Make/Submit Payment for new Subscription Instance

        // Check if Renewals Payment Method Direct Debit
        let renewalsPaymentMethod = formContext.getAttribute("rhs_renewalspaymentmethodcode").getValue();
        if (renewalsPaymentMethod == 120000002) {
            await RHSScripts.Subscription.MakePTXPayment(newSubscriptionId, newSubscriptionPaymentFrequency, newSubscriptionPayer);
        } else {
            if (newSubscriptionPaymentMethod == 844060000/*Cash*/ || newSubscriptionPaymentMethod == 844060001/*Cheque*/ || newSubscriptionPaymentMethod == 844060003 /*PWAC*/) {
                let payments = await RHSScripts.Subscription.RetrieveActiveSubscriptionPayments(newSubscriptionId);
                for (let ctr = 0; ctr < payments.length; ctr++)
                    await RHSScripts.Subscription.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);
            } else if (newSubscriptionPaymentMethod == 120000002/*DD*/) {
                if (currentSubscriptionPaymentMethod != newSubscriptionPaymentMethod) {
                    await RHSScripts.Subscription.MakePTXPayment(newSubscriptionId, newSubscriptionPaymentFrequency, newSubscriptionPayer);
                } else {
                    await RHSScripts.Subscription.ContinueUsingSameDirectDebitForSubscription(currentSubscriptionId, newSubscriptionId);
                }
            } else if (newSubscriptionPaymentMethod == 120000014/*Credit Card (Phone)*/) {
                await RHSScripts.Subscription.MakeCirrusPCIpaymentURL(
                    newSubscriptionId,
                    newSubscriptionPayer,
                    newSubscriptionTotalAmount, true
                );

            }
        }

        //Update Subscription Status on Successful Payment Submission
        if (currentSubscriptionStatusReason == 120000002/*Dormant*/) {
            await RHSScripts.Subscription.UpdateStatusOfPresentAndNewSubscriptionWhenRenewingDormantSubscription(currentSubscriptionId, newSubscriptionId);
        } else if (new Date(newSubscriptionStartDate) > new Date()) {
            await RHSScripts.Subscription.SetSubscriptionAsPaidInAdvance(newSubscriptionId);
        } else {
            await RHSScripts.Subscription.SetSubscriptionAsNew(newSubscriptionId);
        }
        await RHSScripts.Subscription.SetSubscriptionRenewalFieldsOnSuccessfulRenewal(currentSubscriptionId);

        //Save and Refresh
        await formContext.data.refresh(true);
        await formContext.data.save();

        //#endregion

        //#region Ending renewal payment submission
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Subscription renewal transaction successful.", "INFO", SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Success", text: "Renewal is done successfully!" });

        //#endregion
    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Subscription renewal transaction failed. Please try again", "ERROR", SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Renewal failed!  \n\nDetails: " + error.message });
    }
}
//#endregion

//#region Helper Functions
// Logic moved to SubscriptionUpdatePreOpsPlugin
// RHSScripts.Subscription.SetStartDateEndDateAndPayoutDate = async function (formContext) { 
//     // Retrieve product duration
//     let product = formContext.getAttribute("rhs_subscriptionproduct").getValue();
//     let productId = product[0].id.replace("{", "").replace("}", "").toLowerCase();

//     let propertyEntityLogicalName = "dynamicproperty";
//     let propertyOptions = "".concat(
//         `?$select=dynamicpropertyid,name,_defaultvalueoptionset_value`,
//         `&$expand=Dynamicproperty_DynamicPropertyAssociation($filter=(_regardingobjectid_value eq ${productId} and associationstatus eq 0))`,
//         `&$filter=(name eq 'Duration') and (Dynamicproperty_DynamicPropertyAssociation/any(o1:(o1/_regardingobjectid_value eq ${productId} and o1/associationstatus eq 0)))`,
//         `&$top=1`
//     );
//     let durationProperty = (await Xrm.WebApi.retrieveMultipleRecords(propertyEntityLogicalName, propertyOptions)).entities[0];

//     let defaultPropertyOptionSetEntityLogicalName = "dynamicpropertyoptionsetitem";
//     let defaultPropertyOptionSetId = durationProperty._defaultvalueoptionset_value;
//     let defaultPropertyOptionSetOptions = "?$select=dynamicpropertyoptionname,dynamicpropertyoptionvalue";
//     let durationDefaultPropertyOptionSetName = (await Xrm.WebApi.retrieveRecord(defaultPropertyOptionSetEntityLogicalName, defaultPropertyOptionSetId, defaultPropertyOptionSetOptions)).dynamicpropertyoptionname;

//     // Retrieve time-based campaign discount (if any)
//     let durationDiscount = null;
//     let campaign = formContext.getAttribute("rhs_campaigncode").getValue();
//     if (campaign != undefined && campaign != null) {
//         let campaignEntityLogicalName = "campaign";
//         let campaignId = campaign[0].id.replace("{", "").replace("}", "").toLowerCase();
//         let campaignOptions = "?$select=rhs_benefittype,rhs_durationbenefit";

//         let potentialCampaignDiscount = await Xrm.WebApi.retrieveRecord(campaignEntityLogicalName, campaignId, campaignOptions);
//         if (potentialCampaignDiscount.rhs_benefittype == 120000000/*Time-Based*/)
//             durationDiscount = potentialCampaignDiscount.rhs_durationbenefit;
//     }

//     // Prepare start date and end date values
//     let now = new Date();
//     let paymentDate = now.getDate();

//     let rhs_startdate = formContext.getAttribute("rhs_startdate").getValue();
//     let startDate = null;
//     if (rhs_startdate == undefined || rhs_startdate == null) {
//         // startDate = new Date(now);
//         if (paymentDate >= 23 && paymentDate <= 31) {
//             startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of next month
//         } else if (paymentDate === 1) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of current month
//         } else if (paymentDate >= 2 && paymentDate <= 8) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 8, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 8th of current month
//         } else if (paymentDate >= 9 && paymentDate <= 15) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 15, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 15th of current month
//         } else if (paymentDate >= 16 && paymentDate <= 22) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 22, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 22nd of current month
//         }
//     } else {
//         startDate = new Date(rhs_startdate);
//     }

//     let endDate = new Date(startDate);
//     switch(durationDefaultPropertyOptionSetName) {
//         case "3 Months":
//             endDate.setMonth(endDate.getMonth() + 3);
//             endDate.setDate(endDate.getDate() - 1);
//             break;
//         case "6 Months":
//             endDate.setMonth(endDate.getMonth() + 6);
//             endDate.setDate(endDate.getDate() - 1);
//             break;
//         case "1 Year":
//             endDate.setFullYear(endDate.getFullYear() + 1);
//             endDate.setDate(endDate.getDate() - 1);
//             break;
//         case "Lifetime":
//             break;
//     }
//     if(durationDiscount != undefined && durationDiscount != null)
//         endDate.setMonth(endDate.getMonth() + durationDiscount);

//     // Set start date and end date
//     let subscriptionId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
//     let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
//     let record = {};
//     if (rhs_startdate == undefined || rhs_startdate == null)
//         record.rhs_startdate = startDate.toISOString().substring(0, 10);
//     record.rhs_enddate = endDate.toISOString().substring(0, 10);
//     if (paymentMethod != 844060005/*Gift Pack*/) {
//         record.rhs_enddate = endDate.toISOString().substring(0, 10);
//         console.log("record.rhs_enddate:" + record.rhs_enddate);

//         if (record.rhs_enddate) {
//             let { dormancyValue, renewalValue } = await RHSScripts.Subscription.RenewalRangeDates();
//             console.log("dormancyValue:" + dormancyValue);
//             console.log("renewalValue:" + renewalValue);

//             if (dormancyValue != null && renewalValue != null) {
//                 // Calculate Renewal Start Date
//                 let renewalStartDate = new Date(endDate);
//                 renewalStartDate.setMonth(renewalStartDate.getMonth() - renewalValue);
//                 record.rhs_renewalsstartdate = renewalStartDate.toISOString().substring(0, 10);
//                 console.log("record.rhs_renewalsstartdate:" + record.rhs_renewalsstartdate);

//                 // Calculate Renewal End Date
//                 let renewalEndDate = new Date(endDate);
//                 renewalEndDate.setMonth(renewalEndDate.getMonth() + dormancyValue);
//                 record.rhs_renewalsenddate = renewalEndDate.toISOString().substring(0, 10);
//                 console.log("record.rhs_renewalsenddate" + record.rhs_renewalsenddate);
//             }
//         }
//     }
//     if (paymentMethod == 120000002 /* DD */) {
//         var nextPayoutDate = new Date(startDate);
//         console.log("Initial Start Date: " + nextPayoutDate.toISOString());

//         var workingDaysAdded = 0;

//         // Loop until 10 working days
//         while (workingDaysAdded < 10) {
//             nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
//             var dayOfWeek = nextPayoutDate.getDay();

//             // Skip weekends
//             if (dayOfWeek !== 0 && dayOfWeek !== 6) {
//                 let isHoliday = await RHSScripts.Subscription.HasHolidays(nextPayoutDate);
//                 if (!isHoliday) {
//                     workingDaysAdded++;
//                 }
//             }
//         }
//         // Final payout date
//         console.log("Final calculated Payout Date: " + nextPayoutDate);
//         var year = nextPayoutDate.getFullYear();
//         var month = String(nextPayoutDate.getMonth() + 1).padStart(2, '0');
//         var day = String(nextPayoutDate.getDate()).padStart(2, '0');
//         var formattedDate = year + '-' + month + '-' + day;

//         record.rhs_paymentschedule = formattedDate;
//     }
//     await Xrm.WebApi.updateRecord("rhs_subscription", subscriptionId, record);
// }

RHSScripts.Subscription.RenewalRangeDates = async function () {

    let dormancyResponse = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'SubscriptionDormancyPeriodDuration'"
    );

    let renewalResponse = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'SubscriptionRenewalPeriodDuration'"
    );
    let dormancyValue = dormancyResponse.entities.length > 0 ? Number(dormancyResponse.entities[0].rhs_value) : 0;
    let renewalValue = renewalResponse.entities.length > 0 ? Number(renewalResponse.entities[0].rhs_value) : 0;

    return { dormancyValue, renewalValue };
}

RHSScripts.Subscription.ActivateSubscription = async function (subscriptionId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 0;
    record.statuscode = 1;

    await Xrm.WebApi.updateRecord("rhs_subscription", subscriptionId, record);
}

RHSScripts.Subscription.RetrieveSubscriptionTransaction = async function (subscriptionId) {
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,_rhs_subscriptionid_value,rhs_outstandingamount",
        `&$filter=(_rhs_subscriptionid_value eq ${subscriptionId})`,
        "&$top=1"
    );

    return await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options).then(
        function success(result) {
            return result.entities[0];
        },
        function (error) {
            console.log(error.message);
            return null;
        }
    );
}

RHSScripts.Subscription.RetrieveActiveSubscriptionTransaction = async function (subscriptionId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = `?$filter=(_rhs_subscriptionid_value eq ${subscriptionId} and (statecode eq 0 or statuscode eq 120000008))`;

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.Subscription.RetrievePaidSubscriptionTransaction = async function (subscriptionId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = `?$filter=(_rhs_subscriptionid_value eq ${subscriptionId} and (statecode eq 1 and statuscode eq 120000008))`;

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.Subscription.RetrieveActiveSubscriptionPaymentSchedule = async function (subscriptionId) {
    let paymentSchedule = null;
    let entityLogicalName = "rhs_paymentschedule";
    let options = `?$filter=_rhs_subscriptionid_value eq ${subscriptionId}`;

    let paymentSchedules = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (paymentSchedules != undefined && paymentSchedules != null && paymentSchedules.length > 0)
        paymentSchedule = paymentSchedules[0];

    return paymentSchedule;
}

RHSScripts.Subscription.RetrieveActiveSubscriptionFirstPayment = async function (subscriptionId) {
    let payments = await RHSScripts.Subscription.RetrieveActiveSubscriptionPayments(subscriptionId);
    let firstPayment = payments ? payments[0] : null;
    return firstPayment;
}

RHSScripts.Subscription.RetrieveActiveSubscriptionPayments = async function (subscriptionId) {
    let payments = null;
    let entityLogicalName = "rhs_payment";
    let options = "".concat(
        "?$select=rhs_paymentid,rhs_paymentsid,rhs_amount,rhs_duedate,statuscode,statecode",
        `&$filter=(rhs_Transaction/_rhs_subscriptionid_value eq ${subscriptionId} and statecode eq 0)`,
        "&$orderby=rhs_duedate asc"
    );

    payments = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return payments;
}

RHSScripts.Subscription.UpdatePaymentAsPaid = async function (paymentId) {
    await Xrm.WebApi.updateRecord("rhs_payment", paymentId, { "rhs_paidon": (new Date()).toISOString().substring(0, 10), "statecode": 1/*Inactive*/, "statuscode": 2/*Paid*/ });
}

RHSScripts.Subscription.ExecuteSubmitPaymentCustomAPIForSubscription = async function (paymentMethod, subscriptionId, payer, isContinuousPayment, paymentFrequency, totalAmount, outstandingAmount) {
    // Parameters
    let parameters = {};
    parameters.PaymentMethod = paymentMethod;
    parameters.RecordId = subscriptionId;
    parameters.PayerId = payer != null ? payer.id.replace("{", "").replace("}", "").toLowerCase() : null;
    parameters.IsContiniousPayment = isContinuousPayment;
    parameters.PaymentFrequency = paymentFrequency;
    parameters.TransactionType = 120000003;
    parameters.Type = 120000000;
    parameters.PayerEntity = payer != null ? payer.entityType : null;
    parameters.TotalAmount = outstandingAmount != null ? outstandingAmount : totalAmount;
    parameters.OutstandingAmount = outstandingAmount;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_submitpayment_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let transactionid = result["TransactionId"];
        let paymentid = result["PaymentId"];
        let payementscheduleid = result["PayementScheduleId"];
        return [transactionid, paymentid, payementscheduleid]
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Subscription.MakePTXPayment = async function (subscriptionId, paymentFrequency, payerReference) {
    let ptxPaymentUrl = await RHSScripts.Subscription.RetrieveAppSettingValueByName("FAPTXWebFormURL");
    let ptxCallbackURL = await RHSScripts.Subscription.RetrieveAppSettingValueByName("FAPTXCallbackURL");
    if (ptxPaymentUrl == undefined || ptxPaymentUrl == null)
        throw Error("PTXWebFormURL app setting not set for this environment. Please contact an administrator to fix this.");
    if (ptxCallbackURL == undefined || ptxCallbackURL == null)
        throw Error("FAPTXCallbackURL app setting not set for this environment. Please contact an administrator to fix this.");

    if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?");
    ptxPaymentUrl += "?";

    let payer = await Xrm.WebApi.retrieveRecord(payerReference.entityType, payerReference.id);
    let payerCompany = payerReference.entityType == "contact" && payer._parentcustomerid_value != undefined && payer._parentcustomerid_value != null ?
        await Xrm.WebApi.retrieveRecord("account", payer._parentcustomerid_value) : null;
    let payerTitle = payerReference.entityType == "contact" && payer._rhs_title_value != undefined && payer._rhs_title_value != null ?
        await Xrm.WebApi.retrieveRecord("rhs_titleandsalutation", payer._rhs_title_value) : null;

    let postcode = payer.address1_postalcode;
    //let buildingNumberOrName = null; // Building name is not saved on contact or account address fields.
    let address = payerReference.entityType == "contact" ?
        (payer.rhs_loqatehomeaddresshousename != null ? payer.rhs_loqatehomeaddresshousename.split(' ').slice(1).join(' ') : null) :
        (payer.rhs_loqateaddress1housename != null ? payer.rhs_loqateaddress1housename.split(' ').slice(1).join(' ') : null);
    let townOrCity = payerReference.entityType == "contact" ? payer.address1_city : payer.address1_city;

    let buildingNumberOrName = payerReference.entityType === "contact" ? (payer.rhs_loqatehomeaddresshousename ?? null) : (payer.rhs_loqateaddress1housename ?? null);

    let transaction = await RHSScripts.Subscription.RetrieveActiveSubscriptionTransaction(subscriptionId);
    let paymentSchedule = await RHSScripts.Subscription.RetrieveActiveSubscriptionPaymentSchedule(subscriptionId);
    let payments = await RHSScripts.Subscription.RetrieveActiveSubscriptionPayments(subscriptionId);

    //Normalize accented characters
    const normalizeText = (value) => {
        if (!value || typeof value !== "string") return value;
        return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s]/g, "");
    }

    let parameters = {};
    //#region  Customisation parameters
    parameters.formname = null;
    parameters.texttitle = null;
    parameters.textsubtitle = null;
    parameters.contactphone = null;
    parameters.contactemail = null;
    parameters.textapplybutton = null;
    parameters.showformheader = null;
    parameters.legalentityname = null;
    parameters.currentaddresslegend = null;
    parameters.customdatalabel = null;
    parameters.showtitle = null;
    parameters.showfirstname = null;
    parameters.showmiddlename = null;
    parameters.showlastname = null;
    parameters.showdob = null;
    parameters.showemail = null;
    parameters.showmobile = null;
    parameters.showcurrentaddress = null;
    parameters.showbankaccount = null;
    parameters.advancednoticedays = 1;
    parameters.showcompanyname = null;
    parameters.showapplyingascompanycheck = null;
    parameters.useaddressline2 = null;
    parameters.showcustomdata = null;
    parameters.showddplanreference = null;
    parameters.showconfirmddguarantee = null;
    parameters.showddplansummary = null;
    parameters.showddplanfields = null;
    parameters.showgiftaid = null;
    parameters.showerrordetail = null;
    parameters.showbankaccountcreated = null;
    parameters.showcompanyregistrationnumber = null;
    //#endregion
    //#region  Required
    parameters.company = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    //parameters.firstname = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    const firstName = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    parameters.firstname = normalizeText(firstName);
    //parameters.lastname = payerReference.entityType == "contact" ? payer.lastname : null;
    const lastName = payerReference.entityType == "contact" ? payer.lastname : null;
    parameters.lastname = normalizeText(lastName);
    //parameters.email = payer.emailaddress1;
    const emailAddress1 = payer.emailaddress1;
    parameters.email = normalizeText(emailAddress1);
    parameters.currenthousenamenumber = buildingNumberOrName;
    parameters.currentpostcode = postcode;
    //parameters.bankaccountname = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    const bankAccountName = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    parameters.bankaccountname = normalizeText(bankAccountName);
    parameters.sortcode = null;
    parameters.accountnumber = null;
    parameters.ddplanspecification = null;
    parameters.ddregularamount = paymentSchedule != null ? paymentSchedule.rhs_paymentamount : payments[0].rhs_amount;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddstartdate = payments[0].rhs_duedate.substring(0, 10);
    //#endregion
    //#region  Optional
    parameters.requestid = null;
    parameters.requestuserid = null;
    parameters.customdata = null;
    parameters.contactdetailsheader = null;
    parameters.title = null;    // causes problems when more than 5 characters
    //parameters.middlename = payerReference.entityType == "contact" ? payer.middlename : null;
    const middleName = payerReference.entityType == "contact" ? payer.middlename : null;
    parameters.middlename = normalizeText(middleName);
    parameters.dob = payerReference.entityType == "contact" && payer.birthdate != undefined && payer.birthdate != null ? payer.birthdate.substring(0, 10) : null;
    parameters.email = payer.emailaddress1;
    parameters.mobile = payer.telephone1;
    parameters.applyingascompany = null;
    parameters.companyname = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    parameters.currentstreet1 = payer.address1_line1;
    parameters.currenttown = townOrCity;
    parameters.ddnoofcollections = null;//payments.length; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddtotalamount = null;
    parameters.ddfirstamount = payments[0].rhs_amount;
    parameters.ddlastamount = null;//payments[payments.length - 1].rhs_amount; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddplaninterval = 1;
    parameters.ddplantype = paymentFrequency == 120000002/*Monthly*/ ? "Monthly" : "Yearly";
    parameters.dddebtorreference = null;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddplanaltreference = null;
    parameters.ddplanendbydate = null;
    parameters.ddprofilename = null;
    parameters.ptxprofilename = null;
    parameters.giftaid = null;
    parameters.ttl = null;
    parameters.expirationtimer = null;
    parameters.callbackurl = ptxCallbackURL;
    parameters.redirecturl = null;
    //#endregion

    for (let parameterName in parameters) {
        if (parameters[parameterName] != undefined && parameters[parameterName] != null) {
            if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?")
                ptxPaymentUrl += "&";
            ptxPaymentUrl += `${parameterName}=${parameters[parameterName]}`;
        }
    }

    Xrm.Navigation.openUrl(ptxPaymentUrl);

    // Confirm PTX payment
    let alertStrings = { title: "PTX Payment", text: "Have you finished PTX payment?", confirmButtonLabel: "Yes" };
    await Xrm.Navigation.openAlertDialog(alertStrings);

    let directDebitDetail = await RHSScripts.Subscription.RetrieveDirectDebitDetail(parameters.ddplanreference);
    if (directDebitDetail == undefined || directDebitDetail == null) {
        // Delay 15 seconds and recheck again
        await RHSScripts.Subscription.Delay(15000);
        directDebitDetail = await RHSScripts.Subscription.RetrieveDirectDebitDetail(parameters.ddplanreference);

        if (directDebitDetail == undefined || directDebitDetail == null)
            throw Error("Stripe Transaction Failed");
    }
}

RHSScripts.Subscription.RetrieveAppSettingValueByName = async function (name) {
    let appSettingValue = null;
    let entityLogicalName = "rhs_appsettings";
    let options = `?$select=rhs_name,rhs_value&$filter=(rhs_name eq '${name}' and statecode eq 0)`;

    let appSettings = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (appSettings != undefined && appSettings != null && appSettings.length > 0)
        appSettingValue = appSettings[0].rhs_value;

    return appSettingValue
}

RHSScripts.Subscription.RetrieveDirectDebitDetail = async function (reference) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=rhs_reference eq '${reference}'&$top=1`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.Subscription.Delay = function (ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

RHSScripts.Subscription.CallSubscriptionRenewalsCustomAPI = async function (primaryControl, isAdvancePayment = false) {
    try {
        var formContext = primaryControl;
        var subscriptionId = formContext.data.entity.getId()?.replace("{", "").replace("}", "").toLowerCase();

        if (!subscriptionId) {
            Xrm.Navigation.openAlertDialog({ text: "Error: Unable to retrieve Subscription ID (GUID)." });
            return { status: "error", message: "Subscription ID missing" };
        }

        let parameters = {
            "SubscriptionId": subscriptionId,
            "AdvancePayment": isAdvancePayment
        };
        let apiUrl = Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_subscription_renewals";

        let response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "OData-MaxVersion": "4.0",
                "OData-Version": "4.0",
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json"
            },
            body: JSON.stringify(parameters)
        });

        let result = await response.json();
        if (!response.ok) {
            throw new Error(result.error?.message || "Unknown API error occurred.");
        }

        let returnedSubscriptionId = result["SubscriptionId"];
        let apiResult = result["Result"];

        // **Show notification**
        //  await Xrm.Navigation.openAlertDialog({ 
        //   text: `Custom API called successfully!\nSubscription ID: //${returnedSubscriptionId}\nResult: ${apiResult}` 
        //      });

        return { status: "success", subscriptionId: returnedSubscriptionId, result: apiResult };

    } catch (error) {
        console.error("API Error:", error.message);
        // await Xrm.Navigation.openAlertDialog({ text: "Custom API call failed. Error: " + error.message });
        return { status: "error", message: error.message };
    }
}

RHSScripts.Subscription.ShowRenewalSections = async function (formContext) {
    'use strict';

    formContext.getAttribute("rhs_inrenewalsstage").fireOnChange(); //triggers on change event that will show the renewals section
}

RHSScripts.Subscription.RetrieveRenewalSubscription = async function (subscriptionId) {
    let renewalSubscriptionsOfSubscription = (await Xrm.WebApi.retrieveMultipleRecords("rhs_subscription", `?$filter=(_rhs_linkedsubscription_value eq ${subscriptionId} and rhs_isrenewal eq true)&$orderby=createdon desc&$top=1`)).entities;
    return renewalSubscriptionsOfSubscription.length > 0 ? renewalSubscriptionsOfSubscription[0] : null;
}

RHSScripts.Subscription.ExecuteCreateSubscriptionOnRenewalsCustomAPI = async function (subscriptionId) {
    // Parameters
    let parameters = {};
    parameters.SubscriptionId = subscriptionId; // Edm.Guid

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_Create_subscription_onrenewals_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let subscriptionid = result["SubscriptionId"]; // Edm.Guid
        return subscriptionid;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Subscription.UpdateStatusOfPresentAndNewSubscriptionWhenRenewingDormantSubscription = async function (presentSubscriptionId, newSubscriptionId) {
    await Xrm.WebApi.updateRecord("rhs_subscription", presentSubscriptionId, { "statecode": 1/*Inactive*/, "statuscode": 120000007/*Renewed*/ });
    await Xrm.WebApi.updateRecord("rhs_subscription", newSubscriptionId, { "statecode": 0/*Active*/, "statuscode": 1/*Active*/ });
}

RHSScripts.Subscription.SetSubscriptionAsPaidInAdvance = async function (subscriptionId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 1/*Inactive*/;
    record.statuscode = 120000008 /*Paid in Advance*/;

    await Xrm.WebApi.updateRecord("rhs_subscription", subscriptionId, record);
}

RHSScripts.Subscription.SetSubscriptionAsNew = async function (subscriptionId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 0/*Active*/;
    record.statuscode = 120000001 /*New*/;

    await Xrm.WebApi.updateRecord("rhs_subscription", subscriptionId, record);
}

RHSScripts.Subscription.SetSubscriptionRenewalFieldsOnSuccessfulRenewal = async function (subscriptionId) {
    let record = {};
    record.rhs_renewalsstatus = 120000001/*Renewed*/;
    record.rhs_renewaldate = (new Date()).toISOString().substring(0, 10);

    await Xrm.WebApi.updateRecord("rhs_subscription", subscriptionId, record);
}

RHSScripts.Subscription.ContinueUsingSameDirectDebitForSubscription = async function (oldSubscriptionId, newSubscriptionId) {
    let directDebitDetail = await RHSScripts.Subscription.RetrieveSubscriptionDirectDebit(oldSubscriptionId);
    let newTransaction = await RHSScripts.Subscription.RetrieveActiveSubscriptionTransaction(newSubscriptionId);
    let newPayments = await RHSScripts.Subscription.RetrieveActiveSubscriptionPayments(newSubscriptionId);

    //Update direct debit lookup of transaction
    if (directDebitDetail && newTransaction) {
        let transactionUpdate = {};
        transactionUpdate["rhs_directdebitmandate@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

        await Xrm.WebApi.updateRecord("rhs_transaction", newTransaction.rhs_transactionid, transactionUpdate);
    }

    //Update direct debit lookup of payments
    if (directDebitDetail && newPayments) {
        for (let ctr = 0; ctr < newPayments.length; ctr++) {
            var paymentUpdate = {};
            paymentUpdate["rhs_DirectDebitDetails@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

            await Xrm.WebApi.updateRecord("rhs_payment", newPayments[ctr].rhs_paymentid, paymentUpdate);
        }
    }

    //Update direct debit lookup of subscription
    if (directDebitDetail) {
        var directDebitUpdate = {};
        directDebitUpdate["rhs_Subscription@odata.bind"] = `/rhs_subscriptions(${newSubscriptionId})`;

        await Xrm.WebApi.updateRecord("rhs_directdebitdetails", directDebitDetail.rhs_directdebitdetailsid, directDebitUpdate);
    }
}

RHSScripts.Subscription.RetrieveSubscriptionDirectDebit = async function (subscriptionId) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=_rhs_subscription_value eq ${subscriptionId}`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.Subscription.ValidateIfLinkedSubscriptionPaymentMethodIsDirectDebit = async function (formContext) {
    'use strict';

    let linkedSubscriptionFieldValue = formContext.getAttribute("rhs_linkedsubscription")?.getValue();
    if (linkedSubscriptionFieldValue) {
        let linkedSubscription = await Xrm.WebApi.retrieveRecord(
            "rhs_subscription",
            linkedSubscriptionFieldValue[0].id,
            "?$select=rhs_paymentmethodcode"
        );
        if (linkedSubscription.rhs_paymentmethodcode == null) {
            console.log("Linked subscription payment method is null. Skipping validation.");
            return false;
        }
        if (linkedSubscription.rhs_paymentmethodcode == 120000002 /* DirectDebit */) {
            return true;
        }
    } else {
        console.log("No linked subscription selected. Skipping validation.");
    }
    return false;
};

RHSScripts.Subscription.CheckIfSubscriptionWasChangedFromLastTransaction = async function (formContext, transaction) {
    let product = formContext.getAttribute("rhs_subscriptionproduct").getValue()?.[0];
    let productId = product ? product.id.replace("{", "").replace("}", "").toLowerCase() : null;
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
    let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
    let amount = outstandingAmount ? outstandingAmount : totalAmount;

    let isSubscriptionChanged = false;
    if (transaction)
        isSubscriptionChanged = productId != transaction._rhs_product_value || paymentMethod != transaction.rhs_paymentmethodcode || amount != transaction.rhs_amount;

    return isSubscriptionChanged;
}

RHSScripts.Subscription.CancelTransactionAndAssociatedRecords = async function (transaction) {
    let transactionId = transaction.rhs_transactionid;

    //Cancel Payments
    let payments = (await Xrm.WebApi.retrieveMultipleRecords("rhs_payment", `?$select=rhs_paymentid,_rhs_transaction_value&$filter=_rhs_transaction_value eq ${transactionId}`)).entities;
    for (let ctr = 0; ctr < payments.length; ctr++) {
        await Xrm.WebApi.updateRecord("rhs_payment", payments[ctr].rhs_paymentid, { statecode: 1/*Inactive*/, statuscode: 120000004/*Cancelled*/ });
    }

    //Cancel Payment Schedule
    let paymentScheduleId = transaction._rhs_paymentscheduletransaction_value;
    if (paymentScheduleId) {
        await Xrm.WebApi.updateRecord("rhs_paymentschedule", paymentScheduleId, { statecode: 1/*Inactive*/, statuscode: 120000003/*Cancelled*/ });
    }

    //Cancel Transaction
    await Xrm.WebApi.updateRecord("rhs_transaction", transactionId, { statecode: 1/*Inactive*/, statuscode: 2/*Cancelled*/ });
}

RHSScripts.Subscription.MakeCirrusPCIpaymentURL = async function (subscriptionId, payerReference, totalAmount, isRenewal) {
    //Get Current User
    let userSettings = Xrm.Utility.getGlobalContext().userSettings;
    let currentUserId = userSettings.userId.replace("{", "").replace("}", "");
    let cirrusUserValue = await Xrm.WebApi.retrieveRecord("systemuser", currentUserId, "?$select=rhs_cirrususer");

    if (cirrusUserValue.rhs_cirrususer == undefined || cirrusUserValue.rhs_cirrususer == null) {
        await Xrm.Navigation.openAlertDialog({ title: "Failed", text: "The Cirrus User value on the User form cannot be empty. Please supply a value to be used to take payments via Cirrus." });
        throw Error("Cirrus User value is null. Please provide a username to continue.");
    }

    // Redirect to checkout url
    let cirrusFunctionUrl = await RHSScripts.Subscription.RetrieveAppSettingValueByName("CirrusKeyVaultURL");
    if (cirrusFunctionUrl == undefined || cirrusFunctionUrl == null)
        throw Error("cirrusFunctionUrl app setting not set for this environment. Please contact an administrator to fix this.");
    let finalURL = await RHSScripts.Subscription.ExecuteRetrieveCirrusPaymentURL(cirrusFunctionUrl, subscriptionId, payerReference, totalAmount, cirrusUserValue.rhs_cirrususer);

    //Xrm.Navigation.openUrl(finalURL);

    console.log("rhs_cirruspcipayment?url=" + finalURL);

    // Immediately show an informational alert on top
    var alertStrings = {
        text: "Please close the Cirrus dialog once payment is completed.",
        title: "Information"
    };
    var alertOptions = { height: 120, width: 260 };

    await Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

    var pageInput = {
        pageType: "webresource",
        webresourceName: "rhs_cirruspcipayment?url=" + finalURL
    };
    var navigationOptions = {
        target: 2,
        width: 700, // value specified in pixel
        height: 800, // value specified in pixel
        position: 1,
        title: "Cirrus PCI Payment"
    };

    await Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function (returnValue) {
                // This function is executed when the dialog is closed
                console.log("Dialog closed. Return value:", returnValue);

            },
            function (error) {
                // This function is executed if the operation fails
                console.error(error);
            }
        );

    if (isRenewal) {
        let newTransaction = await RHSScripts.Subscription.RetrievePaidSubscriptionTransaction(subscriptionId);
        if (newTransaction == null)
            throw Error("Cirrus Transaction Failed");
    }
    else {
        let intervalId = await RHSScripts.Subscription.RetrieveIsPaymentReceived(subscriptionId);
        if (!intervalId) {
            throw Error("Cirrus Transaction Failed");
        }
    }

    // Confirm PTX payment
    //let alertStrings = { title: "Cirrus PCI Payment", text: "Have you finished CIrrus PCI payment?", confirmButtonLabel: "Yes" };
    //await Xrm.Navigation.openAlertDialog(alertStrings);

}

RHSScripts.Subscription.flattenObject = function (obj, prefix = '') {
    let result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            Object.assign(result, RHSScripts.Subscription.flattenObject(obj[key], `${prefix}${key}.`));
        } else {
            result[`${prefix}${key}`] = obj[key];
        }
    }
    return result;
}

RHSScripts.Subscription.ExecuteRetrieveCirrusPaymentURL = async function (functionUrlName, subscriptionId, payer, totalAmount, CirrusUsername) {
    // Parameters
    var parameters = {};
    parameters.CirrusKeyVaultUrl = functionUrlName; // Edm.String
    parameters.EntityRecord = subscriptionId; // Edm.Guid
    parameters.PayerRecord = payer.id; // Edm.Guid
    parameters.PayerEntity = payer.entityType; // Edm.String
    parameters.TotalAmount = totalAmount; // Edm.Decimal
    parameters.TransactionType = 120000003; // Subscription
    parameters.CirrusUsername = CirrusUsername;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_cirruspaymenturl_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);
        // Return Type: mscrm.rhs_cirruspaymenturlResponse
        // Output Parameters
        let cirruspaymenturl = result["CirrusPaymentURL"]; // Edm.String

        return cirruspaymenturl;
    }).catch(function (error) {
        console.log(error.message);
    });
}

RHSScripts.Subscription.RetrieveIsPaymentReceived = async function (subscriptionId) {
    //let recordId = formContext.data.entity.getId().replace("{", "").replace("}", "");
    let result = await Xrm.WebApi.retrieveRecord("rhs_subscription", subscriptionId, "?$select=statuscode,rhs_ispaymentreceived");
    if (result.statuscode == 1 /*Active */ && result.rhs_ispaymentreceived) {
        return true;
    }
    return false;
}
//#endregion