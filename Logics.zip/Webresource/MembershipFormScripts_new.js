if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Membership) === "undefined") { RHSScripts.Membership = {}; }

//#region Event Functions
RHSScripts.Membership.OnLoad = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();


    await RHSScripts.Membership.HideShowPaymentMethod(executionContext);
    await RHSScripts.Membership.FilterChannelOptions(executionContext);
    await RHSScripts.Membership.FilterPaymentMethods(executionContext);
    await RHSScripts.Membership.ShowOrHideRenewalSections(executionContext); // need to run after FilterPaymentMethods syncronous run
    await RHSScripts.Membership.HideShowGiftAidFields(executionContext);
    RHSScripts.Membership.ShowDonationCampaign(executionContext);
    await RHSScripts.Membership.setMagazineDeliveryContact(executionContext);
    //await RHSScripts.Membership.HideCardDetailsSecondaryMember(executionContext);
    await RHSScripts.Membership.ShowFormNotificationForPatronMembership(executionContext);
}

RHSScripts.Membership.OnSave = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    await RHSScripts.Membership.CheckStatusCodeOnSave(executionContext);
    await RHSScripts.Membership.FilterPaymentMethods(executionContext);
    // await RHSScripts.Membership.CalculateRenewalPayoutDate(executionContext); // Moved to MembershipUpdatePreOpsPlugin because it's not reflecting onSave.
    await RHSScripts.Membership.NotifyToPayOutstandingAmount(executionContext);
    await RHSScripts.Membership.setMagazineDeliveryContact(executionContext);
    await RHSScripts.Membership.NotifyCancellationAtEndDate(executionContext);
    await RHSScripts.Membership.ShowFormNotificationForPatronMembership(executionContext);
}

RHSScripts.Membership.ShowDonationCampaign = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    var formType = formContext.ui.getFormType();

    if (formType != 1) {
        var membershipProduct = formContext.getAttribute("rhs_membershipproductid").getValue();
        var campaignDonation = formContext.getAttribute("rhs_campaigndonation").getValue();

        //check if campaign donation has value and product is patron
        if (membershipProduct != null) {
            var productName = (membershipProduct[0].name).toLowerCase();
            var campaignDonationControl = formContext.getControl("rhs_campaigndonation");

            if (productName.includes("patron") && campaignDonation != null) {
                campaignDonationControl.setVisible(true);
                campaignDonationControl.setDisabled(true);
            }
        }
    }
}

RHSScripts.Membership.OnInRenewalStageChange = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    await RHSScripts.Membership.ShowOrHideRenewalSections(executionContext);
}

RHSScripts.Membership.PrimaryMemberOnchangeMethod = async function (executionContext) {
    RHSScripts.Membership.onChangePrimaryMember(executionContext);
    RHSScripts.Membership.SetPayer(executionContext);
}

RHSScripts.Membership.OnActivationCodeChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    let activationCodeLogicalName = "rhs_activationcode";
    let activationCodeValue = formContext.getAttribute(activationCodeLogicalName).getValue();

    if (activationCodeValue != null && activationCodeValue != "") {
        let membershipGIftPack = await RHSScripts.Membership.RetrieveGiftPackUsingActivationCode(activationCodeValue);

        if (await RHSScripts.Membership.ValidateGiftPackActivationCode(membershipGIftPack, formContext)) {
            let giftPackMembershipProduct = await RHSScripts.Membership.RetrieveGiftPackMembershipProduct(membershipGIftPack["_rhs_product_value"]);
            await RHSScripts.Membership.SetMembershipUsingGiftPack(formContext, membershipGIftPack, giftPackMembershipProduct);
        } else {
            formContext.getAttribute(activationCodeLogicalName).setValue(null);
        }
    } else {
        await RHSScripts.Membership.ResetMembership(formContext);
    }
}

RHSScripts.Membership.OnMembershipProductChange = async function (executionContext) {
    await RHSScripts.Membership.FilterPaymentMethods(executionContext);
    //await RHSScripts.Membership.HideCardDetailsSecondaryMember(executionContext);
}

RHSScripts.Membership.OnRenewalsMembershipProductChange = async function (executionContext) {
    await RHSScripts.Membership.FilterRenewalPaymentMethods(executionContext);
}

RHSScripts.Membership.OnChannelChange = async function (executionContext) {
    await RHSScripts.Membership.FilterPaymentMethods(executionContext);
}

RHSScripts.Membership.RemovePayer = function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();
    let primaryMember = formContext.getAttribute("rhs_contact").getValue();
    let payer = formContext.getAttribute("rhs_payerv2").getValue();
    let isForSomeoneElse = formContext.getAttribute("rhs_ismembershipforsomeone").getValue();

    if (isForSomeoneElse && payer != null) {
        formContext.getAttribute("rhs_payerv2").setValue(null);
    }
}

RHSScripts.Membership.ShowOrHideStudentDetails = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    var membershipProductLookup = formContext.getAttribute("rhs_membershipproductid").getValue();
    var tab = formContext.ui.tabs.get("Summary");
    var section = tab.sections.get("Summary_section_6");
    if (membershipProductLookup) {
        if (membershipProductLookup[0].name && membershipProductLookup[0].name.toLowerCase().includes("student")) {
            section.setVisible(true);
        }
        else {
            section.setVisible(false);
        }
    }
    else {
        section.setVisible(false);
    }
}

RHSScripts.Membership.OnRenewalGiftPackActivationCodeChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    let renewalGiftPackActivationCodeLogicalName = "rhs_renewalgiftpackactivationcode";
    let renewalGiftPackActivationCodeValue = formContext.getAttribute(renewalGiftPackActivationCodeLogicalName).getValue();

    let renewalMembershipProductName = "rhs_renewalsmembershipproduct";
    let renewalMembershipProducValue = formContext.getAttribute(renewalMembershipProductName).getValue();
    let renewalMembershipProduct = renewalMembershipProducValue[0];

    if (renewalGiftPackActivationCodeValue != null && renewalGiftPackActivationCodeValue != "") {
        let membershipGiftPack = await RHSScripts.Membership.RetrieveGiftPackUsingActivationCode(renewalGiftPackActivationCodeValue, renewalMembershipProducValue);

        if (await RHSScripts.Membership.ValidateGiftPackActivationCode(membershipGiftPack, formContext) &&
            await RHSScripts.Membership.ValidateGiftPackActivationCodeWithMembershipProduct(membershipGiftPack, renewalMembershipProduct, formContext)) {
            await RHSScripts.Membership.SetRenewalMembershipUsingGiftPack(formContext);
        } else {
            formContext.getAttribute(renewalGiftPackActivationCodeLogicalName).setValue(null);
        }
    }
}

RHSScripts.Membership.IsReferredOnChange = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    var isReferred = formContext.getAttribute("rhs_isreferredbyexistingmember").getValue();

    if (isReferred) {
        RHSScripts.Membership.FilterReferralMemberLookup(executionContext);
    }
}

RHSScripts.Membership.OutstandingAmountOnChange = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    RHSScripts.Membership.NotifyToPayOutstandingAmount(executionContext);
}

RHSScripts.Membership.OnSecondaryMemberChange = async function (executionContext) {
    //await RHSScripts.Membership.SetCardDetailsSecondaryMember(executionContext);
}

//#endregion

//#region Helper Functions
RHSScripts.Membership.HideShowPaymentMethod = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();

    var linkedMembership = formContext.getAttribute("rhs_linkedmembership").getValue();
    if (linkedMembership) {
        var linkedMembershipId = linkedMembership[0].id.replace("{", "").replace("}", "");;

        var statuscode = await RHSScripts.Membership.RetrieveStatusOfOldMembership(linkedMembershipId);

        if (statuscode === 120000011) {
            var paymentMethodControl = formContext.getControl("rhs_paymentmethod");
            var paymentMethodOnBPFControl = formContext.getControl("header_process_rhs_paymentmethod");

            if (paymentMethodControl) {
                paymentMethodControl.setDisabled(true);
            }

            if (paymentMethodOnBPFControl) {
                paymentMethodOnBPFControl.setDisabled(true);
            }

            formContext.data.process.addOnStageChange(function () {
                paymentMethodControl.setDisabled(true);
                paymentMethodOnBPFControl.setDisabled(true);
            });
        }
    }
}

RHSScripts.Membership.RetrieveStatusOfOldMembership = async function (linkedMembershipId) {
    'use strict';
    var data;
    await Xrm.WebApi.retrieveRecord("rhs_membership", linkedMembershipId, "?$select=statuscode").then(
        function success(result) {
            data = result["statuscode"];
        },
        function (error) {
        }
    );
    return data;
}

RHSScripts.Membership.onChangePrimaryMember = function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();
    let isVisible = formContext.getControl("rhs_activationcode").getVisible();
    let payer = formContext.getAttribute("rhs_payerv2").getValue();

    if (isVisible) {
        if (payer !== null) {
            formContext.getAttribute("rhs_payerv2").setValue(null);
        }
    }
}

RHSScripts.Membership.SetPayer = function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();
    let primaryMember = formContext.getAttribute("rhs_contact").getValue();
    let payer = formContext.getAttribute("rhs_payerv2").getValue();

    let primaryMemberLookup = [];
    if (primaryMember) {
        primaryMemberLookup[0] = {};
        primaryMemberLookup[0].id = primaryMember[0].id;
        primaryMemberLookup[0].name = primaryMember[0].name;
        primaryMemberLookup[0].entityType = primaryMember[0].entityType;
    }

    if (payer == null && primaryMember != null) {
        formContext.getAttribute("rhs_payerv2").setValue(primaryMemberLookup);
    }
}

RHSScripts.Membership.ValidateIfEarlyRenewal = function (formContext) {
    let renewalsStartDate = formContext.getAttribute("rhs_renewalsstartdate").getValue();

    let isEarlyRenewal = renewalsStartDate && new Date() < renewalsStartDate;
    return isEarlyRenewal;
}

RHSScripts.Membership.ShowOrHideRenewalSections = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    var isInRenewalStage = formContext.getAttribute("rhs_inrenewalsstage").getValue();
    console.log("isInRenewalStage:", isInRenewalStage);

    if (isInRenewalStage === true) {
        formContext.ui.tabs.get("Summary").sections.get("Summary_section_9").setVisible(true);
        formContext.ui.tabs.get("Summary").sections.get("Summary_section_10").setVisible(true);
        formContext.getAttribute("rhs_renewalspaymentmethod").setRequiredLevel("required");

        let renewalPaymentMethod = formContext.getAttribute("rhs_renewalspaymentmethod").getValue();
        if (renewalPaymentMethod != 844060005/*Gift Pack*/) {
            // Will now allow renewal campain to be setup per bug #83318 requirement
            // if (RHSScripts.Membership.ValidateIfEarlyRenewal(formContext)) {
            //     formContext.getControl("rhs_renewalscampaign").setVisible(false);
            // }

            await RHSScripts.Membership.FilterRenewalPaymentMethods(executionContext);
        } else {
            formContext.getControl("rhs_renewalscampaign").setVisible(false);
            formContext.getAttribute("rhs_renewalscampaign").setValue(null);
            formContext.getAttribute("rhs_redeemrenewalgiftpack").setValue(true);
            formContext.getControl("rhs_renewalgiftpackactivationcode").setVisible(true);
            formContext.getAttribute("rhs_renewalgiftpackactivationcode").setRequiredLevel("required");
            formContext.getControl("rhs_renewalspaymentmethod").setVisible(false);
            formContext.getAttribute("rhs_renewalspaymentmethod").setValue(844060005/*Gift Pack*/);
            // formContext.getControl("rhs_renewalstotalamount").setVisible(false);
            formContext.getAttribute("rhs_renewalstotalamount").setValue(0);
        }

        let isWelcomeBackEmailSent = formContext.getAttribute("rhs_welcomebackemailsent").getValue();
        if (isWelcomeBackEmailSent == 120000001/*No*/) {
            formContext.getControl("rhs_welcomebackpostallettersent").setVisible(true);
        } else {
            formContext.getControl("rhs_welcomebackpostallettersent").setVisible(false);
        }

    } else {
        //formContext.ui.tabs.get("Summary").sections.get("Summary_section_9").setVisible(false);
        formContext.ui.tabs.get("Summary").sections.get("Summary_section_10").setVisible(false);
        //Summary_section_9 fields
        RHSScripts.Membership.HideShowRenewalsCampaign(executionContext);
        formContext.getControl("rhs_renewalsmembershipproduct").setVisible(false);
        formContext.getControl("rhs_renewalspayer").setVisible(false);
        formContext.getControl("rhs_renewalsstatus").setVisible(false);

        formContext.getAttribute("rhs_renewalsmembershipproduct").setValue(null);
        formContext.getAttribute("rhs_renewalspayer").setValue(null);
        formContext.getAttribute("rhs_renewalsstatus").setValue(null);

        //Summary_section_10 fields
        formContext.getAttribute("rhs_renewalspricelist").setValue(null);
        formContext.getAttribute("rhs_renewalsmembershipprice").setValue(null);
        formContext.getAttribute("rhs_renewalstotalamount").setValue(null);
        formContext.getAttribute("rhs_renewalspaymentmethod").setValue(null);
        formContext.getAttribute("rhs_isrenewalcontinuouspayment").setValue(false);
        formContext.getAttribute("rhs_renewalpaymentfrequency").setValue(null);
        formContext.getAttribute("rhs_renewalpaymentschedule").setValue(null);
        formContext.getAttribute("rhs_isrenewaldddiscountavailed").setValue(false);
    }
}

RHSScripts.Membership.HideShowGiftAidFields = async function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();
    let isForSomeoneElse = formContext.getAttribute("rhs_ismembershipforsomeone").getValue();
    let product = formContext.getAttribute("rhs_membershipproductid").getValue();
    let payer = formContext.getAttribute("rhs_payerv2").getValue();
    let payerId = payer ? payer[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productId = product ? product[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let hasGiftAidForMembership = await RHSScripts.Membership.GetGiftAidsByMembership(membershipId);
    if (hasGiftAidForMembership) {
        formContext.getControl("rhs_isregistrationforgiftaid").setVisible(false);
        return;
    }

    if (isForSomeoneElse == false && payerId && productId) {

        let hasGiftAid = await RHSScripts.Membership.GetGiftAidsByContact(payerId);
        let isProductEligible = await RHSScripts.Membership.IsProductGiftAidEligible(productId);
        let giftPackCode = formContext.getAttribute("rhs_activationcode").getValue();

        if (!hasGiftAid && isProductEligible && giftPackCode == null) {
            formContext.getControl("rhs_isregistrationforgiftaid").setVisible(true);
        } else {
            formContext.getControl("rhs_isregistrationforgiftaid").setVisible(false);
        }
    } else {
        formContext.getControl("rhs_isregistrationforgiftaid").setVisible(false);
    }
}


RHSScripts.Membership.GetGiftAidsByContact = async function (payerId) {
    'use strict';

    try {
        let result = await Xrm.WebApi.retrieveMultipleRecords("rhs_giftaiddeclaration", `?$filter=(_rhs_customerid_value eq ${payerId} and statecode eq 0)&$select=rhs_giftaiddeclarationstatus`);
        let hasValidGiftAid = result.entities.some(
            entity => entity.rhs_giftaiddeclarationstatus === 120000001
        );
        return hasValidGiftAid;
    } catch {
        return false;
    }
}

RHSScripts.Membership.GetGiftAidsByMembership = async function (membershipId) {
    'use strict';

    try {
        let result = await Xrm.WebApi.retrieveMultipleRecords("rhs_giftaiddeclaration", `?$filter=_rhs_membership_value eq ${membershipId} and statecode eq 0`
        );

        return result.entities && result.entities.length > 0;
    } catch {
        return false;
    }
}


RHSScripts.Membership.IsProductGiftAidEligible = async function (productId) {
    'use strict';

    try {
        console.log("ProductId:", productId);
        if (!productId) return false;

        let fetchXml = [
            `<fetch top="1">`,
            `  <entity name="dynamicproperty">`,
            `    <attribute name="dynamicpropertyid" />`,
            `    <attribute name="defaultvalueoptionset" />`,
            `    <filter>`,
            `      <condition attribute="name" operator="eq" value="Gift Aid Eligible" />`,
            `    </filter>`,
            `    <link-entity name="dynamicpropertyassociation" from="dynamicpropertyid" to="dynamicpropertyid" alias="assoc" intersect="true">`,
            `      <filter>`,
            `        <condition attribute="regardingobjectid" operator="eq" value="${productId}" />`,
            `        <condition attribute="associationstatus" operator="eq" value="0" />`,
            `      </filter>`,
            `    </link-entity>`,
            `  </entity>`,
            `</fetch>`
        ].join("");
        console.log("FetchXML Query:", fetchXml);

        let result = await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", `?fetchXml=${encodeURIComponent(fetchXml)}`);
        console.log("Entities returned:", result.entities.length);

        if (result.entities.length === 0) return false;

        let entity = result.entities[0];

        let optionSetId = entity["_defaultvalueoptionset_value"];

        if (!optionSetId) return false;

        let optionSetItemResult = await Xrm.WebApi.retrieveRecord("dynamicpropertyoptionsetitem", optionSetId, "?$select=dynamicpropertyoptionname");

        let optionName = optionSetItemResult?.dynamicpropertyoptionname?.toLowerCase();

        return optionName === "yes";


    } catch (error) {
        return false;
    }
}

RHSScripts.Membership.RetrieveGiftPackUsingActivationCode = async function (activationCodeValue) {
    let giftPackLogicalName = "rhs_giftpack";
    let giftPackOptions = "".concat(
        "?$select=rhs_giftpackcode,statuscode,rhs_expiredate,rhs_ispaymentreceived,rhs_price,_rhs_product_value,_rhs_purchasedby_value,rhs_giftpackid",
        `&$filter=(rhs_giftpackcode eq '${activationCodeValue}')`,
        "&$top=1"
    )

    return await Xrm.WebApi.retrieveMultipleRecords(giftPackLogicalName, giftPackOptions).then(
        function success(result) {
            let giftPack = result.entities[0];
            return giftPack;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

RHSScripts.Membership.RetrieveGiftPackMembershipProduct = async function (giftPackProductBundleId) {
    let giftPackLogicalName = "product";
    let giftPackOptions = `?$select=name,productid&$expand=Product_ProductAssociation_AssocProd($filter=(_productid_value eq d4aec9ad-6c5a-ef11-bfe3-000d3a86fea3))&$filter=(productstructure eq 1 and hierarchypath eq 'Memberships+Product+Family') and (Product_ProductAssociation_AssocProd/any(o1:(o1/_productid_value eq ${giftPackProductBundleId})))`;

    return await Xrm.WebApi.retrieveMultipleRecords(giftPackLogicalName, giftPackOptions).then(
        function success(result) {
            let product = result.entities[0];
            return product;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

RHSScripts.Membership.ValidateGiftPackActivationCode = async function (membershipGIftPack, formContext) {
    if (membershipGIftPack != undefined && membershipGIftPack["statuscode"] == 120000003 &&
        (membershipGIftPack["rhs_expiredate"] == null || new Date(membershipGIftPack["rhs_expiredate"]) > new Date()) &&
        //membershipGIftPack["rhs_ispaymentreceived"] == true  
        membershipGIftPack["statuscode"] == 120000003
    ) {
        return true
    } else {
        Xrm.Navigation.openAlertDialog("Invalid Activation Code, please enter the correct one.");
        return false;
    }
}

RHSScripts.Membership.ValidateGiftPackActivationCodeWithMembershipProduct = async function (membershipGiftPack, membershipProduct, formContext) {
    let giftPackProductId = membershipGiftPack["_rhs_product_value"];
    let membershipProductId = membershipProduct.id.replace("{", "").replace("}", "").toLowerCase();

    let giftPackMembershipProduct = await RHSScripts.Membership.RetrieveGiftPackMembershipProduct(giftPackProductId);
    let giftPackMembershipProductId = giftPackMembershipProduct["productid"];

    if (giftPackMembershipProductId == membershipProductId) {
        return true
    } else {
        Xrm.Navigation.openAlertDialog("Invalid Activation Code, please enter the correct one.");
        return false;
    }
}

RHSScripts.Membership.SetMembershipUsingGiftPack = async function (formContext, membershipGIftPack, giftPackMembershipProduct) {
    let totalAmountLogicalName = "rhs_totalamount";
    let outstandingAmountLogicalName = "rhs_outstandingamount";
    let membershipProductLogicalName = "rhs_membershipproductid";
    let endDateLogicalName = "rhs_enddate";
    let paymentMethodLogicalName = "rhs_paymentmethod";
    let giftPack = "rhs_giftpack";

    let amountValue = 0;//membershipGIftPack.rhs_price;
    let membershipProductValue = [
        {
            "entityType": "product",
            "id": giftPackMembershipProduct["productid"],
            "name": giftPackMembershipProduct["name"]
        }
    ];

    let giftPackValue = [
        {
            id: membershipGIftPack["rhs_giftpackid"],
            entityType: "rhs_giftpack"
        }
    ];


    let paymentMethodValue = 844060005;
    formContext.getAttribute(totalAmountLogicalName).setValue(amountValue);
    formContext.getAttribute(outstandingAmountLogicalName).setValue(amountValue);
    formContext.getAttribute(membershipProductLogicalName).setValue(membershipProductValue);
    formContext.getAttribute(giftPack).setValue(giftPackValue);
    formContext.getAttribute(paymentMethodLogicalName).setValue(paymentMethodValue);

    // COMMENTED CODES BELOW BECAUSE DATE CALCULATION IS NOW BEING DONE IN PLUGIN
    // let product = formContext.getAttribute("rhs_membershipproductid").getValue();
    // if (!product) {
    //     console.error("Product not selected.");
    //     return;
    // }

    // let productId = product[0].id.replace("{", "").replace("}", "").toLowerCase();
    // let propertyEntityLogicalName = "dynamicproperty";
    // let propertyOptions = "".concat(
    //     `?$select=dynamicpropertyid,name,_defaultvalueoptionset_value`,
    //     `&$expand=Dynamicproperty_DynamicPropertyAssociation($filter=(_regardingobjectid_value eq ${productId} and associationstatus eq 0))`,
    //     `&$filter=(name eq 'Duration') and (Dynamicproperty_DynamicPropertyAssociation/any(o1:(o1/_regardingobjectid_value eq ${productId} and o1/associationstatus eq 0)))`,
    //     `&$top=1`
    // );

    // let durationProperty = (await Xrm.WebApi.retrieveMultipleRecords(propertyEntityLogicalName, propertyOptions)).entities[0];
    // if (!durationProperty) {
    //     console.error("Duration property not found.");
    //     return;
    // }

    // let defaultPropertyOptionSetEntityLogicalName = "dynamicpropertyoptionsetitem";
    // let defaultPropertyOptionSetId = durationProperty._defaultvalueoptionset_value;
    // let defaultPropertyOptionSetOptions = "?$select=dynamicpropertyoptionname,dynamicpropertyoptionvalue";
    // let durationDefaultPropertyOptionSetName = (await Xrm.WebApi.retrieveRecord(defaultPropertyOptionSetEntityLogicalName, defaultPropertyOptionSetId, defaultPropertyOptionSetOptions)).dynamicpropertyoptionname;

    // // Retrieve time-based campaign discount (if any)
    // let durationDiscount = null;
    // let campaign = formContext.getAttribute("rhs_campaignid").getValue();
    // if (campaign) {
    //     let campaignEntityLogicalName = "campaign";
    //     let campaignId = campaign[0].id.replace("{", "").replace("}", "").toLowerCase();
    //     let campaignOptions = "?$select=rhs_benefittype,rhs_durationbenefit";

    //     let potentialCampaignDiscount = await Xrm.WebApi.retrieveRecord(campaignEntityLogicalName, campaignId, campaignOptions);
    //     if (potentialCampaignDiscount.rhs_benefittype == 120000000 /* Time-Based */) {
    //         durationDiscount = potentialCampaignDiscount.rhs_durationbenefit;
    //     }
    // }
    // // Prepare start date and end date values
    // let now = new Date();
    // let paymentDate = now.getDate();

    // let startDate = new Date();
    // if (paymentDate >= 23 && paymentDate <= 31) {
    //     startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of next month
    // } else if (paymentDate === 1) {
    //     startDate = new Date(now.getFullYear(), now.getMonth(), 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of current month
    // } else if (paymentDate >= 2 && paymentDate <= 8) {
    //     startDate = new Date(now.getFullYear(), now.getMonth(), 8, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 8th of current month
    // } else if (paymentDate >= 9 && paymentDate <= 15) {
    //     startDate = new Date(now.getFullYear(), now.getMonth(), 15, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 15th of current month
    // } else if (paymentDate >= 16 && paymentDate <= 22) {
    //     startDate = new Date(now.getFullYear(), now.getMonth(), 22, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 22nd of current month
    // }

    // let endDate = new Date(startDate);
    // switch (durationDefaultPropertyOptionSetName) {
    //     case "3 Months":
    //         endDate.setMonth(endDate.getMonth() + 3);
    //         endDate.setDate(endDate.getDate() - 1);
    //         break;
    //     case "6 Months":
    //         endDate.setMonth(endDate.getMonth() + 6);
    //         endDate.setDate(endDate.getDate() - 1);
    //         break;
    //     case "1 Year":
    //         endDate.setFullYear(endDate.getFullYear() + 1);
    //         endDate.setDate(endDate.getDate() - 1);
    //         break;
    //     case "Lifetime":
    //         endDate = null;
    //         break;
    // }

    // if (durationDiscount) {
    //     endDate.setMonth(endDate.getMonth() + durationDiscount);
    // }

    // formContext.getAttribute("rhs_startdate").setValue(startDate);
    // formContext.getAttribute("rhs_newmembershippackmhstatus").setValue(120000001); //pending


    // let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    // if (paymentMethod && endDate) {
    //     formContext.getAttribute("rhs_enddate").setValue(endDate);
    //     let { dormancyValue, renewalValue } = await RHSScripts.Membership.RenewalRangeDates();
    //     console.log("dormancyValue:", dormancyValue);
    //     console.log("renewalValue:", renewalValue);
    //     if (dormancyValue !== null && renewalValue !== null) {
    //         // Calculate Renewal Start Date
    //         let renewalStartDate = new Date(endDate);
    //         let startOriginalDay = renewalStartDate.getDate();
    //         let startOriginalMonth = renewalStartDate.getMonth();
    //         let startOriginalYear = renewalStartDate.getFullYear();
    //         let startTargetMonth = startOriginalMonth - renewalValue;
    //         let startTargetYear = startOriginalYear;

    //         while (startTargetMonth < 0) {
    //             startTargetMonth += 12;
    //             startTargetYear -= 1;
    //         }

    //         let lastDayOfTargetMonth = new Date(startTargetYear, startTargetMonth + 1, 0).getDate();
    //         let newDay = Math.min(startOriginalDay, lastDayOfTargetMonth);

    //         let adjustedRenewalStartDate = new Date(startTargetYear, startTargetMonth, newDay);
    //         adjustedRenewalStartDate.setHours(0, 0, 0, 0);
    //         formContext.getAttribute("rhs_renewalsstartdate").setValue(adjustedRenewalStartDate);

    //         // renewalStartDate.setMonth(renewalStartDate.getMonth() - renewalValue);
    //         // formContext.getAttribute("rhs_renewalsstartdate").setValue(renewalStartDate);
    //         console.log("renewalStartDate:", renewalStartDate);

    //         // Calculate Renewal End Date
    //         let renewalEndDate = new Date(endDate);
    //         let endOriginalDay = renewalEndDate.getDate();
    //         let endOriginalMonth = renewalEndDate.getMonth();
    //         let endOriginalYear = renewalEndDate.getFullYear();

    //         let endTargetMonth = endOriginalMonth + dormancyValue;
    //         let endTargetYear = endOriginalYear;

    //         while (endTargetMonth > 11) {
    //             endTargetMonth -= 12;
    //             endTargetYear += 1;
    //         }

    //         let endLastDayOfTargetMonth = new Date(endTargetYear, endTargetMonth + 1, 0).getDate();
    //         let endNewDay = Math.min(endOriginalDay, endLastDayOfTargetMonth);
    //         let adjustedRenewalEndDate = new Date(endTargetYear, endTargetMonth, endNewDay);
    //         adjustedRenewalEndDate.setHours(12, 0, 0, 0);
    //         formContext.getAttribute("rhs_renewalsenddate").setValue(adjustedRenewalEndDate);
    //         formContext.getAttribute("rhs_cardexpirydate").setValue(endDate);

    //         // renewalEndDate.setMonth(renewalEndDate.getMonth() + dormancyValue);
    //         // formContext.getAttribute("rhs_renewalsenddate").setValue(renewalEndDate);
    //         // console.log("renewalEndDate:", renewalEndDate);
    //         // formContext.getAttribute("rhs_cardexpirydate").setValue(endDate);
    //     }

    // } else if (!endDate) {
    //     let cardExpiryDate = new Date(startDate);
    //     cardExpiryDate.setFullYear(cardExpiryDate.getFullYear() + 1);
    //     cardExpiryDate.setDate(cardExpiryDate.getDate() - 1);

    //     formContext.getAttribute("rhs_cardexpirydate").setValue(cardExpiryDate);
    //     formContext.getAttribute("rhs_enddate").setValue(null);
    // }
}

RHSScripts.Membership.SetRenewalMembershipUsingGiftPack = async function (formContext) {
    let totalAmountLogicalName = "rhs_renewalstotalamount";
    let paymentMethodLogicalName = "rhs_renewalspaymentmethod";

    let totalAmountValue = 0;
    let paymentMethodValue = 844060005/*Gift Pack*/;

    formContext.getAttribute(totalAmountLogicalName).setValue(totalAmountValue);
    formContext.getAttribute(paymentMethodLogicalName).setValue(paymentMethodValue);
}

RHSScripts.Membership.ResetMembership = async function (formContext) {
    let totalAmountLogicalName = "rhs_totalamount";
    let endDateLogicalName = "rhs_enddate";
    let paymentMethodLogicalName = "rhs_paymentmethod";

    formContext.getAttribute(totalAmountLogicalName).setValue(null);
    formContext.getAttribute(endDateLogicalName).setValue(null);
    formContext.getAttribute(paymentMethodLogicalName).setValue(null);
}




RHSScripts.Membership.FilterPaymentMethods = async function (executionContext) {
    try {
        let formContext = executionContext.getFormContext();
        let channel = formContext.getAttribute("rhs_channel")?.getValue();
        let paymentMethodControl = formContext.getControl("rhs_paymentmethod");
        let paymentMethodValue = formContext.getAttribute("rhs_paymentmethod").getValue();
        let statusReason = formContext.getAttribute("statuscode").getValue();
        let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
        let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();

        if (channel === 120000001 /* Phone */) {
            console.log("Filtering payment methods");

            // Retrieve product id
            let membershipProductId = formContext.getAttribute("rhs_membershipproductid").getValue();
            let activationCode = formContext.getAttribute("rhs_activationcode").getValue();

            if (!membershipProductId) {
                console.log("No Membership Product selected.");
                return;
            } else {
                console.log("Membership product on trigger value:" + membershipProductId[0].id.replace("{", "").replace("}", "").toLowerCase());
            }

            if (membershipProductId && formContext.getAttribute("rhs_redeemgiftpack").getValue() == true && activationCode) {
                var optionSetPaymentMethodValue = 844060005;
                formContext.getAttribute("rhs_paymentmethod").setValue(optionSetPaymentMethodValue);
                formContext.getAttribute("rhs_paymentreceived").setValue(true);
                return;
            }

            let membershipProductGuid = membershipProductId[0].id.replace("{", "").replace("}", "").toLowerCase();
            console.log("Retrieved product property:", membershipProductGuid);

            // Fetch allowed payments from property
            let allowedPaymentsPropertyValue = await RHSScripts.Membership.RetrieveProductProperty(membershipProductGuid);
            console.log("Allowed payment product property:", allowedPaymentsPropertyValue);

            let allowedPayments = [];
            if (typeof allowedPaymentsPropertyValue === "string") {
                allowedPayments = allowedPaymentsPropertyValue.split(";");
                console.log("Allowed payments from property:", allowedPayments);
            } else {
                console.warn("Invalid or missing allowedPaymentsPropertyValue:", allowedPaymentsPropertyValue);
                return;
            }

            // Only support DD and CARD
            let paymentMethodCodes = {
                DD: 120000002,      // Direct Debit
                //CARD: 844060002,     // Card
                CARD: 120000014,     // Credit Card (Phone)
                CASH: 844060000,      // Cash
                CHEQUE: 844060001     // Cheque
            };

            let allOptions = [
                { value: 120000002, text: "Direct Debit" },
                //{ value: 844060002, text: "Card" },
                { value: 120000014, text: "Credit Card (Phone)" },
                { value: 844060000, text: "Cash" },
                { value: 844060001, text: "Cheque" }

            ];

            let filteredOptions = allowedPayments.map((code) => {
                let optionValue = paymentMethodCodes[code];
                return allOptions.find(option => option.value === optionValue);
            }).filter(Boolean);

            paymentMethodControl.clearOptions();
            filteredOptions.forEach((option) => {
                paymentMethodControl.addOption(option);
            });

            //selectfirstoption if only one
            if (filteredOptions.length == 1) {
                formContext.getAttribute("rhs_paymentmethod").setValue(filteredOptions[0].value);
            }
        } else {
            console.log("Removing payment method filters.");

            let originalOptions = formContext.getAttribute("rhs_paymentmethod").getOptions();
            paymentMethodControl.clearOptions();
            originalOptions.forEach((option) => {
                paymentMethodControl.addOption(option);
            });
        }

        //Remove Card Payment Option
        paymentMethodControl.removeOption(844060002);

        // Return selected payment method if removed from filter
        if (paymentMethodValue && !paymentMethodControl.getOptions().find((option) => option.value == paymentMethodValue)) {
            if (statusReason == 1/*Active*/ || statusReason == 120000002/*Dormant*/) {
                paymentMethodControl.addOption(
                    formContext.getAttribute("rhs_paymentmethod").getOptions().find((option) => option.value == paymentMethodValue)
                )
            } else {
                formContext.getAttribute("rhs_paymentmethod").setValue(null);
            }
        }
        if (statusReason == 120000003/*Pending Payment*/ && outstandingAmount !== totalAmount) {
            console.log("Remove DD Payment Method.");
            paymentMethodControl.removeOption(120000002);
        }

        console.log("Payment Methods filtered successfully.");
    } catch (error) {
        console.log("Error in filtering Payment Methods:", error);
    }
}

RHSScripts.Membership.FilterRenewalPaymentMethods = async function (executionContext) {
    try {
        let formContext = executionContext.getFormContext();
        let channel = formContext.getAttribute("rhs_channel")?.getValue();
        let paymentMethodControl = formContext.getControl("rhs_renewalspaymentmethod");
        let paymentMethodValue = formContext.getAttribute("rhs_renewalspaymentmethod").getValue();
        let renewalStatus = formContext.getAttribute("rhs_renewalsstatus").getValue();
        let expiryDate = formContext.getAttribute("rhs_enddate").getValue();

        if (channel === 120000001/*Phone*/) {
            console.log("Filtering renewal payment methods");

            // Retrieve renewal product id
            let membershipProductId = formContext.getAttribute("rhs_renewalsmembershipproduct").getValue();
            let renewalGiftPackActivationCode = formContext.getAttribute("rhs_renewalgiftpackactivationcode").getValue();

            if (!membershipProductId) {
                console.log("No Membership Product selected.");
                return;
            }
            if (renewalGiftPackActivationCode) {
                let optionSetPaymentMethodValue = 844060005;
                formContext.getAttribute("rhs_renewalspaymentmethod").setValue(optionSetPaymentMethodValue);
                return;
            }

            let membershipProductGuid = membershipProductId[0].id.replace("{", "").replace("}", "");

            // Fetch allowed payments from property
            let allowedPaymentsPropertyValue = await RHSScripts.Membership.RetrieveProductProperty(membershipProductGuid);
            console.log("Allowed payment product property:", allowedPaymentsPropertyValue);
            // Added a timeout to give time to retrieve all allowed payments for a membership product
            setTimeout(() => {
                if (allowedPaymentsPropertyValue === null) {
                    console.log("No Allowed Payments found for the selected Product.");
                    return;
                }

                let allowedPayments = [];
                if (typeof allowedPaymentsPropertyValue === "string") {
                    allowedPayments = allowedPaymentsPropertyValue.split(";");
                    console.log("Allowed payments from property:", allowedPayments);
                } else {
                    console.warn("Invalid or missing allowedPaymentsPropertyValue:", allowedPaymentsPropertyValue);
                    return;
                }

                // Filter phone channel payments
                let phoneChannelPayments = ["CARD", "DD"];
                allowedPayments = allowedPayments.filter(payment => phoneChannelPayments.includes(payment));

                // Filter the options based on the allowed payments
                let allOptions = [
                    { value: 120000002, text: "Direct Debit" },
                    //{ value: 844060002, text: "Card" },
                    { value: 120000014, text: "Credit Card (Phone)" },
                    { value: 844060000, text: "Cash" },
                    { value: 844060001, text: "Cheque" }
                ];

                let paymentMethodCodes = {
                    DD: 120000002,        // Direct Debit
                    //CARD: 844060002,        // CARD
                    CARD: 120000014,        // CARD
                    CASH: 844060000,      // Cash
                    CHEQUE: 844060001     // Cheque
                };

                let filteredOptions = allowedPayments.map((payment) => {
                    let optionValue = paymentMethodCodes[payment];
                    return allOptions.find(option => option.value === optionValue);
                }).filter(Boolean); // Remove undefined/null values if any

                // If early renewal
                if (paymentMethodValue != 844060005/*Gift Pack*/ && RHSScripts.Membership.ValidateIfEarlyRenewal(formContext)) {
                    filteredOptions = filteredOptions.filter(option =>
                        //option.value == 844060000/*Cash*/ || 
                        option.value == 120000014/*Credit Card*/ //|| 
                        //option.value == 844060002/*Card*/
                    );
                }

                // Set Renewal Payment Method choices
                paymentMethodControl.clearOptions();

                filteredOptions.forEach((option) => {
                    paymentMethodControl.addOption(option);
                })

                // Force Renewals Payment Method optionset field to refresh
                paymentMethodControl.setFocus();

                // Added a timeout to give time to load filtered payments on the Renewals Payment Method optionset field
                setTimeout(() => {
                    formContext.ui.controls.get("rhs_renewalspaymentmethod").setFocus(false);
                }, 50);
            }, 3000);
        } else {
            console.log("Removing renewal payment method filters.");

            // Added a timeout to give time to load original payment options on the optionset field
            setTimeout(() => {
                let originalOptions = formContext.getAttribute("rhs_renewalspaymentmethod").getOptions();
                paymentMethodControl.clearOptions();
                originalOptions.forEach((option) => {
                    paymentMethodControl.addOption(option);
                });

                // Force Renewals Payment Method optionset field to refresh
                paymentMethodControl.setFocus();

                formContext.ui.controls.get("rhs_renewalspaymentmethod").setFocus(false);
            }, 50);
        }

        // Return selected payment method if removed from filter
        if (paymentMethodValue && !paymentMethodControl.getOptions().find((option) => option.value == paymentMethodValue)) {
            if (renewalStatus == 120000001/*Renewed*/) {
                paymentMethodControl.addOption(
                    formContext.getAttribute("rhs_renewalspaymentmethod").getOptions().find((option) => option.value == paymentMethodValue)
                )
            } else {
                formContext.getAttribute("rhs_renewalspaymentmethod").setValue(null);
            }
        }

        console.log("Renewal Payment Methods filtered successfully.");
    } catch (error) {
        console.log("Error in filtering Renewal Payment Methods:", error);
    }
}

RHSScripts.Membership.RetrieveProductProperty = async function (productId) {
    'use strict';
    let allowedPayments = null;

    let fetchData = {
        "name": "Allowed Payments",
        "productid": productId
    };
    console.log("name: ", fetchData.name);
    console.log("productid: ", fetchData.productid);
    console.log("Starting fetch xml ");
    let fetchXml = [
        "<fetch returntotalrecordcount='true'>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='dynamicpropertyid'/>",
        "    <attribute name='defaultvaluestring'/>",
        "    <attribute name='name'/>",
        "    <filter type='and'>",
        "      <condition attribute='name' operator='eq' value='", fetchData.name, "'/>",
        "    </filter>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='aa'>",
        "      <filter>",
        "        <condition attribute='associationstatus' operator='eq' value='0' />",
        "      </filter>",
        "      <link-entity name='product' from='productid' to='regardingobjectid' alias='ab'>",
        "        <filter>",
        "          <condition attribute='productid' operator='eq' value='", fetchData.productid, "'/>",
        "        </filter>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");
    console.log("fetch xml End");
    // Execute the FetchXML query using the Web API
    await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + encodeURIComponent(fetchXml))
        .then(function (result) {
            console.log("fetch xml End: " + result);
            if (result.entities.length > 0) {
                let dynamicProperty = result.entities[0];

                allowedPayments = dynamicProperty.defaultvaluestring;
                console.log("Allowed Payments: ", allowedPayments);

            } else {
                console.warn("No dynamic property found.");
            }
        })
        .catch(function (error) {
            console.error("Error retrieving dynamic property:", error.message);
        });

    return allowedPayments;
    console.log("Retrieval end");
}


RHSScripts.Membership.FilterChannelOptions = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    // Get the 'Channel' field (rhs_channel)
    let channelField = formContext.getControl("rhs_channel");

    // List of option values that you want to keep (Online, FoH, Phone, Post, Third Party)
    let keepOptions = [120000006, 120000000, 120000001, 120000002, 120000004];

    // Get all current options in the global option set
    let options = channelField.getAttribute().getOptions();

    // Loop through the options and remove the ones that are not in the keepOptions array
    options.forEach(function (option) {
        if (keepOptions.indexOf(option.value) === -1) {
            channelField.removeOption(option.value);
        }
    });
}

const PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID = "PayOutstandingAmountNotification";
RHSScripts.Membership.NotifyToPayOutstandingAmount = function (formExecutionContext) {
    let formContext = formExecutionContext.getFormContext();
    let createdon = formContext.getAttribute("createdon").getValue();

    if (createdon != null) {
        let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
        let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
        let payer = formContext.getAttribute("rhs_payerv2").getValue();

        if (paymentMethod != 844060005/*Gift Pack*/ && outstandingAmount != null && outstandingAmount > 0 && payer != null) {
            formContext.ui.clearFormNotification(PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Please pay for the remaining outstanding amount.", "INFO", PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID);
        } else {
            formContext.ui.clearFormNotification(PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID);
        }
    }
}

RHSScripts.Membership.CheckStatusCodeOnSave = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    let statusCode = formContext.getAttribute("statuscode").getValue();

    // Check if the status code is 120000008 or 2
    if (statusCode === 120000008 || statusCode === 2) {
        // Display an alert dialog to the user
        formContext.ui.setFormNotification("Cancellation is Successful", "INFO", "cancellationSuccess");
    } else {
        // Clear the notification if the status code is changed to a different value
        formContext.ui.clearFormNotification("cancellationSuccess");
    }
}

RHSScripts.Membership.RenewalRangeDates = async function () {
    let dormancyPeriod = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'DormancyPeriodDuration'"
    );

    let renewalPeriod = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'RenewalPeriodDuration'"
    );

    let dormancyValue = dormancyPeriod.entities.length > 0 ? Number(dormancyPeriod.entities[0].rhs_value) : 0;
    let renewalValue = renewalPeriod.entities.length > 0 ? Number(renewalPeriod.entities[0].rhs_value) : 0;

    return { dormancyValue, renewalValue };
}

/* Moved to MembershipUpdatePreOpsPlugin because it's not reflecting onSave.
RHSScripts.Membership.CalculateRenewalPayoutDate = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    // Verify if fields exist on the form
    if (!formContext.getAttribute("rhs_renewalspaymentmethod") || !formContext.getAttribute("rhs_renewalpaymentschedule")) {
        console.error("Error: Required fields (rhs_renewalspaymentmethod or rhs_renewalpaymentschedule) are missing from the form.");
        return;
    }

    var paymentMethodField = formContext.getAttribute("rhs_paymentmethod");
    var renewalPaymentMethodField = formContext.getAttribute("rhs_renewalspaymentmethod");
    var renewalPayoutDateField = formContext.getAttribute("rhs_renewalpaymentschedule");
    var endDateField = formContext.getAttribute("rhs_enddate");

    // Get Payment Method value (OptionSet)
    var renewalPaymentMethod = renewalPaymentMethodField.getValue();
    var paymentMethod = paymentMethodField.getValue();

    // Only populate if Payment Method is Direct Debit (120000002)
    if (renewalPaymentMethod === 120000002) {
        var endDate = endDateField.getValue();
        var now = new Date();
        //  var nextPayoutDate = endDate > now ? new Date(endDate) : new Date(now);
        var nextPayoutDate = (endDate && endDate > now) ? new Date(endDate) : new Date(now);
        nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
        console.log("Initial Start Date: " + nextPayoutDate.toISOString());

        if (paymentMethod != renewalPaymentMethod) {
            var workingDaysAdded = 0;

            // Loop until 10 working days
            while (workingDaysAdded < 10) {
                nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
                var dayOfWeek = nextPayoutDate.getDay();

                // Skip weekends
                if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                    let isHoliday = await RHSScripts.Membership.HasHolidays(nextPayoutDate);
                    if (!isHoliday) {
                        workingDaysAdded++;
                    }
                }
            }
        }

        // Final payout date
        console.log("Final calculated Payout Date: " + nextPayoutDate);
        renewalPayoutDateField.setSubmitMode("always");
        renewalPayoutDateField.setValue(nextPayoutDate);
    }
}
*/

RHSScripts.Membership.FilterReferralMemberLookup = function (executionContext) {
    var formContext = executionContext.getFormContext();

    var viewId = "{00000000-0000-0000-0000-000000F00001}";
    var viewDisplayName = "Active Membership Contact";
    var entityName = "contact";
    var fetchXml = [
        "<fetch>",
        "  <entity name='contact'>",
        "    <attribute name='fullname'/>",
        "    <attribute name='rhs_constituentnumber'/>",
        "    <attribute name='address1_postalcode'/>",
        "    <attribute name='address1_country'/>",
        "    <filter type='and'>",
        "      <condition attribute='statecode' operator='eq' value='0'/>",
        "    </filter>",
        "    <filter type='or'>",
        "      <link-entity name='rhs_membership' from='rhs_contact' to='contactid' link-type='any' alias='primary'>",
        "        <filter>",
        "          <condition attribute='statecode' operator='eq' value='0'/>",
        "          <condition attribute='statuscode' operator='eq' value='1'/>",
        "        </filter>",
        "      </link-entity>",
        "      <link-entity name='rhs_membership' from='rhs_member2' to='contactid' link-type='any' alias='secondary'>",
        "        <filter>",
        "          <condition attribute='statecode' operator='eq' value='0'/>",
        "          <condition attribute='statuscode' operator='eq' value='1'/>",
        "        </filter>",
        "      </link-entity>",
        "    </filter>",
        "    <order attribute='fullname'/>",
        "  </entity>",
        "</fetch>"
    ].join("");

    const layoutXml = [
        '<grid name="resultset" object="2" jump="fullname" select="1" icon="1" preview="1">',
        '<row name="result" id="contactid">',
        '<cell name="fullname" width="100"/>',
        '<cell name ="rhs_constituentnumber" width ="100"/>',
        '<cell name ="address1_postalcode" width="100"/>',
        '<cell name ="address1_country" width="100"/>',
        '</row>',
        '</grid>',
    ].join("");

    formContext.getAttribute("rhs_referralmemberid").controls.forEach(c => {
        c.addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);
        c.setDefaultView(viewId);
    });
}
RHSScripts.Membership.onChangeRegisterForGiftAid = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    let isRegisterForGiftAid = formContext.getAttribute("rhs_isregistrationforgiftaid").getValue();
    if (isRegisterForGiftAid == true) {
        let text =
            await Xrm.Navigation.openAlertDialog({ text: "To create a new Gift Aid Declaration for the Payer, please use the Add Gift Aid button in the ribbon. Here, you will also be able to view any existing declarations for this Contact." });
    }
}

RHSScripts.Membership.HasHolidays = async function (nextPayoutDate) {
    nextPayoutDate.setHours(0, 0, 0, 0);
    let nextPayoutDateString = nextPayoutDate.toISOString().split("T")[0];

    let entityLogicalName = "calendar";
    let calendarName = "UK Holidays";
    let query = `?$select=calendarid&$filter=name eq '${calendarName}'`;

    try {
        // Retrieve the calendar record
        let calendars = await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, query);
        if (!calendars || calendars.entities.length === 0) {
            return false;
        }

        let calendarId = calendars.entities[0].calendarid;
        let expandQuery = `?$select=calendarid&$expand=calendar_calendar_rules($select=starttime)`;
        let calendar = await Xrm.WebApi.retrieveRecord(entityLogicalName, calendarId, expandQuery);

        // Check if there are any holidays in the calendar
        if (!calendar.calendar_calendar_rules || calendar.calendar_calendar_rules.length === 0) {
            return false;
        }
        // Convert holiday start times to YYYY-MM-DD format for comparison
        let holidays = calendar.calendar_calendar_rules.map(rule => {
            let holidayDate = new Date(rule.starttime);
            if (isNaN(holidayDate)) {
                return null;
            }

            holidayDate.setHours(0, 0, 0, 0);
            return holidayDate.toISOString().split("T")[0];
        }).filter(Boolean);
        return holidays.includes(nextPayoutDateString);
    } catch (error) {
        console.error("Error retrieving calendar with rules:", error);
        return false;
    }
}




RHSScripts.Membership.setMagazineDeliveryContact = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();

    var magazineDelivery = formContext.getAttribute("rhs_magazinedeliverycontact");
    var primaryMember = formContext.getAttribute("rhs_contact");
    var gardenMagazine = formContext.getAttribute("rhs_gardenmagazine");

    var gardenValue = gardenMagazine && gardenMagazine.getValue();
    var magazineValue = magazineDelivery && magazineDelivery.getValue();
    var primaryValue = primaryMember && primaryMember.getValue();


    if (gardenValue === false || gardenValue === "No") {
        magazineDelivery.setValue(null);
    }

    else if (!magazineValue && primaryValue) {
        magazineDelivery.setValue(primaryValue);
    }

};

RHSScripts.Membership.NotifyCancellationAtEndDate = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();

    let cancellationType = formContext.getAttribute("rhs_cancellationtype").getValue();
    let isCancellationTypeUnsaved = formContext.getAttribute("rhs_cancellationtype").getIsDirty();

    if (cancellationType == 120000001/*At end of membership*/ && isCancellationTypeUnsaved == true) {
        formContext.getAttribute("rhs_cancellationdate").setValue(new Date());
        formContext.getAttribute("statecode").setValue(0/*Active*/);
        formContext.getAttribute("statuscode").setValue(1/*Active*/);
        Xrm.Navigation.openAlertDialog({ title: "To be cancelled", text: "Membership will be cancelled on membership expiry." });
    }
};

RHSScripts.Membership.PopulatePaymentFrequency = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();

    let product = formContext.getAttribute("rhs_membershipproductid").getValue();
    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let paymentFrequency = formContext.getControl("rhs_paymentfrequency");

    if (product && product.length > 0 && paymentMethod !== null) {
        var productName = product[0].name;

        //Check if product name contains "Patron" and Payment Method is Direct Debit
        if (productName && productName.toLowerCase().includes("patron") && paymentMethod === 120000002) {
            //Set Payment Frequency to Annual and lock the field
            formContext.getAttribute("rhs_paymentfrequency").setValue(120000000);
            paymentFrequency.setDisabled(true);
        } else {
            paymentFrequency.setDisabled(false);
        }
    } else {
        paymentFrequency.setDisabled(false);
    }

};
const PATRON_MEMBERSHIP_NOTIFICATION = "PatronMembershipNotification";
const PATRON_AND_ONLY_ACTIVE_MEMBERSHIP_NOTIFICATION = "PatronAndOnlyActiveMembershipNotification";
RHSScripts.Membership.ShowFormNotificationForPatronMembership = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();
    var isPAtronMembership = formContext.getAttribute("rhs_patronmembership").getValue();
    if (isPAtronMembership) {
        var isPatronMessage = "Please note that patron memberships cannot be set to receive garden magazines. For patrons, the garden magazine is to be managed on their underlying membership. This membership can be viewed via their Contact record.";
        formContext.ui.setFormNotification(isPatronMessage, "INFO", PATRON_MEMBERSHIP_NOTIFICATION);
        var primaryMemberValue = formContext.getAttribute("rhs_contact")?.getValue();
        if (primaryMemberValue) {
            var membershipId = formContext.data.entity.getId();
            var primaryMemberId = primaryMemberValue[0].id;
            let filter = `?$filter=(_rhs_contact_value eq ${primaryMemberId} and statecode eq 0)`;
            if (membershipId) {
                membershipId = membershipId.replace(/[{}]/g, "");
                filter += ` and rhs_membershipid ne ${membershipId}`;
            }
            let primaryMemberMembership = await Xrm.WebApi.retrieveMultipleRecords("rhs_membership", filter);
            if (primaryMemberMembership.entities && primaryMemberMembership.entities.length > 0) {
                var isPatronAndOnlyActiveMembershipMembershipMessage = "Please be aware that this member also has another active membership. This membership can be viewed via their Contact record.";
                formContext.ui.setFormNotification(isPatronAndOnlyActiveMembershipMembershipMessage, "INFO", PATRON_AND_ONLY_ACTIVE_MEMBERSHIP_NOTIFICATION);
            }
            else {
                formContext.ui.clearFormNotification(PATRON_AND_ONLY_ACTIVE_MEMBERSHIP_NOTIFICATION);
            }
        }
        else {
            formContext.ui.clearFormNotification(PATRON_AND_ONLY_ACTIVE_MEMBERSHIP_NOTIFICATION);
        }

    }
    else {
        formContext.ui.clearFormNotification(PATRON_MEMBERSHIP_NOTIFICATION);
        formContext.ui.clearFormNotification(PATRON_AND_ONLY_ACTIVE_MEMBERSHIP_NOTIFICATION);
    }


};

RHSScripts.Membership.PopulatePatronMembershipFlag = async function (executionContext) {
    'use strict';

    const formContext = executionContext.getFormContext();
    const patronProductFamilyId = await RHSScripts.Membership.GetEnvironmentVariable("rhs_PatronMembershipProductParentID");
    if (!patronProductFamilyId) return;
    let product = formContext.getAttribute("rhs_membershipproductid").getValue();
    let productId = product ? product[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    if (!productId) return;
    const productResult = await Xrm.WebApi.retrieveRecord(
        "product",
        productId,
        "?$select=_parentproductid_value"
    );

    const parentProductId = productResult["_parentproductid_value"];
    const isPatron = parentProductId?.replace(/[{}]/g, "").toLowerCase() === patronProductFamilyId.replace(/[{}]/g, "").toLowerCase();
    formContext.getAttribute("rhs_patronmembership").setValue(isPatron);
    formContext.getAttribute("rhs_patronmembership").fireOnChange();



};

RHSScripts.Membership.GetEnvironmentVariable = async function (schemaName) {
    const envVariableDefResult = await Xrm.WebApi.retrieveMultipleRecords(
        "environmentvariabledefinition",
        `?$filter=schemaname eq '${schemaName}'&$select=environmentvariabledefinitionid,defaultvalue`
    );

    if (envVariableDefResult.entities.length === 0) {
        return null;
    }

    const envVariableDef = envVariableDefResult.entities[0];
    const envVarabiableDefId = envVariableDef.environmentvariabledefinitionid;

    const envVariableValResult = await Xrm.WebApi.retrieveMultipleRecords(
        "environmentvariablevalue",
        `?$filter=_environmentvariabledefinitionid_value eq ${envVarabiableDefId}&$select=value`
    );

    let value = null;

    if (envVariableValResult.entities.length > 0 && envVariableValResult.entities[0].value) {
        value = envVariableValResult.entities[0].value;
    } else {
        value = envVariableDef.defaultvalue;
    }

    return value || null;
};

RHSScripts.Membership.HideShowRenewalsCampaign = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    if (formContext.getAttribute("rhs_mrpidiscount").getValue() !== true) {
        var isInRenewalStage = formContext.getAttribute("rhs_inrenewalsstage").getValue();
        if (isInRenewalStage !== true) {
            formContext.getControl("rhs_renewalscampaign").setVisible(false);
        }
    }
    else {
        formContext.getControl("rhs_renewalscampaign").setVisible(true);
    }
}

//RHSScripts.Membership.SetCardDetailsSecondaryMember = function (executionContext) {
//    'use strict';
//    let formContext = executionContext.getFormContext();

//    let secondaryMember = formContext.getAttribute("rhs_member2").getValue();
//    let namePrintedOnCardSecondaryMember = formContext.getAttribute("rhs_nameprintedoncardsecondarymember");
//    let cardexpirydateSecondaryMember = formContext.getAttribute("rhs_cardexpirydatesecondarymember");
//    let issuenumberSecondaryMember = formContext.getAttribute("rhs_issuenumbersecondarymember");

//    let GetDateToday = new Date();
//    let now = new Date(Date.UTC(GetDateToday.getUTCFullYear(), GetDateToday.getUTCMonth(), GetDateToday.getUTCDate()));

//    // Calculate expiry date (+1 year - 1 day, leap-year safe)
//    let expiryDate = new Date(now.getTime());
//    expiryDate.setUTCFullYear(expiryDate.getUTCFullYear() + 1);
//    expiryDate.setUTCDate(expiryDate.getUTCDate() - 1);


//    if (secondaryMember != null) {

//        if (namePrintedOnCardSecondaryMember.getValue() == null || namePrintedOnCardSecondaryMember.getValue() !== secondaryMember[0].name) {
//            formContext.getControl("rhs_nameprintedoncardsecondarymember").setVisible(true);
//            formContext.getControl("rhs_cardexpirydatesecondarymember").setVisible(true);
//            formContext.getControl("rhs_issuenumbersecondarymember").setVisible(true);
//            namePrintedOnCardSecondaryMember.setValue(secondaryMember[0].name);
//            issuenumberSecondaryMember.setValue("1");
//            cardexpirydateSecondaryMember.setValue(expiryDate);

//        }
//    } else {

//        formContext.getControl("rhs_nameprintedoncardsecondarymember").setVisible(false);
//        formContext.getControl("rhs_cardexpirydatesecondarymember").setVisible(false);
//        formContext.getControl("rhs_issuenumbersecondarymember").setVisible(false);
//        namePrintedOnCardSecondaryMember.setValue(null);
//        cardexpirydateSecondaryMember.setValue(null);
//        issuenumberSecondaryMember.setValue(null);


//    }
//}




//RHSScripts.Membership.HideCardDetailsSecondaryMember = async function (executionContext) {
//    'use strict';

//    var formContext = executionContext.getFormContext();



//    let secondaryMember = formContext.getAttribute("rhs_member2").getValue();




//    if (secondaryMember == null || secondaryMember.length === 0) {

//        formContext.getControl("rhs_nameprintedoncardsecondarymember").setVisible(false);
//        formContext.getControl("rhs_cardexpirydatesecondarymember").setVisible(false);
//        formContext.getControl("rhs_issuenumbersecondarymember").setVisible(false);


//        formContext.getAttribute("rhs_nameprintedoncardsecondarymember").setValue(null);
//        formContext.getAttribute("rhs_cardexpirydatesecondarymember").setValue(null);
//        formContext.getAttribute("rhs_issuenumbersecondarymember").setValue(null);
//    } else {

//        formContext.getControl("rhs_nameprintedoncardsecondarymember").setVisible(true);
//        formContext.getControl("rhs_cardexpirydatesecondarymember").setVisible(true);
//        formContext.getControl("rhs_issuenumbersecondarymember").setVisible(true);
//    }
//}

//#endregion