async function setMembershipOnActivationCodeChange(formExecutionContext) {
    let formContext = formExecutionContext.getFormContext();

    let activationCodeLogicalName = "rhs_activationcode";
    let activationCodeValue = formContext.getAttribute(activationCodeLogicalName).getValue();

    if (activationCodeValue != null && activationCodeValue != "") {
        let membershipGIftPack = await retrieveGiftPackUsingActivationCode(activationCodeValue);

        if (await validateGiftPackActivationCode(membershipGIftPack)) {
            let giftPackMembershipProduct = await retrieveGiftPackMembershipProduct(membershipGIftPack["_rhs_product_value"]);
            await setMembershipUsingGiftPack(formContext, membershipGIftPack, giftPackMembershipProduct);
        }
    } else {
        await resetMembership(formContext);
    }
}

async function retrieveGiftPackUsingActivationCode(activationCodeValue) {
    let giftPackLogicalName = "rhs_giftpack";
    let giftPackOptions = "".concat(
        "?$select=rhs_giftpackcode,statuscode,rhs_expiredate,rhs_ispaymentreceived,rhs_price,_rhs_product_value,_rhs_purchasedby_value",
        `&$filter=(rhs_giftpackcode eq '${activationCodeValue}')`,
        "&$top=1"
    )

    return await Xrm.WebApi.retrieveMultipleRecords(giftPackLogicalName, giftPackOptions).then(
        function success(result) {
            let giftPack = result.entities[0];
            return giftPack;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function retrieveGiftPackMembershipProduct(giftPackProductBundleId) {
    let giftPackLogicalName = "product";
    let giftPackOptions = `?$select=name,productid&$expand=Product_ProductAssociation_AssocProd($filter=(_productid_value eq d4aec9ad-6c5a-ef11-bfe3-000d3a86fea3))&$filter=(productstructure eq 1 and hierarchypath eq 'Memberships+Product+Family') and (Product_ProductAssociation_AssocProd/any(o1:(o1/_productid_value eq ${giftPackProductBundleId})))`;

    return await Xrm.WebApi.retrieveMultipleRecords(giftPackLogicalName, giftPackOptions).then(
        function success(result) {
            let product = result.entities[0];
            return product;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function validateGiftPackActivationCode(membershipGIftPack) {
    if (membershipGIftPack != undefined && membershipGIftPack["statuscode"] == 120000003 &&
        (membershipGIftPack["rhs_expiredate"] == null || new Date(membershipGIftPack["rhs_expiredate"]) > new Date()) &&
        membershipGIftPack["rhs_ispaymentreceived"] == true
    ) {
        return true
    } else {
        Xrm.Navigation.openAlertDialog("Invalid Activation Code, please enter the correct one.");
        return false;
    }
}

async function setMembershipUsingGiftPack(formContext, membershipGIftPack, giftPackMembershipProduct) {
    let totalAmountLogicalName = "rhs_totalamount";
    let membershipProductLogicalName = "rhs_membershipproductid";
    let endDateLogicalName = "msnfp_enddate";
    let paymentMethodLogicalName = "rhs_paymentmethod";

    let totalAmountValue = 0;//membershipGIftPack.rhs_price;
    let membershipProductValue = [
        {
            "entityType": "product",
            "id": giftPackMembershipProduct["productid"],
            "name": giftPackMembershipProduct["name"]
        }
    ];

    let paymentMethodValue = 844060005;
    formContext.getAttribute(totalAmountLogicalName).setValue(totalAmountValue);
    formContext.getAttribute(membershipProductLogicalName).setValue(membershipProductValue);
    formContext.getAttribute(paymentMethodLogicalName).setValue(paymentMethodValue);

    let product = formContext.getAttribute("rhs_membershipproductid").getValue();
    if (!product) {
        console.error("Product not selected.");
        return;
    }

    let productId = product[0].id.replace("{", "").replace("}", "").toLowerCase();
    let propertyEntityLogicalName = "dynamicproperty";
    let propertyOptions = "".concat(
        `?$select=dynamicpropertyid,name,_defaultvalueoptionset_value`,
        `&$expand=Dynamicproperty_DynamicPropertyAssociation($filter=(_regardingobjectid_value eq ${productId} and associationstatus eq 0))`,
        `&$filter=(name eq 'Duration') and (Dynamicproperty_DynamicPropertyAssociation/any(o1:(o1/_regardingobjectid_value eq ${productId} and o1/associationstatus eq 0)))`,
        `&$top=1`
    );

    let durationProperty = (await Xrm.WebApi.retrieveMultipleRecords(propertyEntityLogicalName, propertyOptions)).entities[0];
    if (!durationProperty) {
        console.error("Duration property not found.");
        return;
    }

    let defaultPropertyOptionSetEntityLogicalName = "dynamicpropertyoptionsetitem";
    let defaultPropertyOptionSetId = durationProperty._defaultvalueoptionset_value;
    let defaultPropertyOptionSetOptions = "?$select=dynamicpropertyoptionname,dynamicpropertyoptionvalue";
    let durationDefaultPropertyOptionSetName = (await Xrm.WebApi.retrieveRecord(defaultPropertyOptionSetEntityLogicalName, defaultPropertyOptionSetId, defaultPropertyOptionSetOptions)).dynamicpropertyoptionname;

    // Retrieve time-based campaign discount (if any)
    let durationDiscount = null;
    let campaign = formContext.getAttribute("rhs_campaignid").getValue();
    if (campaign) {
        let campaignEntityLogicalName = "campaign";
        let campaignId = campaign[0].id.replace("{", "").replace("}", "").toLowerCase();
        let campaignOptions = "?$select=rhs_benefittype,rhs_durationbenefit";

        let potentialCampaignDiscount = await Xrm.WebApi.retrieveRecord(campaignEntityLogicalName, campaignId, campaignOptions);
        if (potentialCampaignDiscount.rhs_benefittype == 120000000 /* Time-Based */) {
            durationDiscount = potentialCampaignDiscount.rhs_durationbenefit;
        }
    }
    // Prepare start date and end date values
    let now = new Date();
    let paymentDate = now.getDate();

    let startDate = new Date();
    if (paymentDate >= 23 && paymentDate <= 31) {
        startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    } else if (paymentDate >= 2 && paymentDate <= 7) {
        startDate = new Date(now.getFullYear(), now.getMonth() + 1, 8);
    } else if (paymentDate >= 8 && paymentDate <= 15) {
        startDate = new Date(now.getFullYear(), now.getMonth() + 1, 15);
    } else if (paymentDate >= 16 && paymentDate <= 22) {
        startDate = new Date(now.getFullYear(), now.getMonth() + 1, 22);
    }

    let endDate = new Date(startDate);
    switch (durationDefaultPropertyOptionSetName) {
        case "3 Months":
            endDate.setMonth(endDate.getMonth() + 3);
            endDate.setDate(endDate.getDate() - 1);
            break;
        case "6 Months":
            endDate.setMonth(endDate.getMonth() + 6);
            endDate.setDate(endDate.getDate() - 1);
            break;
        case "1 Year":
            endDate.setFullYear(endDate.getFullYear() + 1);
            endDate.setDate(endDate.getDate() - 1);
            break;
        case "Lifetime":
            endDate = null;
            break;
    }

    if (durationDiscount) {
        endDate.setMonth(endDate.getMonth() + durationDiscount);
    }

    formContext.getAttribute("msnfp_startdate").setValue(startDate);

    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    if (paymentMethod && endDate) {
        formContext.getAttribute("msnfp_enddate").setValue(endDate);
    } else {
        formContext.getAttribute("msnfp_enddate").setValue(null);
    }
}

async function resetMembership(formContext) {
    let totalAmountLogicalName = "rhs_totalamount";
    let endDateLogicalName = "msnfp_enddate";
    let paymentMethodLogicalName = "rhs_paymentmethod";

    formContext.getAttribute(totalAmountLogicalName).setValue(null);
    formContext.getAttribute(endDateLogicalName).setValue(null);
    formContext.getAttribute(paymentMethodLogicalName).setValue(null);
}