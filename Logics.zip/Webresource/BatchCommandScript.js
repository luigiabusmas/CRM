if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Batch) === "undefined") { RHSScripts.Batch = {}; }

//#region Command Functions
RHSScripts.Batch.RegenerateNAVRequestCommandDisplayRule = function (primaryControl) {

    let formContext = primaryControl;
    let batchType = formContext.getAttribute("rhs_type").getValue();

    if (batchType !== 120000002) { //Type is not Nav18
        return false;
    }

    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    var hasRequiredRole = false;

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers") {
            hasRequiredRole = true;
            break;
        }
    }

    if (!hasRequiredRole) {
        return false;
    }

};

RHSScripts.Batch.RegenerateNAVRequestCommandAction = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    var fetchXml = `
        <fetch>
          <entity name="rhs_fileexportrequests">
            <filter type="and">
              <condition attribute="rhs_exportfilerequesttype" operator="eq" value="120000019" />
              <condition attribute="statuscode" operator="in">
                <value>120000001</value>
                <value>120000003</value>
              </condition>
            </filter>
          </entity>
        </fetch>`;

    var encodedFetch = "?fetchXml=" + encodeURIComponent(fetchXml);
    console.log("Encoded FetchXML:", encodedFetch);

    try {
        var result = await Xrm.WebApi.retrieveMultipleRecords("rhs_fileexportrequests", encodedFetch);
        console.log("Fetch result:", result);

        if (result.entities.length > 0) {
            console.warn("An export file is already in progress. Blocking execution.");

            var notification =
            {
                type: 2,
                level: 2,
                message: "A previous Regenerate NAV Export is still being generated. Please try again later.",
                showCloseButton: true
            }

            Xrm.App.addGlobalNotification(notification).then(
                function success(result) {
                    console.log("Notification created with ID: " + result);
                    // perform other operations as required on notification display
                },
                function (error) {
                    console.log(error.message);
                    // handle error conditions
                }
            );

            return;
        }

        let now = new Date();
        let options = {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'UTC'
        };

        let dateFormatted = new Intl.DateTimeFormat('en-GB', options).format(now);
        dateFormatted = dateFormatted.replace(',', '');


        //Get BatchID and BatchGUId of current record
        let batchID = formContext.getAttribute("rhs_name").getValue();
        let batchGUID = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

        //Create File Export Request
        var data =
        {
            "rhs_exportfilerequesttype": 120000019,
            "rhs_exporttypechoice": 120000001,
            "statuscode": 120000003,
            "statecode": 1,
            "rhs_name": "FileExport - " + dateFormatted
        }

        // create account record
        Xrm.WebApi.createRecord("rhs_fileexportrequests", data).then(
            function success(result) {
                console.log("File Export Request created with ID: " + result.id);
                var newFileExportRequestId = result.id;

                var fileExportRequestParamData = {
                    "rhs_name": "Regenerate NAV Export - " + batchID,
                    "rhs_exportrequest@odata.bind": "/rhs_fileexportrequestses(" + newFileExportRequestId + ")",
                    "rhs_product": batchID,
                    "rhs_value2": batchGUID
                };

                Xrm.WebApi.createRecord("rhs_fileexportrequestparameter", fileExportRequestParamData).then(
                    function success(fileResult) {
                        console.log("File Export Parameter created with ID: " + fileResult.id + " and linked to File Export Request.");
                    },
                    function (error) {
                        console.error("Error creating File Export Parameter: " + error.message);
                    }
                );


            },
            function (error) {
                console.log(error.message);
            }
        );

        var notification =
        {
            type: 2,
            level: 1,
            message: "Regenerating NAV Export. Please do not start this process again until the file is generated.",
            showCloseButton: true
        }

        Xrm.App.addGlobalNotification(notification).then(
            function success(result) {
                console.log("Notification created with ID: " + result);
            },
            function (error) {
                console.log(error.message);
                // handle error conditions
            }
        );

    } catch (error) {
        console.error("Error in RegenerateNAVExport:", error);
        var alertStrings = { text: "Error: " + error.message, title: "Error" };
        var alertOptions = { height: 200, width: 450 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }

};
//#end region
