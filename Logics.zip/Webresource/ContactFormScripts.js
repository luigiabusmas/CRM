// JavaScript source code
// JavaScript source code
//Contact Form Source Code
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Contact) === "undefined") { RHSScripts.Contact = {}; }

let cachedPrimaryNationalLength = null;
let cachedSecondaryNationalLength = null;
let cachedWorkNationalLength = null;


//#region Event Functions
RHSScripts.Contact.OnLoad = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    /*await*/ RHSScripts.Contact.ShowHidePatronFields(executionContext);
    RHSScripts.Contact.CacheCountryPhone(executionContext, "rhs_countryphone1");
    RHSScripts.Contact.CacheCountryPhone(executionContext, "rhs_countryphone2");
    RHSScripts.Contact.CacheCountryPhone(executionContext, "rhs_countryphone3");


}


RHSScripts.Contact.OnIsDeceaseChange = async function (executionContext) {
    console.log("RHSScripts.Contact.OnIsDeceaseChange has been called.");
    RHSScripts.Contact.ContactHasActiveMembership(executionContext);
}


RHSScripts.Contact.OnSave = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    if (formContext.getAttribute("telephone1").getIsDirty() ||
        formContext.getAttribute("telephone2").getIsDirty() ||
        formContext.getAttribute("telephone3").getIsDirty()) {

        let isValid = true;

        // Validate main phone
        const primaryPhoneResult = RHSScripts.Contact.ValidatePrimaryPhoneNumber(executionContext);
        if (!primaryPhoneResult) {
            isValid = false;
        }

        const secondaryPhoneResult = RHSScripts.Contact.ValidateSecondaryPhoneNumber(executionContext);
        if (!secondaryPhoneResult) {
            isValid = false;
        }
        const workPhoneResult = RHSScripts.Contact.ValidateWorkPhoneNumber(executionContext);
        if (!workPhoneResult) {
            isValid = false;
        }

        if (!isValid) {
            executionContext.getEventArgs().preventDefault();
        } else {
            RHSScripts.Contact.ClearFieldNotifications(executionContext);
        }
    }
}

RHSScripts.Contact.ShowHidePatronFields = async function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();
    let contactTypes = formContext.getAttribute("rhs_contacttypes").getValue();

    if (contactTypes) {
        //check if Contact Type includes Patron
        var containsPatron = contactTypes.includes(844060003);

        if (containsPatron) {
            //show fields
            formContext.getControl("rhs_biography").setVisible(true);
            formContext.getControl("rhs_patronarea").setVisible(true);
            formContext.getControl("rhs_agerange").setVisible(true);
            formContext.getControl("rhs_patronleavingrisk").setVisible(true);
            formContext.getControl("rhs_patronactivitylevel").setVisible(true);
            formContext.getControl("rhs_plantreviewsubscriptionbenefit").setVisible(true);
        } else {
            //hide fields
            formContext.getControl("rhs_biography").setVisible(false);
            formContext.getControl("rhs_patronarea").setVisible(false);
            formContext.getControl("rhs_agerange").setVisible(false);
            formContext.getControl("rhs_patronleavingrisk").setVisible(false);
            formContext.getControl("rhs_patronactivitylevel").setVisible(false);
            formContext.getControl("rhs_plantreviewsubscriptionbenefit").setVisible(false);
        }
    } else {
        //hide fields
        formContext.getControl("rhs_biography").setVisible(false);
        formContext.getControl("rhs_patronarea").setVisible(false);
        formContext.getControl("rhs_agerange").setVisible(false);
        formContext.getControl("rhs_patronleavingrisk").setVisible(false);
        formContext.getControl("rhs_patronactivitylevel").setVisible(false);
        formContext.getControl("rhs_plantreviewsubscriptionbenefit").setVisible(false);
    }
}

RHSScripts.Contact.ValidateSecondaryPhoneNumber = function (executionContext) {
    var formContext = executionContext.getFormContext();
    const phoneField = "telephone2";
    let countryField = null;
    const phoneFieldName = formContext.getControl(phoneField).getLabel();
    const phoneValue = formContext.getAttribute(phoneField).getValue();
    if (formContext.getAttribute("rhs_countryphone2").getValue() != null) {
        countryField = formContext.getAttribute("rhs_countryphone2").getValue()[0].id;
    }
    return RHSScripts.Contact.ValidatePhoneNumber(formContext, phoneValue, phoneField, phoneFieldName, countryField, cachedSecondaryNationalLength);

}

RHSScripts.Contact.ValidatePrimaryPhoneNumber = function (executionContext) {
    var formContext = executionContext.getFormContext();
    const phoneField = "telephone1";
    let countryField = null;
    const phoneFieldName = formContext.getControl(phoneField).getLabel();
    const phoneValue = formContext.getAttribute(phoneField).getValue();
    if (formContext.getAttribute("rhs_countryphone1").getValue() != null) {
        countryField = formContext.getAttribute("rhs_countryphone1").getValue()[0].id;
    }
    return RHSScripts.Contact.ValidatePhoneNumber(formContext, phoneValue, phoneField, phoneFieldName, countryField, cachedPrimaryNationalLength);

}


RHSScripts.Contact.ValidateWorkPhoneNumber = function (executionContext) {
    var formContext = executionContext.getFormContext();
    const phoneField = "telephone3";
    let countryField = null;
    const phoneFieldName = formContext.getControl(phoneField).getLabel();
    const phoneValue = formContext.getAttribute(phoneField).getValue();
    if (formContext.getAttribute("rhs_countryphone3").getValue() != null) {
        countryField = formContext.getAttribute("rhs_countryphone3").getValue()[0].id;
    }
    return RHSScripts.Contact.ValidatePhoneNumber(formContext, phoneValue, phoneField, phoneFieldName, countryField, cachedWorkNationalLength);
}

RHSScripts.Contact.ValidatePhoneNumber = function (formContext, phoneValue, phoneField, phoneFieldName, countryField, countryLength) {
    const ctrl = formContext.getControl(phoneField);

    // Clear previous notifications
    ctrl.clearNotification("Phone Validation");

    if (!phoneValue) {
        return true;
    }

    const regex = /^\d*$/;

    if (!regex.test(phoneValue)) {
        ctrl.setNotification(`Only numbers are allowed in the ${phoneFieldName} field, please enter a correct phone number!`, "Phone Validation");
        return false;
    } else {
        ctrl.clearNotification("Phone Validation");
    }

    if (countryField != null && countryLength && phoneValue.length !== countryLength) {
        ctrl.setNotification(`Phone provided is not per expected National Number size: ${countryLength}. Please re-enter your ${phoneFieldName} number without the country code.`, "Phone Validation");
        return false;
    } else {
        ctrl.clearNotification("Phone Validation");
    }

    return true;
}


RHSScripts.Contact.ClearFieldNotifications = function (executionContext) {
    var formContext = executionContext.getFormContext();

    formContext.ui.controls.forEach(function (control) {
        try {
            if (control && control.clearNotification) {
                control.clearNotification();
            }
        } catch (e) {
        }
    })
}

RHSScripts.Contact.OnCountryPhoneChange = function (executionContext) {
    const formContext = executionContext.getFormContext();
    const changedFieldName = executionContext.getEventSource().getName();
    const validFields = ["rhs_countryphone1", "rhs_countryphone2", "rhs_countryphone3"];
    if (validFields.includes(changedFieldName)) {
        RHSScripts.Contact.CacheCountryPhone(executionContext, changedFieldName);
    }
};

RHSScripts.Contact.CacheCountryPhone = function (executionContext, countryPhone) {
    const formContext = executionContext.getFormContext();
    if (countryPhone) {
        const countryName = formContext.getAttribute(countryPhone).getValue();

        if (!countryName) {
            if (countryPhone == "rhs_countryphone1")
                cachedPrimaryNationalLength = null;
            if (countryPhone == "rhs_countryphone2")
                cachedSecondaryNationalLength = null;
            if (countryPhone == "rhs_countryphone3")
                cachedWorkNationalLength = null;
            return;
        }

        Xrm.WebApi.retrieveRecord("rhs_country", countryName[0].id.replace(/[{}]/g, ""), "?$select=rhs_sizeofnationalnumber").then(
            function success(result) {
                if (countryPhone == "rhs_countryphone1")
                    cachedPrimaryNationalLength = result.rhs_sizeofnationalnumber;
                if (countryPhone == "rhs_countryphone2")
                    cachedSecondaryNationalLength = result.rhs_sizeofnationalnumber;
                if (countryPhone == "rhs_countryphone3")
                    cachedWorkNationalLength = result.rhs_sizeofnationalnumber;
            }
        );
    }
}

RHSScripts.Contact.ContactHasActiveMembership = async function (executionContext) {
    'use strict';
    console.log("RHSScripts.Contact.ContactHasActiveMembership has been called.");
    var formContext = executionContext.getFormContext();

    var toggleValue = formContext.getAttribute("rhs_deceased")?.getValue() === true;
    if (!toggleValue) {

        return;
    }

    var contactRecord = formContext.data.entity.getId();

    if (!contactRecord || contactRecord.length === 0) {
        console.log("No contact record found.");
        return;
    }

    var contactId = contactRecord.replace("{", "").replace("}", "").toLowerCase();


    var membershipInfo = await RHSScripts.Contact.CheckifActiveMembership(contactId);

    if (membershipInfo) {

        Xrm.Navigation.openConfirmDialog({
            title: "Active Membership Found",
            text: `This contact is associated with an underlying membership (as a primary or secondary member).
It is required to review and reassign the membership before proceeding.`,
            confirmButtonLabel: "OK",
            cancelButtonLabel: "Cancel"
        }).then(function (confirmResult) {
            if (!confirmResult.confirmed) {

                formContext.getAttribute("rhs_deceased").setValue(false);
            }

        });
    }
};


RHSScripts.Contact.CheckifActiveMembership = async function (contactId) {
    'use strict';

    console.log("RHSScripts.Contact.CheckifActiveMembership has been called.");

    if (!contactId) {
        return false;
    }

    var fetchXml =
        `<fetch top="1">
            <entity name="rhs_membership">
                <attribute name="rhs_membershipid" />
                <filter type="and">
                    <condition attribute="statuscode" operator="eq" value="1" />
                    <filter type="or">
                        <condition attribute="rhs_contact" operator="eq" value="${contactId}" />
                        <condition attribute="rhs_member2" operator="eq" value="${contactId}" />
                    </filter>
                </filter>
            </entity>
        </fetch>`;

    try {
        var result = await Xrm.WebApi.retrieveMultipleRecords(
            "rhs_membership",
            "?fetchXml=" + encodeURIComponent(fetchXml)
        );

        return result.entities.length > 0;

    } catch (error) {
        console.error("ContactHasActiveMembership failed:", error.message);
        return false;
    }
}

//#endregion