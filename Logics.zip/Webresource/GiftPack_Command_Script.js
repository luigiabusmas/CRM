if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.GiftPack) === "undefined") { RHSScripts.GiftPack = {}; }

const SUBMITTING_PAYMENT_NOTIFICATION_ID = "SubmittingPaymentNotification";
const GIFTPACK_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID = "GiftPackTransactionSuccessfulNotification";
const GIFTPACK_TRANSACTION_FAILED_NOTIFICATION_ID = "GiftPackTransactionFailedNotification";

//#region Command Functions
RHSScripts.GiftPack.ConsentsCommand = function (primaryControl) {
    'use strict';
    var formContext = primaryControl;

    var purchasedBy = formContext.getAttribute("rhs_purchasedby").getValue();
    if (purchasedBy !== null){
        var purchasedByEntityType = purchasedBy[0].entityType.toLowerCase();
        //if account
        if (purchasedByEntityType === "account"){
            var alertStrings = { text: "Purchased By is not a Contact.", title: "Information" };
            var alertOptions = { height: 80, width: 200 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        //elseif countact
        else if (purchasedByEntityType === "contact") {

            var purchasedById = purchasedBy[0].id.replace("{", "").replace("}", "").toLowerCase();
            var customPageName = "rhs_contactpointconsentspage_0516f";
            var pageInput = {
                pageType: "custom",
                name: customPageName,
                entityName: "contact", 
                recordId: purchasedById
            };

            var navigationOptions = {
                target: 1,
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions)
                .then(function () {
                    console.log("Custom page opened successfully in the workspace.");
                })
                .catch(function (error) {
                    console.error("Error navigating to the custom page:", error.message);
                });
        }
    }
    else {console.log("purchased By should have a value.");}
}

RHSScripts.GiftPack.MakePaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let giftPackId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    try {
        let isSubmitPayment = formContext.getAttribute("rhs_ispaymentsubmitted").getValue();
        
        if (isSubmitPayment != true) {
            //#region  Prepare the gift pack for payment submission          
            Xrm.Utility.showProgressIndicator("Submitting payment. Please wait...");
            formContext.ui.clearFormNotification(GIFTPACK_TRANSACTION_FAILED_NOTIFICATION_ID);
            formContext.ui.clearFormNotification(GIFTPACK_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Submitting payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);
            //#endregion

            //#region  Generate transaction, payments and payment schedule
            let transaction = await RHSScripts.GiftPack.RetrieveActiveGiftPackTransaction(giftPackId);
            if (transaction == null) {
                let [transactionid, paymentid, payementscheduleid] = await RHSScripts.GiftPack.ExecuteSubmitPaymentCustomAPIForGiftPack(formContext);

                if (transactionid == null && paymentid == null && payementscheduleid == null)
                    throw new Error("Gift pack transaction failed.");
            }            
            //#endregion

            //#region  Make/Submit Payment
            let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
            if (paymentMethod == 844060000/*Cash*/ || paymentMethod == 844060001/*Cheque*/) {
                let payments = await RHSScripts.GiftPack.RetrieveActiveGiftPackPayments(giftPackId);
                for (let ctr = 0; ctr < payments.length; ctr++)
                    await RHSScripts.GiftPack.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);

                await RHSScripts.GiftPack.ActivateGiftPack(formContext);
            } else if (paymentMethod == 844060002/*Card*/) {
                await RHSScripts.GiftPack.MakeStripePayment(formContext);

                let payments = await RHSScripts.GiftPack.RetrieveActiveGiftPackPayments(giftPackId);
                for (let ctr = 0; ctr < payments.length; ctr++)
                    await RHSScripts.GiftPack.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);

                await RHSScripts.GiftPack.ActivateGiftPack(formContext);
            } else if (paymentMethod == 120000002/*DD*/) {
                await RHSScripts.GiftPack.MakePTXPayment(formContext);

                await RHSScripts.GiftPack.ActivateGiftPack(formContext);
            }
            //#endregion

            //#region  Ending payment submission
            Xrm.Utility.closeProgressIndicator();
            formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Gift Pack transaction successful.", "INFO", GIFTPACK_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            Xrm.Navigation.openAlertDialog({ title: "Success", text: "Payment successful." });
            //#endregion
        }
    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Gift pack transaction failed. Please try again", "ERROR", GIFTPACK_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Payment failed." });
    }
}

RHSScripts.GiftPack.RefundPayment = async function (primaryControl) {
    'use strict';
    var formContext = primaryControl;
}

RHSScripts.GiftPack.AgentScriptsCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_membershipagentscripts_dcfe6";
    let pageInput = {
        pageType: "custom",
        name: customPageName
    };

    let paneOptions = {
        title: "Agent Scripts",
        paneId: "AgentScripts",
        canClose: true,
        width: 500
    };

    Xrm.App.sidePanes.createPane(paneOptions).then((pane) => {
        pane.navigate(pageInput);
    })
}
//#endregion

//#region Helper Functions
RHSScripts.GiftPack.ActivateGiftPack = async function (formContext, paymentSubmitted = true, paymentReceived = true) {
    let giftPackId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 0;
    record.statuscode = 120000003;

    await Xrm.WebApi.updateRecord("rhs_giftpack", giftPackId, record);
    await formContext.data.refresh();
}

RHSScripts.GiftPack.RetrieveGiftPackTransaction = async function (giftPackId) {
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,_rhs_giftpackid_value,rhs_outstandingamount",
        `&$filter=(_rhs_giftpackid_value eq ${giftPackId})`,
        "&$top=1"
    );

    return await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options).then(
        function success(result) {
            return result.entities[0];
        },
        function (error) {
            console.log(error.message);
            return null;
        }
    );
}

RHSScripts.GiftPack.RetrieveActiveGiftPackTransaction = async function (giftPackId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,rhs_transacid,_rhs_giftpackid_value,rhs_amount,rhs_paidon,rhs_outstandingamount,statecode,statuscode",
        `&$filter=(_rhs_giftpackid_value eq ${giftPackId} and statecode eq 0)`
    );

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.GiftPack.RetrieveActiveGiftPackPaymentSchedule = async function (giftPackId) {
    let paymentSchedule = null;
    let entityLogicalName = "rhs_paymentschedule";
    let options = `?$filter=_rhs_giftpackid_value eq ${giftPackId}`;

    let paymentSchedules = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (paymentSchedules != undefined && paymentSchedules != null && paymentSchedules.length > 0)
        paymentSchedule = paymentSchedules[0];

    return paymentSchedule;
}

RHSScripts.GiftPack.RetrieveActiveGiftPackPayments = async function (giftPackId) {
    let payments = null;
    let entityLogicalName = "rhs_payment";
    let options = "".concat(
        "?$select=rhs_paymentid,rhs_paymentsid,rhs_amount,rhs_duedate,statuscode,statecode",
        `&$filter=(rhs_Transaction/_rhs_giftpackid_value eq ${giftPackId} and statecode eq 0)`,
        "&$orderby=rhs_duedate asc"
    );
    
    payments = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return payments;
}

RHSScripts.GiftPack.UpdatePaymentAsPaid = async function (paymentId) {
    await Xrm.WebApi.updateRecord("rhs_payment", paymentId, { "rhs_paidon": (new Date()).toISOString().substring(0, 10), "statecode": 1/*Inactive*/, "statuscode": 2/*Paid*/ });
}

RHSScripts.GiftPack.ExecuteSubmitPaymentCustomAPIForGiftPack = async function (formContext) {
    // Fields
    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let giftPackId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let payer = formContext.getAttribute("rhs_purchasedby").getValue();
    let isContinuousPayment = false;
    let paymentFrequency = null;
    let totalAmount = formContext.getAttribute("rhs_totalprice").getValue();
    let outstandingAmount = null;

    // Parameters
    let parameters = {};
    parameters.PaymentMethod = paymentMethod;
    parameters.RecordId = giftPackId;
    parameters.PayerId = payer != null ? payer[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    parameters.IsContiniousPayment = isContinuousPayment;
    parameters.PaymentFrequency = paymentFrequency;
    parameters.TransactionType = 120000001/*Gift Pack*/;
    parameters.Type = 120000000/*Full Payment*/;
    parameters.PayerEntity = payer != null ? payer[0].entityType : null;
    parameters.TotalAmount = outstandingAmount != null ? outstandingAmount : totalAmount;
    parameters.OutstandingAmount = outstandingAmount;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_submitpayment_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let transactionid = result["TransactionId"];
        let paymentid = result["PaymentId"];
        let payementscheduleid = result["PayementScheduleId"];
        return [transactionid, paymentid, payementscheduleid]
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.GiftPack.MakeStripePayment = async function (formContext) {
    let giftPackId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    // Redirect to checkout url
    let checkoutURL = formContext.getAttribute("rhs_checkouturl").getValue();
    let checkoutSessionId = formContext.getAttribute("rhs_checkoutsessionid").getValue();
    if (checkoutURL == undefined || checkoutURL == null || checkoutSessionId == undefined || checkoutSessionId == null) {
        let payer = formContext.getAttribute("rhs_purchasedby").getValue()[0];
        let payerId = payer.id.replace("{", "").replace("}", "").toLowerCase();
        let customerId = (await Xrm.WebApi.retrieveRecord(payer.entityType, payerId, "?$select=msnfp_stripecustomerid")).msnfp_stripecustomerid;
        if (customerId == undefined || customerId == null) {
            customerId = await RHSScripts.GiftPack.ExecuteStripeCreateCustomerCustomAPI(payer.name);

            await Xrm.WebApi.updateRecord(payer.entityType, payerId, { "msnfp_stripecustomerid" : customerId })
        }

        let product = formContext.getAttribute("rhs_product").getValue()[0];
        let totalAmount = formContext.getAttribute("rhs_totalprice").getValue();
        checkoutURL = await RHSScripts.GiftPack.ExecuteStripeCheckoutSession(customerId, "gbp", totalAmount.toString(), "1", "payment", product.name)
        checkoutSessionId = checkoutURL.replace("https://checkout.stripe.com/c/pay/", "").split('#')[0];

        await Xrm.WebApi.updateRecord("rhs_giftpack", giftPackId, { "rhs_checkouturl" : checkoutURL, "rhs_checkoutsessionid" : checkoutSessionId });
    }
    Xrm.Navigation.openUrl(checkoutURL);

    // Confirm stripe payment
    let alertStrings = { title: "Stripe Payment", text: "Have you finished stripe payment?", confirmButtonLabel: "Yes" };
    await Xrm.Navigation.openAlertDialog(alertStrings);
    let [paymentStatus, paymentIntentId] = await RHSScripts.GiftPack.ExecuteStripeGetCheckoutSession(checkoutSessionId);

    if(paymentStatus == "paid" && paymentIntentId != undefined && paymentIntentId != null) {
        await Xrm.WebApi.updateRecord("rhs_giftpack", giftPackId, { "rhs_paymentintentid" : paymentIntentId });
    } else {
        throw Error("Stripe Transaction Failed");
    }
}

RHSScripts.GiftPack.ExecuteStripeCreateCustomerCustomAPI = async function(payerName) {
    // Parameters
    var parameters = {};
    parameters.rhs_stripeName = payerName;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_stripeCreateCustomer", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let stripeCustomerResponse = JSON.parse(result.rhs_stripeCustomerResponse);
        return stripeCustomerResponse.customerId;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.GiftPack.ExecuteStripeCheckoutSession = async function(stripeCustomerId, stripeCurrency, stripeUnitAmount, stripeQuantity, stripeMode, stripeProduct) {
    // Parameters
    var parameters = {};
    parameters.rhs_stripeCustomerId = stripeCustomerId;
    parameters.rhs_stripeCurrency = stripeCurrency;
    parameters.rhs_stipeUnitAmount = stripeUnitAmount;
    parameters.rhs_stripeQuantity = stripeQuantity;
    parameters.rhs_stripeMode = stripeMode;
    parameters.rhs_stripeProduct = stripeProduct;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_checkoutSessionStripe", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let stripeCheckoutSessionResponse = JSON.parse(result.rhs_stripeCheckoutSessionResponse);
        return stripeCheckoutSessionResponse.checkoutUrl;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.GiftPack.ExecuteStripeGetCheckoutSession = async function(stripeCheckoutSessionId) {
    // Parameters
    var parameters = {};
    parameters.rhs_stripeCheckoutSessionId = stripeCheckoutSessionId;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_getCheckoutSessionStripe", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        var response = responseObjects[0];
        var responseBody = responseObjects[1];
        var result = responseBody;
        console.log(result);
        
        // Output Parameters
        let stripeGetCheckoutSessionResponse = JSON.parse(result.rhs_stripeGetCheckoutSessionResponse);
        return [stripeGetCheckoutSessionResponse.payment_status, stripeGetCheckoutSessionResponse.paymentIntentId];
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.GiftPack.MakePTXPayment = async function (formContext) {
    let ptxPaymentUrl = await RHSScripts.GiftPack.RetrieveAppSettingValueByName("FAPTXWebFormURL");
    let ptxCallbackURL = await RHSScripts.GiftPack.RetrieveAppSettingValueByName("FAPTXCallbackURL"); 
    if (ptxPaymentUrl == undefined || ptxPaymentUrl == null)
        throw Error("PTXWebFormURL app setting not set for this environment. Please contact an administrator to fix this.");
    if (ptxCallbackURL == undefined || ptxCallbackURL == null)
        throw Error("FAPTXCallbackURL app setting not set for this environment. Please contact an administrator to fix this.");
    
    if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?");
        ptxPaymentUrl += "?";

    let giftPackId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    // let paymentFrequency = formContext.getAttribute("rhs_paymentfrequency").getValue();
    let payerReference = formContext.getAttribute("rhs_purchasedby").getValue()[0];
    let payer = await Xrm.WebApi.retrieveRecord(payerReference.entityType, payerReference.id);
    let payerCompany = payerReference.entityType == "contact" && payer._parentcustomerid_value != undefined && payer._parentcustomerid_value != null ? 
        await Xrm.WebApi.retrieveRecord("account", payer._parentcustomerid_value) : null;
    let payerTitle = payerReference.entityType == "contact" && payer._rhs_title_value != undefined && payer._rhs_title_value != null ?
        await Xrm.WebApi.retrieveRecord("rhs_titleandsalutation", payer._rhs_title_value) : null;

    let postcode = payer.address1_postalcode;
    let buildingNumberOrName = null; // Building name is not saved on contact or account address fields.
    let address = payerReference.entityType == "contact" ? 
        (payer.rhs_loqatehomeaddresshousename != null ? payer.rhs_loqatehomeaddresshousename.split(' ').slice(1).join(' ') : null) : 
        (payer.rhs_loqateaddress1housename != null ? payer.rhs_loqateaddress1housename.split(' ').slice(1).join(' ') : null);
    let townOrCity = payerReference.entityType == "contact" ? payer.address1_city : payer.address1_city;

    let transaction = await RHSScripts.GiftPack.RetrieveActiveGiftPackTransaction(giftPackId);
    let paymentSchedule = await RHSScripts.GiftPack.RetrieveActiveGiftPackPaymentSchedule(giftPackId);
    let payments = await RHSScripts.GiftPack.RetrieveActiveGiftPackPayments(giftPackId);

    let parameters = { };
    //#region  Customisation parameters
    parameters.formname = null;
    parameters.texttitle = null;
    parameters.textsubtitle = null;
    parameters.contactphone = null;
    parameters.contactemail = null;
    parameters.textapplybutton = null;
    parameters.showformheader = null;
    parameters.legalentityname = null;
    parameters.currentaddresslegend = null;
    parameters.customdatalabel = null;
    parameters.showtitle = null;
    parameters.showfirstname = null;
    parameters.showmiddlename = null;
    parameters.showlastname = null;
    parameters.showdob = null;
    parameters.showemail = null;
    parameters.showmobile = null;
    parameters.showcurrentaddress = null;
    parameters.showbankaccount = null;
    parameters.advancednoticedays = 1;
    parameters.showcompanyname = null;
    parameters.showapplyingascompanycheck = null;
    parameters.useaddressline2 = null;
    parameters.showcustomdata = null;
    parameters.showddplanreference = null;
    parameters.showconfirmddguarantee = null;
    parameters.showddplansummary = null;
    parameters.showddplanfields = null;
    parameters.showgiftaid = null;
    parameters.showerrordetail = null;
    parameters.showbankaccountcreated = null;
    parameters.showcompanyregistrationnumber = null;
    //#endregion
    //#region  Required
    parameters.company = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    parameters.firstname = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    parameters.lastname = payerReference.entityType == "contact" ? payer.lastname: null;
    parameters.email = payer.emailaddress1;
    parameters.currenthousenamenumber = buildingNumberOrName;
    parameters.currentpostcode = postcode;
    parameters.bankaccountname = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    parameters.sortcode = null;
    parameters.accountnumber = null;
    parameters.ddplanspecification = null;
    parameters.ddregularamount = paymentSchedule != null ? paymentSchedule.rhs_paymentamount : payments[0].rhs_amount;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddstartdate = payments[0].rhs_duedate.substring(0, 10);
    //#endregion
    //#region  Optional
    parameters.requestid = null;
    parameters.requestuserid = null;
    parameters.customdata = null;
    parameters.contactdetailsheader = null;
    parameters.title = null;    // causes problems when more than 5 characters
    parameters.middlename = payerReference.entityType == "contact" ? payer.middlename : null;
    parameters.dob = payerReference.entityType == "contact" && payer.birthdate != undefined && payer.birthdate != null ? payer.birthdate.substring(0, 10) : null;
    parameters.email = payer.emailaddress1;
    parameters.mobile = payer.telephone1;
    parameters.applyingascompany = null;
    parameters.companyname = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    parameters.currentstreet1 = address;
    parameters.currenttown = townOrCity;
    parameters.ddnoofcollections = payments.length;
    parameters.ddtotalamount = null;
    parameters.ddfirstamount = payments[0].rhs_amount;
    parameters.ddlastamount = payments[payments.length - 1].rhs_amount;
    parameters.ddplaninterval = 1;
    parameters.ddplantype = /*paymentFrequency == 120000002*//*Monthly*/ payments.length > 1 ? "Monthly" : "Yearly";
    parameters.dddebtorreference = null;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddplanaltreference = null;
    parameters.ddplanendbydate = null;
    parameters.ddprofilename  = null;
    parameters.ptxprofilename = null;
    parameters.giftaid= null;
    parameters.ttl = null;
    parameters.expirationtimer = null;
    parameters.callbackurl = ptxCallbackURL;
    parameters.redirecturl = null;
    //#endregion

    for (let parameterName in parameters) {
        if(parameters[parameterName] != undefined && parameters[parameterName] != null) {
            if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?")
                ptxPaymentUrl += "&";
            ptxPaymentUrl += `${parameterName}=${parameters[parameterName]}`;
        }
    }

    Xrm.Navigation.openUrl(ptxPaymentUrl);

    // Confirm PTX payment
    let alertStrings = { title: "PTX Payment", text: "Have you finished PTX payment?", confirmButtonLabel: "Yes" };
    await Xrm.Navigation.openAlertDialog(alertStrings);

    let directDebitDetail = await RHSScripts.GiftPack.RetrieveDirectDebitDetail(parameters.ddplanreference);
    if (directDebitDetail == undefined || directDebitDetail == null) {
        // Delay 15 seconds and recheck again
        await RHSScripts.GiftPack.Delay(15000);
        directDebitDetail = await RHSScripts.GiftPack.RetrieveDirectDebitDetail(parameters.ddplanreference);
        
        if (directDebitDetail == undefined || directDebitDetail == null)
            throw Error("Stripe Transaction Failed");
    }
}

RHSScripts.GiftPack.RetrieveAppSettingValueByName = async function (name) {
    let appSettingValue = null;
    let entityLogicalName = "rhs_appsettings";
    let options = `?$select=rhs_name,rhs_value&$filter=(rhs_name eq '${name}' and statecode eq 0)`;

    let appSettings = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (appSettings != undefined && appSettings != null && appSettings.length > 0)
        appSettingValue = appSettings[0].rhs_value;

    return appSettingValue
}

RHSScripts.GiftPack.RetrieveDirectDebitDetail = async function (reference) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=rhs_reference eq '${reference}'&$top=1`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.GiftPack.Delay = function (ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
//#endregion