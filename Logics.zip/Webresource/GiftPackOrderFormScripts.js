if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.GiftPackOrder) === "undefined") { RHSScripts.GiftPackOrder = {}; }

RHSScripts.GiftPackOrder.OnLoad = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    RHSScripts.GiftPackOrder.filterPaymentMethodOptions(executionContext);


    RHSScripts.GiftPackOrder.handleDeliveryContactRequirement(formContext);
}

RHSScripts.GiftPackOrder.OnChangeChannel = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    RHSScripts.GiftPackOrder.handleDeliveryContactRequirement(formContext);
}

RHSScripts.GiftPackOrder.OnSave = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    //Bug 80610
    //RHSScripts.GiftPackOrder.validateConsents(executionContext, formContext);
};

RHSScripts.GiftPackOrder.filterPaymentMethodOptions = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    // Get the 'Payment Method' field (rhs_paymentmethodcode)
    var paymentMethodField = formContext.getControl("rhs_paymentmethodcode");

    // List of option values that you want to keep (Cash, Cheque, Debit Card, Credit Card)
    var keepOptions = [120000014/*Credit Card (Phone)*/]; //, 844060000, 844060001, 120000001, 844060002

    // Get all current options in the global option set
    var options = paymentMethodField.getAttribute().getOptions();

    // Loop through the options and remove the ones that are not in the keepOptions array
    options.forEach(function (option) {
        if (keepOptions.indexOf(option.value) === -1) {
            paymentMethodField.removeOption(option.value);
        }
    });
}

RHSScripts.GiftPackOrder.handleDeliveryContactRequirement = function (formContext) {
    'use strict';

    var channelVal = formContext.getAttribute("rhs_channel")?.getValue();
    var deliveryContactAttr = formContext.getAttribute("rhs_deliverycontact");

    if (!deliveryContactAttr) return;

    if (channelVal === 120000006) {
        deliveryContactAttr.setRequiredLevel("none");
    } else {

        deliveryContactAttr.setRequiredLevel("required");
    }
}

RHSScripts.GiftPackOrder.validateConsents = function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();
    var eventArgs = executionContext.getEventArgs();

    if (!eventArgs) return;

    var cancelConsent = formContext.getAttribute("rhs_cancellationconsent")?.getValue();
    var gdprConsent = formContext.getAttribute("rhs_gdprconsent")?.getValue();

    if (cancelConsent && gdprConsent) {

        formContext.ui.clearFormNotification("consentWarning");
    } else {

        formContext.ui.setFormNotification(
            "Both GDPR Consent and Cancellation Consent must be set to Yes before saving.",
            "WARNING",
            "consentWarning"
        );
        eventArgs.preventDefault();
        return false;
    }
}

RHSScripts.GiftPackOrder.refreshWhenPostalChargeandTotalisReady = function (executionContext) {
    try {
        var formContext = executionContext.getFormContext();

        var postalCharges = formContext.getAttribute("rhs_postalcharges_v2")?.getValue();
        var totalPrice = formContext.getAttribute("rhs_totalprice_v2")?.getValue();

        if ((postalCharges != null && postalCharges !== "") ||
            (totalPrice != null && totalPrice !== "")) {

            formContext.ui.refreshRibbon();
        }
    }
    catch (e) {
        console.error("Error in refreshWhenPostalChargeandTotalisReady:", e);
    }
};
