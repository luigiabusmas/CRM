function filterPaymentMethodOptions(executionContext) {
    var formContext = executionContext.getFormContext();
    
    // Get the 'Payment Method' field (rhs_paymentmethodcode)
    var paymentMethodField = formContext.getControl("rhs_paymentmethod");
    let paymentMethodValue = formContext.getAttribute("rhs_paymentmethod").getValue();


    // List of option values that you want to keep (Cash, Cheque, Debit Card, Credit Card)
    var keepOptions = [120000014/*Credit Card (Phone)*/]; //, 844060000, 844060001, 120000001, 844060002
    if (paymentMethodValue && !keepOptions.includes(paymentMethodValue))
        keepOptions.push(paymentMethodValue);

    // Loop through the options and remove the ones that are not in the keepOptions array
    var options = paymentMethodField.getAttribute().getOptions();
    options.forEach(function(option) {
        if (keepOptions.indexOf(option.value) === -1) {
            paymentMethodField.removeOption(option.value);
        }
    });
}

function filterPaymentMethodOptionsRetail(executionContext) {
    var formContext = executionContext.getFormContext();
    
    // Get the 'Payment Method' field (rhs_paymentmethodcode)
    var paymentMethodField = formContext.getControl("rhs_paymentmethod");
    let paymentMethodValue = formContext.getAttribute("rhs_paymentmethod").getValue();

    // List of option values that you want to keep (Cash, Cheque, Debit Card, Credit Card)
    var keepOptions = [120000004]; //, 844060000, 844060001, 120000001, 844060002
    if (paymentMethodValue && !keepOptions.includes(paymentMethodValue))
        keepOptions.push(paymentMethodValue);

    // Loop through the options and remove the ones that are not in the keepOptions array
    var options = paymentMethodField.getAttribute().getOptions();
    options.forEach(function(option) {
        if (keepOptions.indexOf(option.value) === -1) {
            paymentMethodField.removeOption(option.value);
        }
    });
}