function checkStatusCodeOnSave(executionContext) {
    let formContext = executionContext.getFormContext();
    let statusCode = formContext.getAttribute("statuscode").getValue();

    // Check if the status code is 120000008 or 2
    if (statusCode === 120000008 || statusCode === 2) {
        // Display an alert dialog to the user
        formContext.ui.setFormNotification("Cancellation is Successful", "INFO", "cancellationSuccess");
    } else {
        // Clear the notification if the status code is changed to a different value
        formContext.ui.clearFormNotification("cancellationSuccess");
    }
}