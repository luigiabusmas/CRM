if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Subscription) === "undefined") { RHSScripts.Subscription = {}; }

//#region Form Functions
RHSScripts.Subscription.OnLoad = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    await RHSScripts.Subscription.ShowOrHideAdministrationSection(formContext);
    await RHSScripts.Subscription.FilterPaymentMethods(formContext);
    await RHSScripts.Subscription.ShowOrHideRenewalSections(executionContext); // need to run after FilterPaymentMethods syncronous run
}

RHSScripts.Subscription.OnSave = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    // await RHSScripts.Subscription.CalculateRenewalPayoutDate(executionContext); // Moved to SubscriptionUpdatePreOpsPlugin because it's not reflecting onSave.
}

RHSScripts.Subscription.OnSubscriptionProductChange = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    await RHSScripts.Subscription.FilterPaymentMethods(formContext);
}

RHSScripts.Subscription.OnCancellationTypeChange = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    await RHSScripts.Subscription.UpdateStatusBasedOnCancellationType(formContext);
}

RHSScripts.Subscription.OnInRenewalStageChange = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    await RHSScripts.Subscription.ShowOrHideRenewalSections(executionContext);
}

RHSScripts.Subscription.OnChannelChange = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    await RHSScripts.Subscription.FilterPaymentMethods(formContext);
}
//#endregion

//#region Helper Functions
RHSScripts.Subscription.ShowOrHideAdministrationSection = async function(formContext) {
    let cancelSubscription = formContext.getAttribute("rhs_cancelsubscription").getValue();
    let statusReason = formContext.getAttribute("statuscode").getValue();

    if (cancelSubscription == true || (statusReason == 2/*Cancelled*/ || statusReason == 120000004/*To be cancelled*/)) {
        formContext.ui.tabs.get("General").sections.get("Administration").setVisible(true);
    } else {
        formContext.ui.tabs.get("General").sections.get("Administration").setVisible(false);
    }
}

RHSScripts.Subscription.UpdateStatusBasedOnCancellationType = async function(formContext) {
    let cancellationType = formContext.getAttribute("rhs_subscriptioncancellationtype").getValue();
    switch(cancellationType) {
        case 120000000/*Now*/:
            formContext.getAttribute("statecode").setValue(1);
            formContext.getAttribute("statuscode").setValue(2);
            break;
        case 120000001/*At the end of Subscription*/:
            formContext.getAttribute("statecode").setValue(0);
            formContext.getAttribute("statuscode").setValue(120000004);
            break;
    }
}

RHSScripts.Subscription.FilterPaymentMethods = async function(formContext) {
    //let channel = formContext.getAttribute("rhs_channel")?.getValue();
    let channel = formContext.getAttribute("rhs_channel")?.getValue();
    let paymentMethodControl = formContext.getControl("rhs_paymentmethodcode");
    let paymentMethodValue = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let statusReason = formContext.getAttribute("statuscode").getValue();

    // Skip filter if phone channel
    //if (channel === 120000001/*Phone*/) {
    if (channel === 120000001/*Phone*/) {
        console.log("Filtering payment methods");

        // Retrieve product id
        let product = formContext.getAttribute("rhs_subscriptionproduct").getValue();
        if (!product) {
            console.log("No Product selected.");
            return;
        }
        let productId = product[0].id.replace("{", "").replace("}", "");

        // Fetch allowed payments from property
        let allowedPaymentsPropertyValue = await RHSScripts.Subscription.RetrieveProductProperty(productId);

        if (allowedPaymentsPropertyValue === null) {
            console.log("No Allowed Payments found for the selected Product.");
            return;
        }

        let allowedPayments = allowedPaymentsPropertyValue.split(";");

        // Filter the options based on the allowed payments
        let allOptions = [
            { value: 120000002, text: "Direct Debit" },
            //{ value: 844060002, text: "Card" },
            { value: 120000014, text: "Credit Card (Phone)" },
            { value: 844060000, text: "Cash" },
            { value: 844060001, text: "Cheque" },
            { value: 844060003, text: "Pwac" }
        ];

        let paymentMethodCodes = {
            DD: 120000002,        // Direct Debit
            //CARD: 844060002,        // CARD
            CARD: 120000014,        // Credit Card (Phone)
            CASH: 844060000,      // Cash
            CHEQUE: 844060001,  // Cheque
            PWAC: 844060003     // Pwac
        };

        let filteredOptions = allowedPayments.map((payment) => {
            let optionValue = paymentMethodCodes[payment];
            return allOptions.find((option) => option.value === optionValue);
        }).filter(Boolean); // Remove undefined/null values if any

        paymentMethodControl.clearOptions();
        filteredOptions.forEach((option) => {
            paymentMethodControl.addOption(option);
        });
    } else {
        console.log("Removing payment method filters.");

        let originalOptions = formContext.getAttribute("rhs_paymentmethodcode").getOptions();
        paymentMethodControl.clearOptions();
        originalOptions.forEach((option) => {
            paymentMethodControl.addOption(option);
        });
    }

    
    //Remove Card Payment Option
    paymentMethodControl.removeOption(844060002);

    // Return selected payment method if removed from filter
    if (paymentMethodValue && !paymentMethodControl.getOptions().find((option) => option.value == paymentMethodValue)) {
        if (statusReason == 1/*Active*/ || statusReason == 120000002/*Dormant*/) {
            paymentMethodControl.addOption(
                formContext.getAttribute("rhs_paymentmethodcode").getOptions().find((option) => option.value == paymentMethodValue)
            )
        } else {
            formContext.getAttribute("rhs_paymentmethodcode").setValue(null);
        }
    }

    console.log("Payment Methods filtered successfully:");
}

RHSScripts.Subscription.RetrieveProductProperty = async function(productId) {
    'use strict';
    let allowedPayments = null;

    let fetchData = {
        "name": "Allowed Payments",
        "productid": productId
    };

    let fetchXml = [
        "<fetch returntotalrecordcount='true'>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='dynamicpropertyid'/>",
        "    <attribute name='defaultvaluestring'/>",
        "    <attribute name='name'/>",
        "    <filter type='and'>",
        "      <condition attribute='name' operator='eq' value='", fetchData.name, "'/>",
        "    </filter>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='aa'>",
        "      <filter>",
        "        <condition attribute='associationstatus' operator='eq' value='0' />",
        "      </filter>",
        "      <link-entity name='product' from='productid' to='regardingobjectid' alias='ab'>",
        "        <filter>",
        "          <condition attribute='productid' operator='eq' value='", fetchData.productid, "'/>",
        "        </filter>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    // Execute the FetchXML query using the Web API
    await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + encodeURIComponent(fetchXml))
        .then(function (result) {
            if (result.entities.length > 0) {
                let dynamicProperty = result.entities[0];

                allowedPayments = dynamicProperty.defaultvaluestring;
                console.log("Allowed Payments: ", allowedPayments);

            } else {
                console.warn("No dynamic property found.");
            }
        })
        .catch(function (error) {
            console.error("Error retrieving dynamic property:", error.message);
        });

    return allowedPayments;
}

RHSScripts.Subscription.ValidateIfEarlyRenewal = function (formContext) {
    let renewalsStartDate = formContext.getAttribute("rhs_renewalsstartdate").getValue();

    let isEarlyRenewal = renewalsStartDate && new Date() < renewalsStartDate;
    return isEarlyRenewal;
}

RHSScripts.Subscription.ShowOrHideRenewalSections = async function (executionContext) {
    'use strict';

    var formContext = executionContext.getFormContext();
    var isInRenewalStage = formContext.getAttribute("rhs_inrenewalsstage").getValue();
    console.log("isInRenewalStage:", isInRenewalStage);

    if (isInRenewalStage === true) {
        formContext.ui.tabs.get("General").sections.get("General_section_9").setVisible(true);
        formContext.ui.tabs.get("General").sections.get("General_section_10").setVisible(true);
        formContext.getAttribute("rhs_renewalspaymentmethodcode").setRequiredLevel("required");

        // Will now allow renewal campain to be setup per bug #83318 requirement
        // if (RHSScripts.Subscription.ValidateIfEarlyRenewal(formContext)) {
        //     formContext.getControl("rhs_renewalscampaign").setVisible(false);
        // }

        await RHSScripts.Subscription.FilterRenewalPaymentMethods(executionContext);
    } else {
        formContext.ui.tabs.get("General").sections.get("General_section_9").setVisible(false);
        formContext.ui.tabs.get("General").sections.get("General_section_10").setVisible(false);

        formContext.getAttribute("rhs_renewalscampaign").setValue(null);
        formContext.getAttribute("rhs_renewalssubscriptionproduct").setValue(null);
        formContext.getAttribute("rhs_renewalspayer").setValue(null);

        formContext.getAttribute("rhs_renewalssubscriptionprice").setValue(null);
        formContext.getAttribute("rhs_renewalssubscriptionpricevalue").setValue(null);
        formContext.getAttribute("rhs_renewalpostalcharge").setValue(null);
        formContext.getAttribute("rhs_renewalstotalamount").setValue(null);
        formContext.getAttribute("rhs_renewalspaymentmethodcode").setValue(null);
        // formContext.getAttribute("rhs_isrenewalcontinuouspayment").setValue(false); //always false
        formContext.getAttribute("rhs_renewalpaymentschedule").setValue(null);
        formContext.getAttribute("rhs_renewalbillingfrequency").setValue(null);
    }
}

RHSScripts.Subscription.FilterRenewalPaymentMethods = async function (executionContext) {
    try {
        let formContext = executionContext.getFormContext();
        //let channel = formContext.getAttribute("rhs_channel")?.getValue();
        let channel = formContext.getAttribute("rhs_channel")?.getValue();
        let paymentMethodControl = formContext.getControl("rhs_renewalspaymentmethodcode");
        let paymentMethodValue = formContext.getAttribute("rhs_renewalspaymentmethodcode").getValue();
        let renewalStatus = formContext.getAttribute("rhs_renewalsstatus").getValue();

        //if (channel === 120000001/*Phone*/) {
        if (channel === 120000001/*Phone*/) {
            // Retrieve renewal product id
            let subscriptionProductId = formContext.getAttribute("rhs_renewalssubscriptionproduct").getValue();

            if (!subscriptionProductId) {
                console.log("No Subscription Product selected.");
                return;
            }

            let subscriptionProductGuid = subscriptionProductId[0].id.replace("{", "").replace("}", "");

            // Fetch allowed payments from property
            let allowedPaymentsPropertyValue = await RHSScripts.Subscription.RetrieveProductProperty(subscriptionProductGuid);
            console.log("Allowed payment product property:", allowedPaymentsPropertyValue);

            // Added a timeout to give time to retrieve all allowed payments for a membership product
            setTimeout(() => {
                if (allowedPaymentsPropertyValue === null) {
                    console.log("No Allowed Payments found for the selected Product.");
                    return;
                }

                let allowedPayments = [];
                if (typeof allowedPaymentsPropertyValue === "string") {
                    allowedPayments = allowedPaymentsPropertyValue.split(";");
                    console.log("Allowed payments from property:", allowedPayments);
                } else {
                    console.warn("Invalid or missing allowedPaymentsPropertyValue:", allowedPaymentsPropertyValue);
                    return;
                }

                // Filter the options based on the allowed payments
                let allOptions = [
                    { value: 120000002, text: "Direct Debit" },
                    //{ value: 844060002, text: "Card" },
                    { value: 120000014, text: "Credit Card (Phone)" },
                    { value: 844060000, text: "Cash" },
                    { value: 844060001, text: "Cheque" },
                    { value: 844060003, text: "Pwac" }
                ];

                let paymentMethodCodes = {
                    DD: 120000002,        // Direct Debit
                    //CARD: 844060002,        // CARD
                    CARD: 120000014,        // Credit Card (Phone)
                    CASH: 844060000,      // Cash
                    CHEQUE: 844060001,   // Cheque
                    PWAC: 844060003     // Pwac
                };

                let filteredOptions = allowedPayments.map((payment) => {
                    let optionValue = paymentMethodCodes[payment];
                    return allOptions.find((option) => option.value === optionValue);
                }).filter(Boolean); // Remove undefined/null values if any

                // If early renewal
                if (paymentMethodValue != 844060005/*Gift Pack*/ && RHSScripts.Subscription.ValidateIfEarlyRenewal(formContext)) {
                    filteredOptions = filteredOptions.filter(option =>
                        //option.value == 844060000/*Cash*/ || 
                        option.value == 120000014/*Credit Card*/ //|| 
                        //option.value == 844060002/*Card*/
                    );
                }

                // Set Renewal Payment Method choices
                paymentMethodControl.clearOptions();

                filteredOptions.forEach((option) => {
                    paymentMethodControl.addOption(option);
                });

                // Force Renewals Payment Method optionset field to refresh
                paymentMethodControl.setFocus();


                // Added a timeout to give time to load filtered payments on the Renewals Payment Method optionset field
                setTimeout(() => {
                    formContext.ui.controls.get("rhs_renewalspaymentmethodcode").setFocus(false);
                }, 50);
            }, 3000);
        } else {
            console.log("Removing renewal payment method filters.");

            // Added a timeout to give time to load original payment options on the optionset field
            setTimeout(() => {
                let originalOptions = formContext.getAttribute("rhs_renewalspaymentmethodcode").getOptions();
                paymentMethodControl.clearOptions();
                originalOptions.forEach((option) => {
                paymentMethodControl.addOption(option);
                });

                // Force Renewals Payment Method optionset field to refresh
                paymentMethodControl.setFocus();

                formContext.ui.controls.get("rhs_renewalspaymentmethodcode").setFocus(false);
            }, 50);
        }

        // Return selected payment method if removed from filter
        if (paymentMethodValue && !paymentMethodControl.getOptions().find((option) => option.value == paymentMethodValue)) {
            if (renewalStatus == 120000001/*Renewed*/) {
                paymentMethodControl.addOption(
                    formContext.getAttribute("rhs_renewalspaymentmethodcode").getOptions().find((option) => option.value == paymentMethodValue)
                )
            } else {
                formContext.getAttribute("rhs_renewalspaymentmethodcode").setValue(null);
            }
        }

        console.log("Renewal Payment Methods filtered successfully.");
    } catch (error) {
        console.log("Error in filtering Renewal Payment Methods:", error);
    }
}

/*
RHSScripts.Subscription.CalculateRenewalPayoutDate = async function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();

    // Verify if fields exist on the form
    if (!formContext.getAttribute("rhs_renewalspaymentmethod") || !formContext.getAttribute("rhs_renewalpaymentschedule")) {
        console.error("Error: Required fields (rhs_renewalspaymentmethod or rhs_renewalpaymentschedule) are missing from the form.");
        return;
    }

    let paymentMethodField = formContext.getAttribute("rhs_paymentmethod");
    let renewalPaymentMethodField = formContext.getAttribute("rhs_renewalspaymentmethod");
    let renewalPayoutField = formContext.getAttribute("rhs_renewalpaymentschedule");
    let endDateField = formContext.getAttribute("rhs_enddate");

    // Get Payment Method value (OptionSet)
    let renewalPaymentMethod = renewalPaymentMethodField.getValue();
    let paymentMethod = paymentMethodField.getValue();

    // Only populate if Payment Method is Direct Debit (120000002)
    if (renewalPaymentMethod === 120000002) {
        var endDate = endDateField.getValue();
        var now = new Date();
        var nextPayoutDate = endDate > now ? new Date(endDate) : new Date(now);
        nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
        console.log("Initial Start Date: " + nextPayoutDate.toISOString());

        if (paymentMethod != renewalPaymentMethod)
        {
            var workingDaysAdded = 0;

            // Loop until 10 working days
            while (workingDaysAdded < 10) {
                nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
                let dayOfWeek = nextPayoutDate.getDay();

                // Skip weekends
                if (dayOfWeek !== 0 && dayOfWeek !== 6) {
                    let isHoliday = await RHSScripts.Subscription.HasHolidays(nextPayoutDate); //on SubscriptionCommandScripts.js
                    if (!isHoliday) {
                        workingDaysAdded++;
                    }
                }
            }
        }

        // Set the calculated payout date
        renewalPayoutField.setSubmitMode("always");
        renewalPayoutField.setValue(nextPayoutDate);
    }
}
    */

RHSScripts.Subscription.HasHolidays = async function (nextPayoutDate) {
    nextPayoutDate.setHours(0, 0, 0, 0);
    let nextPayoutDateString = nextPayoutDate.toISOString().split("T")[0];

    let entityLogicalName = "calendar";
    let calendarName = "UK Holidays";
    let query = `?$select=calendarid&$filter=name eq '${calendarName}'`;

    try {
        // Retrieve the calendar record
        let calendars = await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, query);
        if (!calendars || calendars.entities.length === 0) {
            return false;
        }

        let calendarId = calendars.entities[0].calendarid;
        let expandQuery = `?$select=calendarid&$expand=calendar_calendar_rules($select=starttime)`;
        let calendar = await Xrm.WebApi.retrieveRecord(entityLogicalName, calendarId, expandQuery);

        // Check if there are any holidays in the calendar
        if (!calendar.calendar_calendar_rules || calendar.calendar_calendar_rules.length === 0) {
            return false;
        }
        // Convert holiday start times to YYYY-MM-DD format for comparison
        let holidays = calendar.calendar_calendar_rules.map(rule => {
            let holidayDate = new Date(rule.starttime);
            if (isNaN(holidayDate)) {
                return null;
            }

            holidayDate.setHours(0, 0, 0, 0);
            return holidayDate.toISOString().split("T")[0];
        }).filter(Boolean);
        return holidays.includes(nextPayoutDateString);
    } catch (error) {
        console.error("Error retrieving calendar with rules:", error);
        return false;
    }
}
//#endregion