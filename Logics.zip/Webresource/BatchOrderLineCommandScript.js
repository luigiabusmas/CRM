if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.BatchOrderLine) === "undefined") { RHSScripts.BatchOrderLine = {}; }

RHSScripts.BatchOrderLine.DeleteLineOnForm = function (primaryControl) {
    var recordGUID = primaryControl.data.entity.getId().replace(/[{}]/g, "");
    var pageInput = {
        pageType: "custom",
        name: "rhs_confirmbatchorderlinedeletion_8f7f3",
        recordId: recordGUID
    };
    var navigationOptions = {
        target: 2,
        position: 1,
        width: { value: 450, unit: "px" },
        height: { value: 380, unit: "px" },
        title: "Confirm Batch Order Line Deletion"
    };
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function () {
                //Add Delay to give way for Power Automate to delete record
                setTimeout(function () {
                    Xrm.WebApi.retrieveRecord("rhs_batchorderline", recordGUID, "?$select=rhs_batchorderlineid").then(
                        function success(result) {
                            if (!result || !result.rhs_batchorderlineid) {
                                primaryControl.ui.close();
                            }
                        },
                        function error(err) {
                            primaryControl.ui.close();
                        }
                    );
                }, 2000);

            }
        ).catch(
            function (error) {
            }
        );
};

RHSScripts.BatchOrderLine.DeleteLineSubgrid = function (selectedItemIds, selectedControl) {
    if (!Array.isArray(selectedItemIds) || selectedItemIds.length === 0) {
        Xrm.Navigation.openAlertDialog({ text: "No records selected." });
        return;
    }

    var pageInput = {
        pageType: "custom",
        name: "rhs_confirmbatchorderlinebulkdeletion_a740a",
        recordId: selectedItemIds
    };
    var navigationOptions = {
        target: 2,
        position: 1,
        width: { value: 450, unit: "px" },
        height: { value: 380, unit: "px" },
        title: "Confirm Batch Order Line Deletion"
    };

    var fetchPromises = selectedItemIds.map(function (id) {
        return Xrm.WebApi.retrieveRecord("rhs_batchorderline", id, "?$select=statuscode");
    });

    Promise.all(fetchPromises).then(function (records) {
        var invalidRecords = records.filter(function (record) {
            return record.statuscode != 1 && record.statuscode != 120000001;
        });

        if (invalidRecords.length > 0) {
            Xrm.Navigation.openAlertDialog({
                text: "You are unable to proceed as one or more of the selected records are not in an appropriate state."
            });
            return;
        }

        Xrm.Navigation.navigateTo(pageInput, navigationOptions)
            .then(
                function () {
                    selectedControl.refresh();
                }
            ).catch(
                function (error) {
                }
            );
    }).catch(function () {
        Xrm.Navigation.openAlertDialog({ text: "Failed to retrieve records." });
    });
};