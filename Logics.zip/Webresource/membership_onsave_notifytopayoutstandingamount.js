const PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID = "PayOutstandingAmountNotification";

async function notifyToPayOutstandingAmount(formExecutionContext) {
    let formContext = formExecutionContext.getFormContext();
    let createdon = formContext.getAttribute("createdon").getValue();

    if (createdon != null) {
        let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
        let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
        let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
        let payer = formContext.getAttribute("rhs_payerv2").getValue();

        let membershipPreImage = await Xrm.WebApi.retrieveRecord("msnfp_membership", membershipId, "?$select=_rhs_payerv2_value,rhs_paymentmethod");

        if (paymentMethod != 844060005/*Gift Pack*/ && outstandingAmount != null && outstandingAmount > 0 &&
            ((membershipPreImage.rhs_paymentmethod != null && paymentMethod != null && membershipPreImage.rhs_paymentmethod != paymentMethod) ||
                (membershipPreImage._rhs_payerv2_value != null && payer != null && membershipPreImage._rhs_payerv2_value != payer.id))) {
            try {
                formContext.ui.clearFormNotification(PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID);
            } catch {
                // do nothing
            } finally {
                formContext.ui.setFormNotification("Please pay for the remaining outstanding amount.", "INFO", PAY_OUTSTANDING_AMOUNT_NOTIFICATION_ID);
            }
        }
    }
}