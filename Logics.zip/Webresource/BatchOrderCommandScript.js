if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.BatchOrder) === "undefined") { RHSScripts.BatchOrder = {}; }


RHSScripts.BatchOrder.DeleteBatchOnForm = function (primaryControl) {
    var recordGUID = primaryControl.data.entity.getId().replace(/[{}]/g, "");
    var pageInput = {
        pageType: "custom",
        name: "rhs_batchordercustomdeletepage_89cca",
        recordId: recordGUID
    };
    var navigationOptions = {
        target: 2,
        position: 1,
        width: { value: 450, unit: "px" },
        height: { value: 380, unit: "px" }
    };
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function () {
                //Add Delay to give way for Power Automate to delete record
                setTimeout(function () {
                    Xrm.WebApi.retrieveRecord("rhs_batchorder", recordGUID, "?$select=rhs_batchorderid").then(
                        function success(result) {
                            if (!result || !result.rhs_batchorderid) {
                                primaryControl.ui.close();
                            }
                        },
                        function error(err) {
                            primaryControl.ui.close();
                        }
                    );
                }, 2000);
            }
        ).catch(
            function (error) {
            }
        );
};


RHSScripts.BatchOrder.ApproveRejectOnForm = function (primaryControl) {
    var recordGUID = primaryControl.data.entity.getId().replace(/[{}]/g, "");
    var pageInput = {
        pageType: "custom",
        name: "rhs_batchorderapprover_77b4a",
        recordId: recordGUID
    };
    var navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" }
    };
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function () {
                primaryControl.data.refresh();
            }
        ).catch(
            function (error) {
            }
        );
};

RHSScripts.BatchOrder.UserIsManagerandTeamLeadRole = function (primaryControl) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;

    if (primaryControl.ui.getFormType() === 1) {
        return false;
    }

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers" && primaryControl.getAttribute("statuscode").getValue() == 1) {
            return true;
        }
    }

    return false;
};

RHSScripts.BatchOrder.UserIsManagerandTeamLeadRoleAndBatchforApprovalReject = function (primaryControl) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers" && primaryControl.getAttribute("statuscode").getValue() == 120000001) {
            return true;
        }
    }

    return false;
};