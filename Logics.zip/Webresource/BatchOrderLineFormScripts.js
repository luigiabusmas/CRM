if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.BatchOrderLine) === "undefined") { RHSScripts.BatchOrderLine = {}; }

//Global Variable
var isRenewal = false;
var isPatronProduct = false;

/* Global Constants */
const PRODUCT_LOOKUP_VIEWS = {
    Membership_Products_Lookup: "Membership Products Lookup",
    Subscription_Products_Lookup: "Subscriptions Products Lookup",
    Gift_Pack_Products_Lookup: "Gift Pack Products Lookup"
};

// Batch Order Type
const TYPE = {
    NewMembership: 120000000,
    MembershipRenewal: 120000001,
    NewSubscription: 120000002,
    SubscriptionRenewal: 120000003,
    Donations: 120000004,
    GiftPacks: 120000005,
};

//#region Event Functions
RHSScripts.BatchOrderLine.OnLoad = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
    RHSScripts.BatchOrderLine.SetPaymentDate(executionContext);

    //commented bug78556
    //await RHSScripts.BatchOrderLine.showHideInelligibleForGiftAidWhenNotElligible(formContext);

    // Pre-populates 'Amount Paid' with the 'Total Amount' value (BUG 80682).
    RHSScripts.BatchOrderLine.SetAmountPaidToTotalAmount(executionContext);

    await RHSScripts.BatchOrderLine.OnOverpaymentCalculation(executionContext); //Causing bug 78534

    //RHSScripts.BatchOrderLine.HideSections(formContext);

    // let batchOrder = await RHSScripts.BatchOrderLine.RetrieveBatchOrder(formContext);
    // if (!batchOrder) { return; }

    RHSScripts.BatchOrderLine.showHidePaymentMethodFields(formContext);
    await RHSScripts.BatchOrderLine.SetProductLookupViewByType(formContext);

    //await RHSScripts.BatchOrderLine.CopyBatchOrderValuesToBatchOrderLineOnCreation(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoMembershipDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoDonationDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic(formContext, batchOrder);
}

RHSScripts.BatchOrderLine.OnSave = async function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    RHSScripts.BatchOrderLine.ValidateRenewalsOnSave(executionContext);
    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
}

RHSScripts.BatchOrderLine.OnBatchOrderChange = async function (executionContext) { // should be same with OnLoad function
    let formContext = executionContext.getFormContext();

    // RHSScripts.BatchOrderLine.HideSections(formContext);

    // let batchOrder = await RHSScripts.BatchOrderLine.RetrieveBatchOrder(formContext);
    // if (!batchOrder) { return; }

    // await RHSScripts.BatchOrderLine.CopyBatchOrderValuesToBatchOrderLineOnCreation(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoMembershipDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoDonationDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic(formContext, batchOrder);
}

RHSScripts.BatchOrderLine.OnMembershipCampaignChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    // let batchOrder = await RHSScripts.BatchOrderLine.RetrieveBatchOrder(formContext);
    // if (!batchOrder) { return; }
    // await RHSScripts.BatchOrderLine.DoMembershipDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoDonationDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic(formContext, batchOrder);

    // await RHSScripts.BatchOrderLine.CalculateTotalAmount(formContext);
    await RHSScripts.BatchOrderLine.SetPricings(formContext);
}

RHSScripts.BatchOrderLine.OnMembershipProductChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    // let batchOrder = await RHSScripts.BatchOrderLine.RetrieveBatchOrder(formContext);
    // if (!batchOrder) { return; }
    // await RHSScripts.BatchOrderLine.DoMembershipDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoDonationDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic(formContext, batchOrder);
}

RHSScripts.BatchOrderLine.OnMembershipTotalAmountChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    // let batchOrder = await RHSScripts.BatchOrderLine.RetrieveBatchOrder(formContext);
    // if (!batchOrder) { return; }
    // await RHSScripts.BatchOrderLine.DoDonationDetailsLogic(formContext, batchOrder);
    // await RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic(formContext, batchOrder);
}

RHSScripts.BatchOrderLine.OnCampaignChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
    await RHSScripts.BatchOrderLine.SetPricings(formContext);
}

// Event handler for the Type field
RHSScripts.BatchOrderLine.OnTypeFieldChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
    await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForMembersOfNewMembership(formContext);
    await RHSScripts.BatchOrderLine.SetPostalCharge(formContext);
    await RHSScripts.BatchOrderLine.SetPricings(formContext);
    await RHSScripts.BatchOrderLine.SetProductLookupViewByType(formContext);
}

// Event handler for the Payment Method field
RHSScripts.BatchOrderLine.OnPaymentMethodChange = function (executionContext) {
    let formContext = executionContext.getFormContext();
    RHSScripts.BatchOrderLine.showHidePaymentMethodFields(formContext);
}

// Event handler for the Total Amount field
RHSScripts.BatchOrderLine.OnTotalAmountChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();

    // Sync the Amount Paid field with the Total Amount
    RHSScripts.BatchOrderLine.SetAmountPaidToTotalAmount(executionContext);
}

RHSScripts.BatchOrderLine.OnPrimaryContactChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    let type = formContext.getAttribute("rhs_type").getValue();

    switch (type) {
        case 120000000 /*New Membership*/:
            await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForPrimaryContact(formContext);
            break;
        case 120000002 /*New Subscription*/:
        case 120000003 /*Subscription Renewal*/:
        case 120000005 /*Gift Pack Purchase*/:
            await RHSScripts.BatchOrderLine.SetPostalCharge(formContext);
            await RHSScripts.BatchOrderLine.SetTotalAmount(formContext);
            break;
    }
}

RHSScripts.BatchOrderLine.OnSecondaryMemberChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    let type = formContext.getAttribute("rhs_type").getValue();

    if (type == 120000000 /*New Membership*/ || type == 120000001 /*Membership Renewal*/) {
        await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForSecondaryContact(formContext);
    }
}

// Event handler for the Product field
RHSScripts.BatchOrderLine.OnProductChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    //commented bug78556
    //await RHSScripts.BatchOrderLine.showHideInelligibleForGiftAidWhenNotElligible(formContext);
    await RHSScripts.BatchOrderLine.SetPricings(formContext);
    let type = formContext.getAttribute("rhs_type").getValue();

    switch (type) {
        case 120000000 /*New Membership*/:
            await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForPrimaryContact(formContext);
            break;
    }
    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
}

RHSScripts.BatchOrderLine.OnDeliveryAddress = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    let type = formContext.getAttribute("rhs_type").getValue();

    switch (type) {
        case 120000005 /*Gift Pack Purchase*/:
            await RHSScripts.BatchOrderLine.SetPostalCharge(formContext);
            await RHSScripts.BatchOrderLine.SetTotalAmount(formContext);
            break;
    }
}

// Event handler for 'Have you been referred?' field
RHSScripts.BatchOrderLine.OnReferredChange = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    await RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections(formContext);
}

function clearRenewalFields(formContext) {
    const fields = [
        "rhs_payer", "rhs_campaign", "rhs_paymentmethodcode", "rhs_product",
        "rhs_primarycontact", "rhs_pricelist", "rhs_productprice", "rhs_totalamount",
        "rhs_secondardmembership" // keep your existing logical name
    ];
    fields.forEach(f => formContext.getAttribute(f)?.setValue(null));
}

RHSScripts.BatchOrderLine.OnMembershipChange = async function (executionContext) {
    const formContext = executionContext.getFormContext();
    const typeValue = formContext.getAttribute("rhs_type").getValue();
    if (typeValue !== 120000001) return; // Membership Renewal only

    // 1) Get lookup first; if cleared -> clear mapped fields and exit
    const membershipLookup = formContext.getAttribute("rhs_membershipid").getValue();
    if (!membershipLookup || membershipLookup.length === 0) {
        clearRenewalFields(formContext);
        return;
    }

    const membershipId = membershipLookup[0].id.replace(/[{}]/g, "");
    // Trust UCI to give the correct entity logical name (e.g., "msnfp_membership")
    const entityLogicalName = membershipLookup[0].entityType;

    try {
        // 2) Retrieve record incl. rhs_inrenewalsstage
        const membership = await Xrm.WebApi.retrieveRecord(
            entityLogicalName,
            membershipId,
            "?$select=rhs_inrenewalsstage,_rhs_payerv2_value,_rhs_renewalscampaign_value,rhs_renewalspaymentmethod," +
            "_rhs_thirdpartypaymenttype_value,_rhs_renewalsmembershipproduct_value,_rhs_contact_value," +
            "_rhs_renewalspricelist_value,rhs_renewalsmembershipprice,rhs_renewalstotalamount,_rhs_member2_value"
        );

        // 3) If not in renewal stage -> clear and exit
        if (membership.rhs_inrenewalsstage === false) {
            clearRenewalFields(formContext);
            return;
        }

        // 4) Map fields
        if (membership._rhs_payerv2_value) {
            formContext.getAttribute("rhs_payer").setValue([{
                id: membership._rhs_payerv2_value,
                entityType: membership["_rhs_payerv2_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_payerv2_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            formContext.getAttribute("rhs_payer").fireOnChange();
        }
        if (membership._rhs_renewalscampaign_value) {
            formContext.getAttribute("rhs_campaign").setValue([{
                id: membership._rhs_renewalscampaign_value,
                entityType: membership["_rhs_renewalscampaign_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_renewalscampaign_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            formContext.getAttribute("rhs_campaign").fireOnChange();
        }
        /*if (membership.rhs_renewalspaymentmethod != null) {
            formContext.getAttribute("rhs_paymentmethod").setValue(membership.rhs_renewalspaymentmethod);
            formContext.getAttribute("rhs_paymentmethod").fireOnChange();
        }*/
        if (membership._rhs_thirdpartypaymenttype_value) {
            formContext.getAttribute("rhs_thirdpartypaymenttype")?.setValue([{
                id: membership._rhs_thirdpartypaymenttype_value,
                entityType: membership["_rhs_thirdpartypaymenttype_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_thirdpartypaymenttype_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            formContext.getAttribute("rhs_thirdpartypaymenttype").fireOnChange();
        }
        if (membership._rhs_renewalsmembershipproduct_value) {
            formContext.getAttribute("rhs_product").setValue([{
                id: membership._rhs_renewalsmembershipproduct_value,
                entityType: membership["_rhs_renewalsmembershipproduct_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_renewalsmembershipproduct_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            formContext.getAttribute("rhs_product").fireOnChange();
        }
        if (membership._rhs_contact_value) {
            formContext.getAttribute("rhs_primarycontact").setValue([{
                id: membership._rhs_contact_value,
                entityType: membership["_rhs_contact_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_contact_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            //formContext.getAttribute("rhs_primarycontact").fireOnChange(); // commented to prevent validation on renewal
        }
        if (membership._rhs_renewalspricelist_value) {
            formContext.getAttribute("rhs_pricelist").setValue([{
                id: membership._rhs_renewalspricelist_value,
                entityType: membership["_rhs_renewalspricelist_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_renewalspricelist_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            formContext.getAttribute("rhs_pricelist").fireOnChange();
        }
        if (membership.rhs_renewalsmembershipprice != null) {
            formContext.getAttribute("rhs_productprice").setValue(membership.rhs_renewalsmembershipprice);
            formContext.getAttribute("rhs_productprice").fireOnChange();
        }
        if (membership.rhs_renewalstotalamount != null) {
            formContext.getAttribute("rhs_totalamount").setValue(membership.rhs_renewalstotalamount);
            formContext.getAttribute("rhs_totalamount").fireOnChange();
        }
        if (membership._rhs_member2_value) {
            formContext.getAttribute("rhs_secondarymember")?.setValue([{
                id: membership._rhs_member2_value,
                entityType: membership["_rhs_member2_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                name: membership["_rhs_member2_value@OData.Community.Display.V1.FormattedValue"]
            }]);
            //formContext.getAttribute("rhs_secondarymember").fireOnChange(); // commented to prevent validation on renewal
        }
    } catch (e) {
        console.error("OnMembershipChange retrieve error:", e);
    }
};


RHSScripts.BatchOrderLine.OnSubscriptionChange = async function (executionContext) {
    const formContext = executionContext.getFormContext();
    const typeValue = formContext.getAttribute("rhs_type").getValue();
    if (typeValue !== 120000003) return; // Subscription Renewal only

    // 1) Get lookup first; if cleared -> clear mapped fields and exit
    const subscriptionLookup = formContext.getAttribute("rhs_subscription").getValue();
    if (!subscriptionLookup || subscriptionLookup.length === 0) {
        clearRenewalFields(formContext);
        return;
    }

    const subscriptionId = subscriptionLookup[0].id.replace(/[{}]/g, "");
    const entityLogicalName = subscriptionLookup[0].entityType;

    try {
        // 2) Retrieve incl. rhs_inrenewalsstage
        const subscription = await Xrm.WebApi.retrieveRecord(
            entityLogicalName,
            subscriptionId,
            "?$select=rhs_inrenewalsstage,_rhs_subscriptionpayer_value,_rhs_renewalscampaign_value,rhs_renewalspaymentmethod," +
            "_rhs_renewalssubscriptionproduct_value,_rhs_recipient_value,_rhs_renewalssubscriptionprice_value," +
            "rhs_renewalssubscriptionpricevalue,rhs_renewalstotalamount"
        );

        // 3) If not in renewal stage -> clear and exit
        if (subscription.rhs_inrenewalsstage === false) {
            clearRenewalFields(formContext);
            return;
        }

        // 4) Map fields helper
        const setLookup = (attr, idField, nameAnno, typeAnno, fireOnChange = true) => {
            const id = subscription[idField];
            if (!id) return;
            let name = subscription[nameAnno] || "";
            let et = subscription[typeAnno];

            if (!et) {
                const existing = formContext.getAttribute(attr)?.getValue();
                if (existing && existing.length > 0) et = existing[0].entityType;
            }
            if (!et) return;

            formContext.getAttribute(attr).setValue([{ id, entityType: et, name }]);
            if (fireOnChange) formContext.getAttribute(attr).fireOnChange()
        };

        setLookup("rhs_payer",
            "_rhs_subscriptionpayer_value",
            "_rhs_subscriptionpayer_value@OData.Community.Display.V1.FormattedValue",
            "_rhs_subscriptionpayer_value@Microsoft.Dynamics.CRM.lookuplogicalname",
            false);

        setLookup("rhs_campaign",
            "_rhs_renewalscampaign_value",
            "_rhs_renewalscampaign_value@OData.Community.Display.V1.FormattedValue",
            "_rhs_renewalscampaign_value@Microsoft.Dynamics.CRM.lookuplogicalname");

        /*if (subscription.rhs_renewalspaymentmethod != null) {
            formContext.getAttribute("rhs_paymentmethod").setValue(subscription.rhs_renewalspaymentmethod);
            formContext.getAttribute("rhs_paymentmethod").fireOnChange();
        }*/

        setLookup("rhs_product",
            "_rhs_renewalssubscriptionproduct_value",
            "_rhs_renewalssubscriptionproduct_value@OData.Community.Display.V1.FormattedValue",
            "_rhs_renewalssubscriptionproduct_value@Microsoft.Dynamics.CRM.lookuplogicalname");

        setLookup("rhs_primarycontact",
            "_rhs_recipient_value",
            "_rhs_recipient_value@OData.Community.Display.V1.FormattedValue",
            "_rhs_recipient_value@Microsoft.Dynamics.CRM.lookuplogicalname",
            false);

        setLookup("rhs_pricelist",
            "_rhs_renewalssubscriptionprice_value",
            "_rhs_renewalssubscriptionprice_value@OData.Community.Display.V1.FormattedValue",
            "_rhs_renewalssubscriptionprice_value@Microsoft.Dynamics.CRM.lookuplogicalname");

        if (subscription.rhs_renewalssubscriptionpricevalue != null) {
            formContext.getAttribute("rhs_productprice").setValue(subscription.rhs_renewalssubscriptionpricevalue);
        }
        if (subscription.rhs_renewalstotalamount != null) {
            formContext.getAttribute("rhs_totalamount").setValue(subscription.rhs_renewalstotalamount);
        }
    } catch (e) {
        console.error("OnSubscriptionChange retrieve error:", e);
    }
};


RHSScripts.BatchOrderLine.OnOverpaymentCalculation = async function (executionContext) { // Causing bug 78534. DOn't know why or where.
    let formContext = executionContext.getFormContext();

    const typeValue = formContext.getAttribute("rhs_type").getValue();
    const amountPaid = formContext.getAttribute("rhs_amountpaid")?.getValue() || 0;
    const totalAmount = formContext.getAttribute("rhs_totalamount")?.getValue() || 0;

    // === 1. Reset Donation/Write-off sections and values ===
    let donationSection = formContext.ui.tabs.get("General").sections.get("General_section_Donation");
    let writeoffSection = formContext.ui.tabs.get("General").sections.get("General_section_Writeoff");

    //  if (donationSection) donationSection.setVisible(false);
    //  if (writeoffSection) writeoffSection.setVisible(false);

    // === 2. Exit early if lookup is cleared ===
    if (typeValue === 120000001 && (!formContext.getAttribute("rhs_membershipid").getValue()?.length)) return;
    if (typeValue === 120000003 && (!formContext.getAttribute("rhs_subscription").getValue()?.length)) return;

    // === 3. Skip if it's not Membership/Subscription Renewal ===
    if (typeValue !== 120000004) {
        formContext.getAttribute("rhs_donationamount")?.setValue(null);
        formContext.getAttribute("rhs_donationcampaign")?.setValue(null);
        formContext.getAttribute("rhs_writeoffamount")?.setValue(null);
    }
    else if (typeValue === 120000004) {
        let donationAmount = amountPaid;
        formContext.getAttribute("rhs_donationamount").setValue(donationAmount);
        let generalTabSections = RHSScripts.BatchOrderLine.getGeneralTabSections(formContext);
        if (generalTabSections.MEMBERSHIP_DETAILS) {
            generalTabSections.MEMBERSHIP_DETAILS.setVisible(false);
        }
        return;
    }
    // === 4. Renewal Stage validation ===
    if (typeValue === 120000001) { // Membership Renewal
        let membership = formContext.getAttribute("rhs_membershipid").getValue();
        if (membership && membership.length > 0) {
            let membershipId = membership[0].id.replace(/[{}]/g, "");
            try {
                let record = await Xrm.WebApi.retrieveRecord("rhs_membership", membershipId, "?$select=rhs_inrenewalsstage");
                if (record.rhs_inrenewalsstage === false) {
                    Xrm.Navigation.openAlertDialog({ text: "The selected Membership is not in the renewal stage." });

                    // Clear all dependent fields
                    formContext.getAttribute("rhs_membershipid").setValue(null);
                    formContext.getAttribute("rhs_payer")?.setValue(null);
                    formContext.getAttribute("rhs_campaign")?.setValue(null);
                    formContext.getAttribute("rhs_paymentmethodcode")?.setValue(null);
                    formContext.getAttribute("rhs_product")?.setValue(null);
                    formContext.getAttribute("rhs_primarycontact")?.setValue(null);
                    formContext.getAttribute("rhs_pricelist")?.setValue(null);
                    formContext.getAttribute("rhs_productprice")?.setValue(null);
                    formContext.getAttribute("rhs_totalamount")?.setValue(null);
                    formContext.getAttribute("rhs_secondardmembership")?.setValue(null);
                    formContext.getAttribute("rhs_thirdpartypaymenttype")?.setValue(null);
                    return;
                }
            } catch (e) {
                console.error("Error checking membership renewal stage:", e);
            }
        }
    }

    if (typeValue === 120000003) { // Subscription Renewal
        let subscription = formContext.getAttribute("rhs_subscription").getValue();
        if (subscription && subscription.length > 0) {
            let subscriptionId = subscription[0].id.replace(/[{}]/g, "");
            try {
                let record = await Xrm.WebApi.retrieveRecord("rhs_subscription", subscriptionId, "?$select=rhs_inrenewalsstage");
                if (record.rhs_inrenewalsstage === false) {
                    Xrm.Navigation.openAlertDialog({ text: "The selected Subscription is not in the renewal stage." });

                    // Clear all dependent fields
                    formContext.getAttribute("rhs_subscription").setValue(null);
                    formContext.getAttribute("rhs_payer")?.setValue(null);
                    formContext.getAttribute("rhs_campaign")?.setValue(null);
                    formContext.getAttribute("rhs_paymentmethodcode")?.setValue(null);
                    formContext.getAttribute("rhs_product")?.setValue(null);
                    formContext.getAttribute("rhs_primarycontact")?.setValue(null);
                    formContext.getAttribute("rhs_pricelist")?.setValue(null);
                    formContext.getAttribute("rhs_productprice")?.setValue(null);
                    formContext.getAttribute("rhs_totalamount")?.setValue(null);
                    formContext.getAttribute("rhs_secondardmembership")?.setValue(null);
                    formContext.getAttribute("rhs_thirdpartypaymenttype")?.setValue(null);
                    return;
                }
            } catch (e) {
                console.error("Error checking subscription renewal stage:", e);
            }
        }
    }

    // === 5. Amount logic ===
    // Exact Match -> Do nothing
    if (amountPaid === totalAmount) return;

    // Overpayment -> Donation
    else if (amountPaid > totalAmount) {
        if (donationSection) donationSection.setVisible(true);
        if (writeoffSection) writeoffSection.setVisible(false);

        let donationAmount = amountPaid - totalAmount;
        formContext.getAttribute("rhs_donationamount").setValue(donationAmount);

        try {
            let configResult = await Xrm.WebApi.retrieveMultipleRecords(
                "rhs_cultivateconfigurations",
                `?$select=rhs_value,_rhs_campaign_value&$filter=rhs_name eq 'DefaultOverPaymentDonationCampaign'`
            );
            if (configResult.entities.length > 0) {
                let config = configResult.entities[0];
                if (config._rhs_campaign_value) {
                    formContext.getAttribute("rhs_donationcampaign").setValue([{
                        id: config._rhs_campaign_value,
                        entityType: "campaign",
                        name: config["_rhs_campaign_value@OData.Community.Display.V1.FormattedValue"]
                    }]);
                }
            }
        } catch (e) {
            console.error("Error retrieving default donation campaign:", e);
        }
        return;
    }

    // Underpayment -> Write-off - Causing bug 78534
    else if (amountPaid < totalAmount) {
        if (writeoffSection) writeoffSection.setVisible(true);
        if (donationSection) donationSection.setVisible(false);

        let writeOffAmount = totalAmount - amountPaid;
        formContext.getAttribute("rhs_writeoffamount").setValue(writeOffAmount);
    }
};
//#endregion


//#region Section Logic Functions
/*
RHSScripts.BatchOrderLine.HideSections = function (formContext) {
    formContext.ui.tabs.get("General").sections.get("General_section_Membership").setVisible(false);
    formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(false);
    formContext.ui.tabs.get("General").sections.get("General_section_Writeoff").setVisible(false);
    formContext.ui.tabs.get("General").sections.get("General_section_Subscription").setVisible(false);
    formContext.ui.tabs.get("General").sections.get("General_section_Giftpack").setVisible(false);
    //formContext.ui.tabs.get("General").sections.get("General_section_RenewMembership").setVisible(false); // Section removed on form 09/23/25
    //formContext.ui.tabs.get("General").sections.get("General_section_RenewSubscription").setVisible(false);
}*/

/**
 * A function to get form sections by a simplified logical name.
 * @param {Xrm.FormContext} formContext The form context.
 * @returns {Object} An object mapping display names to section objects.
 */
RHSScripts.BatchOrderLine.getGeneralTabSections = function (formContext) {
    const sections = formContext.ui.tabs.get("General").sections;

    return {
        MEMBERSHIP_DETAILS: sections.get("General_section_Membership"),
        SUBSCRIPTION_DETAILS: sections.get("General_section_Subscription"),
        DONATION_DETAILS: sections.get("General_section_Donation"),
        GIFT_PACK_DELIVERY_DETAILS: sections.get("General_section_Giftpack"),
        WRITEOFF_DETAILS: sections.get("General_section_Writeoff")
    };
};

/**
 * Shows/hides sections and fields based on the 'Payment Method' field's value.
 * @param {Xrm.FormContext} formContext The form context.
 */
RHSScripts.BatchOrderLine.showHidePaymentMethodFields = function (formContext) {
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productName = productValue ? productValue[0].name : "";
    const paymentMethodControl = formContext.getControl("rhs_paymentmethodcode")
    const paymentMethodValue = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    const thirdPartyPaymentTypeControl = formContext.getControl("rhs_thirdpartypaymenttype");
    const thirdPartyPaymentTypeAttribute = formContext.getAttribute("rhs_thirdpartypaymenttype");
    const showThirdParty = (paymentMethodValue === 120000003); // Third Party

    if (thirdPartyPaymentTypeControl) {
        thirdPartyPaymentTypeControl.setVisible(showThirdParty);
        if (thirdPartyPaymentTypeAttribute) {
            thirdPartyPaymentTypeAttribute.setRequiredLevel(showThirdParty ? "required" : "none");
        }
    }

    if (paymentMethodControl && productName.toLowerCase().includes("patron")) {
        console.log("Remove DD Payment Method.");
        if (paymentMethodValue == 120000002)
            formContext.getAttribute("rhs_paymentmethodcode").setValue(null);
        paymentMethodControl.removeOption(120000002);
    }

    //formContext.getAttribute("rhs_paymentmethod").fireOnChange();
};

/**
* Shows/hides fields and sections based on the 'Type' field's value.
* @param {Xrm.FormContext} formContext The form context.
*/
RHSScripts.BatchOrderLine.showHideTypeFieldsAndSections = async function (formContext) {
    const typeValue = formContext.getAttribute("rhs_type").getValue();
    const generalTabSections = RHSScripts.BatchOrderLine.getGeneralTabSections(formContext);

    // Get all relevant controls for visibility and required level changes
    const paymentMethodControl = formContext.getControl("rhs_paymentmethodcode");
    const payingInSlipNumberControl = formContext.getControl("rhs_payinginslipnumber");
    const priceListControl = formContext.getControl("rhs_pricelist");
    const productPriceControl = formContext.getControl("rhs_productprice");
    const totalAmountControl = formContext.getControl("rhs_totalamount");

    const isThisMembershipAOneYearGiftControl = formContext.getControl("rhs_memoneyeargift");
    const membershipControl = formContext.getControl("rhs_membershipid");
    const subscriptionControl = formContext.getControl("rhs_subscription");
    const secondaryMemberControl = formContext.getControl("rhs_secondarymember");
    const referralMemberControl = formContext.getControl("rhs_referralmember");
    const thirdPartyPaymentTypeControl = formContext.getControl("rhs_thirdpartypaymenttype");
    const locationControl = formContext.getControl("rhs_location");
    const channelSourceControl = formContext.getControl("rhs_channelsource");
    const productControl = formContext.getControl("rhs_product");
    const primaryContactControl = formContext.getControl("rhs_primarycontact");
    const isThisForSomeoneElseControl = formContext.getControl("rhs_isthismembershipforsomeoneelse");
    const newMembershipPackControl = formContext.getControl("rhs_newmembershippacktomember");
    const referredControl = formContext.getControl("rhs_isreferredbyexistingmember");
    const ineligibleForGiftAidControl = formContext.getControl("rhs_ineligibleforgiftaid");
    const writeOffControl = formContext.getControl("rhs_isthisawriteoff");
    const campaignControl = formContext.getControl("rhs_campaign");
    const underlyingmembershippatronControl = formContext.getControl("rhs_underlyingmembershippatron");

    // Get all relevant attributes for required level changes
    const secondaryMemberAttribute = formContext.getAttribute("rhs_secondarymember");
    const referralMemberAttribute = formContext.getAttribute("rhs_referralmember");
    const haveReferredAttribute = formContext.getAttribute("rhs_isreferredbyexistingmember");
    const donationCampaignAttribute = formContext.getAttribute("rhs_donationcampaign");
    const membershipAttribute = formContext.getAttribute("rhs_membershipid");
    const subscriptionAttribute = formContext.getAttribute("rhs_subscription");
    const underlyingmembershippatron = formContext.getAttribute("rhs_underlyingmembershippatron");

    // Get form type
    const formType = formContext.ui.getFormType();
    // 1 = Create, 2 = Update. We only want to enable fields for these types.
    const isActiveForm = formType === 1 || formType === 2;

    const editableControlsToReset = [
        membershipControl, subscriptionControl, secondaryMemberControl, referralMemberControl,
        thirdPartyPaymentTypeControl, locationControl, channelSourceControl,
        productControl, primaryContactControl,
        isThisForSomeoneElseControl, newMembershipPackControl, referredControl, ineligibleForGiftAidControl, writeOffControl
    ];

    editableControlsToReset.forEach(control => {
        if (control) {
            control.setVisible(true);

            if (isActiveForm) {
                // Only enable controls if the form is NOT inactive/read-only.
                control.setDisabled(false);
            }
            // If isActiveForm is false (i.e., Read-Only/Inactive), 
            // the control.setDisabled(false) is skipped, allowing the platform 
            // to enforce the read-only status.
        }
    });

    if (secondaryMemberAttribute) secondaryMemberAttribute.setRequiredLevel("none");
    if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
    if (donationCampaignAttribute) donationCampaignAttribute.setRequiredLevel("none");
    if (membershipAttribute) membershipAttribute.setRequiredLevel("none");
    if (subscriptionAttribute) subscriptionAttribute.setRequiredLevel("none");

    // Hide all sections first to prevent race conditions.
    for (const section in generalTabSections) {
        if (generalTabSections[section]) {
            generalTabSections[section].setVisible(false);
        }
    }

    // If no type is selected, return without hiding any controls by default.
    if (!typeValue) {
        RHSScripts.BatchOrderLine.showHidePaymentMethodFields(formContext);
        return;
    }

    RHSScripts.BatchOrderLine.updatePrimaryContactLabel(formContext);

    switch (typeValue) {
        case TYPE.NewMembership: // New Membership
            if (generalTabSections.MEMBERSHIP_DETAILS) {
                generalTabSections.MEMBERSHIP_DETAILS.setVisible(true);
            }
            if (membershipControl) membershipControl.setDisabled(true);
            if (isThisMembershipAOneYearGiftControl) isThisMembershipAOneYearGiftControl.setVisible(true);
            if (campaignControl) campaignControl.setVisible(true);
            if (priceListControl) priceListControl.setVisible(true);
            if (productPriceControl) productPriceControl.setVisible(true);
            if (totalAmountControl) totalAmountControl.setVisible(true);

            // Hide specific controls not relevant to New Membership
            if (subscriptionControl) subscriptionControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);

            const productLookupNew = formContext.getAttribute("rhs_product").getValue();
            if (productLookupNew && productLookupNew.length > 0) {
                const productId = productLookupNew[0].id.replace(/[{}]/g, "");
                const productProperty = await RHSScripts.BatchOrderLine.GetProductPropertyIntegerValue(productId, "Number of Members Allowed");
                const showSecondary = productProperty && productProperty === 2;
                if (secondaryMemberControl) secondaryMemberControl.setVisible(showSecondary);
                if (secondaryMemberAttribute) secondaryMemberAttribute.setRequiredLevel(showSecondary ? "required" : "none");
                if (isPatronProduct) {
                    if (underlyingmembershippatron) underlyingmembershippatron.setValue(false);
                    if (underlyingmembershippatronControl) underlyingmembershippatronControl.setVisible(false);
                } else {
                    if (underlyingmembershippatronControl) underlyingmembershippatronControl.setVisible(true);
                }
            } else {
                if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
                if (secondaryMemberAttribute) secondaryMemberAttribute.setRequiredLevel("none");
            }

            const haveReferred = haveReferredAttribute.getValue();
            const showReferral = haveReferred === 1;
            if (referralMemberControl) referralMemberControl.setVisible(showReferral);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel(showReferral ? "required" : "none");
            break;

        case TYPE.MembershipRenewal: // Membership Renewal
            if (generalTabSections.MEMBERSHIP_DETAILS) {
                generalTabSections.MEMBERSHIP_DETAILS.setVisible(true);
            }
            // Use !isActiveForm to ensure it's disabled if the form is inactive.
            if (membershipControl) membershipControl.setDisabled(!isActiveForm);
            if (primaryContactControl) primaryContactControl.setDisabled(true);

            if (campaignControl) campaignControl.setVisible(true);
            if (priceListControl) priceListControl.setVisible(true);
            if (productPriceControl) productPriceControl.setVisible(true);
            if (totalAmountControl) totalAmountControl.setVisible(true);

            if (isThisMembershipAOneYearGiftControl) isThisMembershipAOneYearGiftControl.setVisible(false);
            if (subscriptionControl) subscriptionControl.setVisible(false);
            if (isThisForSomeoneElseControl) isThisForSomeoneElseControl.setVisible(false);
            if (newMembershipPackControl) newMembershipPackControl.setVisible(false);
            if (referredControl) referredControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);
            if (underlyingmembershippatronControl) underlyingmembershippatronControl.setVisible(false);
            if (membershipAttribute) membershipAttribute.setRequiredLevel("required");
            const productLookupRenewal = formContext.getAttribute("rhs_product").getValue();
            if (productLookupRenewal && productLookupRenewal.length > 0) {
                const productId = productLookupRenewal[0].id.replace(/[{}]/g, "");
                const productProperty = await RHSScripts.BatchOrderLine.GetProductPropertyIntegerValue(productId, "Number of Members Allowed");
                const showSecondary = productProperty && productProperty === 2;
                if (secondaryMemberControl) secondaryMemberControl.setVisible(showSecondary);
                if (secondaryMemberAttribute && productId) {
                    secondaryMemberAttribute.setRequiredLevel(showSecondary ? "required" : "none");
                } else {
                    if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
                    if (secondaryMemberAttribute) secondaryMemberAttribute.setRequiredLevel("none");
                }
            } else {
                if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
                if (secondaryMemberAttribute) secondaryMemberAttribute.setRequiredLevel("none");
            }
            break;

        case TYPE.NewSubscription: // New Subscription
            if (generalTabSections.SUBSCRIPTION_DETAILS) {
                generalTabSections.SUBSCRIPTION_DETAILS.setVisible(true);
            }
            if (subscriptionControl) subscriptionControl.setDisabled(true);
            if (campaignControl) campaignControl.setVisible(true);
            if (priceListControl) priceListControl.setVisible(true);
            if (productPriceControl) productPriceControl.setVisible(true);
            if (totalAmountControl) totalAmountControl.setVisible(true);

            if (membershipControl) membershipControl.setVisible(false);
            if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (isThisForSomeoneElseControl) isThisForSomeoneElseControl.setVisible(false);
            if (newMembershipPackControl) newMembershipPackControl.setVisible(false);
            if (referredControl) referredControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);

            if (thirdPartyPaymentTypeControl) thirdPartyPaymentTypeControl.setVisible(false);
            if (locationControl) locationControl.setVisible(false);
            if (channelSourceControl) channelSourceControl.setVisible(false);
            break;

        case TYPE.SubscriptionRenewal: // Subscription Renewal
            if (generalTabSections.SUBSCRIPTION_DETAILS) {
                generalTabSections.SUBSCRIPTION_DETAILS.setVisible(true);
            }
            // Use !isActiveForm to ensure it's disabled if the form is inactive.
            if (subscriptionControl) subscriptionControl.setDisabled(!isActiveForm);
            if (primaryContactControl) primaryContactControl.setDisabled(true);

            if (campaignControl) campaignControl.setVisible(true);
            if (priceListControl) priceListControl.setVisible(true);
            if (productPriceControl) productPriceControl.setVisible(true);
            if (totalAmountControl) totalAmountControl.setVisible(true);

            if (membershipControl) membershipControl.setVisible(false);
            if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
            if (isThisForSomeoneElseControl) isThisForSomeoneElseControl.setVisible(false);
            if (newMembershipPackControl) newMembershipPackControl.setVisible(false);
            if (referredControl) referredControl.setVisible(false);

            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);

            if (thirdPartyPaymentTypeControl) thirdPartyPaymentTypeControl.setVisible(false);
            if (locationControl) locationControl.setVisible(false);
            if (channelSourceControl) channelSourceControl.setVisible(false);

            if (subscriptionAttribute) subscriptionAttribute.setRequiredLevel("required");
            break;

        case TYPE.Donations: // Fundraising (Donation)
            if (generalTabSections.DONATION_DETAILS) {
                generalTabSections.DONATION_DETAILS.setVisible(true);
                donationCampaignAttribute.setRequiredLevel("required");
            }

            if (membershipControl) membershipControl.setDisabled(true);
            if (subscriptionControl) subscriptionControl.setDisabled(true);

            if (isThisForSomeoneElseControl) isThisForSomeoneElseControl.setVisible(false);
            if (newMembershipPackControl) newMembershipPackControl.setVisible(false);
            if (referredControl) referredControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);
            if (thirdPartyPaymentTypeControl) thirdPartyPaymentTypeControl.setVisible(false);
            if (secondaryMemberControl) secondaryMemberControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (campaignControl) campaignControl.setVisible(false);
            if (priceListControl) priceListControl.setVisible(false);
            if (locationControl) locationControl.setVisible(false);
            if (productControl) productControl.setVisible(false);
            if (primaryContactControl) primaryContactControl.setVisible(false);
            if (productPriceControl) productPriceControl.setVisible(false);
            if (totalAmountControl) totalAmountControl.setVisible(false);
            break;

        case TYPE.GiftPacks: // Gift Packs
            if (generalTabSections.GIFT_PACK_DELIVERY_DETAILS) {
                generalTabSections.GIFT_PACK_DELIVERY_DETAILS.setVisible(true);
                if (newMembershipPackControl) newMembershipPackControl.setVisible(false);
            }

            if (campaignControl) campaignControl.setVisible(true);
            if (priceListControl) priceListControl.setVisible(true);
            if (productPriceControl) productPriceControl.setVisible(true);
            if (totalAmountControl) totalAmountControl.setVisible(true);

            if (membershipControl) membershipControl.setVisible(false);
            if (isThisMembershipAOneYearGiftControl) isThisMembershipAOneYearGiftControl.setVisible(false);
            if (isThisForSomeoneElseControl) isThisForSomeoneElseControl.setVisible(false);
            if (referredControl) referredControl.setVisible(false);
            if (secondaryMemberControl) secondaryMemberControl.setVisible(false);

            if (subscriptionControl) subscriptionControl.setVisible(false);
            if (referralMemberControl) referralMemberControl.setVisible(false);
            if (referralMemberAttribute) referralMemberAttribute.setRequiredLevel("none");
            // if (paymentMethodControl) paymentMethodControl.setVisible(false);
            if (payingInSlipNumberControl) payingInSlipNumberControl.setVisible(false);
            //if (ineligibleForGiftAidControl) ineligibleForGiftAidControl.setVisible(false);
            if (writeOffControl) writeOffControl.setVisible(false);
            break;
    }

    RHSScripts.BatchOrderLine.showHidePaymentMethodFields(formContext);
};

RHSScripts.BatchOrderLine.showHideInelligibleForGiftAidWhenNotElligible = async function (formContext) {
    let ineligibleForGiftAidControl = formContext.getControl("rhs_ineligibleforgiftaid");
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    if (productId) {
        let giftAidEligiblePropertyValue = await RHSScripts.BatchOrderLine.GetProductPropertyOptionSetValue(productId, "Gift Aid Eligible");
        if (giftAidEligiblePropertyValue == 1)
            ineligibleForGiftAidControl.setVisible(true);
        else {
            ineligibleForGiftAidControl.setVisible(false);
        }
    }
}

/**
 * Updates the label of the 'Primary Contact' field based on the 'Type' field's value.
 * @param {Xrm.FormContext} formContext The form context.
 */
RHSScripts.BatchOrderLine.updatePrimaryContactLabel = function (formContext) {
    const typeValue = formContext.getAttribute("rhs_type").getValue();
    const primaryContactControl = formContext.getControl("rhs_primarycontact");

    if (!primaryContactControl) return;
    let label = "Primary Contact";

    switch (typeValue) {
        case 120000000: // New Membership
        case 120000001: // Membership Renewal
            label = "Primary Member";
            break;
        case 120000002: // Subscription
        case 120000003: // Subscription Renewal
            label = "Recipient";
            break;
        case 120000005: // Gift Pack Purchase
            label = "Delivery Contact";
            break;
        default:
            label = "Primary Contact";
            break;
    }
    primaryContactControl.setLabel(label);
};

/**
 * Dynamically sets the Product lookup view based on the Type field value.
 * @param {Xrm.FormContext} formContext
 */
RHSScripts.BatchOrderLine.SetProductLookupViewByType = async function (formContext) {
    try {
        const typeValue = formContext.getAttribute("rhs_type")?.getValue();
        const productControl = formContext.getControl("rhs_product");
        if (!productControl || !typeValue) return;

        // Determine which view name to use based on type
        let viewName = null;
        switch (typeValue) {
            case 120000000: // New Membership
            case 120000001: // Membership Renewal
                viewName = PRODUCT_LOOKUP_VIEWS.Membership_Products_Lookup;
                break;
            case 120000002: // New Subscription
            case 120000003: // Subscription Renewal
                viewName = PRODUCT_LOOKUP_VIEWS.Subscription_Products_Lookup;
                break;
            case 120000005: // Gift Pack
                viewName = PRODUCT_LOOKUP_VIEWS.Gift_Pack_Products_Lookup;
                break;
            default:
                return; // Other types
        }

        // Retrieve the system view dynamically by name
        const fetchXml = [
            "<fetch top='1'>",
            "  <entity name='savedquery'>",
            "    <attribute name='savedqueryid' />",
            "    <filter>",
            "      <condition attribute='name' operator='eq' value='", viewName, "'/>",
            "      <condition attribute='returnedtypecode' operator='eq' value='1024'/>", // Product entity
            "    </filter>",
            "  </entity>",
            "</fetch>"
        ].join("");

        const results = await Xrm.WebApi.retrieveMultipleRecords("savedquery", "?fetchXml=" + encodeURIComponent(fetchXml));
        if (results.entities.length === 0) {
            console.warn(`Product lookup view '${viewName}' not found.`);
            return;
        }

        const viewId = results.entities[0].savedqueryid;

        // Set the found view as the default
        productControl.setDefaultView(viewId);
        productControl.refresh();

    } catch (e) {
        console.error("Error in SetProductLookupViewByType:", e);
    }
};


RHSScripts.BatchOrderLine.RetrieveBatchOrder = async function (formContext) {
    let batchOrderLookup = formContext.getAttribute("rhs_batchorder").getValue()
    if (!batchOrderLookup)
        return null;

    let batchOrderId = batchOrderLookup[0].id.replace("{", "").replace("}", "").toLowerCase();
    let batchOrder = await Xrm.WebApi.retrieveRecord("rhs_batchorder", batchOrderId);

    return batchOrder;
}

RHSScripts.BatchOrderLine.CopyBatchOrderValuesToBatchOrderLineOnCreation = async function (formContext, batchOrder) {
    let createdOn = formContext.getAttribute("createdon").getValue();

    if (!createdOn) {
        switch (batchOrder.rhs_type) {
            case 120000000/*New Membership*/:
                // Set Membership Campaign
                let campaign = formContext.getAttribute("rhs_campaign").getValue();
                if (!campaign && batchOrder._rhs_campaigncode_value) {
                    let campaignReference = [{
                        id: batchOrder["_rhs_campaigncode_value"],
                        entityType: batchOrder["_rhs_campaigncode_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_campaigncode_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_campaign").setValue(campaignReference);
                }

                // Set Membership Product
                let membershipProduct = formContext.getAttribute("rhs_membershipproduct").getValue();
                if (!membershipProduct && batchOrder._rhs_membershipproduct_value) {
                    let productReference = [{
                        id: batchOrder["_rhs_membershipproduct_value"],
                        entityType: batchOrder["_rhs_membershipproduct_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_membershipproduct_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_membershipproduct").setValue(productReference);
                }

                // Set Membership Price List
                let priceList = formContext.getAttribute("rhs_pricelist").getValue();
                if (!priceList && batchOrder._rhs_pricelist_value) {
                    let priceListReference = [{
                        id: batchOrder["_rhs_pricelist_value"],
                        entityType: batchOrder["_rhs_pricelist_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_pricelist_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_pricelist").setValue(priceListReference);
                }

                // Set total amount
                formContext.getAttribute("rhs_totalamount").setValue(batchOrder.rhs_totalamount);
                // Set payment method
                formContext.getAttribute("rhs_paymentmethodcode").setValue(batchOrder.rhs_paymentmethodcode);
                formContext.getAttribute("rhs_paymentmethodcode").fireOnChange(); //triggers busines rule

                // Set third party payment type
                let thirdPartyPaymentType = formContext.getAttribute("rhs_thirdpartypaymenttype").getValue();
                if (!thirdPartyPaymentType && batchOrder._rhs_thirdpartypaymenttype_value) {
                    let thirdPartyPaymentTypeReference = [{
                        id: batchOrder["_rhs_thirdpartypaymenttype_value"],
                        entityType: batchOrder["_rhs_thirdpartypaymenttype_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_thirdpartypaymenttype_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_thirdpartypaymenttype").setValue(thirdPartyPaymentTypeReference);
                }

                // Channel
                formContext.getAttribute("rhs_channelsource").setValue(batchOrder.rhs_channelsource);
                // Location
                let location = formContext.getAttribute("rhs_location").getValue();
                if (!location && batchOrder._rhs_location_value) {
                    let locationReference = [{
                        id: batchOrder["_rhs_location_value"],
                        entityType: batchOrder["_rhs_location_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_location_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_location").setValue(locationReference);
                    formContext.getAttribute("rhs_location").fireOnChange(); //triggers busines rule
                }

                break;
            case 120000005/*Fundraising (Donation)*/:
                // Set payment method
                formContext.getAttribute("rhs_paymentmethodcode").setValue(batchOrder.rhs_paymentmethodcode);
                formContext.getAttribute("rhs_paymentmethodcode").fireOnChange(); //triggers busines rule

                // Set donation amount (assuming total amount becomes donation amount)
                formContext.getAttribute("rhs_donationamount").setValue(batchOrder.rhs_totalamount);
                // Channel
                formContext.getAttribute("rhs_channelsource").setValue(batchOrder.rhs_channelsource);
                // Campaign (Donation)
                let donationCampaign = formContext.getAttribute("rhs_donationcampaign").getValue();
                if (!donationCampaign && batchOrder._rhs_donationcampaign_value) {
                    let donationCampaignReference = [{
                        id: batchOrder["_rhs_donationcampaign_value"],
                        entityType: batchOrder["_rhs_donationcampaign_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
                        name: batchOrder["_rhs_donationcampaign_value@OData.Community.Display.V1.FormattedValue"]
                    }]
                    formContext.getAttribute("rhs_donationcampaign").setValue(donationCampaignReference);
                }

                break;
        }
    }
}

// RHSScripts.BatchOrderLine.DoMembershipDetailsLogic = async function (formContext, batchOrder) {
//     if (batchOrder?.rhs_type == 120000000/*New Membership*/) {
//         formContext.ui.tabs.get("General").sections.get("General_section_Membership").setVisible(true);
//         formContext.getAttribute("rhs_product").setRequiredLevel("required");
//         formContext.getAttribute("rhs_primarycontact").setRequiredLevel("required");
//         formContext.getAttribute("rhs_payer").setRequiredLevel("required");
//         formContext.getAttribute("rhs_totalamount").setRequiredLevel("required");
//         if (!formContext.getAttribute("createdon").getValue())
//             await RHSScripts.BatchOrderLine.SetMembershipPrice(formContext, batchOrder);
//     } else {
//         formContext.ui.tabs.get("General").sections.get("General_section_Membership").setVisible(false);
//     }
// }

// RHSScripts.BatchOrderLine.DoDonationDetailsLogic = async function (formContext, batchOrder) {
//     let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
//     //let membershipPrice = formContext.getAttribute("rhs_membershipprice").getValue();

//     switch (batchOrder?.rhs_type) {
//         case 120000000/*New Membership*/:
//             //Commented by JMM  9/18/2025 as it has issues with deprecated Membership Price will do else logic instead
//             //if (totalAmount && membershipPrice && totalAmount > membershipPrice) {
//             //    formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(true);
//             //    formContext.getAttribute("rhs_donationamount").setValue(totalAmount - membershipPrice);
//             //    formContext.getAttribute("rhs_donationcampaign").setRequiredLevel("required");
//             //} else {
//             //    formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(false);
//             //    formContext.getAttribute("rhs_donationamount").setValue(null);
//             //    formContext.getAttribute("rhs_donationcampaign").setRequiredLevel("none");
//             //    formContext.getAttribute("rhs_donationcampaign").setValue(null);
//             //}
//             formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(false);
//             formContext.getAttribute("rhs_donationamount").setValue(null);
//             formContext.getAttribute("rhs_donationcampaign").setRequiredLevel("none");
//             formContext.getAttribute("rhs_donationcampaign").setValue(null);
//             break;
//         case 120000005/*Fundraising (Donation)*/:
//             formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(true);
//             formContext.getAttribute("rhs_payer").setRequiredLevel("required");
//             formContext.getControl("rhs_donationamount").setDisabled(false);
//             formContext.getAttribute("rhs_donationamount").setRequiredLevel("required");
//             formContext.getAttribute("rhs_donationcampaign").setRequiredLevel("required");

//             break;
//         default:
//             formContext.ui.tabs.get("General").sections.get("General_section_Donation").setVisible(false);
//             break;
//     }
// }

// RHSScripts.BatchOrderLine.DoWriteOffDetailsLogic = async function (formContext, batchOrder) {
//     let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
//     //let membershipPrice = formContext.getAttribute("rhs_membershipprice").getValue();

//     switch (batchOrder?.rhs_type) {
//         case 120000000/*New Membership*/:
//             //Commented by JMM  9/18/2025 as it has issues with deprecated Membership Price will do else logic instead
//             //if (totalAmount && membershipPrice && totalAmount < membershipPrice) {
//             //    formContext.ui.tabs.get("General").sections.get("General_section_Writeoff").setVisible(true);
//             //    formContext.getAttribute("rhs_writeoffamount").setValue(membershipPrice - totalAmount);
//             //} else {
//             //    formContext.ui.tabs.get("General").sections.get("General_section_Writeoff").setVisible(false);
//             //    formContext.getAttribute("rhs_writeoffamount").setValue(null);
//             //}
//             formContext.ui.tabs.get("General").sections.get("General_section_Writeoff").setVisible(false);
//             formContext.getAttribute("rhs_writeoffamount").setValue(null);
//             break;
//         default:
//             formContext.ui.tabs.get("General").sections.get("General_section_Writeoff").setVisible(false);
//             break;
//     }
// }
// #endregion

// #region Getter Functions
/**
 * Helper function to retrieve a specific product property using FetchXML.
 * @param {string} productId The ID of the product.
 * @param {string} propertyName The name of the property to retrieve.
 * @returns {Promise<number|null>} A promise that resolves to the integer value of the property, or null.
 */
RHSScripts.BatchOrderLine.GetProductPropertyIntegerValue = async function (productId, propertyName) {
    'use strict';
    let propertyValue = null;

    let fetchXml = [
        "<fetch>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='defaultvalueinteger'/>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='dpa'>",
        "      <filter>",
        "        <condition attribute='associationstatus' operator='eq' value='0' />",
        "        <condition attribute='regardingobjectid' operator='eq' value='", productId, "'/>",
        "      </filter>",
        "    </link-entity>",
        "    <filter>",
        "      <condition attribute='name' operator='eq' value='", propertyName, "'/>",
        "    </filter>",
        "  </entity>",
        "</fetch>"
    ].join("");

    try {
        let result = await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + fetchXml);
        if (result.entities && result.entities.length > 0) {
            propertyValue = result.entities[0].defaultvalueinteger;
        }
    } catch (error) {
        console.error("Error retrieving product property via FetchXML:", error.message);
    }
    return propertyValue;
};

RHSScripts.BatchOrderLine.GetProductPropertyOptionSetValue = async function (productId, propertyName) {
    'use strict';
    let propertyValue = null;

    let fetchXml = [
        "<fetch>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='defaultvalueoptionset'/>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='dpa'>",
        "      <filter>",
        "        <condition attribute='associationstatus' operator='eq' value='0' />",
        "        <condition attribute='regardingobjectid' operator='eq' value='", productId, "'/>",
        "      </filter>",
        "    </link-entity>",
        "    <filter>",
        "      <condition attribute='name' operator='eq' value='", propertyName, "'/>",
        "    </filter>",
        "    <link-entity name='dynamicpropertyoptionsetitem' from='dynamicpropertyoptionsetvalueid' to='defaultvalueoptionset'>",
        "      <attribute name='dynamicpropertyoptionvalue' />",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    try {
        let result = await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + fetchXml);
        if (result.entities && result.entities.length > 0) {
            propertyValue = result.entities[0]["dynamicpropertyoptionsetitem2.dynamicpropertyoptionvalue"];
            if (propertyValue === undefined)
                propertyValue = null;
        }
    } catch (error) {
        console.error("Error retrieving product property via FetchXML:", error.message);
    }
    return propertyValue;
};

RHSScripts.BatchOrderLine.RetrieveSubscriptionMemberships = async function (recipientId, payerId) {
    let entityLogicalName = "rhs_membership";
    let options = "".concat(
        "?$select=".concat("_rhs_payerv2_value,_rhs_contact_value,_rhs_member2_value,statecode,statuscode"),
        `&$filter=(`.concat(
            `statuscode eq 1 and (`,
            `_rhs_contact_value eq ${recipientId} or _rhs_contact_value eq ${payerId} or `,
            `_rhs_member2_value eq ${recipientId} or _rhs_member2_value eq ${payerId} or `,
            `_rhs_payerv2_value eq ${recipientId} or _rhs_payerv2_value eq ${payerId}`,
            `))`
        )
    );

    let memberships = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return memberships;
}

RHSScripts.BatchOrderLine.RetrieveMemberships = async function (memberId) {
    let entityLogicalName = "rhs_membership";
    let options = "".concat(
        "?$select=".concat("_rhs_payerv2_value,_rhs_contact_value,_rhs_member2_value,statecode,statuscode"),
        `&$filter=(`.concat(
            `rhs_patronmembership eq false and `,
            `statuscode eq 1 and (`,
            `_rhs_contact_value eq ${memberId} or _rhs_member2_value eq ${memberId}`,
            `))`
        )
    );

    let memberships = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return memberships;
}

RHSScripts.BatchOrderLine.RetrievePatronMemberships = async function (memberId) {
    let entityLogicalName = "rhs_membership";
    let options = "".concat(
        "?$select=".concat("_rhs_payerv2_value,_rhs_contact_value,_rhs_member2_value,statecode,statuscode"),
        `&$filter=(`.concat(
            `rhs_patronmembership eq true and `,
            `statuscode eq 1 and (`,
            `_rhs_contact_value eq ${memberId} or _rhs_member2_value eq ${memberId}`,
            `))`
        )
    );

    let memberships = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return memberships;
}

RHSScripts.BatchOrderLine.RetrieveProductParentID = async function (productId) {
    let entityLogicalName = "product";
    let options = `?$select=_parentproductid_value&$filter=productid eq '${productId}'`;

    let productParentID = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return productParentID[0]._parentproductid_value;
}

// #region Get Cultivate Configuration
RHSScripts.BatchOrderLine.GetCultivateConfiguration = async function (name) {
    let entityLogicalName = "rhs_cultivateconfigurations";
    let options = `?$select=_rhs_campaign_value,rhs_description,rhs_name,_rhs_pricelist_value,rhs_value&$filter=rhs_name eq '${name}'`;

    let cultivateConfigurations = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    if (cultivateConfigurations.length > 0)
        return cultivateConfigurations[0]
    else
        return null;
}

RHSScripts.BatchOrderLine.GetCultivateConfigurationPriceListValue = async function (name) {
    let cultivateConfiguration = await RHSScripts.BatchOrderLine.GetCultivateConfiguration(name);

    if (cultivateConfiguration?._rhs_pricelist_value) {
        let lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = cultivateConfiguration["_rhs_pricelist_value"];
        lookupValue[0].name = cultivateConfiguration["_rhs_pricelist_value@OData.Community.Display.V1.FormattedValue"];
        lookupValue[0].entityType = cultivateConfiguration["_rhs_pricelist_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

        return lookupValue;
    } else {
        return null;
    }
}
// #endregion

// #region Get Price List
RHSScripts.BatchOrderLine.GetProductDefaultPriceListValue = async function (productId) {
    if (!productId)
        return;

    let product = await Xrm.WebApi.retrieveRecord("product", productId, "?$select=_pricelevelid_value")

    if (product?._pricelevelid_value) {
        let lookupValue = new Array();
        lookupValue[0] = new Object();
        lookupValue[0].id = product["_pricelevelid_value"];
        lookupValue[0].name = product["_pricelevelid_value@OData.Community.Display.V1.FormattedValue"];
        lookupValue[0].entityType = product["_pricelevelid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

        return lookupValue;
    } else {
        return null
    }
}

RHSScripts.BatchOrderLine.GetNewMembershipPriceList = async function (formContext) {
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productName = productValue ? productValue[0].name : null;

    let cultivateConfigurationName = productName && productName.includes("Patron") ? "PatronBackOfficePriceList" : "BackOfficePriceList";
    let lookupValue = await RHSScripts.BatchOrderLine.GetCultivateConfigurationPriceListValue(cultivateConfigurationName)
    return lookupValue
}

RHSScripts.BatchOrderLine.GetMembershipRenewalPriceListValue = async function (formContext) {
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productName = productValue ? productValue[0].name : null;

    let cultivateConfigurationName = productName && productName.includes("Patron") ? "PatronRenewalPriceList" : "RenewalsPriceList";
    let lookupValue = await RHSScripts.BatchOrderLine.GetCultivateConfigurationPriceListValue(cultivateConfigurationName)
    return lookupValue
}

RHSScripts.BatchOrderLine.GetNewSubscriptionPriceListValue = async function (formContext) {
    let recipientValue = formContext.getAttribute("rhs_primarycontact").getValue();
    let recipientId = recipientValue ? recipientValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let payerValue = formContext.getAttribute("rhs_payer").getValue();
    let payerId = payerValue ? payerValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    let memberships = await RHSScripts.BatchOrderLine.RetrieveSubscriptionMemberships(recipientId, payerId)
    let isMember = memberships.length > 0;

    let cultivateConfigurationName = isMember ? "PlantUKMemberPriceList" : "PlantUKNonMemberPriceList";
    let lookupValue = await RHSScripts.BatchOrderLine.GetCultivateConfigurationPriceListValue(cultivateConfigurationName)
    return lookupValue
}

RHSScripts.BatchOrderLine.GetSubscriptionRenewalPriceListValue = async function (formContext) {
    let recipientValue = formContext.getAttribute("rhs_primarycontact").getValue();
    let recipientId = recipientValue ? recipientValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let payerValue = formContext.getAttribute("rhs_payer").getValue();
    let payerId = payerValue ? payerValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    let memberships = await RHSScripts.BatchOrderLine.RetrieveSubscriptionMemberships(recipientId, payerId)
    let isMember = memberships.length > 0;

    let cultivateConfigurationName = isMember ? "PlantUKMemberRenewalPriceList" : "PlantUKNonMemberRenewalPriceList";
    let lookupValue = await RHSScripts.BatchOrderLine.GetCultivateConfigurationPriceListValue(cultivateConfigurationName)
    return lookupValue
}

RHSScripts.BatchOrderLine.GetGiftPackurchasePriceListValue = async function (formContext) {
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productId = productValue ? productValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    let lookupValue = await RHSScripts.BatchOrderLine.GetProductDefaultPriceListValue(productId);
    return lookupValue;
}

RHSScripts.BatchOrderLine.GetPriceListLookupValue = async function (formContext) {
    let typeValue = formContext.getAttribute("rhs_type").getValue();
    let lookupValue = null;

    switch (typeValue) {
        case 120000000 /*New Membership*/:
            lookupValue = await RHSScripts.BatchOrderLine.GetNewMembershipPriceList(formContext);
            break;
        case 120000001 /*Membership Renewal*/:
            lookupValue = await RHSScripts.BatchOrderLine.GetMembershipRenewalPriceListValue(formContext);
            break;
        case 120000002 /*New Subscription*/:
            lookupValue = await RHSScripts.BatchOrderLine.GetNewSubscriptionPriceListValue(formContext);
            break;
        case 120000003 /*Subscription Renewal*/:
            lookupValue = await RHSScripts.BatchOrderLine.GetSubscriptionRenewalPriceListValue(formContext);
            break;
        case 120000005 /*Gift Pack Purchase*/:
            lookupValue = await RHSScripts.BatchOrderLine.GetGiftPackurchasePriceListValue(formContext);
            break;
    }

    return lookupValue;
}
// #endregion

// #region Get Price
RHSScripts.BatchOrderLine.GetProductPrice = async function (productId, priceListId) {
    if (!productId || !priceListId)
        return null;

    let logicalName = "productpricelevel";
    let options = "".concat(
        "?$select=amount",
        `&$filter=(_productid_value eq ${productId} and _pricelevelid_value eq ${priceListId})`
    );
    let priceListItems = (await Xrm.WebApi.retrieveMultipleRecords(logicalName, options)).entities;

    let priceListItemPrice = priceListItems.length > 0 ? priceListItems[0].amount : null;
    return priceListItemPrice;
}

RHSScripts.BatchOrderLine.GetDiscountedPrice = async function (productId, productPrice, campaignId, paymentMethod, paymentFrequency = 120000000/*Annually*/) {
    if (!productPrice)
        return null;
    if (!productId || !campaignId)
        return productPrice;

    // Set discounted price to product price
    let discountedPrice = productPrice;

    // Set discounted price to campaign price
    let campaign = await Xrm.WebApi.retrieveRecord("campaign", campaignId,
        `?$select=_rhs_paymentdiscountconfiguration_value,_pricelistid_value,_rhs_productid_value,rhs_benefittype`);
    let prictListItems = (await Xrm.WebApi.retrieveMultipleRecords("productpricelevel",
        "".concat(`?$select=amount,_pricelevelid_value,_productid_value`,
            `&$filter=(_pricelevelid_value eq ${campaign._pricelistid_value} and _productid_value eq ${productId})`
        ))).entities;
    let campaignPrice = prictListItems.length > 0 ? prictListItems[0].amount : null;

    if (campaignPrice)
        discountedPrice = campaignPrice;

    // Deduct additional discount from payment discount configuration if applicable
    if (campaign._rhs_paymentdiscountconfiguration_value) {
        let paymentDiscountConfiguration = await Xrm.WebApi.retrieveRecord("rhs_paymentdiscountconfiguration",
            campaign._rhs_paymentdiscountconfiguration_value, "?$select=rhs_paymentmethodcode,rhs_discountamount,rhs_discountpercentage");
        if (campaign.rhs_benefittype == 120000001/*Price Based*/ && paymentDiscountConfiguration &&
            paymentDiscountConfiguration.rhs_paymentmethodcode == paymentMethod &&
            (paymentMethod != 120000002/*Direct Debit*/ || paymentFrequency == 120000000/*Annually*/)) {
            if (paymentDiscountConfiguration.rhs_discountpercentage)
                discountedPrice -= (paymentDiscountConfiguration.rhs_discountpercentage / 100) * productPrice
            if (paymentDiscountConfiguration.rhs_discountamount)
                discountedPrice -= paymentDiscountConfiguration.rhs_discountamount
        }
    }

    return discountedPrice;
}
// #endregion

// #region Get Postal Charge
RHSScripts.BatchOrderLine.GetSubscriptionPostalCharge = async function (customerLookupValue) {
    if (!customerLookupValue)
        return null;

    let customer = await Xrm.WebApi.retrieveRecord(
        customerLookupValue[0].entityType,
        customerLookupValue[0].id.replace("{", "").replace("}", "").toLowerCase(),
        "?$select=address1_country"
    );

    let entityLogicalName = "rhs_country";
    let options = `?$select=rhs_name,rhs_postalcharges&$filter=contains(rhs_name,'${customer.address1_country}')`;
    let countries = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    let postalCharge = countries.length > 0 ? countries[0].rhs_postalcharges : null;
    return postalCharge;
}

RHSScripts.BatchOrderLine.GetGiftPackPostalCharge = async function (customerLookupValue, deliveryAddressCode) {
    if (!customerLookupValue)
        return null;

    let customer = await Xrm.WebApi.retrieveRecord(
        customerLookupValue[0].entityType,
        customerLookupValue[0].id.replace("{", "").replace("}", "").toLowerCase(),
        "?$select=address1_country"
    );
    let countryField = "";

    switch (customerLookupValue[0].entityType) {
        case "contact":
            switch (deliveryAddressCode) {
                case 844060000/*Home Address*/:
                    countryField = "address1_country";
                    break;
                case 844060001/*Alternate Address*/:
                    if (deliveryAddressCode == customer.rhs_secondaryaddresstype) {
                        countryField = "address2_country";
                    } else if (deliveryAddressCode == customer.rhs_alternateaddresstypecode) {
                        countryField = "rhs_loqateaddress3country";
                    }
                    break;
                case 844060002/*Work Address*/:
                    if (deliveryAddressCode == customer.rhs_secondaryaddresstype) {
                        countryField = "address2_country";
                    } else if (deliveryAddressCode == customer.rhs_alternateaddresstypecode) {
                        countryField = "rhs_loqateaddress3country";
                    }
                    break;
                case 844060003/*Secretariat Preferred Address*/:
                    countryField = "";
                    break;
            }
            break;
        case "account":
            switch (deliveryAddressCode) {
                case 844060000/*Home Address*/:
                    countryField = "address1_country";
                    break;
                case 844060001/*Alternate Address*/:
                case 844060002/*Work Address*/:
                case 844060003/*Secretariat Preferred Address*/:
                    countryField = "address2_country";
                    break;
            }
            break;
    }

    let entityLogicalName = "rhs_country";
    let options = `?$select=rhs_name,rhs_postalcharges&$filter=contains(rhs_name,'${customer[countryField]}')`;
    let countries = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    let postalCharge = countries.length > 0 ? countries[0].rhs_postalcharges : null;
    return postalCharge;
}

RHSScripts.BatchOrderLine.GetPostalCharge = async function (formContext) {
    let type = formContext.getAttribute("rhs_type").getValue();
    let primaryContactLookup = formContext.getAttribute("rhs_primarycontact").getValue();
    let deliveryAddressCode = formContext.getAttribute("rhs_deliveryaddress").getValue();
    let postalCharge = null;

    switch (type) {
        case 120000002 /*New Subscription*/:
            postalCharge = await RHSScripts.BatchOrderLine.GetSubscriptionPostalCharge(primaryContactLookup);
            break;
        case 120000003 /*Subscription Renewal*/:
            postalCharge = await RHSScripts.BatchOrderLine.GetSubscriptionPostalCharge(primaryContactLookup);
            break;
        case 120000005 /*Gift Pack Purchase*/:
            postalCharge = await RHSScripts.BatchOrderLine.GetGiftPackPostalCharge(primaryContactLookup, deliveryAddressCode);
            break;
    }

    return postalCharge;
}
// #endregion

// #region Calculate Total Amount
RHSScripts.BatchOrderLine.CalculateMembershipTotalAmount = async function (formContext) {
    let priceListLookup = formContext.getAttribute("rhs_pricelist").getValue();
    let priceListId = priceListLookup ? priceListLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let campaignLookup = formContext.getAttribute("rhs_campaign").getValue();
    let campaignId = campaignLookup ? campaignLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();

    let productPrice = await RHSScripts.BatchOrderLine.GetProductPrice(productId, priceListId);
    let campaignDiscountedPrice = campaignId ?
        await RHSScripts.BatchOrderLine.GetDiscountedPrice(productId, productPrice, campaignId, paymentMethod) :
        null;

    let price = campaignId ? campaignDiscountedPrice : productPrice;
    let totalAmount = price;
    return totalAmount;
}

RHSScripts.BatchOrderLine.CalculateSubscriptionTotalAmount = async function (formContext) {
    let subscriber = formContext.getAttribute("rhs_primarycontact").getValue();
    let priceListLookup = formContext.getAttribute("rhs_pricelist").getValue();
    let priceListId = priceListLookup ? priceListLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let campaignLookup = formContext.getAttribute("rhs_campaign").getValue();
    let campaignId = campaignLookup ? campaignLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();

    let productPrice = await RHSScripts.BatchOrderLine.GetProductPrice(productId, priceListId);
    let campaignDiscountedPrice = campaignId ?
        await RHSScripts.BatchOrderLine.GetDiscountedPrice(productId, productPrice, campaignId, paymentMethod) :
        null;
    let postalCharge = await RHSScripts.BatchOrderLine.GetPostalCharge(formContext);

    let price = campaignId ? campaignDiscountedPrice : productPrice;
    let totalAmount = postalCharge ? price + postalCharge : price;
    return totalAmount;
}

RHSScripts.BatchOrderLine.CalculateGiftPackPurchasePTotalAmount = async function (formContext) {
    let subscriber = formContext.getAttribute("rhs_primarycontact").getValue();
    let priceListLookup = formContext.getAttribute("rhs_pricelist").getValue();
    let priceListId = priceListLookup ? priceListLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let campaignLookup = formContext.getAttribute("rhs_campaign").getValue();
    let campaignId = campaignLookup ? campaignLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();

    let productPrice = await RHSScripts.BatchOrderLine.GetProductPrice(productId, priceListId);
    let campaignDiscountedPrice = campaignId ?
        await RHSScripts.BatchOrderLine.GetDiscountedPrice(productId, productPrice, campaignId, paymentMethod) :
        null;
    let postalCharge = await RHSScripts.BatchOrderLine.GetPostalCharge(formContext);

    let price = campaignId ? campaignDiscountedPrice : productPrice;
    let totalAmount = postalCharge ? price + postalCharge : price;
    return totalAmount;
}

RHSScripts.BatchOrderLine.CalculateTotalAmount = async function (formContext) {
    let type = formContext.getAttribute("rhs_type").getValue();
    let totalAmount = null;
    switch (type) {
        case 120000000 /*New Membership*/:
        case 120000001 /*Membership Renewal*/:
            totalAmount = await RHSScripts.BatchOrderLine.CalculateMembershipTotalAmount(formContext);
            break;
        case 120000002 /*New Subscription*/:
        case 120000003 /*Subscription Renewal*/:
            totalAmount = await RHSScripts.BatchOrderLine.CalculateSubscriptionTotalAmount(formContext);
            break;
        case 120000005 /*Gift Pack Purchase*/:
            totalAmount = await RHSScripts.BatchOrderLine.CalculateGiftPackPurchasePTotalAmount(formContext);
            break;
    }

    return totalAmount;
}
// #endregion
// #endregion

// #region Setter Functions
RHSScripts.BatchOrderLine.SetMembershipPrice = async function (formContext, batchOrder) {
    let priceListLookup = formContext.getAttribute("rhs_pricelist").getValue();
    let priceListId = priceListLookup ? priceListLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    if (batchOrder.rhs_type == 120000000/*New Membership*/ && productId && priceListId) {
        let membershipPrice = await RHSScripts.BatchOrderLine.GetProductPrice(productId, priceListId);
        let campaign = formContext.getAttribute("rhs_campaign").getValue();
        if (campaign) {
            let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
            membershipPrice = await RHSScripts.BatchOrderLine.GetDiscountedPrice(productId, membershipPrice, campaign[0].id, paymentMethod)
        }

        //formContext.getAttribute("rhs_membershipprice").setValue(membershipPrice);
    } else {
        // formContext.getAttribute("rhs_membershipprice").setValue(null);
    }
}

RHSScripts.BatchOrderLine.SetPriceList = async function (formContext) {
    let priceListLookupValue = await RHSScripts.BatchOrderLine.GetPriceListLookupValue(formContext);
    formContext.getAttribute("rhs_pricelist").setValue(priceListLookupValue);
    formContext.getAttribute("rhs_pricelist").fireOnChange();
}

RHSScripts.BatchOrderLine.SetProductPrice = async function (formContext) {
    let priceListLookup = formContext.getAttribute("rhs_pricelist").getValue();
    let priceListId = priceListLookup ? priceListLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productLookup = formContext.getAttribute("rhs_product").getValue();
    let productId = productLookup ? productLookup[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    let productPrice = await RHSScripts.BatchOrderLine.GetProductPrice(productId, priceListId);
    formContext.getAttribute("rhs_productprice").setValue(productPrice);
    formContext.getAttribute("rhs_productprice").fireOnChange();
}

RHSScripts.BatchOrderLine.SetPostalCharge = async function (formContext) {
    let postalCharge = await RHSScripts.BatchOrderLine.GetPostalCharge(formContext);
    if (postalCharge !== undefined) {
        formContext.getAttribute("rhs_postalcharge").setValue(postalCharge);
        formContext.getAttribute("rhs_postalcharge").fireOnChange();
    }
}

RHSScripts.BatchOrderLine.SetTotalAmount = async function (formContext) {
    let totalAmount = await RHSScripts.BatchOrderLine.CalculateTotalAmount(formContext);
    formContext.getAttribute("rhs_totalamount").setValue(totalAmount);
    formContext.getAttribute("rhs_totalamount").fireOnChange();
}

// Pre-populates 'Amount Paid' with the 'Total Amount' value.
RHSScripts.BatchOrderLine.SetAmountPaidToTotalAmount = function (executionContext) {
    let formContext = executionContext.getFormContext();
    let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
    let amountPaidAttr = formContext.getAttribute("rhs_amountpaid");

    // Check if both attributes exist and total amount has a value
    if (totalAmount !== null && amountPaidAttr !== null) {
        // Only pre-populate if 'Amount Paid' is currently empty (null).
        if (amountPaidAttr.getValue() === null) {
            amountPaidAttr.setValue(totalAmount);

            amountPaidAttr.fireOnChange();
        }
    }
};

RHSScripts.BatchOrderLine.SetPricings = async function (formContext) {
    let type = formContext.getAttribute("rhs_type").getValue();
    if (type != null && type != 120000004/*Fundraising (Donation)*/) {
        await RHSScripts.BatchOrderLine.SetPriceList(formContext);
        await RHSScripts.BatchOrderLine.SetProductPrice(formContext);
        await RHSScripts.BatchOrderLine.SetTotalAmount(formContext);
    }
}
// #endregion

// #region Validator Functions
RHSScripts.BatchOrderLine.ValidateRenewalField = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    //Batch Order Line Type Field
    const TYPE_MEMBERSHIP_RENEWAL = 120000001;
    const TYPE_SUBSCRIPTION_RENEWAL = 120000003;

    //Membership/Subscription Renewal Status
    const STATUS_RENEWED = 120000001;
    const STATUS_NOT_ELIGIBLE = 120000005;

    let typeValue = formContext.getAttribute("rhs_type").getValue();
    isRenewal = false;

    // Decide which field to validate
    var lookupAttr = null;
    var lookupCtrl = null;
    var lookupFieldName = "";
    var label = "";

    if (typeValue === TYPE_MEMBERSHIP_RENEWAL) {
        lookupFieldName = "rhs_membershipid";
        label = "Membership";
    } else if (typeValue === TYPE_SUBSCRIPTION_RENEWAL) {
        lookupFieldName = "rhs_subscription";
        label = "Subscription";
    } else {
        return; // Not a renewal line
    }

    lookupAttr = formContext.getAttribute(lookupFieldName);
    lookupCtrl = formContext.getControl(lookupFieldName);

    // Clear any existing notification
    lookupCtrl.clearNotification("renewal_invalid");

    let lookupValue = formContext.getAttribute(lookupFieldName).getValue();
    if (!lookupValue) return;
    let recordId = lookupValue[0].id.replace(/[{}]/g, "");
    let entityLogicalName = lookupValue[0].entityType;

    Xrm.WebApi.retrieveRecord(entityLogicalName, recordId, "?$select=rhs_renewalsstatus").then(
        function (result) {
            var status = result["rhs_renewalsstatus"];

            if (status === STATUS_RENEWED || status === STATUS_NOT_ELIGIBLE) {
                // Invalid renewal
                isRenewal = true;
                var msg = "The selected " + label + " cannot be renewed.";
                lookupCtrl.setNotification(msg, "renewal_invalid");

            } else {
                // Valid renewal
                isRenewal = false;
                lookupCtrl.clearNotification("renewal_invalid");

            }
        },
        function (error) {
            console.error("Error retrieving " + label + " record:", error.message);
        }
    );

}

RHSScripts.BatchOrderLine.ValidateRenewalsOnSave = function (executionContext) {
    var formContext = executionContext.getFormContext();
    var eventArgs = executionContext.getEventArgs();

    if (isRenewal = false) {
        eventArgs.preventDefault();

    }
}

RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForPrimaryContact = async function (formContext) {
    let notificationId = "primary_member_invalid";
    let contactControl = formContext.getControl("rhs_primarycontact");
    let contactValue = formContext.getAttribute("rhs_primarycontact").getValue();
    let contactId = contactValue ? contactValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productId = productValue ? productValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    if (contactId) {
        let memberships = await RHSScripts.BatchOrderLine.RetrieveMemberships(contactId);
        let patronMemberships = await RHSScripts.BatchOrderLine.RetrievePatronMemberships(contactId);

        if (productId) {
            let envVarProductParentID = await RHSScripts.BatchOrderLine.GetEnvironmentVariableValue("rhs_PatronMembershipProductParentID");
            let productParentID = await RHSScripts.BatchOrderLine.RetrieveProductParentID(productId);

            if (envVarProductParentID == productParentID) {
                isPatronProduct = true;
            } else {
                isPatronProduct = false;
            }

            if ((memberships.length > 0 && !isPatronProduct) || (patronMemberships.length > 0 && isPatronProduct)) {
                contactControl.setNotification("There is an existing membership for the primary member selected", notificationId);
            } else {
                contactControl.clearNotification(notificationId);
            }
        } else {
            if (memberships.length > 0 && patronMemberships.length > 0) {
                contactControl.setNotification("There is an existing membership for the primary member selected", notificationId);
            } else {
                contactControl.clearNotification(notificationId);
            }
        }
    }
}

RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForSecondaryContact = async function (formContext) {
    let notificationId = "secondary_member_invalid";
    let contactControl = formContext.getControl("rhs_secondarymember");
    let contactValue = formContext.getAttribute("rhs_secondarymember").getValue();
    let contactId = contactValue ? contactValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    let productValue = formContext.getAttribute("rhs_product").getValue();
    let productId = productValue ? productValue[0].id.replace("{", "").replace("}", "").toLowerCase() : null;

    if (contactId) {
        let memberships = await RHSScripts.BatchOrderLine.RetrieveMemberships(contactId);
        let patronMemberships = await RHSScripts.BatchOrderLine.RetrievePatronMemberships(contactId);

        if (productId) {
            let envVarProductParentID = await RHSScripts.BatchOrderLine.GetEnvironmentVariableValue("rhs_PatronMembershipProductParentID");
            let productParentID = await RHSScripts.BatchOrderLine.RetrieveProductParentID(productId);

            if (envVarProductParentID == productParentID) {
                isPatronProduct = true;
            } else {
                isPatronProduct = false;
            }

            if ((memberships.length > 0 && !isPatronProduct) || (patronMemberships.length > 0 && isPatronProduct)) {
                contactControl.setNotification("There is an existing membership for the secondary member selected", notificationId);
            } else {
                contactControl.clearNotification(notificationId);
            }
        } else {
            if (memberships.length > 0 && patronMemberships.length > 0) {
                contactControl.setNotification("There is an existing membership for the secondary member selected", notificationId);
            } else {
                contactControl.clearNotification(notificationId);
            }
        }
    }
}

RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForMembersOfNewMembership = async function (formContext) {
    let type = formContext.getAttribute("rhs_type").getValue();

    if (type == 120000000 /*New Membership*/) {
        await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForPrimaryContact(formContext);
        await RHSScripts.BatchOrderLine.ValidateDuplicateMembershipForSecondaryContact(formContext);
    }
}

RHSScripts.BatchOrderLine.SetPaymentDate = function (executionContext) {
    let formContext = executionContext.getFormContext();
    let paymentDate = formContext.getAttribute("rhs_paymentdate");

    if (paymentDate.getValue() == null) {
        let today = new Date();
        today.setHours(0, 0, 0, 0);
        paymentDate.setValue(today);
    }
}
// #endregion
// #region Get Environment Variable Value Function
RHSScripts.BatchOrderLine.GetEnvironmentVariableValue = async function (schemaName) {
    if (!schemaName)
        return null;

    let entityVariableResults = await Xrm.WebApi.retrieveMultipleRecords("environmentvariabledefinition", "?$filter=schemaname eq '" + schemaName + "'&$select=defaultvalue,environmentvariabledefinitionid&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)");

    if (!entityVariableResults || !entityVariableResults.entities || entityVariableResults.entities.length < 1)
        return null;
    let environmentVariableValue = entityVariableResults.entities[0];
    if (!environmentVariableValue.environmentvariabledefinition_environmentvariablevalue || environmentVariableValue.environmentvariabledefinition_environmentvariablevalue.length < 1)
        return entityVariableResults.entities[0].defaultvalue;

    return environmentVariableValue.environmentvariabledefinition_environmentvariablevalue[0].value;
}
// #endregion