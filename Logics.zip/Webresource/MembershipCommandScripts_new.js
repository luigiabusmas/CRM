// JavaScript source code
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Membership) === "undefined") { RHSScripts.Membership = {}; }

const SUBMITTING_PAYMENT_NOTIFICATION_ID = "SubmittingPaymentNotification";
const MEMBERSHIP_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID = "MembershipTransactionSuccessfulNotification";
const MEMBERSHIP_TRANSACTION_FAILED_NOTIFICATION_ID = "MembershipTransactionFailedNotification";
const CIRRUS_TRANSACTION_NOTIFICATION_ID = "CirrusPaymentNotification";

//#region Command Functions
RHSScripts.Membership.ChangePaymentMethodCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    formContext.getControl("rhs_paymentmethod").setDisabled(false);
    formContext.getControl("rhs_iscontinuouspayment").setDisabled(false);
    formContext.getControl("rhs_paymentfrequency").setDisabled(false);
    formContext.getControl("rhs_paymentschedule").setDisabled(false);

    formContext.getAttribute("rhs_paymentmethod").setValue(null);
    formContext.getAttribute("rhs_iscontinuouspayment").setValue(false);
    formContext.getAttribute("rhs_paymentfrequency").setValue(null);
    formContext.getAttribute("rhs_paymentschedule").setValue(null);

    Xrm.Page.getAttribute("rhs_paymentmethod").setRequiredLevel("required");
}

RHSScripts.Membership.GiftAidDeclarationCommand = async function (primaryControl) {
    'use strict';
    var formContext = primaryControl;

    // Validation Start
    var payerField = formContext.getAttribute("rhs_payerv2");
    var payerValue = payerField ? payerField.getValue() : null;

    if (!payerValue || payerValue.length === 0) {
        var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as the Payer field is empty. \n\nPlease add a Payer and try again.", title: "Action Required" };
        var alertOptions = { height: 215, width: 590 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        return;
    }
    var contactId = payerValue[0].id.replace("{", "").replace("}", "").toLowerCase();
    var payerType = payerValue[0].entityType.toLowerCase();
    console.log("Payer:", payerValue);
    console.log("payerValue Length:", payerValue.length);

    if (payerType !== "contact") {
        var alertStrings = { text: "\nThe Payer should be a Contact", title: "Information" };
        var alertOptions = { height: 100, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        return;
    }

    if (payerType === "contact") {
        console.log("CotactId:", contactId);
        try {
            var contactDetails = await Xrm.WebApi.retrieveRecord("contact", contactId, "?$select=address1_country,address1_postalcode,address1_city,address1_line1,rhs_loqatehomeaddresshousename");
            var country = contactDetails['address1_country'];
            var normalCountry = country ? country.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\W_-]+/g, '') : '';
            var isUK = normalCountry === 'unitedkingdom' || normalCountry === 'uk';
            var houseName = contactDetails['rhs_loqatehomeaddresshousename'];
            var addressLine1 = contactDetails['address1_line1'];
            var city = contactDetails['address1_city'];
            var postCode = contactDetails['address1_postalcode'];
            console.log("normalCountry: " + normalCountry);

            if (normalCountry && isUK) {
                if (!postCode || !city || !(addressLine1 || houseName)) {
                    var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Contact (Payer) does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
                    var alertOptions = { height: 240, width: 590 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    return;
                }
            } else if (!normalCountry) {
                var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Contact (Payer) does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
                var alertOptions = { height: 240, width: 590 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                return;
            }
        } catch (error) {
            console.error("Error retrieving contact details:", error.message);
            alert("Error retrieving contact details: " + error.message);
        }
    }
    // Validation End
    var entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    var customPageName = "rhs_newgiftaiddeclaration_fff4a";
    var pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "membership",
        recordId: entityId
    };

    var navigationOptions = {
        target: 1,
        position: 1
    };

    // Navigate to the custom page
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(function () {
            console.log("Custom page opened successfully in the workspace.");
        })
        .catch(function (error) {
            console.error("Error navigating to the custom page:", error.message);
        });
}

RHSScripts.Membership.RedeemGiftPackCodeCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    formContext.getAttribute("rhs_redeemgiftpack").setValue(true);
    formContext.getControl("rhs_activationcode").setVisible(true);
    formContext.getControl("rhs_isreferredbyexistingmember").setVisible(false);
    formContext.getControl("rhs_isregistrationforgiftaid").setVisible(false);
    formContext.getControl("rhs_payerv2").setVisible(false);
    formContext.getControl("rhs_ismembershipforsomeone").setVisible(false);
    formContext.getControl("rhs_campaignid").setVisible(false);
    Xrm.Page.getAttribute("rhs_activationcode").setRequiredLevel("required");
    formContext.getControl("rhs_membershipproductid").setDisabled(true);

    formContext.getAttribute("rhs_issubmitpayment").setValue(true);
    formContext.getAttribute("rhs_paymentreceived").setValue(true);
    formContext.getAttribute("statuscode").setValue(1);

    var tabName = "Summary";
    var sectionName = "Summary_section_8a";

    // Check if the tab exists and is visible
    var tab = formContext.ui.tabs.get(tabName);
    if (tab) {
        var section = tab.sections.get(sectionName);
        if (section) {
            // Hide the section
            section.setVisible(false);
        } else {
            console.error(`Section '${sectionName}' not found in tab '${tabName}'.`);
        }
    } else {
        console.error(`Tab '${tabName}' not found.`);
    }

}

RHSScripts.Membership.ChangePayerCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    formContext.getControl("rhs_payerv2").setDisabled(false);
    formContext.getControl("rhs_ismembershipforsomeone").setDisabled(false);

    formContext.getControl("rhs_payerv2").setValue(null);
    Xrm.Page.getAttribute("rhs_payerv2").setRequiredLevel("required");
}

RHSScripts.Membership.AddDonationCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    formContext.getControl("rhs_totalamount").setDisabled(false);
    formContext.getAttribute("rhs_totalamount").setRequiredLevel("required");

    formContext.getControl("rhs_campaigndonation").setVisible(true);
    formContext.getAttribute("rhs_campaigndonation").setRequiredLevel("required");

    formContext.getControl("rhs_donationamount").setVisible(true);
}

RHSScripts.Membership.MakePaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let product = formContext.getAttribute("rhs_membershipproductid").getValue()?.[0];

    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let payer = formContext.getAttribute("rhs_payerv2").getValue()?.[0];
    let isContinuousPayment = formContext.getAttribute("rhs_iscontinuouspayment").getValue();
    let paymentFrequency = formContext.getAttribute("rhs_paymentfrequency").getValue();
    let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
    let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();

    let checkoutURL = formContext.getAttribute("rhs_checkouturl").getValue();
    let checkoutSessionId = formContext.getAttribute("rhs_checkoutsessionid").getValue();

    let donationCampaign = formContext.getAttribute("rhs_campaigndonation").getValue()?.[0];
    let donationAmount = formContext.getAttribute("rhs_donationamount").getValue();;

    try {
        let isSubmitPayment = formContext.getAttribute("rhs_issubmitpayment").getValue();
        let isPaymentReceived = formContext.getAttribute("rhs_paymentreceived").getValue();

        if (isPaymentReceived != true) {
            //#region  Prepare the membership for payment submission
            Xrm.Utility.showProgressIndicator("Submitting payment. Please wait...");
            formContext.ui.clearFormNotification(MEMBERSHIP_TRANSACTION_FAILED_NOTIFICATION_ID);
            formContext.ui.clearFormNotification(MEMBERSHIP_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Submitting payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);

            // await RHSScripts.Membership.SetStartDateEndDateAndPayoutDate(formContext); // Date calculation logic moved to MembershipUpdatePreOpsPlugin

            formContext.getAttribute("rhs_issubmitpayment").setValue(true); // Trigger date fields population and disables the button.
            formContext.getAttribute("rhs_issubmitpayment").fireOnChange();
            await formContext.data.save();
            await formContext.data.refresh(true);
            //#endregion

            //#region  Generate transaction, payments and payment schedule
            let [transactionId, paymentId, payementscheduleId, donationId] = [null, null, null, null];
            let transaction = await RHSScripts.Membership.RetrieveActiveMembershipTransaction(membershipId);
            let firstPayment = await RHSScripts.Membership.RetrieveActiveMembershipFirstPayment(membershipId);
            let donation = await RHSScripts.Membership.RetrieveActiveMembershipDonation(membershipId);

            let isMembershipChanged = await RHSScripts.Membership.CheckIfMembershipWasChangedFromLastTransaction(formContext, transaction);
            let isFirstDDPaymentDueDateElapsed = paymentMethod == 120000002/*DD*/ && firstPayment?.rhs_duedate && new Date(firstPayment.rhs_duedate) < new Date();
            if (isMembershipChanged || isFirstDDPaymentDueDateElapsed) {
                await RHSScripts.Membership.CancelTransactionAndAssociatedRecords(transaction);
            }

            if (!transaction || isMembershipChanged || isFirstDDPaymentDueDateElapsed) {
                let membershipTotalAmount = donationAmount && totalAmount == outstandingAmount ? totalAmount - donationAmount : totalAmount;
                let membershipOutstandingAmount = donationAmount && totalAmount == outstandingAmount ? outstandingAmount - donationAmount : outstandingAmount;
                [transactionId, paymentId, payementscheduleId] = await RHSScripts.Membership.ExecuteSubmitPaymentCustomAPIForMembership(
                    paymentMethod, membershipId, payer, isContinuousPayment, paymentFrequency, membershipTotalAmount, membershipOutstandingAmount
                );
                await formContext.data.refresh(true);

                if (transactionId == null && paymentId == null && payementscheduleId == null) {
                    throw new Error("Membership transaction failed.");
                } else {
                    transaction = await RHSScripts.Membership.RetrieveActiveMembershipTransaction(membershipId);
                }
            } else {
                transactionId = transaction.rhs_transactionid;
            }

            if (product.name.toLowerCase().includes("patron") && donationAmount && totalAmount == outstandingAmount && !donation) {
                donationId = await RHSScripts.Membership.ExecuteInjectMembershipDonation(membershipId);
                await formContext.data.refresh(true);

                if (donationId == null) {
                    throw new Error("Membership transaction failed.");
                } else {
                    donation = await RHSScripts.Membership.RetrieveActiveMembershipDonation(membershipId);
                }
            }

            //#endregion

            //#region  Make/Submit Payment
            if (paymentMethod != 120000014) /*Credit Card Phone */ {
                if (paymentMethod == 844060000/*Cash*/ || paymentMethod == 844060001/*Cheque*/ ||
                    paymentMethod == 844060004/*CAF*/ || paymentMethod == 844060003/*PWAC*/ || paymentMethod == 120000003/*Third Parties*/
                ) {
                    let payments = await RHSScripts.Membership.RetrieveActiveMembershipPayments(membershipId);
                    for (let ctr = 0; ctr < payments.length; ctr++)
                        await RHSScripts.Membership.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);
                } else if (paymentMethod == 120000002/*DD*/) {
                    if (await RHSScripts.Membership.ValidateIfLinkedMembershipPaymentMethodIsDirectDebit(formContext)) {
                        let linkedMembershipId = formContext.getAttribute("rhs_linkedmembership").getValue()[0].id.replace("{", "").replace("}", "").toLowerCase();
                        await RHSScripts.Membership.ContinueUsingSameDirectDebitForMembership(linkedMembershipId, membershipId);
                    } else {
                        await RHSScripts.Membership.MakePTXPayment(membershipId, paymentFrequency, payer);
                    }
                }
                await RHSScripts.Membership.ActivateMembership(membershipId);
            }
            else if (paymentMethod == 120000014/*Credit Card Phone*/) {
                await RHSScripts.Membership.MakeCirrusPCIpaymentURL(membershipId, payer, totalAmount, false);
            }

            //#region Patron Logics
            if (product.name.toLowerCase().includes("patron")) {
                if (donationId) {
                    await RHSScripts.Membership.ActivateDonation(donationId, paymentMethod);
                }

                if (await RHSScripts.Membership.ValidateIfPatronFellow(membershipId, paymentMethod)) {
                    await RHSScripts.Membership.ExecuteSubscriptionCreationAPI(membershipId);
                }
            }
            //#endregion

            await formContext.data.refresh(true);
            //#endregion

            //#region  Ending payment submission
            Xrm.Utility.closeProgressIndicator();
            formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Membership transaction successful.", "INFO", MEMBERSHIP_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            Xrm.Navigation.openAlertDialog({ title: "Success", text: "Payment successful." });
            //#endregion
        }
    } catch (error) {
        formContext.getAttribute("rhs_issubmitpayment").setValue(false);
        formContext.getAttribute("rhs_issubmitpayment").fireOnChange();
        await formContext.data.save();
        await formContext.data.refresh(true);

        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Membership transaction failed. Please try again", "ERROR", MEMBERSHIP_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Payment failed. \n\nDetails: " + error.message });
    }
}

RHSScripts.Membership.ChangeMembership = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    let renewalStatus = formContext.getAttribute("rhs_renewalsstatus").getValue();
    let inRenewalStage = formContext.getAttribute("rhs_inrenewalsstage").getValue();

    if (renewalStatus == 120000000/*Pending Renewal*/ && inRenewalStage == true) {
        await RHSScripts.Membership.ChangeMembershipDuringRenewalPeriod(formContext);
    } else {
        await RHSScripts.Membership.ChangeMembershipOutsideRenewalPeriod(formContext);
    }
}

/*RHSScripts.Membership.ConsentsCommand = function (primaryControl) {
    'use strict';

    var formContext = primaryControl;
    var payer = formContext.getAttribute("rhs_payerv2").getValue();

    if (payer !== null) {
        var payerEntityType = payer[0].entityType.toLowerCase();
        //if account
        if (payerEntityType === "account") {
            var alertStrings = { text: "Payer is not a Contact.", title: "Information" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        }
        //elseif countact
        else if (payerEntityType === "contact") {

            var payerId = payer[0].id.replace("{", "").replace("}", "").toLowerCase();
            var customPageName = "rhs_contactpointconsentspage_0516f";
            var pageInput = {
                pageType: "custom",
                name: customPageName,
                entityName: "contact",
                recordId: payerId
            };

            var navigationOptions = {
                target: 1,
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions)
                .then(function () {
                    console.log("Custom page opened successfully in the workspace.");
                })
                .catch(function (error) {
                    console.error("Error navigating to the custom page:", error.message);
                });
        }
    }
    else { console.log("Payer should have a value."); }
}*/

RHSScripts.Membership.RefundPayment = async function (primaryControl) {
    'use strict';
}

RHSScripts.Membership.RhsMemberRenewEarly = async function (primaryControl) {
    'use strict';

    try {
        let formContext = primaryControl;
        const poundSymbol = "\u00A3";
        // Check if outstanding amount exists
        if (formContext.getAttribute("rhs_outstandingamount")) {
            let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
            let paymentFrequency = formContext.getAttribute("rhs_paymentfrequency")?.getValue() || null;
            let paymentSchedule = formContext.getAttribute("rhs_paymentschedule")?.getValue() || null;

            if (outstandingAmount === 0) {
                let confirmOptions = { text: "Customer is not in renewal, and balance is \u00A30. Confirm advance payment.", title: "Confirm Renewal" };

                let response = await Xrm.Navigation.openConfirmDialog(confirmOptions);
                if (response.confirmed) {
                    Xrm.Utility.showProgressIndicator("Renewing membership early. Please wait...");

                    formContext.getAttribute("rhs_inrenewalsstage")?.setValue(true);

                    //if (formContext.getAttribute("rhs_enddate")) {
                    //    let currentEndDate = formContext.getAttribute("rhs_enddate").getValue();
                    //    if (currentEndDate) {
                    //        let renewalEndDate = new Date(currentEndDate);
                    //        renewalEndDate.setMonth(renewalEndDate.getMonth() + 3);

                    //        let renewalStartDate = new Date(currentEndDate);
                    //        renewalStartDate.setMonth(renewalStartDate.getMonth() - 2);

                    //        formContext.getAttribute("rhs_RenewalsStartDate")?.setValue(renewalStartDate);
                    //        formContext.getAttribute("rhs_RenewalsEndDate")?.setValue(renewalEndDate);
                    //    }
                    //}

                    // formContext.getAttribute("rhs_startdate")?.setValue(new Date());
                    // formContext.getAttribute("rhs_renewalpaymentfrequency")?.setValue(paymentFrequency);
                    // formContext.getAttribute("rhs_renewalpaymentschedule")?.setValue(paymentSchedule);

                    try {
                        // **Wait for the save operation to complete**
                        await formContext.data.save();

                        // **API Call after successful save**
                        let apiCallResult = await RHSScripts.Membership.CallMembershipRenewalsCustomAPI(formContext, true);

                        if (!apiCallResult || apiCallResult.status !== "success") {
                            formContext.getAttribute("rhs_inrenewalsstage")?.setValue(false);
                            await formContext.data.save();

                            Xrm.Utility.closeProgressIndicator();
                            await Xrm.Navigation.openAlertDialog({ text: "API call failed. Renewal cannot continue." });
                            return;
                        }

                        // **Show success message and refresh form**
                        await Xrm.Navigation.openAlertDialog({ text: "This membership has been placed in its renewal period." });
                        await formContext.data.save();
                        await formContext.data.refresh(true);

                        // **Show renewal sections**
                        await RHSScripts.Membership.ShowRenewalSections(formContext);
                    } catch (saveError) {
                        await Xrm.Navigation.openAlertDialog({ text: "Error: Unable to save the record. Try again." });
                    }

                    Xrm.Utility.closeProgressIndicator();
                } else {
                    await Xrm.Navigation.openAlertDialog({ text: "Action canceled." });
                }
            } else {
                await Xrm.Navigation.openAlertDialog({ text: "Customer balance is not \u00A30. Renewal cannot proceed." });
            }
        } else {
            await Xrm.Navigation.openAlertDialog({ text: "Error: Outstanding amount field is missing." });
        }

    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        await Xrm.Navigation.openAlertDialog({ text: "An unexpected error occurred: " + error.message });
    }
}

RHSScripts.Membership.TakeRenewalPaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let currentMembershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let currentMembershipPaymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let currentMembershipStatusReason = formContext.getAttribute("statuscode").getValue();


    try {
        //#region  Prepare the membership for renewal payment submission
        Xrm.Utility.showProgressIndicator("Submitting renewal payment. Please wait...");
        formContext.ui.clearFormNotification(MEMBERSHIP_TRANSACTION_FAILED_NOTIFICATION_ID);
        formContext.ui.clearFormNotification(MEMBERSHIP_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Submitting renewal payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);
        //#endregion

        //#region Retrieve/Create a new Membership Instance
        let newMembership = await RHSScripts.Membership.RetrieveRenewalMembership(currentMembershipId);
        let newMembershipId = null;

        if (newMembership == null) {
            newMembershipId = await RHSScripts.Membership.ExecuteCreateMembershipOnRenewalsCustomAPI(currentMembershipId);
            newMembership = await Xrm.WebApi.retrieveRecord("rhs_membership", newMembershipId);
        } else {
            newMembershipId = newMembership["rhs_membershipid"];
        }

        let newMembershipPayer = {
            "id": newMembership["_rhs_payerv2_value"],
            "entityType": newMembership["_rhs_payerv2_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
            "name": newMembership["_rhs_payerv2_value@OData.Community.Display.V1.FormattedValue"]
        };
        let newMembershipProduct = {
            "id": newMembership["_rhs_membershipproductid_value"],
            "entityType": newMembership["_rhs_membershipproductid_value@Microsoft.Dynamics.CRM.lookuplogicalname"],
            "name": newMembership["_rhs_membershipproductid_value@OData.Community.Display.V1.FormattedValue"]
        };
        let newMembershipStartDate = newMembership.rhs_startdate;
        let newMembershipPaymentMethod = newMembership.rhs_paymentmethod;
        let newMembershipIsContinuousPayment = newMembership.rhs_iscontinuouspayment;
        let newMembershipPaymentFrequency = newMembership.rhs_paymentfrequency;
        let newMembershipTotalAmount = newMembership.rhs_totalamount;
        let newMembershipOutstandingAmount = newMembership.rhs_outstandingamount;
        let newMembershipCheckoutUrl = newMembership.rhs_checkouturl;
        let newMembershipCheckoutSessionId = newMembership.rhs_checkoutsessionid;
        //#endregion

        //#region Generate transaction, payments and payment schedule for new Membership Instance
        if (newMembershipPaymentMethod != 844060005/*Gift Pack*/) {
            let transaction = await RHSScripts.Membership.RetrieveActiveMembershipTransaction(newMembershipId);
            if (transaction == null) {
                let [transactionid, paymentid, payementscheduleid] = await RHSScripts.Membership.ExecuteSubmitPaymentCustomAPIForMembership(
                    newMembershipPaymentMethod,
                    newMembershipId,
                    newMembershipPayer,
                    newMembershipIsContinuousPayment,
                    newMembershipPaymentFrequency,
                    newMembershipTotalAmount,
                    newMembershipOutstandingAmount
                );
                if (transactionid == null && paymentid == null && payementscheduleid == null)
                    throw new Error("Membership renewal transaction failed.");
            }
        }
        //#endregion

        //#region Make/Submit Payment for new Membership Instance

        // Check if Renewals Payment Method Direct Debit
        let renewalsPaymentMethod = formContext.getAttribute("rhs_renewalspaymentmethod").getValue();
        if (renewalsPaymentMethod == 120000002) {
            await RHSScripts.Membership.MakePTXPayment(newMembershipId, newMembershipPaymentFrequency, newMembershipPayer);
        } else {
            if (newMembershipPaymentMethod == 844060000/*Cash*/ || newMembershipPaymentMethod == 844060001/*Cheque*/ ||
                newMembershipPaymentMethod == 844060004/*CAF*/ || newMembershipPaymentMethod == 844060003/*PWAC*/
            ) {
                let payments = await RHSScripts.Membership.RetrieveActiveMembershipPayments(newMembershipId);
                for (let ctr = 0; ctr < payments.length; ctr++)
                    await RHSScripts.Membership.UpdatePaymentAsPaid(payments[ctr].rhs_paymentid);
            } else if (newMembershipPaymentMethod == 120000014/* Credit Card Phone*/) {
                await RHSScripts.Membership.MakeCirrusPCIpaymentURL(
                    newMembershipId,
                    newMembershipPayer,
                    newMembershipTotalAmount, true
                );
            } else if (newMembershipPaymentMethod == 120000002/*DD*/) {
                if (currentMembershipPaymentMethod != newMembershipPaymentMethod) {
                    await RHSScripts.Membership.MakePTXPayment(newMembershipId, newMembershipPaymentFrequency, newMembershipPayer);
                } else {
                    await RHSScripts.Membership.ContinueUsingSameDirectDebitForMembership(currentMembershipId, newMembershipId);
                }
            }
        }

        //Update Membership Status on Successful Payment Submission
        if (currentMembershipStatusReason == 120000002/*Dormant*/) {
            await RHSScripts.Membership.UpdateStatusOfPresentAndNewMembershipWhenRenewingDormantMembership(currentMembershipId, newMembershipId);
        } else if (new Date(newMembershipStartDate) > new Date()) {
            await RHSScripts.Membership.SetMembershipAsPaidInAdvance(newMembershipId);
        } else {
            await RHSScripts.Membership.SetMembershipAsProspect(newMembershipId);
        }
        await RHSScripts.Membership.SetMembershipRenewalFieldsOnSuccessfulRenewal(currentMembershipId);

        //Save and Refresh
        await formContext.data.refresh(true);
        await formContext.data.save();
        //#endregion

        //#region Ending renewal payment submission
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Membership renewal transaction successful.", "INFO", MEMBERSHIP_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Success", text: "Renewal is done successfully!" });
        //#endregion
    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Membership renewal transaction failed. Please try again", "ERROR", MEMBERSHIP_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Renewal failed! \n\nDetails: " + error.message });
    }
}

RHSScripts.Membership.RetrieveGoneAwaySuppressionsOfContact = async function (contactId) {
    let fetchXml = `?fetchXml=
        <fetch>
            <entity name="rhs_suppression">
                <attribute name="rhs_newcolumn" />
                <filter>
                    <condition attribute="rhs_newcolumn" operator="eq" value="Gone Away" />
                </filter>
                <link-entity name="rhs_contact_rhs_suppression" from="rhs_suppressionid" to="rhs_suppressionid" intersect="true">
                    <filter>
                        <condition attribute="contactid" operator="eq" value="${contactId}" />
                    </filter>
                </link-entity>
            </entity>
        </fetch>`;

    let goneAwaySuppressions = (await Xrm.WebApi.retrieveMultipleRecords("rhs_suppression", fetchXml)).entities;
    return goneAwaySuppressions;
}

RHSScripts.Membership.ResendMembershipCardCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let resendMembershipCardMHStatus = formContext.getAttribute("rhs_resendmembershipcardmhstatus").getValue();
    let newMembershipPackMHStatus = formContext.getAttribute("rhs_newmembershippackmhstatus").getValue();

    let PrimaryMember = formContext.getAttribute("rhs_contact").getValue();
    let PrimaryMemberId = PrimaryMember[0].id.replace("{", "").replace("}", "").toLowerCase();
    let PrimaryMemberEntity = PrimaryMember[0].entityType;

    let SecondaryMember = formContext.getAttribute("rhs_member2").getValue() ?? [];
    let SecondaryMemberId = (SecondaryMember.length > 0 ? SecondaryMember[0].id.replace("{", "").replace("}", "").toLowerCase() : null) ?? null;
    let SecondaryMemberEntity = (SecondaryMember.length > 0 ? SecondaryMember[0].entityType : null) ?? null;

    let membershipProductLookup = formContext.getAttribute("rhs_membershipproductid").getValue();
    let productId = membershipProductLookup[0].id.replace("{", "").replace("}", "").toLowerCase();

    let allowedMembers = await RHSScripts.Membership.RetrieveProductPropertyResendCard(productId);



    let isContactPrimaryMemberDeceased = PrimaryMemberEntity == "contact" &&
        (await Xrm.WebApi.retrieveMultipleRecords("contact", `?$select=rhs_deceased&$filter=(contactid eq ${PrimaryMemberId} and rhs_deceased eq true)`)).entities.length > 0;
    let doesContactPrimaryMemberHasGoneAwaySuppression = PrimaryMemberEntity == "contact" && (await RHSScripts.Membership.RetrieveGoneAwaySuppressionsOfContact(PrimaryMemberId)).length > 0;

    let isContactSecondaryMemberDeceased = SecondaryMemberEntity == "contact" &&
        (await Xrm.WebApi.retrieveMultipleRecords("contact", `?$select=rhs_deceased&$filter=(contactid eq ${SecondaryMemberId} and rhs_deceased eq true)`)).entities.length > 0;
    let doesContactSecondaryMemberHasGoneAwaySuppression = SecondaryMemberEntity == "contact" && (await RHSScripts.Membership.RetrieveGoneAwaySuppressionsOfContact(SecondaryMemberId)).length > 0;



    if (resendMembershipCardMHStatus == 120000001/*Pending*/ || newMembershipPackMHStatus == 120000001/*Pending*/) {
        await Xrm.Navigation.openErrorDialog({ message: "You are unable to proceed as we are already processing the sending of a membership card." });
    } else {

        if (allowedMembers != 2) {

            if (isContactPrimaryMemberDeceased == false && doesContactPrimaryMemberHasGoneAwaySuppression == false) {
                formContext.getAttribute("rhs_resendmembershipcardmhstatus").setValue(120000001/*Pending*/);
                formContext.getAttribute("rhs_replacementcardrecipient").setValue(120000000/*PrimaryMember*/);
                formContext.getAttribute("rhs_replacementcard").setValue(true);
                formContext.data.save();
                await Xrm.Navigation.openAlertDialog({ text: "Resend Membership card initiated successfully!" });

            } else {

                await Xrm.Navigation.openErrorDialog({ message: "You are unable to proceed as the member has a suppression." });
            }
        } else if (allowedMembers == 2) {

            let responseBoth = await Xrm.Navigation.openConfirmDialog({
                cancelButtonLabel: "No",
                confirmButtonLabel: "Yes",
                text: "Do you want to continue resending the membership card to both Primary Member and Secondary Member?",
                title: "Resend Membership Card"
            });

            let sendToBoth = responseBoth.confirmed;
            let sendToPrimary = false;
            let sendToSecondary = false;

            if (!sendToBoth) {

                let primaryResponse = await Xrm.Navigation.openConfirmDialog({
                    cancelButtonLabel: "No",
                    confirmButtonLabel: "Yes",
                    text: "Do you want to continue resending the membership card to the Primary Member?",
                    title: "Resend Membership Card"
                });

                sendToPrimary = primaryResponse.confirmed;
            }

            if (!sendToBoth && !sendToPrimary) {

                let secondaryResponse = await Xrm.Navigation.openConfirmDialog({
                    cancelButtonLabel: "No",
                    confirmButtonLabel: "Yes",
                    text: "Do you want to continue resending the membership card to the Secondary Member?",
                    title: "Resend Membership Card"
                });

                sendToSecondary = secondaryResponse.confirmed;
            }


            if (sendToBoth) {

                if (isContactPrimaryMemberDeceased == true || doesContactPrimaryMemberHasGoneAwaySuppression == true ||
                    isContactSecondaryMemberDeceased == true || doesContactSecondaryMemberHasGoneAwaySuppression == true) {
                    await Xrm.Navigation.openErrorDialog({ message: "You are unable to proceed as a selected member has a suppression" });
                } else {
                    formContext.getAttribute("rhs_resendmembershipcardmhstatus").setValue(120000001/*Pending*/);
                    formContext.getAttribute("rhs_replacementcardrecipient").setValue(120000002/*BothMembers*/);
                    formContext.getAttribute("rhs_replacementcard").setValue(true);
                    formContext.data.save();
                    await Xrm.Navigation.openAlertDialog({ text: "Resend Membership card initiated successfully!" });
                }
            } else if (sendToPrimary) {

                if (isContactPrimaryMemberDeceased == true || doesContactPrimaryMemberHasGoneAwaySuppression == true) {
                    await Xrm.Navigation.openErrorDialog({ message: "You are unable to proceed as the Primary Member has a suppression" });
                } else {
                    formContext.getAttribute("rhs_resendmembershipcardmhstatus").setValue(120000001/*Pending*/);
                    formContext.getAttribute("rhs_replacementcardrecipient").setValue(120000000/*PrimaryMember*/);
                    formContext.getAttribute("rhs_replacementcard").setValue(true);
                    formContext.data.save();
                    await Xrm.Navigation.openAlertDialog({ text: "Resend Membership card initiated successfully!" });
                }
            } else if (sendToSecondary) {

                if (isContactSecondaryMemberDeceased == true || doesContactSecondaryMemberHasGoneAwaySuppression == true) {
                    await Xrm.Navigation.openErrorDialog({ message: "You are unable to proceed as the Secondary Member has a suppression" });
                } else {
                    formContext.getAttribute("rhs_resendmembershipcardmhstatus").setValue(120000001/*Pending*/);
                    formContext.getAttribute("rhs_replacementcardrecipient").setValue(120000001/*SecondaryMember*/);
                    formContext.getAttribute("rhs_replacementcard").setValue(true);
                    formContext.data.save();
                    await Xrm.Navigation.openAlertDialog({ text: "Resend Membership card initiated successfully!" });
                }
            } else {
                console.log("No selection made for resending membership card.");
            }
        } else {
            console.log("Allowed members is not 2");
        }
    }

}

RHSScripts.Membership.RedeemGiftPackCodeForRenewalCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    formContext.getControl("rhs_renewalscampaign").setVisible(false);
    formContext.getAttribute("rhs_renewalscampaign").setValue(null);
    formContext.getAttribute("rhs_redeemrenewalgiftpack").setValue(true);
    formContext.getControl("rhs_renewalgiftpackactivationcode").setVisible(true);
    formContext.getAttribute("rhs_renewalgiftpackactivationcode").setRequiredLevel("required");
    formContext.getControl("rhs_renewalspaymentmethod").setVisible(false);
    formContext.getAttribute("rhs_renewalspaymentmethod").setValue(844060005/*Gift Pack*/);
    // formContext.getControl("rhs_renewalstotalamount").setVisible(false);
    formContext.getAttribute("rhs_renewalstotalamount").setValue(0);
}

RHSScripts.Membership.CancelMembershipCommand = async function (primaryControl) {
    'use strict';
    //let formContext = primaryControl;

    //formContext.getAttribute("rhs_cancelmembership").setValue(true);
    //formContext.getAttribute("rhs_cancelmembership").fireOnChange(); //triggers busines rule
    let formContext = primaryControl;
    let entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let customPageName = "rhs_newmembershipcancellation_7abc8";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_membership",
        recordId: entityId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Cancel Membership"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );


}

RHSScripts.Membership.AgentScriptsCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_membershipagentscripts_dcfe6";
    let pageInput = {
        pageType: "custom",
        name: customPageName
    };

    let paneOptions = {
        title: "Agent Scripts",
        paneId: "AgentScripts",
        canClose: true,
        width: 500
    };

    Xrm.App.sidePanes.createPane(paneOptions).then((pane) => {
        pane.navigate(pageInput);
    })
}
//#endregion

//#region Helper
//#region Helper Functions
RHSScripts.Membership.RetrieveProductPropertyResendCard = async function (productId) {
    'use strict';
    let allowedMembers = null;

    let fetchData = {
        "name": "Number of Members Allowed",
        "productid": productId
    };

    let fetchXml = [
        `<fetch>`,
        `    <entity name="dynamicproperty">`,
        `        <attribute name="defaultvalueinteger" />`,
        `        <filter>`,
        `            <condition attribute="name" operator="like" value="${fetchData.name}" />`,
        `        </filter>`,
        `        <link-entity name="dynamicpropertyassociation" from="dynamicpropertyid" to="dynamicpropertyid" alias="Association">`,
        `            <attribute name="regardingobjectid" />`,
        `            <filter>`,
        `                <condition attribute="associationstatus" operator="eq" value="0" />`,
        `                <condition attribute="regardingobjectid" operator="eq" value="${fetchData.productid}" />`,
        `            </filter>`,
        `        </link-entity>`,
        `    </entity>`,
        `</fetch>`,
    ].join("");

    // Execute the FetchXML query using the Web API
    await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + encodeURIComponent(fetchXml))
        .then(function (result) {
            if (result.entities.length > 0) {
                let dynamicProperty = result.entities[0];

                allowedMembers = dynamicProperty.defaultvalueinteger;
                console.log("Number of Members Allowed:", allowedMembers);

            } else {
                console.warn("No dynamic property found.");
            }
        })
        .catch(function (error) {
            console.error("Error retrieving dynamic property:", error.message);
        });

    return allowedMembers;
}



RHSScripts.Membership.RetrieveProductProperty = async function (productId) {
    'use strict';
    let allowedMembers = null;

    let fetchData = {
        "name": "Number of Members Allowed",
        "productid": productId
    };

    let fetchXml = [
        "<fetch returntotalrecordcount='true'>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='dynamicpropertyid'/>",
        "    <attribute name='defaultvalueinteger'/>",
        "    <attribute name='name'/>",
        "    <filter type='and'>",
        "      <condition attribute='name' operator='eq' value='", fetchData.name, "'/>",
        "    </filter>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='aa'>",
        "      <link-entity name='product' from='productid' to='regardingobjectid' alias='ab'>",
        "        <filter>",
        "          <condition attribute='productid' operator='eq' value='", fetchData.productid, "'/>",
        "        </filter>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    // Execute the FetchXML query using the Web API
    await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + encodeURIComponent(fetchXml))
        .then(function (result) {
            if (result.entities.length > 0) {
                let dynamicProperty = result.entities[0];

                allowedMembers = dynamicProperty.defaultvalueinteger;
                console.log("Number of Members Allowed:", allowedMembers);

            } else {
                console.warn("No dynamic property found.");
            }
        })
        .catch(function (error) {
            console.error("Error retrieving dynamic property:", error.message);
        });

    return allowedMembers;
}

RHSScripts.Membership.OpenNewMembershipForm = function (parameters) {
    'use strict';
    let entityFormOptions = {
        entityName: "rhs_membership",
        openInNewWindow: true,
        useQuickCreateForm: false,
    };

    // Open the new form with pre-populated values
    Xrm.Navigation.openForm(entityFormOptions, parameters).then(
        function (success) {
            console.log("New Membership form opened successfully");
        },
        function (error) {
            console.error("Error opening new Membership form: ", error.message);
        }
    );
}

RHSScripts.Membership.DeactivateMembership = async function (entityName, membershipId, statuscode) {
    'use strict';

    let reasonName = "Change Membership Type";
    let cancellationReason = await RHSScripts.Membership.RetrieveCancellationreason(reasonName);
    let cancellationReasonId = null;
    if (cancellationReason !== null) {
        cancellationReasonId = cancellationReason["rhs_cancellationreasonid"];
    }

    var record = {};
    record.statecode = 1;
    record.statuscode = statuscode;
    record.rhs_cancelmembership = true;
    record.rhs_cancellationtype = 120000000;
    record["rhs_MembershipCancellationReasonId@odata.bind"] = "/rhs_cancellationreasons(" + cancellationReasonId + ")"; // Lookup

    await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record).then(
        function success(result) {
            var updatedId = result.id;
            console.log(updatedId);
        },
        function (error) {
            console.log(error.message);
        }
    );
};

RHSScripts.Membership.GenerateRandomString = function (length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';

    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters.charAt(randomIndex);
    }
    return result;
}

RHSScripts.Membership.RetrieveCancellationreason = async function (reasonName) {
    let entityLogicalName = "rhs_cancellationreason";
    let options = "".concat(
        "?$select=rhs_cancellationreasonid,rhs_name",
        `&$filter=(rhs_name eq '${reasonName}')`,
        "&$top=1"
    );

    return await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options).then(
        function success(result) {
            return result.entities[0];
        },
        function (error) {
            console.log(error.message);
            return null;
        }
    );
}

RHSScripts.Membership.RetrieveMembershipTransaction = async function (membershipId) {
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,_rhs_membershipid_value,rhs_outstandingamount",
        `&$filter=(_rhs_membershipid_value eq ${membershipId})`,
        "&$top=1"
    );

    return await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options).then(
        function success(result) {
            return result.entities[0];
        },
        function (error) {
            console.log(error.message);
            return null;
        }
    );
}

RHSScripts.Membership.RetrieveActiveMembershipTransaction = async function (membershipId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = `?$filter=(_rhs_membershipid_value eq ${membershipId} and (statecode eq 0 or statuscode eq 120000008))`;

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.Membership.RetrievePaidMembershipTransaction = async function (membershipId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = `?$filter=(_rhs_membershipid_value eq ${membershipId} and (statecode eq 1 and statuscode eq 120000008))`;

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.Membership.RetrieveActiveMembershipDonation = async function (membershipId) {
    let donation = null;
    let entityLogicalName = "rhs_donation";
    let options = "".concat(
        "?$select=rhs_amount,_rhs_campaign_value,rhs_ongoingddamount,rhs_paymentmethodcode,rhs_donationid",
        `&$expand=rhs_transaction_rhs_donation($select=rhs_transactionid;$filter=(_rhs_membershipid_value eq ${membershipId} and statecode eq 0))`,
        `&$filter=(rhs_transaction_rhs_donation/any(o1:(o1/_rhs_membershipid_value eq ${membershipId} and o1/statecode eq 0)))`
    );

    let donations = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (donations != undefined && donations != null && donations.length > 0)
        donation = donations[0];

    return donation;
}

RHSScripts.Membership.RetrieveActiveMembershipPaymentSchedule = async function (membershipId) {
    let paymentSchedule = null;
    let entityLogicalName = "rhs_paymentschedule";
    let options = `?$filter=_rhs_membership_value eq ${membershipId}`;

    let paymentSchedules = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (paymentSchedules != undefined && paymentSchedules != null && paymentSchedules.length > 0)
        paymentSchedule = paymentSchedules[0];

    return paymentSchedule;
}

RHSScripts.Membership.RetrieveActiveMembershipFirstPayment = async function (membershipId) {
    let payments = await RHSScripts.Membership.RetrieveActiveMembershipPayments(membershipId);
    let firstPayment = payments ? payments[0] : null;
    return firstPayment;
}

RHSScripts.Membership.RetrieveActiveMembershipPayments = async function (membershipId) {
    let payments = null;
    let entityLogicalName = "rhs_payment";
    let options = "".concat(
        "?$select=rhs_paymentid,rhs_paymentsid,rhs_amount,rhs_duedate,statuscode,statecode",
        `&$filter=(rhs_Transaction/_rhs_membershipid_value eq ${membershipId} and statecode eq 0)`,
        "&$orderby=rhs_duedate asc"
    );

    payments = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return payments;
}

RHSScripts.Membership.UpdatePaymentAsPaid = async function (paymentId) {
    await Xrm.WebApi.updateRecord("rhs_payment", paymentId, { "rhs_paidon": (new Date()).toISOString().substring(0, 10), "statecode": 1/*Inactive*/, "statuscode": 2/*Paid*/ });
}

RHSScripts.Membership.ExecuteSubmitPaymentCustomAPIForMembership = async function (paymentMethod, membershipId, payer, isContinuousPayment, paymentFrequency, totalAmount, outstandingAmount) {
    // Parameters
    let parameters = {};
    parameters.PaymentMethod = paymentMethod;
    parameters.RecordId = membershipId;
    parameters.PayerId = payer != null ? payer.id.replace("{", "").replace("}", "").toLowerCase() : null;
    parameters.IsContiniousPayment = isContinuousPayment;
    parameters.PaymentFrequency = paymentFrequency;
    parameters.TransactionType = 120000002;
    parameters.Type = 120000000;
    parameters.PayerEntity = payer != null ? payer.entityType : null;
    parameters.TotalAmount = outstandingAmount != null ? outstandingAmount : totalAmount;
    parameters.OutstandingAmount = outstandingAmount;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_submitpayment_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let transactionid = result["TransactionId"];
        let paymentid = result["PaymentId"];
        let payementscheduleid = result["PayementScheduleId"];
        return [transactionid, paymentid, payementscheduleid]
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Membership.ExecuteInjectMembershipDonation = async function (membershipId) {
    // Parameters
    let parameters = {};
    parameters.MembershipId = membershipId;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_injectmembershipdonation_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let donationId = result["DonationId"];
        return donationId;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

// Logic moved to MembershipUpdatePreOpsPlugin
// RHSScripts.Membership.SetStartDateEndDateAndPayoutDate = async function (formContext) {
//     // Retrieve product duration
//     let product = formContext.getAttribute("rhs_membershipproductid").getValue();
//     let productId = product[0].id.replace("{", "").replace("}", "").toLowerCase();
//     let productName = product[0].name

//     let propertyEntityLogicalName = "dynamicproperty";
//     let propertyOptions = "".concat(
//         `?$select=dynamicpropertyid,name,_defaultvalueoptionset_value`,
//         `&$expand=Dynamicproperty_DynamicPropertyAssociation($filter=(_regardingobjectid_value eq ${productId} and associationstatus eq 0))`,
//         `&$filter=(name eq 'Duration') and (Dynamicproperty_DynamicPropertyAssociation/any(o1:(o1/_regardingobjectid_value eq ${productId} and o1/associationstatus eq 0)))`,
//         `&$top=1`
//     );
//     let durationProperty = (await Xrm.WebApi.retrieveMultipleRecords(propertyEntityLogicalName, propertyOptions)).entities[0];

//     let defaultPropertyOptionSetEntityLogicalName = "dynamicpropertyoptionsetitem";
//     let defaultPropertyOptionSetId = durationProperty._defaultvalueoptionset_value;
//     let defaultPropertyOptionSetOptions = "?$select=dynamicpropertyoptionname,dynamicpropertyoptionvalue";
//     let durationDefaultPropertyOptionSetName = (await Xrm.WebApi.retrieveRecord(defaultPropertyOptionSetEntityLogicalName, defaultPropertyOptionSetId, defaultPropertyOptionSetOptions)).dynamicpropertyoptionname;

//     // Retrieve time-based campaign discount (if any)
//     let durationDiscount = null;
//     let campaign = formContext.getAttribute("rhs_campaignid").getValue();
//     if (campaign != undefined && campaign != null) {
//         let campaignEntityLogicalName = "campaign";
//         let campaignId = campaign[0].id.replace("{", "").replace("}", "").toLowerCase();
//         let campaignOptions = "?$select=rhs_benefittype,rhs_durationbenefit";

//         let potentialCampaignDiscount = await Xrm.WebApi.retrieveRecord(campaignEntityLogicalName, campaignId, campaignOptions);
//         if (potentialCampaignDiscount.rhs_benefittype == 120000000/*Time-Based*/)
//             durationDiscount = potentialCampaignDiscount.rhs_durationbenefit;
//     }

//     // Prepare start date and end date values

//     let GetDateToday = new Date();
//     let now = new Date(Date.UTC(GetDateToday.getUTCFullYear(), GetDateToday.getUTCMonth(), GetDateToday.getUTCDate()));
//     console.log("Now: " + now.toISOString());
//     // let now = new Date();
//     let paymentDate = now.getDate();
//     //let rhs_startdate = formContext.getAttribute("rhs_startdate").setValue(now);
//     let rhs_startdate = formContext.getAttribute("rhs_startdate").getValue();
//     let saved_enddate = formContext.getAttribute("rhs_enddate").getValue();


//     let startDate = null;
//     if (rhs_startdate == undefined || rhs_startdate == null) {
//         // startDate = new Date(now);
//         if (productName.includes("Patron")) {
//             startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of next month
//         } else {
//             if (paymentDate >= 23 && paymentDate <= 31) {
//                 // startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of next month
//                 startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds())); // 1st of next month (UTC)
//             } else if (paymentDate === 1) {
//                 // startDate = new Date(now.getFullYear(), now.getMonth(), 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of current month
//                 startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds())); // 1st of current month (UTC)
//             } else if (paymentDate >= 2 && paymentDate <= 8) {
//                 // startDate = new Date(now.getFullYear(), now.getMonth(), 8, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 8th of current month
//                 startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 8, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds())); // 8th of current month (UTC)
//             } else if (paymentDate >= 9 && paymentDate <= 15) {
//                 // startDate = new Date(now.getFullYear(), now.getMonth(), 15, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 15th of current month
//                 startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 15, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds())); // 15th of current month (UTC)
//             } else if (paymentDate >= 16 && paymentDate <= 22) {
//                 // startDate = new Date(now.getFullYear(), now.getMonth(), 22, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 22nd of current month
//                 startDate = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 22, now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds())); // 22nd of current month (UTC)
//             }
//             console.log("Calculated Start Date: " + startDate);
//         }
//     } else {
//         startDate = new Date(rhs_startdate);
//         //startDate = new Date(
//         //    rhs_startdate.getFullYear(),
//         //    rhs_startdate.getMonth(),
//         //    rhs_startdate.getDate()
//         //);
//         console.log("Retrieved Start Date: " + startDate);
//     }

//     let endDate = new Date(startDate);
//     console.log("Assigning startdate to enddate " + endDate);
//     if (saved_enddate == undefined || saved_enddate == null) {

//         console.log("Product Duration " + durationDefaultPropertyOptionSetName);
//         switch (durationDefaultPropertyOptionSetName) {
//             case "3 Months":
//                 endDate.setMonth(endDate.getMonth() + 3);
//                 endDate.setDate(endDate.getDate() - 1);
//                 break;
//             case "6 Months":
//                 endDate.setMonth(endDate.getMonth() + 6);
//                 endDate.setDate(endDate.getDate() - 1);
//                 break;
//             case "1 Year":
//                 endDate.setFullYear(endDate.getFullYear() + 1);
//                 endDate.setDate(endDate.getDate() - 1);
//                 break;
//             case "Lifetime":
//                 endDate = null;
//                 break;
//         }
//         console.log("Calculated End Date: " + endDate);


//     } else {
//         endDate = new Date(saved_enddate);
//         console.log("Retrieved End Date: " + endDate);

//     }




//     if (durationDiscount != undefined && durationDiscount != null)
//         endDate.setMonth(endDate.getMonth() + durationDiscount);

//     // Set start date and end date
//     let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
//     let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
//     let record = {};
//     if (rhs_startdate == undefined || rhs_startdate == null) {
//         record.rhs_startdate = startDate.toISOString().substring(0, 10);

//         console.log("new value of record.rhs_startdate:" + record.rhs_startdate);
//     } else {
//         // record.rhs_startdate = rhs_startdate.toISOString().substring(0, 10);
//         record.rhs_startdate = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`;
//         console.log("Retrieved record.rhs_startdate:" + record.rhs_startdate);
//     }




//     if (paymentMethod != 844060005/*Gift Pack*/) {
//         // record.rhs_enddate = endDate.toISOString().substring(0, 10);
//         //record.rhs_enddate = `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}`;
//         if (endDate !== null) {
//             record.rhs_enddate = `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}`;
//             console.log("record.rhs_enddate:", record.rhs_enddate);
//         }




//         if (record.rhs_enddate) {
//             let { dormancyValue, renewalValue } = await RHSScripts.Membership.RenewalRangeDates();
//             console.log("dormancyValue:" + dormancyValue);
//             console.log("renewalValue:" + renewalValue);

//             if (dormancyValue != null && renewalValue != null) {
//                 //Added by JMM for US 63698
//                 let rhs_renewalsstartdate = formContext.getAttribute("rhs_renewalsstartdate").getValue();
//                 let rhs_renewalsenddate = formContext.getAttribute("rhs_renewalsenddate").getValue();
//                 //End US 63698
//                 if (rhs_renewalsstartdate == null) {
//                     // Calculate Renewal Start Date
//                     //let renewalStartDate = new Date(endDate);
//                     let renewalStartDate = new Date(record.rhs_enddate);
//                     //let renewalStartDate = new Date(Date.UTC(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate()));
//                     renewalStartDate.setMonth(renewalStartDate.getMonth() - renewalValue);
//                     record.rhs_renewalsstartdate = renewalStartDate.toISOString().substring(0, 10);
//                     console.log("record.rhs_renewalsstartdate:" + record.rhs_renewalsstartdate);
//                 }

//                 if (rhs_renewalsenddate == null) {
//                     // Calculate Renewal End Date
//                     //let renewalEndDate = new Date(endDate);
//                     let renewalEndDate = new Date(record.rhs_enddate);
//                     //let renewalEndDate = new Date(Date.UTC(endDate.getUTCFullYear(), endDate.getUTCMonth(), endDate.getUTCDate()));
//                     renewalEndDate.setMonth(renewalEndDate.getMonth() + dormancyValue);
//                     record.rhs_renewalsenddate = renewalEndDate.toISOString().substring(0, 10);
//                     console.log("record.rhs_renewalsenddate" + record.rhs_renewalsenddate);
//                 }

//             }
//         }
//     }
//     if (paymentMethod == 120000002 /* DD */) {
//         var nextPayoutDate = new Date(startDate);
//         console.log("Initial Start Date: " + nextPayoutDate.toISOString());

//         var workingDaysAdded = 0;

//         // Loop until 10 working days
//         while (workingDaysAdded < 10) {
//             nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
//             var dayOfWeek = nextPayoutDate.getDay();

//             // Skip weekends
//             if (dayOfWeek !== 0 && dayOfWeek !== 6) {
//                 let isHoliday = await RHSScripts.Membership.HasHolidays(nextPayoutDate);
//                 if (!isHoliday) {
//                     workingDaysAdded++;
//                 }
//             }
//         }
//         // Final payout date
//         console.log("Final calculated Payout Date: " + nextPayoutDate);
//         var year = nextPayoutDate.getFullYear();
//         var month = String(nextPayoutDate.getMonth() + 1).padStart(2, '0');
//         var day = String(nextPayoutDate.getDate()).padStart(2, '0');
//         var formattedDate = year + '-' + month + '-' + day;

//         record.rhs_paymentschedule = formattedDate;
//     }
//     await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record);
// }

RHSScripts.Membership.RenewalRangeDates = async function () {

    let dormancyResponse = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'DormancyPeriodDuration'"
    );

    let renewalResponse = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_cultivateconfigurations",
        "?$select=rhs_value&$filter=rhs_name eq 'RenewalPeriodDuration'"
    );
    let dormancyValue = dormancyResponse.entities.length > 0 ? Number(dormancyResponse.entities[0].rhs_value) : 0;
    let renewalValue = renewalResponse.entities.length > 0 ? Number(renewalResponse.entities[0].rhs_value) : 0;

    return { dormancyValue, renewalValue };
}

RHSScripts.Membership.ActivateMembership = async function (membershipId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_issubmitpayment = paymentSubmitted;
    record.rhs_paymentreceived = paymentReceived;
    record.statecode = 0;
    record.statuscode = 1;

    await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record);
}

RHSScripts.Membership.ActivateDonation = async function (donationId, paymentMethod, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_issubmitpayment = paymentSubmitted;
    record.rhs_paymentreceived = paymentReceived;
    record.statecode = 0;

    console.log("Payment method used: " + paymentMethod);
    if (paymentMethod == 120000002) {
        record.statuscode = 120000003;
    } else {
        record.statuscode = 1;
    }
    await Xrm.WebApi.updateRecord("rhs_donation", donationId, record);
}


RHSScripts.Membership.MakePTXPayment = async function (membershipId, paymentFrequency, payerReference) {
    let ptxPaymentUrl = await RHSScripts.Membership.RetrieveAppSettingValueByName("FAPTXWebFormURL");
    let ptxCallbackURL = await RHSScripts.Membership.RetrieveAppSettingValueByName("FAPTXCallbackURL");
    if (ptxPaymentUrl == undefined || ptxPaymentUrl == null)
        throw Error("PTXWebFormURL app setting not set for this environment. Please contact an administrator to fix this.");
    if (ptxCallbackURL == undefined || ptxCallbackURL == null)
        throw Error("FAPTXCallbackURL app setting not set for this environment. Please contact an administrator to fix this.");

    if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?");
    ptxPaymentUrl += "?";

    let payer = await Xrm.WebApi.retrieveRecord(payerReference.entityType, payerReference.id);
    let payerCompany = payerReference.entityType == "contact" && payer._parentcustomerid_value != undefined && payer._parentcustomerid_value != null ?
        await Xrm.WebApi.retrieveRecord("account", payer._parentcustomerid_value) : null;
    let payerTitle = payerReference.entityType == "contact" && payer._rhs_title_value != undefined && payer._rhs_title_value != null ?
        await Xrm.WebApi.retrieveRecord("rhs_titleandsalutation", payer._rhs_title_value) : null;

    let postcode = payer.address1_postalcode;
    let address = payerReference.entityType == "contact" ?
        (payer.rhs_loqatehomeaddresshousename != null ? payer.rhs_loqatehomeaddresshousename.split(' ').slice(1).join(' ') : null) :
        (payer.rhs_loqateaddress1housename != null ? payer.rhs_loqateaddress1housename.split(' ').slice(1).join(' ') : null);
    let townOrCity = payerReference.entityType == "contact" ? payer.address1_city : payer.address1_city;

    let buildingNumberOrName = payerReference.entityType === "contact" ? (payer.rhs_loqatehomeaddresshousename ?? null) : (payer.rhs_loqateaddress1housename ?? null);
    // Building name is not saved on contact or account address fields.

    let transaction = await RHSScripts.Membership.RetrieveActiveMembershipTransaction(membershipId);
    let paymentSchedule = await RHSScripts.Membership.RetrieveActiveMembershipPaymentSchedule(membershipId);
    let payments = await RHSScripts.Membership.RetrieveActiveMembershipPayments(membershipId);

    //Normalize accented characters
    const normalizeText = (value) => {
        if (!value || typeof value !== "string") return value;
        return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s]/g, "");
    }

    let parameters = {};
    //#region  Customisation parameters
    parameters.formname = null;
    parameters.texttitle = null;
    parameters.textsubtitle = null;
    parameters.contactphone = null;
    parameters.contactemail = null;
    parameters.textapplybutton = null;
    parameters.showformheader = null;
    parameters.legalentityname = null;
    parameters.currentaddresslegend = null;
    parameters.customdatalabel = null;
    parameters.showtitle = null;
    parameters.showfirstname = null;
    parameters.showmiddlename = null;
    parameters.showlastname = null;
    parameters.showdob = null;
    parameters.showemail = null;
    parameters.showmobile = null;
    parameters.showcurrentaddress = null;
    parameters.showbankaccount = null;
    parameters.advancednoticedays = 1;
    parameters.showcompanyname = null;
    parameters.showapplyingascompanycheck = null;
    parameters.useaddressline2 = null;
    parameters.showcustomdata = null;
    parameters.showddplanreference = null;
    parameters.showconfirmddguarantee = null;
    parameters.showddplansummary = null;
    parameters.showddplanfields = null;
    parameters.showgiftaid = null;
    parameters.showerrordetail = null;
    parameters.showbankaccountcreated = null;
    parameters.showcompanyregistrationnumber = null;
    //#endregion
    //#region  Required
    parameters.company = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    //parameters.firstname = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    const firstName = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    parameters.firstname = normalizeText(firstName);
    //parameters.lastname = payerReference.entityType == "contact" ? payer.lastname : null;
    const lastName = payerReference.entityType == "contact" ? payer.lastname : null;
    parameters.lastname = normalizeText(lastName);
    //parameters.email = payer.emailaddress1;
    const emailAddress1 = payer.emailaddress1;
    parameters.email = normalizeText(emailAddress1);
    parameters.currenthousenamenumber = buildingNumberOrName;
    parameters.currentpostcode = postcode;
    //parameters.bankaccountname = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    const bankAccountName = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    parameters.bankaccountname = normalizeText(bankAccountName);
    parameters.sortcode = null;
    parameters.accountnumber = null;
    parameters.ddplanspecification = null;
    parameters.ddregularamount = paymentSchedule != null ? paymentSchedule.rhs_paymentamount : payments[0].rhs_amount;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddstartdate = payments[0].rhs_duedate.substring(0, 10);
    //#endregion
    //#region  Optional
    parameters.requestid = null;
    parameters.requestuserid = null;
    parameters.customdata = null;
    parameters.contactdetailsheader = null;
    parameters.title = null;    // causes problems when more than 5 characters
    //parameters.middlename = payerReference.entityType == "contact" ? payer.middlename : null;
    const middleName = payerReference.entityType == "contact" ? payer.middlename : null;
    parameters.middlename = normalizeText(middleName);
    parameters.dob = payerReference.entityType == "contact" && payer.birthdate != undefined && payer.birthdate != null ? payer.birthdate.substring(0, 10) : null;
    parameters.email = payer.emailaddress1;
    parameters.mobile = payer.telephone1;
    parameters.applyingascompany = null;
    parameters.companyname = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    parameters.currentstreet1 = payer.address1_line1;
    parameters.currenttown = townOrCity;
    parameters.ddnoofcollections = null; //payments.length; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddtotalamount = null;
    parameters.ddfirstamount = payments[0].rhs_amount;
    parameters.ddlastamount = null; //payments[payments.length - 1].rhs_amount; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddplaninterval = 1;
    parameters.ddplantype = paymentFrequency == 120000002/*Monthly*/ ? "Monthly" : "Yearly";
    parameters.dddebtorreference = null;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddplanaltreference = null;
    parameters.ddplanendbydate = null;
    parameters.ddprofilename = null;
    parameters.ptxprofilename = null;
    parameters.giftaid = null;
    parameters.ttl = null;
    parameters.expirationtimer = null;
    parameters.callbackurl = ptxCallbackURL;
    parameters.redirecturl = null;
    //#endregion

    for (let parameterName in parameters) {
        if (parameters[parameterName] != undefined && parameters[parameterName] != null) {
            if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?")
                ptxPaymentUrl += "&";
            ptxPaymentUrl += `${parameterName}=${parameters[parameterName]}`;
        }
    }

    Xrm.Navigation.openUrl(ptxPaymentUrl);

    // Confirm PTX payment
    let alertStrings = { title: "PTX Payment", text: "Have you finished PTX payment?", confirmButtonLabel: "Yes" };
    await Xrm.Navigation.openAlertDialog(alertStrings);

    let directDebitDetail = await RHSScripts.Membership.RetrieveDirectDebitDetail(parameters.ddplanreference);
    if (directDebitDetail == undefined || directDebitDetail == null) {
        // Delay 15 seconds and recheck again
        await RHSScripts.Membership.Delay(15000);
        directDebitDetail = await RHSScripts.Membership.RetrieveDirectDebitDetail(parameters.ddplanreference);

        if (directDebitDetail == undefined || directDebitDetail == null)
            throw Error("PTX Transaction Failed");
    }
}

RHSScripts.Membership.RetrieveAppSettingValueByName = async function (name) {
    let appSettingValue = null;
    let entityLogicalName = "rhs_appsettings";
    let options = `?$select=rhs_name,rhs_value&$filter=(rhs_name eq '${name}' and statecode eq 0)`;

    let appSettings = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (appSettings != undefined && appSettings != null && appSettings.length > 0)
        appSettingValue = appSettings[0].rhs_value;

    return appSettingValue
}

RHSScripts.Membership.RetrieveDirectDebitDetail = async function (reference) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=rhs_reference eq '${reference}'&$top=1`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.Membership.Delay = function (ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

RHSScripts.Membership.CallMembershipRenewalsCustomAPI = async function (primaryControl, isAdvancePayment = false) {
    try {
        var formContext = primaryControl;
        var membershipId = formContext.data.entity.getId()?.replace("{", "").replace("}", "").toLowerCase();

        if (!membershipId) {
            Xrm.Navigation.openAlertDialog({ text: "Error: Unable to retrieve Membership ID (GUID)." });
            return { status: "error", message: "Membership ID missing" };
        }

        let parameters = {
            "MembershipId": membershipId,
            "AdvancePayment": isAdvancePayment
        };
        let apiUrl = Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_membership_renewals_new";

        let response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "OData-MaxVersion": "4.0",
                "OData-Version": "4.0",
                "Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json"
            },
            body: JSON.stringify(parameters)
        });

        let result = await response.json();
        if (!response.ok) {
            throw new Error(result.error?.message || "Unknown API error occurred.");
        }

        let returnedMembershipId = result["MembershipId"];
        let apiResult = result["Result"];

        // **Show notification**
        //  await Xrm.Navigation.openAlertDialog({ 
        //   text: `Custom API called successfully!\nMembership ID: //${returnedMembershipId}\nResult: ${apiResult}` 
        //      });

        return { status: "success", membershipId: returnedMembershipId, result: apiResult };

    } catch (error) {
        console.error("API Error:", error.message);
        // await Xrm.Navigation.openAlertDialog({ text: "Custom API call failed. Error: " + error.message });
        return { status: "error", message: error.message };
    }
}

RHSScripts.Membership.RetrieveRenewalMembership = async function (membershipId) {
    let renewalMembershipsOfMembership = (await Xrm.WebApi.retrieveMultipleRecords("rhs_membership", `?$filter=(_rhs_linkedmembership_value eq ${membershipId} and rhs_isrenewal eq true)&$orderby=createdon desc&$top=1`)).entities;
    return renewalMembershipsOfMembership.length > 0 ? renewalMembershipsOfMembership[0] : null;
}

RHSScripts.Membership.ExecuteCreateMembershipOnRenewalsCustomAPI = async function (membershipId) {
    // Parameters
    let parameters = {};
    parameters.MembershipId = membershipId; // Edm.Guid

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_Create_membership_onrenewals_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let membershipid = result["MembershipId"]; // Edm.Guid
        return membershipid;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Membership.SetMembershipAsPaidInAdvance = async function (membershipId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_issubmitpayment = paymentSubmitted;
    record.rhs_paymentreceived = paymentReceived;
    record.statecode = 1/*Inactive*/;
    record.statuscode = 120000005 /*Paid in Advance*/;

    await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record);
}

RHSScripts.Membership.SetMembershipAsProspect = async function (membershipId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_issubmitpayment = paymentSubmitted;
    record.rhs_paymentreceived = paymentReceived;
    record.statecode = 0/*Active*/;
    record.statuscode = 120000000 /*Prospect*/;

    await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record);
}

RHSScripts.Membership.UpdateStatusOfPresentAndNewMembershipWhenRenewingDormantMembership = async function (presentMembershipId, newMembershipId) {
    await Xrm.WebApi.updateRecord("rhs_membership", presentMembershipId, { "statecode": 1/*Inactive*/, "statuscode": 120000004/*Renewed*/ });
    await Xrm.WebApi.updateRecord("rhs_membership", newMembershipId, { "statecode": 0/*Active*/, "statuscode": 1/*Active*/ });
}

RHSScripts.Membership.SetMembershipRenewalFieldsOnSuccessfulRenewal = async function (membershipId) {
    let record = {};
    record.rhs_renewalsstatus = 120000001/*Renewed*/;
    record.rhs_renewaldate = (new Date()).toISOString().substring(0, 10);

    await Xrm.WebApi.updateRecord("rhs_membership", membershipId, record);
}

RHSScripts.Membership.ShowRenewalSections = async function (formContext) {
    'use strict';

    formContext.getAttribute("rhs_inrenewalsstage").fireOnChange(); //triggers on change event that will show the renewals section
}

// RHSScripts.Membership.ResendMembershipPack = async function (primaryControl) {
//     'use strict';
//     let formContext = primaryControl;

//     // Get values
//     let today = new Date();
//     let resendMembershipPackMHStatus = formContext.getAttribute("rhs_resendmembershippackmhstatus").getValue();
//     let renewalMembershipPackMHStatus = formContext.getAttribute("rhs_renewalmembershippackmhstatus").getValue();
//     let startDate = formContext.getAttribute("rhs_startdate").getValue();
//     let threeMonthsLater = new Date(startDate);
//     threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);

//     let payer = formContext.getAttribute("rhs_payerv2").getValue();
//     let payerId = payer[0].id.replace("{", "").replace("}", "").toLowerCase();
//     let payerEntity = payer[0].entityType;

//     // Check conditions
//     if (today > threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001)) {
//         formContext.ui.setFormNotification("We are unable to resend a membership pack as it is over 3 months since the membership start date", "ERROR", "error_notification");
//         setTimeout(() => formContext.ui.clearFormNotification("error_notification"), 5000);
//         return;
//     } else if (today < threeMonthsLater && (resendMembershipPackMHStatus == 120000001 || renewalMembershipPackMHStatus == 120000001)) {
//         formContext.ui.setFormNotification("You are unable to proceed as we are already processing the sending of a membership pack", "ERROR", "error_notification");
//         setTimeout(() => formContext.ui.clearFormNotification("error_notification"), 5000);
//         return;
//     } else if (today < threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001)) {
//         // Validate if payer is deceased or has gone away suppression
//         let isContactPayerDeceased = payerEntity == "contact" && (await Xrm.WebApi.retrieveMultipleRecords("contact", `?$select=rhs_deceased&$filter=(contactid eq ${payerId} and rhs_deceased eq true)`)).entities.length > 0;
//         let doesContactPayerHasGoneAwaySuppression = payerEntity == "contact" && (await RHSScripts.Membership.RetrieveGoneAwaySuppressionsOfContact(payerId)).length > 0;

//         if (isContactPayerDeceased || doesContactPayerHasGoneAwaySuppression) {
//             formContext.ui.setFormNotification("You are unable to proceed as this contact has a suppression applied.", "ERROR", "error_notification");
//             setTimeout(() => formContext.ui.clearFormNotification("error_notification"), 5000);
//             return;
//         }

//         // Open custom popup for reason input
//         let pageInput = {
//             pageType: "webresource",
//             webresourceName: "rhs_resendMembershipPack"
//         };
//         let navigationOptions = {
//             target: 2,
//             width: 400,
//             height: 200,
//             position: 1,
//             title: "Resend Membership Pack Reason"
//         };

//         Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
//             function () {
//                 console.log("Web resource opened successfully.");
//             },
//             function (error) {
//                 console.error("Error opening web resource:", error);
//             }
//         );

//         // Listen for message from the web resource
//         window.addEventListener("message", function (event) {
//             if (event.data && event.data.reason) {
//                 console.log("Reason entered: ", event.data.reason);
//                 Xrm.Navigation.openAlertDialog({ title: "Reason Captured", text: event.data.reason });
//             }
//         }, false);
//     }
// }

RHSScripts.Membership.ResendMembershipPack = async function (primaryControl) {

    'use strict'
    let formContext = primaryControl;

    //Get values
    let today = new Date();
    let resendMembershipPackMHStatus = formContext.getAttribute("rhs_resendmembershippackmhstatus").getValue();
    let renewalMembershipPackMHStatus = formContext.getAttribute("rhs_renewalmembershippackmhstatus").getValue();
    // let newMembershipPackMHStatus = formContext.getAttribute("rhs_newmembershippackmhstatus").getValue(); // added newMembershipPackMHStatus
    let startDate = formContext.getAttribute("rhs_startdate").getValue();
    let threeMonthsLater = new Date(startDate);
    threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);

    let payer = formContext.getAttribute("rhs_payerv2").getValue();
    let payerId = payer[0].id.replace("{", "").replace("}", "").toLowerCase();
    let payerEntity = payer[0].entityType;

    //check if date today is greater than 3 months after membership start date
    // if (today > threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001 || newMembershipPackMHStatus != 120000001)) { //added newMembershipPackMHStatus
    if (today > threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001)) {
        formContext.ui.setFormNotification("We are unable to resend a membership pack as it is over 3 months since the membership start date", "ERROR", "error_notification");
        setTimeout(function () {
            formContext.ui.clearFormNotification("error_notification");
        }, 5000);
        return;
    }
    //check if date today is less than 3 months after membership start date and status eq Pending
    //else if (today < threeMonthsLater && (resendMembershipPackMHStatus == 120000001 || renewalMembershipPackMHStatus == 120000001 || newMembershipPackMHStatus == 120000001)) { //added newMembershipPackMHStatus
    else if (today < threeMonthsLater && (resendMembershipPackMHStatus == 120000001 || renewalMembershipPackMHStatus == 120000001)) {
        formContext.ui.setFormNotification("You are unable to proceed as we are already processing the sending of a membership pack", "ERROR", "error_notification");
        setTimeout(function () {
            formContext.ui.clearFormNotification("error_notification");
        }, 5000);
        return;
    }
    //check if date today is less than 3m onths after membership start date and status is not eq to pending
    //else if (today < threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001 || newMembershipPackMHStatus != 120000001)) {//
    else if (today < threeMonthsLater && (resendMembershipPackMHStatus != 120000001 || renewalMembershipPackMHStatus != 120000001)) {
        // Validate if payer is deceased or has gone away suppression
        let isContactPayerDeceased = payerEntity == "contact" && (await Xrm.WebApi.retrieveMultipleRecords("contact", `?$select=rhs_deceased&$filter=(contactid eq ${payerId} and rhs_deceased eq true)`)).entities.length > 0;
        let doesContactPayerHasGoneAwaySuppression = payerEntity == "contact" && (await RHSScripts.Membership.RetrieveGoneAwaySuppressionsOfContact(payerId)).length > 0;

        if (isContactPayerDeceased || doesContactPayerHasGoneAwaySuppression) {
            formContext.ui.setFormNotification("You are unable to proceed as this contact has a suppression applied.", "ERROR", "error_notification");
            setTimeout(() => formContext.ui.clearFormNotification("error_notification"), 5000);
            return;
        }

        // Ask for resend membership pack resend, the resend membership pack
        let resendMembershipPackReason = prompt("Resend Membership Pack Reason");
        if (resendMembershipPackReason != undefined && resendMembershipPackReason != null && resendMembershipPackReason != "") {
            let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
            await Xrm.WebApi.updateRecord("rhs_membership", membershipId, {
                "rhs_resendmembershippackreason": resendMembershipPackReason,
                "rhs_resendmembershippackmhstatus": 120000001
            });
            await formContext.data.refresh(true);
        } else {
            await Xrm.Navigation.openAlertDialog({ title: "Resend Membership Pack failed", text: "No reason provided on Resending Membership Pack." });
        }

    }
}
/* //Moved to MembershipUpdatePreOpsPlugin
RHSScripts.Membership.SetCardExpiryDate = async function (formContext) {
    try {
        let endDate = formContext.getAttribute("rhs_enddate").getValue();
        let startDate = formContext.getAttribute("rhs_startdate").getValue();
        let createdOn = formContext.getAttribute("createdon").getValue();
        debugger;

        if (createdOn) {
            if (endDate) {
                formContext.getAttribute("rhs_cardexpirydate").setValue(endDate);
            } else if (!endDate && startDate) {
                let cardExpiryDate = new Date(startDate.getTime());
                cardExpiryDate.setFullYear(cardExpiryDate.getFullYear() + 1);
                cardExpiryDate.setDate(cardExpiryDate.getDate() - 1);

                console.log("Start Date:", startDate.toDateString());
                console.log("Calculated Expiry Date:", cardExpiryDate.toDateString());

                formContext.getAttribute("rhs_cardexpirydate").setValue(cardExpiryDate);
            }

            formContext.getAttribute("rhs_annualcardmhstatus").setValue(120000001); // Pending
            // formContext.getAttribute("rhs_newmembershippackmhstatus").setValue(120000001); // Pending

            console.log("Card expiry date set successfully.");
        }
    } catch (error) {
        console.error("Error in SetCardExpiryDate:", error);
    }
};
*/

RHSScripts.Membership.ContinueUsingSameDirectDebitForMembership = async function (oldMembershipId, newMembershipId) {
    let directDebitDetail = await RHSScripts.Membership.RetrieveMembershipDirectDebit(oldMembershipId);
    let newTransaction = await RHSScripts.Membership.RetrieveActiveMembershipTransaction(newMembershipId);
    let newPayments = await RHSScripts.Membership.RetrieveActiveMembershipPayments(newMembershipId);

    //Update direct debit lookup of transaction
    if (directDebitDetail && newTransaction) {
        let transactionUpdate = {};
        transactionUpdate["rhs_directdebitmandate@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

        await Xrm.WebApi.updateRecord("rhs_transaction", newTransaction.rhs_transactionid, transactionUpdate);
    }

    //Update direct debit lookup of payments
    if (directDebitDetail && newPayments) {
        for (let ctr = 0; ctr < newPayments.length; ctr++) {
            var paymentUpdate = {};
            paymentUpdate["rhs_DirectDebitDetails@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

            await Xrm.WebApi.updateRecord("rhs_payment", newPayments[ctr].rhs_paymentid, paymentUpdate);
        }
    }

    //Update direct debit lookup of membership
    if (directDebitDetail) {
        var directDebitUpdate = {};
        directDebitUpdate["rhs_MembershipId@odata.bind"] = `/rhs_memberships(${newMembershipId})`;

        await Xrm.WebApi.updateRecord("rhs_directdebitdetails", directDebitDetail.rhs_directdebitdetailsid, directDebitUpdate);
    }
}

RHSScripts.Membership.RetrieveMembershipDirectDebit = async function (membershipId) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=_rhs_membershipid_value eq ${membershipId}`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.Membership.ChangeMembershipOutsideRenewalPeriod = async function (formContext) {
    'use strict';

    // Define the confirmation dialog options
    let confirmOptions = {
        title: "Confirm Membership Change",
        subtitle: "Are you sure?",
        text: "Do you really want to change Membership? It will cancel the existing membership!",
        confirmButtonLabel: "Yes",
        cancelButtonLabel: "No"
    };

    // Open the confirmation dialog
    let confirmationResult = await Xrm.Navigation.openConfirmDialog(confirmOptions);
    if (!confirmationResult.confirmed) {
        console.log("User canceled the upgrade action.");
        return; // Exit the function if the user clicks "No"
    }

    console.log("User confirmed the membership change action.");

    let membershipId = formContext.data.entity.getId();
    let linkedMembershipId = formContext.data.entity.getId();
    let recordId = linkedMembershipId.replace("{", "").replace("}", "").toLowerCase();
    let linkedMembershipName = formContext.getAttribute("rhs_name").getValue();
    let recordEntityType = formContext.data.entity.getEntityName();;
    let primaryMember = formContext.getAttribute("rhs_contact").getValue();
    let payer = formContext.getAttribute("rhs_payerv2").getValue();
    let membershipProductLookup = formContext.getAttribute("rhs_membershipproductid").getValue();
    let joiningDate = formContext.getAttribute("rhs_joiningdate").getValue();
    let startDate = formContext.getAttribute("rhs_startdate").getValue();
    let endDate = formContext.getAttribute("rhs_enddate").getValue();
    let isForSomeoneElse = formContext.getAttribute("rhs_ismembershipforsomeone").getValue();
    let haveYouBeenReferred = formContext.getAttribute("rhs_isreferredbyexistingmember").getValue();
    let referralMember = formContext.getAttribute("rhs_referralmemberid").getValue();
    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let isContinuousPayment = formContext.getAttribute("rhs_iscontinuouspayment").getValue();
    let paymentFrequency = formContext.getAttribute("rhs_paymentfrequency").getValue();
    let paymentSchedule = formContext.getAttribute("rhs_paymentschedule").getValue();

    if (!membershipProductLookup && !primaryMember && !payer) {
        console.log("Membership Product / Primary Member / Payer is null.");
        return;
    }
    else {
        let productId = membershipProductLookup[0].id.replace("{", "").replace("}", "");
        //let allowedMembers = await RHSScripts.Membership.RetrieveProductProperty(productId);

        // Determine membership status to be set based on payment method
        let membershipStatus = 120000003/*Pending Payment*/;

        // Build the parameters for the new form
        let parameters = {};

        let linkedMembershipLookup = [];
        linkedMembershipLookup[0] = {};
        linkedMembershipLookup[0].id = linkedMembershipId;
        linkedMembershipLookup[0].name = linkedMembershipName;
        linkedMembershipLookup[0].entityType = recordEntityType;

        let primaryMemberLookup = [];
        if (primaryMember) {
            primaryMemberLookup[0] = {};
            primaryMemberLookup[0].id = primaryMember[0].id;
            primaryMemberLookup[0].name = primaryMember[0].name;
            primaryMemberLookup[0].entityType = primaryMember[0].entityType;
        }

        let payerLookup = [];
        if (payer) {
            payerLookup[0] = {};
            payerLookup[0].id = payer[0].id;
            payerLookup[0].name = payer[0].name;
            payerLookup[0].entityType = payer[0].entityType;
        }

        let referralMemberLookup = [];
        if (referralMember) {
            referralMemberLookup[0] = {};
            referralMemberLookup[0].id = referralMember[0].id;
            referralMemberLookup[0].name = referralMember[0].name;
            referralMemberLookup[0].entityType = referralMember[0].entityType;
        }

        // Pre-fill the fields in the new membership form
        parameters["rhs_linkedmembership"] = linkedMembershipLookup;
        parameters["rhs_contact"] = primaryMemberLookup;
        parameters["rhs_payerv2"] = payerLookup;
        parameters["rhs_referralmemberid"] = referralMemberLookup;

        if (joiningDate) parameters["rhs_joiningdate"] = joiningDate;
        if (startDate) parameters["rhs_startdate"] = startDate;
        if (endDate) parameters["rhs_enddate"] = endDate;

        parameters["rhs_replacementcard"] = true;
        parameters["rhs_ismembershipforsomeone"] = isForSomeoneElse;
        parameters["rhs_isreferredbyexistingmember"] = haveYouBeenReferred;
        parameters["statuscode"] = membershipStatus;

        if (paymentMethod != 844060005/*Gift Pack*/) parameters["rhs_paymentmethod"] = paymentMethod;
        parameters["rhs_iscontinuouspayment"] = isContinuousPayment;
        parameters["rhs_paymentfrequency"] = paymentFrequency;
        parameters["rhs_paymentschedule"] = paymentSchedule;

        //Populate Carried Over Amount and Membership Total Amount
        if (paymentMethod != 120000002/*DD*/ && isContinuousPayment != true) {
            parameters["rhs_carriedoveramount"] = 0;
        }
        else {
            let membershipTransaction = await RHSScripts.Membership.RetrieveMembershipTransaction(membershipId);

            if (membershipTransaction != undefined && membershipTransaction != null) {
                let transactionOutstandingAmount = membershipTransaction["rhs_outstandingamount"] != null ? membershipTransaction["rhs_outstandingamount"] : 0;

                parameters["rhs_carriedoveramount"] = transactionOutstandingAmount;
            }
        }

        //Deactivate membership of Status = Change Membership Type, 2
        await RHSScripts.Membership.DeactivateMembership(recordEntityType, recordId, 2)

        //Refresh form
        await formContext.data.refresh(true);

        //Open New form with populated values
        RHSScripts.Membership.OpenNewMembershipForm(parameters);
    }

}

RHSScripts.Membership.ChangeMembershipDuringRenewalPeriod = async function (formContext) {
    'use strict';

    // Define the confirmation dialog options
    let confirmOptions = {
        title: "Confirm Membership Change (During Renewal Period)",
        subtitle: "Are you sure?",
        text: "Do you really want to change Renewal Membership? It will NOT cancel the existing membership!",
        confirmButtonLabel: "Yes",
        cancelButtonLabel: "No"
    };

    // Open the confirmation dialog
    let confirmationResult = await Xrm.Navigation.openConfirmDialog(confirmOptions);
    if (!confirmationResult.confirmed) {
        console.log("User canceled the upgrade action.");
        return; // Exit the function if the user clicks "No"
    }
    console.log("User confirmed the membership change action.");

    let membershipProduct = formContext.getAttribute("rhs_membershipproductid").getValue();
    formContext.getControl("rhs_renewalsmembershipproduct").setDisabled(false);
    formContext.getAttribute("rhs_renewalsmembershipproduct").setValue(membershipProduct);
}

RHSScripts.Membership.ValidateIfLinkedMembershipPaymentMethodIsDirectDebit = async function (formContext) {
    'use strict';

    let linkedMembershipFieldValue = formContext.getAttribute("rhs_linkedmembership").getValue();
    if (linkedMembershipFieldValue) {
        let linkedMembership = await Xrm.WebApi.retrieveRecord("rhs_membership", linkedMembershipFieldValue[0].id, "?$select=rhs_paymentmethod");
        if (linkedMembership.rhs_paymentmethod == 120000002/*DirectDebit*/) {
            return true;
        }
    }

    return false;
}

RHSScripts.Membership.ValidateIfPatronFellow = async function (membershipId, paymentMethod) {
    var isPatronFellow = false;

    // if (paymentMethod == 120000002/*DD*/) {
    var fetchXml = [
        "<fetch>",
        "  <entity name='rhs_membership'>",
        "    <attribute name='rhs_contact'/>",
        "    <attribute name='rhs_payerv2'/>",
        "    <filter>",
        "      <condition attribute='rhs_membershipid' operator='eq' value='", membershipId, "'/>",
        "    </filter>",
        "    <link-entity name='product' from='productid' to='rhs_membershipproductid' alias='prod'>",
        "      <filter>",
        "        <condition attribute='name' operator='like' value='%fellow%'/>",
        "      </filter>",
        "      <link-entity name='dynamicproperty' from='regardingobjectid' to='productid' alias='prop'>",
        "        <attribute name='dynamicpropertyid'/>",
        "        <filter>",
        "          <condition attribute='name' operator='eq' value='Benefit Type'/>",
        "        </filter>",
        "        <link-entity name='dynamicpropertyoptionsetitem' from='dynamicpropertyid' to='dynamicpropertyid' alias='propvalue'>",
        "          <attribute name='dynamicpropertyoptionsetvalueid'/>",
        "          <filter>",
        "            <condition attribute='dynamicpropertyoptionname' operator='eq' value='Plant Review'/>",
        "          </filter>",
        "        </link-entity>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    await Xrm.WebApi.retrieveMultipleRecords("rhs_membership", "?fetchXml=" + fetchXml).then(
        function success(result) {
            if (result != null && result.entities.length > 0) {
                isPatronFellow = true;
            }
        },
        function (error) {
            console.log(error.message);
            // handle error conditions
        }
    );
    // }
    return isPatronFellow;
}

RHSScripts.Membership.ExecuteSubscriptionCreationAPI = async function (membershipId) {
    // Parameters
    let parameters = {};
    parameters.MembershipId = membershipId;
    //parameters.TransactionId = transactionId;
    //parameters.IsPatronFellow = isPatronFellow;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_subscription_creation_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let subscriptionId = result["SubscriptionId"];
        console.log(subscriptionId);
        return subscriptionId;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Membership.ExecuteCreatePaidDonationCustomAPI = async function (membershipId, transactionId, donationAmount) {
    // Parameters
    let parameters = {
        MembershipId: membershipId,
        TransactionId: transactionId,
        DonationAmount: donationAmount,
        IsStandaloneDonation: false,
        BatchOrderLineId: "00000000-0000-0000-0000-000000000000"
    };

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_createpaiddonation_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let donationId = result["DonationId"];
        console.log(donationId);
        return donationId;
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.Membership.GetExpectedTotalAmount = async function (formContext) {
    let productId = formContext.getAttribute("rhs_membershipproductid").getValue()[0]?.id.replace("{", "").replace("}", "").toLowerCase();
    let priceListId = formContext.getAttribute("rhs_pricelist").getValue()[0]?.id.replace("{", "").replace("}", "").toLowerCase();
    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();

    let expectedTotalAmount = await RHSScripts.Membership.GetProductPrice(productId, priceListId);
    let campaign = formContext.getAttribute("rhs_campaignid").getValue();
    if (campaign)
        expectedTotalAmount = await RHSScripts.Membership.GetDiscountedPrice(expectedTotalAmount, campaign[0].id, paymentMethod)

    return expectedTotalAmount;
}

RHSScripts.Membership.GetProductPrice = async function (productId, priceListId) {
    let logicalName = "productpricelevel";
    let options = "".concat(
        "?$select=amount",
        `&$filter=(_productid_value eq ${productId} and _pricelevelid_value eq ${priceListId})`
    );

    let priceListItem = (await Xrm.WebApi.retrieveMultipleRecords(logicalName, options)).entities[0];
    return priceListItem?.amount;
}

RHSScripts.Membership.GetDiscountedPrice = async function (productPrice, campaignId, paymentMethod, paymentFrequency = 120000000/*Annually*/) {
    // Set discounted price to product price
    let discountedPrice = productPrice;

    // Set discounted price to campaign price
    let campaign = await Xrm.WebApi.retrieveRecord("campaign", campaignId,
        `?$select=_rhs_paymentdiscountconfiguration_value,_pricelistid_value,_rhs_productid_value,rhs_benefittype`);
    let campaignPrice = (await Xrm.WebApi.retrieveMultipleRecords("productpricelevel",
        "".concat(`?$select=amount,_pricelevelid_value,_productid_value`,
            `&$filter=(_pricelevelid_value eq ${campaign._pricelistid_value} and _productid_value eq ${campaign._rhs_productid_value})`
        ))).entities[0]?.amount;
    if (campaignPrice)
        discountedPrice = campaignPrice;

    // Deduct additional discount from payment discount configuration if applicable
    if (campaign._rhs_paymentdiscountconfiguration_value) {
        let paymentDiscountConfiguration = await Xrm.WebApi.retrieveRecord("rhs_paymentdiscountconfiguration",
            campaign._rhs_paymentdiscountconfiguration_value, "?$select=rhs_paymentmethodcode,rhs_discountamount,rhs_discountpercentage");
        if (campaign.rhs_benefittype == 120000001/*Price Based*/ && paymentDiscountConfiguration &&
            paymentDiscountConfiguration.rhs_paymentmethod == paymentMethod &&
            (paymentMethod != 120000002/*Direct Debit*/ || paymentFrequency == 120000000/*Annually*/)) {
            if (paymentDiscountConfiguration.rhs_discountpercentage)
                discountedPrice -= (paymentDiscountConfiguration.rhs_discountpercentage / 100) * productPrice
            if (paymentDiscountConfiguration.rhs_discountamount)
                discountedPrice -= paymentDiscountConfiguration.rhs_discountamount
        }
    }

    return discountedPrice;
}

RHSScripts.Membership.CheckIfMembershipWasChangedFromLastTransaction = async function (formContext, transaction) {
    let product = formContext.getAttribute("rhs_membershipproductid").getValue()?.[0];
    let productId = product ? product.id.replace("{", "").replace("}", "").toLowerCase() : null;
    let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
    let totalAmount = formContext.getAttribute("rhs_totalamount").getValue();
    let outstandingAmount = formContext.getAttribute("rhs_outstandingamount").getValue();
    let amount = outstandingAmount ? outstandingAmount : totalAmount;

    let isMembershipChanged = false;
    if (transaction)
        isMembershipChanged = productId != transaction._rhs_product_value || paymentMethod != transaction.rhs_paymentmethod_code || amount != transaction.rhs_amount;

    return isMembershipChanged;
}

RHSScripts.Membership.CancelTransactionAndAssociatedRecords = async function (transaction) {
    let transactionId = transaction.rhs_transactionid;

    //Cancel Payments
    let payments = (await Xrm.WebApi.retrieveMultipleRecords("rhs_payment", `?$select=rhs_paymentid,_rhs_transaction_value&$filter=_rhs_transaction_value eq ${transactionId}`)).entities;
    for (let ctr = 0; ctr < payments.length; ctr++) {
        await Xrm.WebApi.updateRecord("rhs_payment", payments[ctr].rhs_paymentid, { statecode: 1/*Inactive*/, statuscode: 120000004/*Cancelled*/ });
    }

    //Cancel Payment Schedule
    let paymentScheduleId = transaction._rhs_paymentscheduletransaction_value;
    if (paymentScheduleId) {
        await Xrm.WebApi.updateRecord("rhs_paymentschedule", paymentScheduleId, { statecode: 1/*Inactive*/, statuscode: 120000003/*Cancelled*/ });
    }

    //Cancel Transaction
    await Xrm.WebApi.updateRecord("rhs_transaction", transactionId, { statecode: 1/*Inactive*/, statuscode: 2/*Cancelled*/ });
}

RHSScripts.Membership.MembershipExtensionCommandForm = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let customPageName = "rhs_newmembershipextension_cad82";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_membership",
        recordId: entityId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Membership Extension"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}
RHSScripts.Membership.ShowReinstateButton = function (primaryControl) {


    let roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    let status = primaryControl.getAttribute("statecode")?.getValue();
    let statusReason = primaryControl.getAttribute("statuscode")?.getValue();

    if (primaryControl.ui.getFormType() === 1) {
        return false;
    }

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers" && status == 1 && statusReason == 2) {
            return true;
        }
    }

    return false;
};

RHSScripts.Membership.ReinstateMembershipCommandForm = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let customPageName = "rhs_newmembershipreinstatement_7ca01";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_membership",
        recordId: entityId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Membership Reinstatement"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Membership.MakeCirrusPCIpaymentURL = async function (membershipId, payerReference, totalAmount, isRenewal) {
    // Redirect to checkout url
    //Get Current User
    let userSettings = Xrm.Utility.getGlobalContext().userSettings;
    let currentUserId = userSettings.userId.replace("{", "").replace("}", "");
    let cirrusUserValue = await Xrm.WebApi.retrieveRecord("systemuser", currentUserId, "?$select=rhs_cirrususer");

    if (cirrusUserValue.rhs_cirrususer == undefined || cirrusUserValue.rhs_cirrususer == null) {
        await Xrm.Navigation.openAlertDialog({ title: "Failed", text: "The Cirrus User value on the User form cannot be empty. Please supply a value to be used to take payments via Cirrus." });
        throw Error("Cirrus User value is null. Please provide a username to continue.");
    }

    //Get CirrusKeyVaultURL
    let cirrusFunctionUrl = await RHSScripts.Membership.RetrieveAppSettingValueByName("CirrusKeyVaultURL");
    if (cirrusFunctionUrl == undefined || cirrusFunctionUrl == null)
        throw Error("cirrusFunctionUrl app setting not set for this environment. Please contact an administrator to fix this.");

    let finalURL = await RHSScripts.Membership.ExecuteRetrieveCirrusPaymentURL(cirrusFunctionUrl, membershipId, payerReference, totalAmount, cirrusUserValue.rhs_cirrususer);

    //Xrm.Navigation.openUrl(finalURL);

    console.log("rhs_cirruspcipayment?url=" + finalURL);

    // Immediately show an informational alert on top
    var alertStrings = {
        text: "Please close the Cirrus dialog once payment is completed.",
        title: "Information"
    };
    var alertOptions = { height: 120, width: 260 };

    await Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

    var pageInput = {
        pageType: "webresource",
        webresourceName: "rhs_cirruspcipayment?url=" + finalURL
    };
    var navigationOptions = {
        target: 2,
        width: 700, // value specified in pixel
        height: 800, // value specified in pixel
        position: 1,
        title: "Cirrus PCI Payment"
    };

    await Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function (returnValue) {
                // This function is executed when the dialog is closed
                console.log("Dialog closed. Return value:", returnValue);

            },
            function (error) {
                // This function is executed if the operation fails
                console.error(error);
            }
        );

    if (isRenewal) {
        let newTransaction = await RHSScripts.Membership.RetrievePaidMembershipTransaction(membershipId);
        if (newTransaction == null)
            throw Error("Cirrus Transaction Failed");
    }
    else {
        let intervalId = await RHSScripts.Membership.RetrieveIsPaymentReceived(membershipId);
        if (!intervalId) {
            throw Error("Cirrus Transaction Failed");
        }
    }

    // Confirm PTX payment
    //let alertStrings = { title: "Cirrus PCI Payment", text: "Have you finished CIrrus PCI payment?", confirmButtonLabel: "Yes" };
    //await Xrm.Navigation.openAlertDialog(alertStrings);
}

RHSScripts.Membership.RetrieveEnvironmentVariableValueByName = async function (name) {
    let environmentVariableValue = null;
    let entityLogicalName = "environmentvariabledefinition";
    let options = `?$top=1&$select=environmentvariabledefinitionid,defaultvalue&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)&$filter=schemaname eq '${name}'`;

    let environmentvariables = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (environmentvariables != undefined && environmentvariables != null && environmentvariables.length > 0)
        environmentVariableValue = environmentvariables[0].rhs_value;

    if (environmentvariables && environmentvariables.entities && environmentvariables.entities.length > 0) {
        var responseDefinition = environmentvariables.entities[0];
        // Get the default value
        environmentVariableValue = responseDefinition.defaultvalue;

        // Get the related current value if provided
        if (responseDefinition.environmentvariabledefinition_environmentvariablevalue &&
            responseDefinition.environmentvariabledefinition_environmentvariablevalue.length > 0) {
            environmentVariableValue = responseDefinition.environmentvariabledefinition_environmentvariablevalue[0].value;
        }
    }

    return environmentVariableValue
}

RHSScripts.Membership.ExecuteRetrieveCirrusPaymentURL = async function (functionUrlName, membershipId, payer, totalAmount, CirrusUsername) {
    // Parameters
    var parameters = {};
    parameters.CirrusKeyVaultUrl = functionUrlName; // Edm.String
    parameters.EntityRecord = membershipId; // Edm.Guid
    parameters.PayerRecord = payer.id; // Edm.Guid
    parameters.PayerEntity = payer.entityType; // Edm.String
    parameters.TotalAmount = totalAmount; // Edm.Decimal
    parameters.TransactionType = 120000002; // Edm.Int32
    parameters.CirrusUsername = CirrusUsername;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_cirruspaymenturl_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);
        // Return Type: mscrm.rhs_cirruspaymenturlResponse
        // Output Parameters
        let cirruspaymenturl = result["CirrusPaymentURL"]; // Edm.String

        return cirruspaymenturl;
    }).catch(function (error) {
        console.log(error.message);
    });
}

RHSScripts.Membership.RetrieveIsPaymentReceived = async function (membershipId) {
    //let recordId = formContext.data.entity.getId().replace("{", "").replace("}", "");
    let result = await Xrm.WebApi.retrieveRecord("rhs_membership", membershipId, "?$select=statuscode,rhs_paymentreceived");
    if (result.statuscode == 1/* Active */ && result.rhs_paymentreceived) {
        return true;
    }
    return false;
}

RHSScripts.Membership.ApplyGiftAidOverrideCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let membershipId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    // Confirmation dialog
    let confirmStrings = {
        title: "Confirm Gift Aid Override",
        text:
            "This will apply a gift aid override to all future payments scheduled against this Membership. " +
            "All such payments will be marked as ineligible for gift aid.\n\n" +
            "Please note that this override will also cascade to any renewals for this membership.\n\n" +
            "Please confirm that you wish to continue."
    };

    let confirmOptions = {
        height: 320,
        width: 500
    };

    let confirmResult = await Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions);

    if (!confirmResult.confirmed) {
        return;
    }

    let now = new Date();
    let userId = Xrm.Utility.getGlobalContext().userSettings.userId
        .replace("{", "")
        .replace("}", "");

    /* -----------------------------
       Update current Membership
    ------------------------------ */
    formContext.getAttribute("rhs_giftaidoverride").setValue(true);
    formContext.getAttribute("rhs_giftaidoverridedate").setValue(now);
    formContext.getAttribute("rhs_giftaidoverrideuser").setValue([
        {
            id: userId,
            entityType: "systemuser"
        }
    ]);

    await formContext.data.save();

    /* -----------------------------
       Retrieve renewal memberships
       ----------------------------- */
    let query =
        "?$select=rhs_membershipid" +
        "&$filter=" +
        "rhs_isrenewal eq true" +
        " and _rhs_linkedmembership_value eq " + membershipId +
        " and statuscode eq 120000005"; // Paid in Advance

    let renewals = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_membership",
        query
    );

    /* -----------------------------
       Update renewal memberships
       ----------------------------- */
    for (let i = 0; i < renewals.entities.length; i++) {

        let renewalUpdate = {
            rhs_giftaidoverride: true,
            rhs_giftaidoverridedate: now,
            "rhs_giftaidoverrideuser@odata.bind": `/systemusers(${userId})`
        };

        await Xrm.WebApi.updateRecord(
            "rhs_membership",
            renewals.entities[i].rhs_membershipid,
            renewalUpdate
        );
    }

    // Refresh form after updates
    formContext.data.refresh(false);
}

RHSScripts.Membership.RemoveGiftAidOverrideCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let membershipId = formContext.data.entity.getId()
        .replace("{", "")
        .replace("}", "")
        .toLowerCase();

    /* -----------------------------
       Confirmation dialog
    ------------------------------ */
    let confirmStrings = {
        title: "Confirm Gift Aid Override Removal",
        text:
            "This will remove the gift aid override on this Membership. All future payments scheduled against this Membership " +
            "will no longer be subject to the override and will be considered for gift aid in accordance with other gift aid rules.\n\n" +
            "Please note that the removal of this override will also cascade to any pending renewals for this membership.\n\n" +
            "Please confirm that you wish to continue."
    };

    let confirmOptions = {
        height: 340,
        width: 500
    };

    let confirmResult = await Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions);

    if (!confirmResult.confirmed) {
        return;
    }

    /* -----------------------------
       Update current Membership
    ------------------------------ */
    formContext.getAttribute("rhs_giftaidoverride").setValue(false);
    formContext.getAttribute("rhs_giftaidoverridedate").setValue(null);
    formContext.getAttribute("rhs_giftaidoverrideuser").setValue(null);

    await formContext.data.save();

    /* -----------------------------
       Retrieve renewal memberships
    ------------------------------ */
    let query =
        "?$select=rhs_membershipid" +
        "&$filter=" +
        "rhs_isrenewal eq true" +
        " and _rhs_linkedmembership_value eq " + membershipId +
        " and statuscode eq 120000005"; // Paid in Advance

    let renewals = await Xrm.WebApi.retrieveMultipleRecords(
        "rhs_membership",
        query
    );

    /* -----------------------------
       Update renewal memberships
    ------------------------------ */
    for (let i = 0; i < renewals.entities.length; i++) {

        let renewalUpdate = {
            rhs_giftaidoverride: false,
            rhs_giftaidoverridedate: null,
            "rhs_giftaidoverrideuser@odata.bind": null
        };

        await Xrm.WebApi.updateRecord(
            "rhs_membership",
            renewals.entities[i].rhs_membershipid,
            renewalUpdate
        );
    }

    // Refresh form after updates
    formContext.data.refresh(false);
}

//#endregion