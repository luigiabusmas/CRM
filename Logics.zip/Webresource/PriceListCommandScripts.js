if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.PriceList) === "undefined") { RHSScripts.PriceList = {}; }

const CLONING_INPROGRESS_NOTIFICATION_ID = "CloningInProgressNotification";
const CLONING_SUCCESS_NOTIFICATION_ID = "CloningSuccessNotification";
const CLONING_FAILED_NOTIFICATION_ID = "CloningFailedNotification";

//#region Command Functions
RHSScripts.PriceList.ClonePriceListCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    try{
        formContext.ui.clearFormNotification(CLONING_INPROGRESS_NOTIFICATION_ID);
        formContext.ui.clearFormNotification(CLONING_SUCCESS_NOTIFICATION_ID);
        formContext.ui.clearFormNotification(CLONING_FAILED_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Cloning price list. Please wait...", "WARNING", CLONING_INPROGRESS_NOTIFICATION_ID);

        let priceListId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
        
        let oldPriceListId = priceListId;
        let newPriceListId = await RHSScripts.PriceList.ClonePriceList(formContext);
        await RHSScripts.PriceList.ClonePriceListItems(oldPriceListId, newPriceListId);

        await RHSScripts.PriceList.OpenClonedPriceList(newPriceListId);

        formContext.ui.clearFormNotification(CLONING_INPROGRESS_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Cloning success.", "INFO", CLONING_SUCCESS_NOTIFICATION_ID);
    } catch (error) {
        console.log(error);
        formContext.ui.clearFormNotification(CLONING_INPROGRESS_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Cloning failed.", "ERROR", CLONING_FAILED_NOTIFICATION_ID);
    }
}
//#endregion

//#region Helper Functions
RHSScripts.PriceList.ClonePriceList = async function(formContext) {
    let name = formContext.getAttribute("name").getValue();
    let startDate = formContext.getAttribute("begindate").getValue();
    let endDate = formContext.getAttribute("enddate").getValue();
    let currency = formContext.getAttribute("transactioncurrencyid").getValue();
    let description = formContext.getAttribute("description").getValue();
    let now = new Date();

    let entityLogicalName = "pricelevel";
    let record = {};
    
    if (name != undefined && name != null)
        record["name"] = `Copy of - ${name} (Cloned in ${now.toISOString()})`;
    if (startDate != undefined && startDate != null)
        record["begindate"] = startDate.toISOString();
    if (endDate != null)
        record["enddate"] = endDate.toISOString();
    if (currency != undefined && currency != null) {
        let currencyId = currency[0].id.replace("{", "").replace("}", "").toLowerCase();
        record["transactioncurrencyid@odata.bind"] = `/transactioncurrencies(${currencyId})`;
    }
    if (description != undefined && description != null)
        record["description"] = description;

    let id = (await Xrm.WebApi.createRecord(entityLogicalName, record).then(
        function (result) {
            console.log("Price List created with ID: " + result.id);
            return result;
        },
        function (error) {
            console.log(error);
            throw error;
        })).id.replace("{", "").replace("}", "").toLowerCase();

    return id;
}

RHSScripts.PriceList.ClonePriceListItems = async function(oldPriceListId, newPriceListId) {
    let newPriceListItems = [];

    let entityLogicalName = "productpricelevel";
    let options = "".concat(
        `?$filter=_pricelevelid_value eq ${oldPriceListId}`
    );
    
    let oldPriceListItems = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options).then(
        function success(result) {
            for (var i = 0; i < result.entities.length; i++)
                console.log(result.entities[i]);
            return result;
        },
        function (error) {
            console.log(error);
            throw error;
        }
    )).entities;

    for (let index = 0; index < oldPriceListItems.length; index++) {
        let oldPriceListItem = oldPriceListItems[index];

        let entityLogicalName = "productpricelevel";
        let record = {};

        if (newPriceListId != undefined && newPriceListId != null)
            record["pricelevelid@odata.bind"] = `/pricelevels(${newPriceListId})`;
        if (oldPriceListItem._productid_value != undefined && oldPriceListItem._productid_value != null)
            record["productid@odata.bind"] = `/products(${oldPriceListItem._productid_value})`;
        if (oldPriceListItem._uomid_value != undefined && oldPriceListItem._uomid_value != null)
            record["uomid@odata.bind"] = `/uoms(${oldPriceListItem._uomid_value})`;
        // if (oldPriceListItem._transactioncurrencyid_value != undefined && oldPriceListItem._transactioncurrencyid_value != null)
        //    record["transactioncurrencyid@odata.bind"] = `/transactioncurrency(${oldPriceListItem._transactioncurrencyid_value})`;
        if (oldPriceListItem._discounttypeid_value != undefined && oldPriceListItem._discounttypeid_value != null)
            record["discounttypeid@odata.bind"] = `/discounttypes(${oldPriceListItem._discounttypeid_value})`;
        if (oldPriceListItem.quantitysellingcode != undefined && oldPriceListItem.quantitysellingcode != null)
            record["quantitysellingcode"] = oldPriceListItem.quantitysellingcode;
        if (oldPriceListItem.pricingmethodcode != undefined && oldPriceListItem.pricingmethodcode != null)
            record["pricingmethodcode"] = oldPriceListItem.pricingmethodcode;
        if (oldPriceListItem.amount != undefined && oldPriceListItem.amount != null)
            record["amount"] = oldPriceListItem.amount;
        if (oldPriceListItem.percentage != undefined && oldPriceListItem.percentage != null)
            record["percentage"] = oldPriceListItem.percentage;
        if (oldPriceListItem.roundingpolicycode != undefined && oldPriceListItem.roundingpolicycode != null)
            record["roundingpolicycode"] = oldPriceListItem.roundingpolicycode;
        if (oldPriceListItem.roundingoptioncode != undefined && oldPriceListItem.roundingoptioncode != null)
            record["roundingoptioncode"] = oldPriceListItem.roundingoptioncode;
        if (oldPriceListItem.roundingoptionamount != undefined && oldPriceListItem.roundingoptionamount != null)
            record["roundingoptionamount"] = oldPriceListItem.roundingoptionamount;

        let newPriceListItemId = (await Xrm.WebApi.createRecord(entityLogicalName, record).then(
            function (result) {
                console.log("Price List Item created with ID: " + result.id);
                return result;
            },
            function (error) {
                console.log(error);
                throw error;
            })).id.replace("{", "").replace("}", "").toLowerCase();

        newPriceListItems.push(newPriceListItemId);
    }

    return newPriceListItems;
}

RHSScripts.PriceList.OpenClonedPriceList = async function(priceListId) {
    let entityFormOptions = {};
    entityFormOptions["entityName"] = "pricelevel";
    entityFormOptions["entityId"] = priceListId;

    Xrm.Navigation.openForm(entityFormOptions).then(
        function (success) {
            console.log(success);
        },
        function (error) {
            console.log(error);
        }
    );
}
//#endregion