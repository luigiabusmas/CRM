if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.ThirdPartyDonation) === "undefined") { RHSScripts.ThirdPartyDonation = {}; }

RHSScripts.ThirdPartyDonation.DeleteThirdPartyDonationOnForm = function (primaryControl) {
    var recordGUID = primaryControl.data.entity.getId().replace(/[{}]/g, "");
    var pageInput = {
        pageType: "custom",
        name: "rhs_confirmthirdpartydonationdeletion_1a951",
        recordId: recordGUID
    };
    var navigationOptions = {
        target: 2,
        position: 1,
        width: { value: 450, unit: "px" },
        height: { value: 380, unit: "px" }
    };
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function () {
                //Add Delay to give way for Power Automate to delete record
                setTimeout(function () {
                    Xrm.WebApi.retrieveRecord("rhs_thirdpartydonation", recordGUID, "?$select=rhs_thirdpartydonationid").then(
                        function success(result) {
                            if (!result || !result.rhs_thirdpartydonationid) {
                                primaryControl.ui.close();
                            }
                        },
                        function error(err) {
                            primaryControl.ui.close();
                        }
                    );
                }, 2000);
            }
        ).catch(
            function (error) {
            }
        );
};

RHSScripts.ThirdPartyDonation.GenerateCAFCardReport = function (primaryControl) {
    var pageInput = {
        pageType: "custom",
        name: "rhs_generatecafcardreport_89b1d",
        entityName: "rhs_thirdpartydonation"
    };
    var navigationOptions = {
        target: 2,
        position: 1,
        width: { value: 450, unit: "px" },
        height: { value: 380, unit: "px" },
        title: "Confirm CAF Card Report Generation"
    };
    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function () {
            }
        ).catch(
            function (error) {
            }
        );
};

RHSScripts.ThirdPartyDonation.ConfirmButton = async function (primaryControl) {
    const formContext = primaryControl;

    var confirmStrings = {
        text: "Please confirm that you wish to continue. " +
            "Please note that proceeding will process this donation, which includes generating transaction and payment records which will be sent to finance.",
        title: "Confirm Third Party Donation"
    };

    const result = await Xrm.Navigation.openConfirmDialog(confirmStrings);

    if (result.confirmed) {
        const STATUS_REASON_PROCESSED = 2;
        const STATUS_INACTIVE = 1;
        formContext.getAttribute("statuscode").setValue(STATUS_REASON_PROCESSED);
        formContext.getAttribute("statecode").setValue(STATUS_INACTIVE);
        await formContext.data.save();
    }
};

RHSScripts.ThirdPartyDonation.UserIsManagerandTeamLeadRole = function (primaryControl) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;

    if (primaryControl.ui.getFormType() === 1) {
        return false;
    }

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers" && primaryControl.getAttribute("statuscode").getValue() == 1) {
            return true;
        }
    }

    return false;
};

RHSScripts.ThirdPartyDonation.ViewIsProvisional = function (primaryControl) {
    var gridContext = primaryControl;
    var targetViewId = "32cc4cfb-309d-f011-bbd3-6045bd10fad1";
    var viewSelector = gridContext.getViewSelector();
    var currentView = viewSelector.getCurrentView();
    var currentViewId = viewSelector.getCurrentView().id.toLowerCase().replace(/[{}]/g, "");
    return currentViewId === targetViewId;

};
