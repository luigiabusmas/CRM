if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Campaign) === "undefined") { RHSScripts.Campaign = {}; }

RHSScripts.Campaign.PopulateDescription = async function (executionContext) {
    let formContext = executionContext.getFormContext();
    let restrictedFundLookup = formContext.getAttribute("rhs_restrictedfund").getValue()
    if (!restrictedFundLookup)
        return null;

    let restrictedFundId = restrictedFundLookup[0].id.replace("{", "").replace("}", "").toLowerCase();
    let restrictedFund = await Xrm.WebApi.retrieveRecord("rhs_restrictedfund", restrictedFundId);
    if (restrictedFund.rhs_description != null) {
        formContext.getAttribute("description").setValue(restrictedFund.rhs_description);
    }
};