if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Organisation) === "undefined") { RHSScripts.Organisation = {}; }

let cachedNationalLength = null;

//#region Event Functions
RHSScripts.Organisation.OnSave = function (executionContext) {
    let isValid = true;

    RHSScripts.Organisation.ClearFieldNotifications(executionContext);

    // Validate main phone
    const mainPhoneResult = RHSScripts.Organisation.ValidateMainPhone(executionContext);
    if (!mainPhoneResult) {
        isValid = false;
    }

    // Validate other phone
    const otherPhoneResult = RHSScripts.Organisation.ValidateOtherPhone(executionContext);
    if (!otherPhoneResult) {
        isValid = false;
    }

    // If any validation failed ? prevent save
    if (!isValid) {
        executionContext.getEventArgs().preventDefault();
    } else {
        RHSScripts.Organisation.ClearFieldNotifications(executionContext);
    }
}

RHSScripts.Organisation.OnCountryChange = function (executionContext) {
    const formContext = executionContext.getFormContext();
    const countryName = formContext.getAttribute("address1_country").getValue();

    if (!countryName) {
        cachedNationalLength = null;
        return;
    }

    Xrm.WebApi.retrieveMultipleRecords("rhs_country",
        `?$select=rhs_sizeofnationalnumber&$filter=rhs_description eq '${countryName}'`
    ).then(result => {
        if (result.entities.length > 0) {
            cachedNationalLength = result.entities[0].rhs_sizeofnationalnumber;
        }
    });
}

// Validate Other Phone
RHSScripts.Organisation.ValidateOtherPhone = function (executionContext) {
    const formContext = executionContext.getFormContext();
    const phoneField = "telephone2";
    const phoneFieldName = "Other Phone";
    const phoneValue = formContext.getAttribute(phoneField).getValue();
    return RHSScripts.Organisation.ValidatePhoneNumber(formContext, phoneValue, phoneField, phoneFieldName);
}

// Validate Main Phone
RHSScripts.Organisation.ValidateMainPhone = function (executionContext) {
    const formContext = executionContext.getFormContext();
    const phoneField = "telephone1";
    const phoneFieldName = "Main Phone";
    const phoneValue = formContext.getAttribute(phoneField).getValue();
    return RHSScripts.Organisation.ValidatePhoneNumber(formContext, phoneValue, phoneField, phoneFieldName);
}

RHSScripts.Organisation.ValidatePhoneNumber = function (formContext, phoneValue, phoneField, phoneFieldName) {
    const ctrl = formContext.getControl(phoneField);

    // Clear previous notifications
    ctrl.clearNotification("Phone Validation");

    if (!phoneValue) {
        return true; // nothing to validate
    }

    // Ensure only numbers are allowed
    const regex = /^[0-9]+$/;

    if (!regex.test(phoneValue)) {
        ctrl.setNotification(`Only numbers are allowed in the ${phoneFieldName} field, please enter a correct phone number!`, "Phone Validation");
        return false;
    }

    if (!cachedNationalLength && phoneValue) {
        ctrl.setNotification(`No country to validate the ${phoneFieldName} number format from. Please enter a value in the Address 1: Country field.`, "Phone Validation");
        return false;
    }

    if (cachedNationalLength && phoneValue.length !== cachedNationalLength) {
        ctrl.setNotification(`Phone provided is not per expected National Number size: ${cachedNationalLength}. Please re-enter your ${phoneFieldName} number without the country code.`, "Phone Validation");
        return false;
    }

    ctrl.clearNotification("Phone Validation");
    return true; // Passed validation
}

RHSScripts.Organisation.ClearFieldNotifications = function (executionContext) {
    var formContext = executionContext.getFormContext();

    formContext.ui.controls.forEach(function (control) {
        try {
            if (control && control.clearNotification) {
                control.clearNotification();
            }
        } catch (e) {
            console.log("Error clearing notification on control.", control.getName(), e.message);
        }
    })
}

//#endregion