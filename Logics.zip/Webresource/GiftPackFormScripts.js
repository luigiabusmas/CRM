if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.GiftPack) === "undefined") { RHSScripts.GiftPack = {}; }

RHSScripts.GiftPack.OnLoad = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    RHSScripts.GiftPack.showNotificationforEu(executionContext);
 RHSScripts.GiftPack.SetCampaignCodeRequired(formContext);
    if (formContext.ui.getFormType() === 1) {
        RHSScripts.GiftPack.populateDeliveryContact(formContext);
    }
}

RHSScripts.GiftPack.OnChangeChannel = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    RHSScripts.GiftPack.SetCampaignCodeRequired(formContext);
}

RHSScripts.GiftPack.PurchasedBy_OnChange = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    RHSScripts.GiftPack.populateDeliveryContact(formContext);
}

RHSScripts.GiftPack.populateDeliveryContact = function (formContext) {
    'use strict';
    console.log("populateDeliveryContact function has been called.");
    var purchasedBy = formContext.getAttribute("rhs_purchasedby").getValue();
    var giftpackbulkpurchase = formContext.getAttribute("rhs_giftpackbulkpurchase").getValue();

    if (giftpackbulkpurchase == null) {
        if (purchasedBy != null) {
            formContext.getAttribute("rhs_deliverycontactid").setValue(purchasedBy);
            console.log("Delivery Contact set to Purchased By: " + purchasedBy);
        } else {
            formContext.getAttribute("rhs_deliverycontactid").setValue(null);
            console.log("Delivery Contact set to null.");
        }
    }

}

RHSScripts.GiftPack.showNotificationforEu = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

    formContext.ui.setFormNotification(
        "Gift Packs cannot be sent to countries within the European Union (EU). Please verify the Delivery Contact's home address before proceeding.",
        "WARNING",
        "GP_EU_Notification"
    );

}

 RHSScripts.GiftPack.SetCampaignCodeRequired = function (formContext) {
    'use strict';

    var channelVal = formContext.getAttribute("rhs_channel")?.getValue();
    var CampaignCodeAttr = formContext.getAttribute("rhs_campaignid");

    if (!CampaignCodeAttr) return;

    if (channelVal === 120000001) {
        CampaignCodeAttr.setRequiredLevel("required");
    } else {

        CampaignCodeAttr.setRequiredLevel("none");
    }
}