if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.FileExportRequest) === "undefined") { RHSScripts.FileExportRequest = {}; }

//#region Command Functions
RHSScripts.FileExportRequest.GenerateMembershipRenewalLetter = async function (primaryControl) {
    'use strict';

    var formContext = primaryControl;

    var fetchXml = `
        <fetch>
          <entity name="rhs_fileexportrequests">
            <filter type="and">
              <condition attribute="rhs_exportfilerequesttype" operator="eq" value="120000000" />
              <condition attribute="statuscode" operator="eq" value="120000001" /> 
            </filter>
          </entity>
        </fetch>`;

    var encodedFetch = "?fetchXml=" + encodeURIComponent(fetchXml);
    console.log("Encoded FetchXML:", encodedFetch);

    try {
        var result = await Xrm.WebApi.retrieveMultipleRecords("rhs_fileexportrequests", encodedFetch);
        console.log("Fetch result:", result);

        if (result.entities.length > 0) {
            console.warn("An export file is already in progress. Blocking execution.");

            var alertStrings = {
                text: "There is already an export file in progress. Please wait until it is completed before running again.",
                title: "Action Blocked"
            };
            var alertOptions = { height: 200, width: 450 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        console.log("No active export found. Triggering custom action: FileExportRequests_Instant_GenerateMembershipRenewalLetter");

        var request = {
            getMetadata: function () {
                return {
                    boundParameter: null,
                    parameterTypes: {},
                    operationType: 0,
                    operationName: "FileExportRequests_Instant_GenerateMembershipRenewalLetter" // <-- Flow/Action name
                };
            }
        };

        var response = await Xrm.WebApi.execute(request);
        console.log("Flow execution response:", response);

        var alertStrings = { text: "Flow triggered successfully!", title: "Success" };
        var alertOptions = { height: 150, width: 300 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

    } catch (error) {
        console.error("Error in GenerateMembershipRenewalLetter:", error);
        var alertStrings = { text: "Error: " + error.message, title: "Error" };
        var alertOptions = { height: 200, width: 450 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
};

RHSScripts.FileExportRequest.GenerateGiftAid3rdPartyCommandButton = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_generategiftaid3rdpartyexport_4a3f1";

    let pageInput = {
        pageType: "custom",
        name: customPageName
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Generate gift aid third party export"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};

RHSScripts.FileExportRequest.GenerateDDClaimBatchFile = async function (primaryControl, fileExport) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_generatebacsfileexport_2c87e";

    var customMessage = {
        FileToGenerate: fileExport
    };
    var paramValue = JSON.stringify(customMessage);

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        recordId: paramValue
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Generate BACS File Export"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};


RHSScripts.FileExportRequest.GenerateNAVRequestCommandDisplayRule = function (primaryControl) {

    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    var hasRequiredRole = false;

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers") {
            hasRequiredRole = true;
            break;
        }
    }

    if (!hasRequiredRole) {
        return false;
    }
};

RHSScripts.FileExportRequest.GenerateNAVRequestCommandAction = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    var fetchXml = `
        <fetch>
          <entity name="rhs_fileexportrequests">
            <filter type="and">
              <condition attribute="rhs_exportfilerequesttype" operator="eq" value="120000018" />
              <condition attribute="statuscode" operator="in">
                <value>120000001</value>
                <value>120000003</value>
              </condition>
            </filter>
          </entity>
        </fetch>`;

    var encodedFetch = "?fetchXml=" + encodeURIComponent(fetchXml);
    console.log("Encoded FetchXML:", encodedFetch);

    try {
        var result = await Xrm.WebApi.retrieveMultipleRecords("rhs_fileexportrequests", encodedFetch);
        console.log("Fetch result:", result);

        if (result.entities.length > 0) {
            console.warn("An export file is already in progress. Blocking execution.");

            var notification =
            {
                type: 2,
                level: 2,
                message: "A previous NAV Export is still being generated. Please try again later.",
                showCloseButton: true
            }

            Xrm.App.addGlobalNotification(notification).then(
                function success(result) {
                    console.log("Notification created with ID: " + result);
                    // perform other operations as required on notification display
                },
                function (error) {
                    console.log(error.message);
                    // handle error conditions
                }
            );

            return;
        }

        let now = new Date();
        let options = {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false,
            timeZone: 'UTC'
        };

        let dateFormatted = new Intl.DateTimeFormat('en-GB', options).format(now);
        dateFormatted = dateFormatted.replace(',', '');

        //Create File Export Request
        var data =
        {
            "rhs_exportfilerequesttype": 120000018,
            "rhs_exporttypechoice": 120000001,
            "statuscode": 120000003,
            "statecode": 1,
            "rhs_name": "FileExport - " + dateFormatted
        }

        // create file export request record
        Xrm.WebApi.createRecord("rhs_fileexportrequests", data).then(
            function success(result) {
                console.log("File Export Request created with ID: " + result.id);
            },
            function (error) {
                console.log(error.message);
            }
        );

        var notification =
        {
            type: 2,
            level: 1,
            message: "Generating NAV Export. Please do not start this process again until the file is generated.",
            showCloseButton : true
        }

        Xrm.App.addGlobalNotification(notification).then(
            function success(result) {
                console.log("Notification created with ID: " + result);
            },
            function (error) {
                console.log(error.message);
                // handle error conditions
            }
        );

        formContext.refresh(true);

    } catch (error) {
        console.error("Error in GenerateNAVExport:", error);
        var alertStrings = { text: "Error: " + error.message, title: "Error" };
        var alertOptions = { height: 200, width: 450 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    }
    
};
//#end region
