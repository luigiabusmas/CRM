async function filterPaymentMethods(executionContext) {
    try {
        // Get the form context
        const formContext = executionContext.getFormContext();

        // Get the selected value of the rhs_membershipproductid lookup
        const membershipProductId = formContext.getAttribute("rhs_membershipproductid").getValue();

        // Get the value of the 
        const activationCode = formContext.getAttribute("rhs_activationcode").getValue();


        if (!membershipProductId) {
            console.log("No Membership Product selected.");
            return;
        }

        if (membershipProductId && formContext.getAttribute("rhs_redeemgiftpack").getValue() == true && activationCode) {
            var optionSetPaymentMethodValue = 844060005;
            formContext.getAttribute("rhs_paymentmethod").setValue(optionSetPaymentMethodValue);
            formContext.getAttribute("rhs_paymentreceived").setValue(true);
            return;
        }

        const membershipProductGuid = membershipProductId[0].id.replace("{", "").replace("}", "");

        // Fetch the Product record and retrieve Allowed Payments field
        const productRecord = await RetrieveProductProperty(membershipProductGuid);

        if (productRecord === null) {
            console.log("No Allowed Payments found for the selected Product.");
            return;
        }

        // Split the Allowed Payments value into an array
        const allowedPayments = productRecord.split(";");

        // Define the complete list of all available payment options
        const allOptions = [
            { value: 120000002, text: "Direct Debit" },
            { value: 844060002, text: "Card" },
            { value: 844060000, text: "Cash" },
            { value: 844060001, text: "Cheque" }
        ];

        // Define a simplified mapping for quick lookup
        const paymentMethodCodes = {
            DD: 120000002,        // Direct Debit
            CARD: 844060002,        // CARD
            CASH: 844060000,      // Cash
            CHEQUE: 844060001     // Cheque
        };

        // Filter the options based on the allowed payments
        const filteredOptions = allowedPayments.map((payment) => {
            const optionValue = paymentMethodCodes[payment];
            return allOptions.find((option) => option.value === optionValue);
        }).filter(Boolean); // Remove undefined/null values if any

        // Update the rhs_paymentmethod Option Set field
        const paymentMethodControl = formContext.getControl("rhs_paymentmethod");

        // Clear all existing options first
        paymentMethodControl.clearOptions();

        // Add filtered options dynamically
        filteredOptions.forEach((option) => {
            paymentMethodControl.addOption(option);
        });

        console.log("Payment Methods filtered successfully:", filteredOptions);
    } catch (error) {
        console.log("Error in filtering Payment Methods:", error);
    }
}

// FetchXML Query to Retrieve Product Properties
RetrieveProductProperty = async function (productId) {
    'use strict';
    let allowedPayments = null;

    let fetchData = {
        "name": "Allowed Payments",
        "productid": productId
    };

    let fetchXml = [
        "<fetch returntotalrecordcount='true'>",
        "  <entity name='dynamicproperty'>",
        "    <attribute name='dynamicpropertyid'/>",
        "    <attribute name='defaultvaluestring'/>",
        "    <attribute name='name'/>",
        "    <filter type='and'>",
        "      <condition attribute='name' operator='eq' value='", fetchData.name, "'/>",
        "    </filter>",
        "    <link-entity name='dynamicpropertyassociation' from='dynamicpropertyid' to='dynamicpropertyid' link-type='inner' alias='aa'>",
        "      <link-entity name='product' from='productid' to='regardingobjectid' alias='ab'>",
        "        <filter>",
        "          <condition attribute='productid' operator='eq' value='", fetchData.productid, "'/>",
        "        </filter>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    // Execute the FetchXML query using the Web API
    await Xrm.WebApi.retrieveMultipleRecords("dynamicproperty", "?fetchXml=" + encodeURIComponent(fetchXml))
        .then(function (result) {
            if (result.entities.length > 0) {
                let dynamicProperty = result.entities[0];

                allowedPayments = dynamicProperty.defaultvaluestring;
                console.log("Allowed Payments: ", allowedPayments);

            } else {
                console.warn("No dynamic property found.");
            }
        })
        .catch(function (error) {
            console.error("Error retrieving dynamic property:", error.message);
        });

    return allowedPayments;
}

// Onload function
function onFormLoad(executionContext) {
    // Call the filter function
    filterPaymentMethods(executionContext);
}

// Onchange function
function onMembershipProductChange(executionContext) {
    // Call the same function
    filterPaymentMethods(executionContext);
}