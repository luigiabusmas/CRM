async function showMessageOnPaymentReceived(formExecutionContext) {
    let formContext = formExecutionContext.getFormContext();

    if(await validatePaymentReceived(formContext))
        await showConfirmationMessage(formContext);
}

async function retrieveMembershipUsingId(id) {
    let entityLogicalName = "msnfp_membership";
    let options = "?$select=rhs_paymentreceived";

    return await Xrm.WebApi.retrieveRecord(entityLogicalName, id, options).then(
        function success(result) {
            return result;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function validatePaymentReceived(formContext) {
    //Validate if triggered on update
    let modifiedOnLogicalName = "modifiedon";
    let modifiedOnValue = formContext.getAttribute(modifiedOnLogicalName).getValue();

    if (modifiedOnValue != undefined && modifiedOnValue != null)
    {
        //Validate if payment received changed to true
        let membershipIdValue = formContext.data.entity.getId();
        let membershipPreImage = await retrieveMembershipUsingId(membershipIdValue);

        let paymentReceivedLogicalName = "rhs_paymentreceived";
        let paymentReceivedValue = formContext.getAttribute(paymentReceivedLogicalName).getValue();

        if(membershipPreImage[paymentReceivedLogicalName] != paymentReceivedValue && paymentReceivedValue == true)
            return true;
    }

    //Default return
    return false;
}

async function showConfirmationMessage(formContext) {
    let message = "Membership Transaction Successful";
    let level = "INFORMATION";
    formContext.ui.setFormNotification(message, level)
}