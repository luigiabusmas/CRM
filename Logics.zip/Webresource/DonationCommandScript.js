//Donation Command  Source Code
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Donation) === "undefined") { RHSScripts.Donation = {}; }

const SUBMITTING_PAYMENT_NOTIFICATION_ID = "SubmittingPaymentNotification";
const SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID = "SubscriptionTransactionSuccessfulNotification";
const SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID = "SubscriptionTransactionFailedNotification";

//#region Command Functions
RHSScripts.Donation.GiftAidDeclarationCommand = async function (primaryControl) {
    'use strict';
    var formContext = primaryControl;

    // Validation Start
    var donorField = formContext.getAttribute("rhs_donor");
    var donorValue = donorField ? donorField.getValue() : null;

    //Check if Donor has value
    if (!donorValue || donorValue.length === 0) {
        var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as the Donor field is empty. \n\nPlease add a Donor and try again.", title: "Action Required" };
        var alertOptions = { height: 215, width: 590 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        return;
    }
    var donorId = donorValue[0].id.replace("{", "").replace("}", "").toLowerCase();
    var donorType = donorValue[0].entityType.toLowerCase();
    console.log("Payer:", donorValue);
    console.log("donorValue Length:", donorValue.length);

    //Check if Donor is Contact
    if (donorType !== "contact") {
        var alertStrings = { text: "\nYou are unable to add Gift Aid Declaration as this Donor is an Organisation.", title: "Information" };
        var alertOptions = { height: 220, width: 260 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        return;
    }

    if (donorType === "contact") {
        console.log("CotactId:", donorId);
        try {
            var contactDetails = await Xrm.WebApi.retrieveRecord("contact", donorId, "?$select=address1_country,address1_postalcode,address1_city,address1_line1,rhs_loqatehomeaddresshousename");
            var country = contactDetails['address1_country'];
            var normalCountry = country ? country.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\W_-]+/g, '') : '';
            var isUK = normalCountry === 'unitedkingdom' || normalCountry === 'uk';
            var houseName = contactDetails['rhs_loqatehomeaddresshousename'];
            var addressLine1 = contactDetails['address1_line1'];
            var city = contactDetails['address1_city'];
            var postCode = contactDetails['address1_postalcode'];
            console.log("normalCountry: " + normalCountry);
            console.log("houseName:" + houseName);


            if (normalCountry && isUK) {
                if (!postCode || !city || !(addressLine1 || houseName)) {
                    var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Donor does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
                    var alertOptions = { height: 240, width: 590 };
                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    return;
                }
            } else if (!normalCountry) {
                var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Donor does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
                var alertOptions = { height: 240, width: 590 };
                Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                return;
            }

        } catch (error) {
            console.error("Error retrieving contact details:", error.message);
            alert("Error retrieving contact details: " + error.message);
        }
    }
    // Validation End
    var entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    var customPageName = "rhs_newgiftaiddeclaration_fff4a";
    var pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "donation",
        recordId: entityId
    };

    var navigationOptions = {
        target: 1,
        position: 1
    };

    // Navigate to the custom page
    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(function () {
            console.log("Custom page opened successfully in the workspace.");
        })
        .catch(function (error) {
            console.error("Error navigating to the custom page:", error.message);
        });
}


// Cancel Donation
RHSScripts.Donation.CancelDonationCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    // Confirm first
    let confirmCancel = window.confirm("Cancel Donation?");
    if (!confirmCancel) {
        return;
    }

    // Set fields
    formContext.getAttribute("rhs_canceldonation").setValue(true);
    formContext.getAttribute("rhs_canceldonation").fireOnChange(); //triggers busines rule
};


/* CancelDDCommand was reworked according to task 66163
// Cancel Donation DD 
RHSScripts.Donation.CancelDdCommand = async function (primaryControl) {
    'use strict';

    var confirmCancel = window.confirm("Cancel Donation?");
    if (!confirmCancel) {
        return;
    }

    var formContext = primaryControl;
    var donationId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    var notificationId = "CANCEL_DONATION_IN_PROGRESS";

    // Show loading indicator and notification
    Xrm.Utility.showProgressIndicator("Cancelling donation. Please wait...");
    formContext.ui.setFormNotification("Cancelling donation. Please wait...", "INFO", notificationId);

    // Set fields
    formContext.getAttribute("statecode").setValue(1);
    formContext.getAttribute("statuscode").setValue(120000002);
    formContext.getAttribute("rhs_canceldonation").setValue(true);
    formContext.getAttribute("rhs_donationcancellationreason").setValue([
        {
            id: "5d0e233a-7214-f011-998a-002248c76136",
            name: "",
            entityType: "rhs_cancellationreason"
        }
    ]);

    // Prepare parameters for the Custom API
    var parameters = {
        RecordId: donationId,
        TransactionType: 120000000
    };

    // Call the custom action via Web API (hardcoded API name)
    fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_cancelDDI", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(function (response) {
        return response.json().then(function (json) {
            if (response.ok) {
                return [response, json];
            } else {
                throw json.error;
            }
        });
    }).then(function (responseObjects) {
        var response = responseObjects[0];
        var responseBody = responseObjects[1];

        console.log("Custom Action Response (Success):", responseBody);
        Xrm.Navigation.openAlertDialog({ text: "Donation cancelled successfully." });
  formContext.data.save();
        console.log("Payment IDs:", responseBody["PayementIds"]);
        console.log("Payment Schedule IDs:", responseBody["PayementScheduleIds"]);
        console.log("Transaction IDs:", responseBody["TransactionIds"]);

    }).catch(function (error) {
        console.error("Custom Action Failed:", error);
        Xrm.Navigation.openAlertDialog({
            text: "An error occurred while calling the cancellation action:\n" + error.message
        });
        formContext.ui.setFormNotification("Cancellation failed: " + error.message, "ERROR", notificationId);
    }).finally(function () {
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(notificationId);
    });
};
*/


//Make payment
RHSScripts.Donation.MakePaymentCommand = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;

    let donationId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let donation = formContext.getAttribute("rhs_donationtype").getValue()[0];

    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let ongoingDDAmount = formContext.getAttribute("rhs_ongoingddamount").getValue();
    let paymentFrequency = formContext.getAttribute("rhs_paymentfrequency").getValue();
    let totalAmount = null;
    if (paymentMethod !== null) {
        let paymentMethodValue = paymentMethod; // assuming it's an Option Set

        if (paymentMethodValue === 120000014) { // Credit Card Phone
            totalAmount = formContext.getAttribute("rhs_amount").getValue();
        } else if (paymentMethodValue === 120000002) { // Direct Debit
            if (paymentFrequency == 120000002) { // monthly
                totalAmount = ongoingDDAmount * 12;
            }
        }
    }
    let donor = formContext.getAttribute("rhs_donor").getValue()[0];
    let isContinuousPayment = formContext.getAttribute("rhs_iscontinuouspayment").getValue();

    let checkoutURL = formContext.getAttribute("rhs_checkouturl").getValue();
    let checkoutSessionId = formContext.getAttribute("rhs_checkoutsessionid").getValue();

    try {
        let isSubmitPayment = formContext.getAttribute("rhs_issubmitpayment").getValue();

        if (isSubmitPayment != true) {
            //#region  Prepare the subscription for payment submission
            Xrm.Utility.showProgressIndicator("Submitting payment. Please wait...");
            formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
            formContext.ui.clearFormNotification(SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Submitting payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);

            // await RHSScripts.Donation.SetPayoutDate(formContext); // Date calculation logic moved to DonationUpdatePreOpsPlugin

            formContext.getAttribute("rhs_issubmitpayment").setValue(true); // Trigger date fields population and disables the button.
            formContext.getAttribute("rhs_issubmitpayment").fireOnChange();
            await formContext.data.save();
            await formContext.data.refresh(true);
            //#endregion

            //#region  Generate transaction, payments and payment schedule
            let transaction = await RHSScripts.Donation.RetrieveActiveDonationTransaction(donationId);
            let firstPayment = await RHSScripts.Donation.RetrieveActiveDonationFirstPayment(donationId);

            let isFirstDDPaymentDueDateElapsed = paymentMethod == 120000002/*DD*/ && firstPayment?.rhs_duedate && new Date(firstPayment.rhs_duedate) < new Date();
            if (isFirstDDPaymentDueDateElapsed) {
                await RHSScripts.Donation.CancelTransactionAndAssociatedRecords(transaction);
            }

            if (transaction == null || isFirstDDPaymentDueDateElapsed) {
                let [transactionid, paymentid, payementscheduleid] = await RHSScripts.Donation.ExecuteSubmitPaymentCustomAPIForDonation(
                    paymentMethod, donationId, donor, isContinuousPayment, paymentFrequency, totalAmount
                );
                await formContext.data.refresh(true);

                if (transactionid == null && paymentid == null && payementscheduleid == null)
                    throw new Error("Donation transaction failed.");
            }
            //#endregion

            //#region  Make/Submit Payment
            if (paymentMethod == 844060000/*Cash*/ || paymentMethod == 844060001/*Cheque*/ ||
                paymentMethod == 120000002/*DD*/ ||
                paymentMethod == 844060005/*Gift Pack*/
            ) {
                if (paymentMethod == 120000002/*DD*/) {
                    await RHSScripts.Donation.MakePTXPayment(donationId, paymentFrequency, donor);
                    // if (await RHSScripts.Subscription.ValidateIfLinkedDonationPaymentMethodIsDirectDebit(formContext)) {
                    //     let linkedSubscriptionId = formContext.getAttribute("rhs_linkeddonation").getValue()[0].id.replace("{", "").replace("}", "").toLowerCase();
                    //     await RHSScripts.Subscription.ContinueUsingSameDirectDebitForDonation(linkedSubscriptionId, donationId);
                    // } else {
                    //     await RHSScripts.Subscription.MakePTXPayment(donationId, paymentFrequency, donor);
                    // }
                }
                await RHSScripts.Donation.ActivateDonation(donationId, formContext);
                await formContext.data.refresh(true);
            } else if (paymentMethod == 120000014/*Credit Card*/) {
                await RHSScripts.Donation.MakeCirrusPCIpaymentURL(donationId, donor, totalAmount, formContext);
                await formContext.data.refresh(true);
            }
            //#endregion

            //#region  Ending payment submission
            Xrm.Utility.closeProgressIndicator();
            formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
            formContext.ui.setFormNotification("Donation transaction successful.", "INFO", SUBSCRIPTION_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
            Xrm.Navigation.openAlertDialog({ title: "Success", text: "Payment successful." });
            //#endregion
        }
    } catch (error) {
        formContext.getAttribute("rhs_issubmitpayment").setValue(false);
        formContext.getAttribute("rhs_issubmitpayment").fireOnChange();
        await formContext.data.save();
        await formContext.data.refresh(true);

        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Donation transaction failed. Please try again", "ERROR", SUBSCRIPTION_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Payment failed. \n\nDetails: " + error.message });
    }
}

RHSScripts.Donation.ExecuteSubmitPaymentCustomAPIForDonation = async function (paymentMethod, donationId, donor, isContinuousPayment, paymentFrequency, totalAmount, outstandingAmount = null) {
    // Parameters
    let parameters = {};
    parameters.PaymentMethod = paymentMethod;
    parameters.RecordId = donationId;
    parameters.PayerId = donor != null ? donor.id.replace("{", "").replace("}", "").toLowerCase() : null;
    parameters.IsContiniousPayment = isContinuousPayment;
    parameters.PaymentFrequency = paymentFrequency;
    parameters.TransactionType = 120000000;
    parameters.Type = 120000000;
    parameters.PayerEntity = donor != null ? donor.entityType : null;
    parameters.TotalAmount = totalAmount;
    // parameters.OutstandingAmount = outstandingAmount;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_submitpayment_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let transactionid = result["TransactionId"];
        let paymentid = result["PaymentId"];
        let payementscheduleid = result["PayementScheduleId"];
        return [transactionid, paymentid, payementscheduleid]
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

// Logic moved to DonationUpdatePreOpsPlugin
// RHSScripts.Donation.SetPayoutDate = async function (formContext) {

//     let donationId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
//     let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
//     let now = new Date();
//     let paymentDate = now.getDate();
//     let rhs_startdate = formContext.getAttribute("rhs_startdate").getValue();
//     let startDate = null;
//     if (rhs_startdate == undefined || rhs_startdate == null) {
//         // startDate = new Date(now);
//         if (paymentDate >= 23 && paymentDate <= 31) {
//             startDate = new Date(now.getFullYear(), now.getMonth() + 1, 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of next month
//         } else if (paymentDate === 1) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 1, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 1st of current month
//         } else if (paymentDate >= 2 && paymentDate <= 7) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 8, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 8th of current month
//         } else if (paymentDate >= 8 && paymentDate <= 15) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 15, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 15th of current month
//         } else if (paymentDate >= 16 && paymentDate <= 22) {
//             startDate = new Date(now.getFullYear(), now.getMonth(), 22, now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds()); // 22nd of current month
//         }
//     } else {
//         startDate = new Date(rhs_startdate);
//     }
//     console.log("Calculated Start Date: " + startDate.toISOString());

//     let endDate = new Date(startDate);
//     endDate.setFullYear(endDate.getFullYear() + 1);
//     endDate.setDate(endDate.getDate() - 1);
//     //
//     let record = {};
//     if (rhs_startdate == undefined || rhs_startdate == null)
//         record.rhs_startdate = startDate.toISOString().substring(0, 10);
//     console.log("record.rhs_startdate:" + record.rhs_startdate);

//     if (paymentMethod != 844060005/*Gift Pack*/) {
//         record.rhs_enddate = endDate.toISOString().substring(0, 10);
//         console.log("record.rhs_enddate:" + record.rhs_enddate);
//     }
//     if (paymentMethod == 120000002 /* DD */) {
//         var nextPayoutDate = new Date(startDate);
//         console.log("Initial Start Date: " + nextPayoutDate.toISOString());

//         var workingDaysAdded = 0;

//         // Loop until 10 working days
//         while (workingDaysAdded < 10) {
//             nextPayoutDate.setDate(nextPayoutDate.getDate() + 1);
//             var dayOfWeek = nextPayoutDate.getDay();

//             // Skip weekends
//             if (dayOfWeek !== 0 && dayOfWeek !== 6) {
//                 let isHoliday = await RHSScripts.Donation.HasHolidays(nextPayoutDate);
//                 if (!isHoliday) {
//                     workingDaysAdded++;
//                 }
//             }
//         }
//         // Final payout date
//         console.log("Final calculated Payout Date: " + nextPayoutDate);
//         var year = nextPayoutDate.getFullYear();
//         var month = String(nextPayoutDate.getMonth() + 1).padStart(2, '0');
//         var day = String(nextPayoutDate.getDate()).padStart(2, '0');
//         var formattedDate = year + '-' + month + '-' + day;

//         record.rhs_payoutdate = formattedDate;
//     }

//     // if (paymentMethod == 120000002 /* DD */) {
//     // // let nextPayoutDate = formContext.getAttribute("rhs_payoutdate").getValue();
//     // let nextPayoutDate = formContext.getAttribute("createdon").getValue(); 
//     //     console.log("nextPayoutDate: " + nextPayoutDate);
//     //     var year = nextPayoutDate.getFullYear();
//     //     var month = String(nextPayoutDate.getMonth() + 1).padStart(2, '0');
//     //     var day = String(nextPayoutDate.getDate()).padStart(2, '0');
//     //     var formattedDate = year + '-' + month + '-' + day;

//     //     record.rhs_payoutdate = formattedDate;
//     // }
//     await Xrm.WebApi.updateRecord("rhs_donation", donationId, record);
// }

RHSScripts.Donation.HasHolidays = async function (nextPayoutDate) {
    nextPayoutDate.setHours(0, 0, 0, 0);
    let nextPayoutDateString = nextPayoutDate.toISOString().split("T")[0];

    let entityLogicalName = "calendar";
    let calendarName = "UK Holidays";
    let query = `?$select=calendarid&$filter=name eq '${calendarName}'`;

    try {
        // Retrieve the calendar record
        let calendars = await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, query);
        if (!calendars || calendars.entities.length === 0) {
            return false;
        }

        let calendarId = calendars.entities[0].calendarid;
        let expandQuery = `?$select=calendarid&$expand=calendar_calendar_rules($select=starttime)`;
        let calendar = await Xrm.WebApi.retrieveRecord(entityLogicalName, calendarId, expandQuery);

        // Check if there are any holidays in the calendar
        if (!calendar.calendar_calendar_rules || calendar.calendar_calendar_rules.length === 0) {
            return false;
        }
        // Convert holiday start times to YYYY-MM-DD format for comparison
        let holidays = calendar.calendar_calendar_rules.map(rule => {
            let holidayDate = new Date(rule.starttime);
            if (isNaN(holidayDate)) {
                return null;
            }

            holidayDate.setHours(0, 0, 0, 0);
            return holidayDate.toISOString().split("T")[0];
        }).filter(Boolean);
        return holidays.includes(nextPayoutDateString);
    } catch (error) {
        console.error("Error retrieving calendar with rules:", error);
        return false;
    }
}
RHSScripts.Donation.RetrieveActiveDonationTransaction = async function (donationId) {//okay
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,rhs_transacid,_rhs_donation_value,rhs_amount,rhs_paidon,rhs_outstandingamount,statecode,statuscode",
        `&$filter=(_rhs_donation_value eq ${donationId} and (statecode eq 0 or statuscode eq 120000008))`
    );

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}
RHSScripts.Donation.ValidateIfLinkedDonationPaymentMethodIsDirectDebit = async function (formContext) { //not in use
    'use strict';

    let linkedSubscriptionFieldValue = formContext.getAttribute("rhs_linkedsubscription").getValue();
    if (linkedSubscriptionFieldValue) {
        let linkedSubscription = await Xrm.WebApi.retrieveRecord("rhs_subscription", linkedSubscriptionFieldValue[0].id, "?$select=rhs_paymentmethodcode");
        if (linkedSubscription.rhs_paymentmethodcode == 120000002/*DirectDebit*/) {
            return true;
        }
    }

    return false;
}
// RHSScripts.Donation.ContinueUsingSameDirectDebitForDonation = async function (oldDonationId, newDonationId) {
//     let directDebitDetail = await RHSScripts.Subscription.RetrieveDonationDirectDebit(oldDonationId);
//     let newTransaction = await RHSScripts.Subscription.RetrieveActiveDonationTransaction(newDonationId);
//     let newPayments = await RHSScripts.Subscription.RetrieveActiveDonationPayments(newDonationId);

//     //Update direct debit lookup of transaction
//     if (directDebitDetail && newTransaction) {
//         let transactionUpdate = {};
//         transactionUpdate["rhs_directdebitmandate@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

//         await Xrm.WebApi.updateRecord("rhs_transaction", newTransaction.rhs_transactionid, transactionUpdate);
//     }

//     //Update direct debit lookup of payments
//     if (directDebitDetail && newPayments) {
//         for (let ctr = 0; ctr < newPayments.length; ctr++) {
//             var paymentUpdate = {};
//             paymentUpdate["rhs_DirectDebitDetails@odata.bind"] = `/rhs_directdebitdetailses(${directDebitDetail.rhs_directdebitdetailsid})`;

//             await Xrm.WebApi.updateRecord("rhs_payment", newPayments[ctr].rhs_paymentid, paymentUpdate);
//         }
//     }

//     //Update direct debit lookup of subscription
//     if(directDebitDetail) {
//         var directDebitUpdate = {};
//         directDebitUpdate["rhs_Subscription@odata.bind"] = `/rhs_subscriptions(${newSubscriptionId})`;

//         await Xrm.WebApi.updateRecord("rhs_directdebitdetails", directDebitDetail.rhs_directdebitdetailsid, directDebitUpdate);
//     }
// }
// RHSScripts.Donation.RetrieveDonationDirectDebit = async function (donationId) {
//     let directDebitDetail = null;
//     let entityLogicalName = "rhs_directdebitdetails";
//     let options = `?$filter=_rhs_donation_value eq ${donationId}`;

//     let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
//     if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
//         directDebitDetail = directDebitDetails[0];

//     return directDebitDetail;
// }

RHSScripts.Donation.MakePTXPayment = async function (donationId, paymentFrequency, payerReference) {
    let ptxPaymentUrl = await RHSScripts.Donation.RetrieveAppSettingValueByName("FAPTXWebFormURL");
    let ptxCallbackURL = await RHSScripts.Donation.RetrieveAppSettingValueByName("FAPTXCallbackURL");
    if (ptxPaymentUrl == undefined || ptxPaymentUrl == null)
        throw Error("PTXWebFormURL app setting not set for this environment. Please contact an administrator to fix this.");
    if (ptxCallbackURL == undefined || ptxCallbackURL == null)
        throw Error("FAPTXCallbackURL app setting not set for this environment. Please contact an administrator to fix this.");

    if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?");
    ptxPaymentUrl += "?";

    let payer = await Xrm.WebApi.retrieveRecord(payerReference.entityType, payerReference.id);
    let payerCompany = payerReference.entityType == "contact" && payer._parentcustomerid_value != undefined && payer._parentcustomerid_value != null ?
        await Xrm.WebApi.retrieveRecord("account", payer._parentcustomerid_value) : null;
    let payerTitle = payerReference.entityType == "contact" && payer._rhs_title_value != undefined && payer._rhs_title_value != null ?
        await Xrm.WebApi.retrieveRecord("rhs_titleandsalutation", payer._rhs_title_value) : null;

    let postcode = payer.address1_postalcode;
    //let buildingNumberOrName = null; // Building name is not saved on contact or account address fields.
    let address = payerReference.entityType == "contact" ?
        (payer.rhs_loqatehomeaddresshousename != null ? payer.rhs_loqatehomeaddresshousename.split(' ').slice(1).join(' ') : null) :
        (payer.rhs_loqateaddress1housename != null ? payer.rhs_loqateaddress1housename.split(' ').slice(1).join(' ') : null);
    let townOrCity = payerReference.entityType == "contact" ? payer.address1_city : payer.address1_city;

    let buildingNumberOrName = payerReference.entityType === "contact" ? (payer.rhs_loqatehomeaddresshousename ?? null) : (payer.rhs_loqateaddress1housename ?? null);
    let transaction = await RHSScripts.Donation.RetrieveActiveDonationTransaction(donationId);
    let paymentSchedule = await RHSScripts.Donation.RetrieveActiveDonationPaymentSchedule(donationId);
    let payments = await RHSScripts.Donation.RetrieveActiveDonationPayments(donationId);

    //Normalize accented characters
    const normalizeText = (value) => {
        if (!value || typeof value !== "string") return value;
        return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s]/g, "");
    }

    let parameters = {};
    //#region  Customisation parameters
    parameters.formname = null;
    parameters.texttitle = null;
    parameters.textsubtitle = null;
    parameters.contactphone = null;
    parameters.contactemail = null;
    parameters.textapplybutton = null;
    parameters.showformheader = null;
    parameters.legalentityname = null;
    parameters.currentaddresslegend = null;
    parameters.customdatalabel = null;
    parameters.showtitle = null;
    parameters.showfirstname = null;
    parameters.showmiddlename = null;
    parameters.showlastname = null;
    parameters.showdob = null;
    parameters.showemail = null;
    parameters.showmobile = null;
    parameters.showcurrentaddress = null;
    parameters.showbankaccount = null;
    parameters.advancednoticedays = 1;
    parameters.showcompanyname = null;
    parameters.showapplyingascompanycheck = null;
    parameters.useaddressline2 = null;
    parameters.showcustomdata = null;
    parameters.showddplanreference = null;
    parameters.showconfirmddguarantee = null;
    parameters.showddplansummary = null;
    parameters.showddplanfields = null;
    parameters.showgiftaid = null;
    parameters.showerrordetail = null;
    parameters.showbankaccountcreated = null;
    parameters.showcompanyregistrationnumber = null;
    //#endregion
    //#region  Required
    parameters.company = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    //parameters.firstname = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    const firstName = payerReference.entityType == "contact" ? payer.firstname : payer.name;
    parameters.firstname = normalizeText(firstName);
    //parameters.lastname = payerReference.entityType == "contact" ? payer.lastname : null;
    const lastName = payerReference.entityType == "contact" ? payer.lastname : null;
    parameters.lastname = normalizeText(lastName);
    //parameters.email = payer.emailaddress1;
    const emailAddress1 = payer.emailaddress1;
    parameters.email = normalizeText(emailAddress1);
    parameters.currenthousenamenumber = buildingNumberOrName;
    parameters.currentpostcode = postcode;
    //parameters.bankaccountname = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    const bankaccountName = payerReference.entityType == "contact" ? payer.fullname : payer.name;
    parameters.bankaccountname = normalizeText(bankaccountName);
    parameters.sortcode = null;
    parameters.accountnumber = null;
    parameters.ddplanspecification = null;
    parameters.ddregularamount = paymentSchedule != null ? paymentSchedule.rhs_paymentamount : payments[0].rhs_amount;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddstartdate = payments[0].rhs_duedate.substring(0, 10);
    //#endregion
    //#region  Optional
    parameters.requestid = null;
    parameters.requestuserid = null;
    parameters.customdata = null;
    parameters.contactdetailsheader = null;
    parameters.title = null;    // causes problems when more than 5 characters
    //parameters.middlename = payerReference.entityType == "contact" ? payer.middlename : null;
    const middleName = payerReference.entityType == "contact" ? payer.middlename : null;
    parameters.middlename = normalizeText(middleName);
    parameters.dob = payerReference.entityType == "contact" && payer.birthdate != undefined && payer.birthdate != null ? payer.birthdate.substring(0, 10) : null;
    parameters.email = payer.emailaddress1;
    parameters.mobile = payer.telephone1;
    parameters.applyingascompany = null;
    parameters.companyname = payerReference.entityType == "contact" ? (payerCompany != null ? payerCompany.name : null) : payer.name;
    parameters.currentstreet1 = payer.address1_line1;
    parameters.currenttown = townOrCity;
    parameters.ddnoofcollections = null; //payments.length; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddtotalamount = null;
    parameters.ddfirstamount = payments[0].rhs_amount;
    parameters.ddlastamount = null; //payments[payments.length - 1].rhs_amount; // commented to prevent DD to end (unless manually cancelled)
    parameters.ddplaninterval = 1;
    parameters.ddplantype = paymentFrequency == 120000002/*Monthly*/ ? "Monthly" : "Yearly";
    parameters.dddebtorreference = null;
    parameters.ddplanreference = transaction.rhs_transacid;
    parameters.ddplanaltreference = null;
    parameters.ddplanendbydate = null;
    parameters.ddprofilename = null;
    parameters.ptxprofilename = null;
    parameters.giftaid = null;
    parameters.ttl = null;
    parameters.expirationtimer = null;
    parameters.callbackurl = ptxCallbackURL;
    parameters.redirecturl = null;
    //#endregion

    for (let parameterName in parameters) {
        if (parameters[parameterName] != undefined && parameters[parameterName] != null) {
            if (ptxPaymentUrl.substring(ptxPaymentUrl.length - 1) != "?")
                ptxPaymentUrl += "&";
            ptxPaymentUrl += `${parameterName}=${parameters[parameterName]}`;
        }
    }

    Xrm.Navigation.openUrl(ptxPaymentUrl);

    // Confirm PTX payment
    let alertStrings = { title: "PTX Payment", text: "Have you finished PTX payment?", confirmButtonLabel: "Yes" };
    await Xrm.Navigation.openAlertDialog(alertStrings);

    let directDebitDetail = await RHSScripts.Donation.RetrieveDirectDebitDetail(parameters.ddplanreference);
    if (directDebitDetail == undefined || directDebitDetail == null) {
        // Delay 15 seconds and recheck again
        await RHSScripts.Donation.Delay(15000);
        directDebitDetail = await RHSScripts.Donation.RetrieveDirectDebitDetail(parameters.ddplanreference);

        if (directDebitDetail == undefined || directDebitDetail == null)
            throw Error("Stripe Transaction Failed");
    }
}

RHSScripts.Donation.ActivateDonation = async function (donationId, formContext, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    let paymentFrequency = null;
    if (formContext && typeof formContext.getAttribute === "function") {
        const attr = formContext.getAttribute("rhs_paymentfrequency");
        paymentFrequency = attr ? attr.getValue() : null;
    }

    record.rhs_paymentreceived = paymentSubmitted;
    record.rhs_issubmitpayment = paymentReceived;
    record.statuscode = (paymentFrequency === 120000002) ? 120000003 : 1;
    record.statecode = 0;



    await Xrm.WebApi.updateRecord("rhs_donation", donationId, record);
}
RHSScripts.Donation.RetrieveAppSettingValueByName = async function (name) {
    let appSettingValue = null;
    let entityLogicalName = "rhs_appsettings";
    let options = `?$select=rhs_name,rhs_value&$filter=(rhs_name eq '${name}' and statecode eq 0)`;

    let appSettings = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (appSettings != undefined && appSettings != null && appSettings.length > 0)
        appSettingValue = appSettings[0].rhs_value;

    return appSettingValue
}
RHSScripts.Donation.RetrieveActiveDonationPaymentSchedule = async function (donationId) {
    let paymentSchedule = null;
    let entityLogicalName = "rhs_paymentschedule";
    let options = `?$filter=_rhs_subscriptionid_value eq ${donationId}`;

    let paymentSchedules = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (paymentSchedules != undefined && paymentSchedules != null && paymentSchedules.length > 0)
        paymentSchedule = paymentSchedules[0];

    return paymentSchedule;
}
RHSScripts.Donation.RetrieveActiveDonationFirstPayment = async function (donationId) {
    let payments = await RHSScripts.Donation.RetrieveActiveDonationPayments(donationId);
    let firstPayment = payments ? payments[0] : null;
    return firstPayment;
}
RHSScripts.Donation.RetrieveActiveDonationPayments = async function (donationId) {
    let payments = null;
    let entityLogicalName = "rhs_payment";
    let options = "".concat(
        "?$select=rhs_paymentid,rhs_paymentsid,rhs_amount,rhs_duedate,statuscode,statecode",
        `&$filter=(rhs_Transaction/_rhs_donation_value eq ${donationId} and statecode eq 0)`,
        "&$orderby=rhs_duedate asc"
    );

    payments = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return payments;
}

RHSScripts.Donation.UpdatePaymentAsPaid = async function (paymentId) {
    await Xrm.WebApi.updateRecord("rhs_payment", paymentId, { "rhs_paidon": (new Date()).toISOString().substring(0, 10), "statecode": 1/*Inactive*/, "statuscode": 2/*Paid*/ });
}
RHSScripts.Donation.RetrieveDirectDebitDetail = async function (reference) {
    let directDebitDetail = null;
    let entityLogicalName = "rhs_directdebitdetails";
    let options = `?$filter=rhs_reference eq '${reference}'&$top=1`;

    let directDebitDetails = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (directDebitDetails != undefined && directDebitDetails != null && directDebitDetails.length > 0)
        directDebitDetail = directDebitDetails[0];

    return directDebitDetail;
}

RHSScripts.Donation.Delay = function (ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

RHSScripts.Donation.MakeCirrusPCIpaymentURL = async function (donationId, donor, totalAmount, formContext) {
    // Redirect to checkout url
    //Get Current User
    let userSettings = Xrm.Utility.getGlobalContext().userSettings;
    let currentUserId = userSettings.userId.replace("{", "").replace("}", "");
    let cirrusUserValue = await Xrm.WebApi.retrieveRecord("systemuser", currentUserId, "?$select=rhs_cirrususer");

    if (cirrusUserValue.rhs_cirrususer == undefined || cirrusUserValue.rhs_cirrususer == null) {
        await Xrm.Navigation.openAlertDialog({ title: "Failed", text: "The Cirrus User value on the User form cannot be empty. Please supply a value to be used to take payments via Cirrus." });
        throw Error("Cirrus User value is null. Please provide a username to continue.");
    }

    //Get CirrusKeyVaultURL
    let cirrusFunctionUrl = await RHSScripts.Donation.RetrieveAppSettingValueByName("CirrusKeyVaultURL");
    if (cirrusFunctionUrl == undefined || cirrusFunctionUrl == null)
        throw Error("cirrusFunctionUrl app setting not set for this environment. Please contact an administrator to fix this.");

    let finalURL = await RHSScripts.Donation.ExecuteRetrieveCirrusPaymentURL(cirrusFunctionUrl, donationId, donor, totalAmount, cirrusUserValue.rhs_cirrususer);

    console.log(finalURL);

    // Immediately show an informational alert on top
    var alertStrings = {
        text: "Please close the Cirrus dialog once payment is completed.",
        title: "Information"
    };
    var alertOptions = { height: 120, width: 260 };

    await Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);

    var pageInput = {
        pageType: "webresource",
        webresourceName: "rhs_cirruspcipayment?url=" + finalURL
    };
    var navigationOptions = {
        target: 2,
        width: 700, // value specified in pixel
        height: 800, // value specified in pixel
        position: 1,
        title: "Cirrus PCI Payment"
    };

    await Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function (returnValue) {
                // This function is executed when the dialog is closed
                console.log("Dialog closed. Return value:", returnValue);

            },
            function (error) {
                // This function is executed if the operation fails
                console.error(error);
            }
        );

    let intervalId = await RHSScripts.Donation.RetrieveIsPaymentReceived(formContext);
    if (!intervalId) {
        throw Error("Cirrus Transaction Failed");
    }
    // Confirm PTX payment
    //let alertStrings = { title: "Cirrus PCI Payment", text: "Have you finished CIrrus PCI payment?", confirmButtonLabel: "Yes" };
    //await Xrm.Navigation.openAlertDialog(alertStrings);

}

RHSScripts.Donation.ExecuteRetrieveCirrusPaymentURL = async function (functionUrlName, donationId, payer, totalAmount, CirrusUsername) {
    // Parameters
    var parameters = {};
    parameters.CirrusKeyVaultUrl = functionUrlName; // Edm.String
    parameters.EntityRecord = donationId; // Edm.Guid
    parameters.PayerRecord = payer.id; // Edm.Guid
    parameters.PayerEntity = payer.entityType; // Edm.String
    parameters.TotalAmount = totalAmount; // Edm.Decimal
    parameters.TransactionType = 120000000; // Donation
    parameters.CirrusUsername = CirrusUsername;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_cirruspaymenturl_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);
        // Return Type: mscrm.rhs_cirruspaymenturlResponse
        // Output Parameters
        let cirruspaymenturl = result["CirrusPaymentURL"]; // Edm.String

        return cirruspaymenturl;
    }).catch(function (error) {
        console.log(error.message);
    });
}

RHSScripts.Donation.RetrieveIsPaymentReceived = async function (formContext) {
    let recordId = formContext.data.entity.getId().replace("{", "").replace("}", "");
    let result = await Xrm.WebApi.retrieveRecord("rhs_donation", recordId, "?$select=statuscode,rhs_paymentreceived");
    if (result.statuscode == 1 /*Active Paid*/ && result.rhs_paymentreceived) {
        return true;
    }
    return false;
}

RHSScripts.Donation.CancelTransactionAndAssociatedRecords = async function (transaction) {
    let transactionId = transaction.rhs_transactionid;

    //Cancel Payments
    let payments = (await Xrm.WebApi.retrieveMultipleRecords("rhs_payment", `?$select=rhs_paymentid,_rhs_transaction_value&$filter=_rhs_transaction_value eq ${transactionId}`)).entities;
    for (let ctr = 0; ctr < payments.length; ctr++) {
        await Xrm.WebApi.updateRecord("rhs_payment", payments[ctr].rhs_paymentid, { statecode: 1/*Inactive*/, statuscode: 120000004/*Cancelled*/ });
    }

    //Cancel Payment Schedule
    let paymentScheduleId = transaction._rhs_paymentscheduletransaction_value;
    if (paymentScheduleId) {
        await Xrm.WebApi.updateRecord("rhs_paymentschedule", paymentScheduleId, { statecode: 1/*Inactive*/, statuscode: 120000003/*Cancelled*/ });
    }

    //Cancel Transaction
    await Xrm.WebApi.updateRecord("rhs_transaction", transactionId, { statecode: 1/*Inactive*/, statuscode: 2/*Cancelled*/ });
}
//#endregion