//RefundRequest Command Script
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.RefundRequest) === "undefined") { RHSScripts.RefundRequest = {}; }

//#region Command Functions
RHSScripts.RefundRequest.ApproveRejectRefundRequestFromView = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let gridContext = primaryControl;

    let pageInput = {
        pageType: "custom",
        name: "rhs_approverequestrefund_5489c",
        entityName: "rhs_refundrequest",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Approve Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};

RHSScripts.RefundRequest.ApproveRejectRefundRequestFromForm = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;

    let refundRequestId = primaryControl.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let pageInput = {
        pageType: "custom",
        name: "rhs_approverequestrefund_5489c",
        entityName: "rhs_refundrequest",
        recordId: refundRequestId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Approve Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};

RHSScripts.RefundRequest.MarkAsRefundedFromForm = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;

    let refundRequestLineId = primaryControl.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let pageInput = {
        pageType: "custom",
        name: "rhs_actionrequestrefund_bc483",
        entityName: "rhs_refundrequest",
        recordId: refundRequestLineId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Action Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.RefundRequest.ShowButtonForRHSMembershipTeamLeadsandManagers = function () {
    // Get the user's security roles
    var userRoles = Xrm.Utility.getGlobalContext().userSettings.roles.getAll();
    // Loop through the roles
    for (var i = 0; i < userRoles.length; i++) {
        // Check if the current role is 'RHS Membership Team Leads and Managers'
        if (userRoles[i].name.toLowerCase() === "rhs membership team leads and managers") {
            return true;
        }
    }
    // If the loop completes without a match, return false
    return false;
}
//#endregion