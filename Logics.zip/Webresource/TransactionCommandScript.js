//Transaction Command Script
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Transaction) === "undefined") { RHSScripts.Transaction = {}; }

//#region Command Functions
RHSScripts.Transaction.IssueRefundRequestFromView = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let gridContext = primaryControl;

    let pageInput = {
        pageType: "custom",
        name: "rhs_transactionrequestrefund_dfcf4",
        entityName: "rhs_transaction",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Transaction Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Transaction.RequestRefundFromForm = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;
    
    let transactionId = primaryControl.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let pageInput = {
        pageType: "custom",
        name: "rhs_transactionrequestrefund_dfcf4",
        entityName: "rhs_transaction",
        recordId: transactionId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Transaction Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Transaction.ReverseFromMainGrid = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let gridContext = primaryControl;

    let pageInput = {
        pageType: "custom",
        name: "rhs_transactionreversalpage_b6878",
        entityName: "rhs_transaction",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Reverse Transaction Page"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Transaction.ReverseFromForm = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;
    let transactionId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let pageInput = {
        pageType: "custom",
        name: "rhs_transactionreversalpage_b6878",
        entityName: "rhs_transaction",
        recordId: transactionId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Reverse Transaction Page"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            primaryControl.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Transaction.ShowButtonForRHSMembershipTeamLeadsandManagers = function () {
    // Get the user's security roles
    var userRoles = Xrm.Utility.getGlobalContext().userSettings.roles.getAll();
    // Loop through the roles
    for (var i = 0; i < userRoles.length; i++) {
        // Check if the current role is 'RHS Membership Team Leads and Managers'
        if (userRoles[i].name.toLowerCase() === "rhs membership team leads and managers") {
            return true;
        }
    }
    // If the loop completes without a match, return false
    return false;
}

//#endregion