if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.GiftPackOrder) === "undefined") { RHSScripts.GiftPackOrder = {}; }

const SUBMITTING_PAYMENT_NOTIFICATION_ID = "SubmittingPaymentNotification";
const GIFTPACKORDER_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID = "GiftPackOrderTransactionSuccessfulNotification";
const GIFTPACKORDER_TRANSACTION_FAILED_NOTIFICATION_ID = "GiftPackOrderTransactionFailedNotification";
const CIRRUS_PAYMENT_GIFTPACKORDER_NOTIFICATION = "CirrusPaymentNotification";

RHSScripts.GiftPackOrder.MakePaymentCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let giftPackOrderId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    try {
        //#region  Prepare the gift pack for payment submission          
        Xrm.Utility.showProgressIndicator("Submitting payment. Please wait...");
        formContext.ui.clearFormNotification(GIFTPACKORDER_TRANSACTION_FAILED_NOTIFICATION_ID);
        formContext.ui.clearFormNotification(GIFTPACKORDER_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Submitting payment. Please wait...", "WARNING", SUBMITTING_PAYMENT_NOTIFICATION_ID);
        //#endregion

        //#region  Generate transaction, payments and payment schedule for each of related Gift Packs
        let transaction = await RHSScripts.GiftPackOrder.RetrieveActiveGiftPackTransaction(giftPackOrderId);
        if (transaction == null) {
            let [transactionid, paymentid, payementscheduleid] = await RHSScripts.GiftPackOrder.ExecuteSubmitPaymentCustomAPIForGiftPack(formContext);

            if (transactionid == null && paymentid == null && payementscheduleid == null)
                throw new Error("Gift pack transaction failed.");
        }

        //#endregion

        //#region  Make/Submit Payment
        let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
        if (paymentMethod == 120000014/*Credit Card (Phone)*/) {
            await RHSScripts.GiftPackOrder.MakeCirrusPCIpaymentURL(giftPackOrderId, formContext);
            await formContext.data.refresh(true);
            //await RHSScripts.GiftPackOrder.ActivateGiftPackOrder(formContext); // May need to move this to integ side
            //await RHSScripts.GiftPackOrder.ActivateGiftPack(formContext, giftPackOrderId); // May need to move this to integ side
        }
        //#endregion

        //#region  Ending payment submission
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Gift Pack Order transaction successful.", "INFO", GIFTPACKORDER_TRANSACTION_SUCCESSFUL_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Success", text: "Payment successful." });

        //#endregion
    } catch (error) {
        Xrm.Utility.closeProgressIndicator();
        formContext.ui.clearFormNotification(SUBMITTING_PAYMENT_NOTIFICATION_ID);
        formContext.ui.setFormNotification("Gift pack Order transaction failed. Please try again", "ERROR", GIFTPACKORDER_TRANSACTION_FAILED_NOTIFICATION_ID);
        Xrm.Navigation.openAlertDialog({ title: "Failed", text: "Payment failed. \n\nDetails: " + error.message });
    }
}

RHSScripts.GiftPackOrder.RetrieveActiveGiftPackTransaction = async function (giftPackOrderId) {
    let transaction = null;
    let entityLogicalName = "rhs_transaction";
    let options = "".concat(
        "?$select=rhs_transactionid,rhs_transacid,_rhs_giftpackorder_value,rhs_amount,rhs_paidon,rhs_outstandingamount,statecode,statuscode",
        `&$filter=(_rhs_giftpackorder_value eq ${giftPackOrderId} and (statecode eq 0 or statuscode eq 120000008))`
    );

    let transactions = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (transactions != undefined && transactions != null && transactions.length > 0)
        transaction = transactions[0];

    return transaction;
}

RHSScripts.GiftPackOrder.ExecuteSubmitPaymentCustomAPIForGiftPack = async function (formContext) {
    // Fields
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let giftPackOrderId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let payer = formContext.getAttribute("rhs_purchasedby").getValue();
    let isContinuousPayment = false;
    let paymentFrequency = null;
    let totalAmount = formContext.getAttribute("rhs_totalprice_v2").getValue();
    let outstandingAmount = null;

    // Parameters
    let parameters = {};
    parameters.PaymentMethod = paymentMethod;
    parameters.RecordId = giftPackOrderId;
    parameters.PayerId = payer != null ? payer[0].id.replace("{", "").replace("}", "").toLowerCase() : null;
    parameters.IsContiniousPayment = isContinuousPayment;
    parameters.PaymentFrequency = paymentFrequency;
    parameters.TransactionType = 120000001/*Gift Pack*/;
    parameters.Type = 120000000/*Full Payment*/;
    parameters.PayerEntity = payer != null ? payer[0].entityType : null;
    parameters.TotalAmount = outstandingAmount != null ? outstandingAmount : totalAmount;
    parameters.OutstandingAmount = outstandingAmount;

    // Execute Custom API
    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_submitpayment_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);

        // Output Parameters
        let transactionid = result["TransactionId"];
        let paymentid = result["PaymentId"];
        let payementscheduleid = result["PayementScheduleId"];
        return [transactionid, paymentid, payementscheduleid]
    }).catch(function (error) {
        console.log(error.message);
        throw error;
    });
}

RHSScripts.GiftPackOrder.RetrieveActiveGiftPackOrderPayments = async function (giftPackOderId) {
    let payments = null;
    let entityLogicalName = "rhs_payment";
    let options = "".concat(
        "?$select=rhs_paymentid,rhs_paymentsid,rhs_amount,rhs_duedate,statuscode,statecode",
        `&$filter=(rhs_Transaction/_rhs_giftpackorder_value eq ${giftPackOderId} and statecode eq 0)`,
        "&$orderby=rhs_duedate asc"
    );

    payments = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;

    return payments;
}

RHSScripts.GiftPackOrder.UpdatePaymentAsPaid = async function (paymentId) {
    await Xrm.WebApi.updateRecord("rhs_payment", paymentId, { "rhs_paidon": (new Date()).toISOString().substring(0, 10), "statecode": 1/*Inactive*/, "statuscode": 2/*Paid*/ });
}

RHSScripts.GiftPackOrder.ActivateGiftPackOrder = async function (formContext, paymentSubmitted = true, paymentReceived = true) {
    let giftPackOrderId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 0;
    record.statuscode = 120000001;

    await Xrm.WebApi.updateRecord("rhs_giftpackorder", giftPackOrderId, record);
    await formContext.data.refresh();
}

RHSScripts.GiftPackOrder.ActivateGiftPack = async function (formContext, giftPackOrderId, paymentSubmitted = true, paymentReceived = true) {
    let record = {};
    record.rhs_ispaymentsubmitted = paymentSubmitted;
    record.rhs_ispaymentreceived = paymentReceived;
    record.statecode = 0;
    record.statuscode = 120000003;
    let entityLogicalName = "rhs_giftpack";
    let options = "".concat(
        "?$select=rhs_giftpackid,_rhs_giftpackorder_value",
        `&$filter=(_rhs_giftpackorder_value eq ${giftPackOrderId} and (statecode eq 0))`
    );

    let giftPacks = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    for (let giftPack of giftPacks) {
        let recordId = giftPack.rhs_giftpackid;
        await Xrm.WebApi.updateRecord("rhs_giftpack", recordId, record);
    }
    await formContext.data.refresh();
}

RHSScripts.GiftPackOrder.MakeCirrusPCIpaymentURL = async function (giftPackOrderId, formContext) {
    //Get Current User
    let userSettings = Xrm.Utility.getGlobalContext().userSettings;
    let currentUserId = userSettings.userId.replace("{", "").replace("}", "");
    let cirrusUserValue = await Xrm.WebApi.retrieveRecord("systemuser", currentUserId, "?$select=rhs_cirrususer");

    if (cirrusUserValue.rhs_cirrususer == undefined || cirrusUserValue.rhs_cirrususer == null) {
        await Xrm.Navigation.openAlertDialog({ title: "Failed", text: "The Cirrus User value on the User form cannot be empty. Please supply a value to be used to take payments via Cirrus." });
        throw Error("Cirrus User value is null. Please provide a username to continue.");
    }

    let payerReference = formContext.getAttribute("rhs_purchasedby").getValue()[0];
    let totalAmount = formContext.getAttribute("rhs_totalprice_v2").getValue();
    //Get CirrusKeyVaultURL
    let cirrusFunctionUrl = await RHSScripts.GiftPackOrder.RetrieveAppSettingValueByName("CirrusKeyVaultURL");
    if (cirrusFunctionUrl == undefined || cirrusFunctionUrl == null)
        throw Error("cirrusFunctionUrl app setting not set for this environment. Please contact an administrator to fix this.");
    let finalURL = await RHSScripts.GiftPackOrder.ExecuteRetrieveCirrusPaymentURL(cirrusFunctionUrl, giftPackOrderId, payerReference, totalAmount, cirrusUserValue.rhs_cirrususer);

    //Xrm.Navigation.openUrl(finalURL);

    console.log("rhs_cirruspcipayment?url=" + finalURL);

    // Immediately show an informational alert on top
    var alertStrings = {
        text: "Please close the Cirrus dialog once payment is completed.",
        title: "Information"
    };
    var alertOptions = { height: 120, width: 260 };

    await Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
    var pageInput = {
        pageType: "webresource",
        webresourceName: "rhs_cirruspcipayment?url=" + finalURL
    };
    var navigationOptions = {
        target: 2,
        width: 700, // value specified in pixel
        height: 800, // value specified in pixel
        position: 1,
        title: "Cirrus PCI Payment"
    };

    await Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(
            function (returnValue) {
                // This function is executed when the dialog is closed
                console.log("Dialog closed. Return value:", returnValue);

            },
            function (error) {
                // This function is executed if the operation fails
                console.error(error);
            }
        );


    let intervalId = await RHSScripts.GiftPackOrder.RetrieveIsPaymentReceived(formContext);
    if (!intervalId) {
        throw Error("Cirrus Transaction Failed");
    }

}

RHSScripts.GiftPackOrder.flattenObject = function (obj, prefix = '') {
    let result = {};
    for (let key in obj) {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            Object.assign(result, RHSScripts.GiftPackOrder.flattenObject(obj[key], `${prefix}${key}.`));
        } else {
            result[`${prefix}${key}`] = obj[key];
        }
    }
    return result;
}

RHSScripts.GiftPackOrder.ExecuteRetrieveCirrusSecretCustomAPI = async function (functionUrlName) {
    // Parameters
    let parameters = {};
    parameters.CirrusKeyVaultUrl = functionUrlName;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_keyvaultaccess", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);
        // Return Type: mscrm.rhs_keyvaultaccessResponse
        // Output Parameters
        let cirrususrkey = result["CirrusUsrKey"]; // Edm.String
        let cirruspwdkey = result["CirrusPwdKey"]; // Edm.String
        let cirrusbaseurlkey = result["CirrusBaseUrlKey"]; // Edm.String
        return [cirrusbaseurlkey, cirrususrkey, cirruspwdkey];
    }).catch(function (error) {
        console.log(error.message);
    });
}

RHSScripts.GiftPackOrder.RetrieveAppSettingValueByName = async function (name) {
    let appSettingValue = null;
    let entityLogicalName = "rhs_appsettings";
    let options = `?$select=rhs_name,rhs_value&$filter=(rhs_name eq '${name}' and statecode eq 0)`;

    let appSettings = (await Xrm.WebApi.retrieveMultipleRecords(entityLogicalName, options)).entities;
    if (appSettings != undefined && appSettings != null && appSettings.length > 0)
        appSettingValue = appSettings[0].rhs_value;

    return appSettingValue
}

RHSScripts.GiftPackOrder.ExecuteRetrieveCirrusPaymentURL = async function (functionUrlName, giftPackOrderId, payer, totalAmount, CirrusUsername) {
    // Parameters
    var parameters = {};
    parameters.CirrusKeyVaultUrl = functionUrlName; // Edm.String
    parameters.EntityRecord = giftPackOrderId; // Edm.Guid
    parameters.PayerRecord = payer.id; // Edm.Guid
    parameters.PayerEntity = payer.entityType; // Edm.String
    parameters.TotalAmount = totalAmount; // Edm.Decimal
    parameters.TransactionType = 120000001; // Gift Pack
    parameters.CirrusUsername = CirrusUsername;

    return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_cirruspaymenturl_new", {
        method: "POST",
        headers: {
            "OData-MaxVersion": "4.0",
            "OData-Version": "4.0",
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json"
        },
        body: JSON.stringify(parameters)
    }).then(
        function success(response) {
            return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
        }
    ).then(function (responseObjects) {
        let response = responseObjects[0];
        let responseBody = responseObjects[1];
        let result = responseBody;
        console.log(result);
        // Return Type: mscrm.rhs_cirruspaymenturlResponse
        // Output Parameters
        let cirruspaymenturl = result["CirrusPaymentURL"]; // Edm.String

        return cirruspaymenturl;
    }).catch(function (error) {
        console.log(error.message);
    });
}

RHSScripts.GiftPackOrder.RetrieveIsPaymentReceived = async function (formContext) {
    let recordId = formContext.data.entity.getId().replace("{", "").replace("}", "");
    let result = await Xrm.WebApi.retrieveRecord("rhs_giftpackorder", recordId, "?$select=statuscode,rhs_ispaymentreceived");
    if (result.statuscode == 120000001 && result.rhs_ispaymentreceived) {
        return true;
    }
    return false;
}

RHSScripts.GiftPackOrder.AgentScriptsCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_membershipagentscripts_dcfe6";
    let pageInput = {
        pageType: "custom",
        name: customPageName
    };

    let paneOptions = {
        title: "Agent Scripts",
        paneId: "AgentScripts",
        canClose: true,
        width: 500
    };

    Xrm.App.sidePanes.createPane(paneOptions).then((pane) => {
        pane.navigate(pageInput);
    })
}