//Donation Form Source Code
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Donation) === "undefined") { RHSScripts.Donation = {}; }

let paymentOptions = [];

//#region Event Functions
RHSScripts.Donation.OnLoad = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    paymentOptions = formContext.getControl("rhs_paymentmethodcode").getOptions();

    RHSScripts.Donation.ShowGiftAidButton(executionContext);
    RHSScripts.Donation.FilterPaymentMethods(executionContext);

}

RHSScripts.Donation.OnSave = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();

}

RHSScripts.Donation.ShowGiftAidButton = function (executionContext) {
    'use strict';


    let formContext = executionContext.getFormContext();
    let fieldName = "rhs_registerforgiftaid";
    let fieldControl = formContext.getControl(fieldName);

    if (fieldControl) {
        fieldControl.setVisible(false);
    }

    // Get required field values
    let anonymous = formContext.getAttribute("rhs_anonymous")?.getValue();
    let donationType = formContext.getAttribute("rhs_donationtype")?.getValue();
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodcode")?.getValue();
    let donor = formContext.getAttribute("rhs_donor")?.getValue();

    let donationTypeId = donationType?.[0]?.id?.replace(/[{}]/g, '');
    let donorId = donor?.[0]?.id?.replace(/[{}]/g, '');
    let donorType = donor?.[0]?.entityType;

    // Validate required info
    let isCardOrDD = paymentMethod === 120000002 || paymentMethod === 844060002 || paymentMethod === 120000014;
    let isNotAnonymous = anonymous !== true;
    let isContact = donorType === "contact";

    if (!donationTypeId || !donorId || !isCardOrDD || !isNotAnonymous || !isContact) {
        console.log("Conditions not met - skipping Gift Aid field.");
        return;
    }

    try {
        // Check if the donation type is Gift Aid eligible
        let donationTypeRecord = Xrm.WebApi.retrieveRecord("rhs_donationtype", donationTypeId, "?$select=rhs_giftaideligible");
        let isGiftAidEligible = donationTypeRecord?.rhs_giftaideligible;

        if (!isGiftAidEligible) {
            console.log("Donation type is not Gift Aid eligible.");
            return;
        }

        // Check if the contact has an active gift aid declaration
        let contactRecord = Xrm.WebApi.retrieveRecord("contact", donorId, "?$select=rhs_activegiftaiddeclaration");
        let hasActiveDeclaration = contactRecord?.rhs_activegiftaiddeclaration;

        // Final combined condition check
        if (isGiftAidEligible && !hasActiveDeclaration && isNotAnonymous && isCardOrDD && isContact) {
            fieldControl.setVisible(true);
        }

    } catch (error) {
        console.error("Error in ShowGiftAidButton:", error.message);
    }
}

RHSScripts.Donation.onChangeRegisterForGiftAid = function (executionContext) {
    let formContext = executionContext.getFormContext();

    let isRegisterForGiftAid = formContext.getAttribute("rhs_registerforgiftaid").getValue();
    if (isRegisterForGiftAid == true) {
        Xrm.Navigation.openAlertDialog({ text: "To create a new Gift Aid Declaration for the Donor, please use the Add Gift Aid button in the ribbon. Here, you will also be able to view any existing declarations for this Contact." });
    }
}
RHSScripts.Donation.onChangeChannel = function (executionContext) {
    'use strict';
    let formContext = executionContext.getFormContext();

    RHSScripts.Donation.FilterPaymentMethods(executionContext);

}

RHSScripts.Donation.FilterPaymentMethods = function (executionContext) {
    'use strict';
    var formContext = executionContext.getFormContext();
    let fieldControl = formContext.getControl("rhs_paymentmethodcode");
    let paymentMethodValue = formContext.getAttribute("rhs_paymentmethodcode").getValue();
    let channel = formContext.getAttribute("rhs_channel").getValue();
    let allowedValues = [/*{ text: "Card", value: 844060002 }, */ { text: "Direct Debit", value: 120000002 }, { text: "Credit Card (Phone)", value: 120000014 }];
    let statusReason = formContext.getAttribute("statuscode").getValue();
    let createdFromTPD = formContext.getAttribute("rhs_createdfromthirdpartydonation")?.getValue() ?? false;
    if (channel != null && channel == 120000001 && !createdFromTPD) //Phone
    {
        //add allowed options only
        fieldControl.clearOptions();
        allowedValues.forEach(function (option) {
            fieldControl.addOption(option);
        });
    } else {
        //add back all options
        fieldControl.clearOptions();
        paymentOptions.forEach(function (option) {
            fieldControl.addOption(option);
        });
    }

    //Remove Card Payment Option
    fieldControl.removeOption(844060002);

    // Return selected payment method if removed from filter
    if (paymentMethodValue && !fieldControl.getOptions().find((option) => option.value == paymentMethodValue)) {
        if (statusReason == 1/*Active - Paid*/ || statusReason == 120000003/*Active - Ongoing*/) {
            fieldControl.addOption(
                formContext.getAttribute("rhs_paymentmethodcode").getOptions().find((option) => option.value == paymentMethodValue)
            )
        } else {
            formContext.getAttribute("rhs_paymentmethodcode").setValue(null);
        }
    }
}

RHSScripts.Donation.DisplayOnScreenMessage = function (executionContext) {

    'use strict';
    let formContext = executionContext.getFormContext();
    let isRecognized = formContext.getAttribute("rhs_isrecognition").getValue();

    if (isRecognized == true) {
        Xrm.Navigation.openAlertDialog({ text: "Please be advised that the Donor has realised an Incentive, and a Recognition record has been created. Please navigate to this Recognition to enter the text and other details." });
    }
}