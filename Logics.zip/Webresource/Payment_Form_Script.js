if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Payment) === "undefined") { RHSScripts.Payment = {}; }

// RHSScripts.Payment.OnSave = async function (executionContext) {
//     'use strict';
//     var formContext = executionContext.getFormContext();
//     let paymentId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

//     //Payment Refund
//     try{
//         let type = formContext.getAttribute("rhs_type").getValue();
//         let paymentMethod = formContext.getAttribute("rhs_paymentmethod").getValue();
//         let createdOn = formContext.getAttribute("createdon").getValue();
    
//         if (type == 120000002/*Refund*/ && paymentMethod == 844060002/*Card*/ && (createdOn == undefined || createdOn == null)) {
//             // Retrieve transaction and gift pack
//             let transactionId = formContext.getAttribute("rhs_transaction").getValue()[0].id.replace("{", "").replace("}", "").toLowerCase();
//             let transaction = await Xrm.WebApi.retrieveRecord("rhs_transaction", transactionId, "?$select=rhs_amount,_rhs_giftpackid_value");
//             let giftPack = await Xrm.WebApi.retrieveRecord("rhs_giftpack", transaction._rhs_giftpackid_value, "?$select=rhs_paymentintentid");

//             // Trigger stripe integration
//             let paymentIntentId = giftPack.rhs_paymentintentid;
//             let refundId = await RHSScripts.Payment.ExecuteStripeRefund(paymentIntentId);
//             if (refundId != undefined && refundId != null)
//                 formContext.getAttribute("rhs_refundid").setValue(refundId);

//             // Deduct transaction amount w/ refund
//             let paymentRefundAmount = formContext.getAttribute("rhs_amount").getValue();
//             let refundedAmount = transaction.rhs_amount - paymentRefundAmount;
//             await Xrm.WebApi.updateRecord("rhs_transaction", transactionId, { "rhs_amount": refundedAmount });

//             //Set refund payment status as paid (inactive staus won't work on-create)
//             /*formContext.getAttribute("statecode").setValue(1);
//             formContext.getAttribute("statuscode").setValue(2);*/
//         }
//     } catch(error) {
//         formContext.ui.setFormNotification("Payment refund failed.", "ERROR");
//     }
// }

// RHSScripts.Payment.ExecuteStripeRefund = async function (intentId) {
//     // Parameters
//     var parameters = {};
//     parameters.rhs_stripePaymentIntentId = intentId;

//     return await fetch(Xrm.Utility.getGlobalContext().getClientUrl() + "/api/data/v9.2/rhs_stripeRefund", {
//         method: "POST",
//         headers: {
//             "OData-MaxVersion": "4.0",
//             "OData-Version": "4.0",
//             "Content-Type": "application/json; charset=utf-8",
//             "Accept": "application/json"
//         },
//         body: JSON.stringify(parameters)
//     }).then(
//         function success(response) {
//             return response.json().then((json) => { if (response.ok) { return [response, json]; } else { throw json.error; } });
//         }
//     ).then(function (responseObjects) {
//         var response = responseObjects[0];
//         var responseBody = responseObjects[1];
//         var result = responseBody;
//         console.log(result);
        
//         // Output Parameters
//         let stripeRefundResponse = JSON.parse(result.rhs_stripeRefundResponse);
//         // if (stripeRefundResponse.refundId == undefined || stripeRefundResponse.refundId == null)
//         //     throw Error("Stripe Refund Failed.");
//         return stripeRefundResponse.refundId;
//     }).catch(function (error) {
//         console.log(error.message);
//         throw error;
//     });
// }