if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.BatchOrder) === "undefined") { RHSScripts.BatchOrder = {}; }

let awaitingPromptResponse = false;

//#region Form Functions
RHSScripts.BatchOrder.OnSave = async function(executionContext) {
    let formContext = executionContext.getFormContext();

    let createdOn = formContext.getAttribute("createdon").getValue()
    if (createdOn) {
        await RHSScripts.BatchOrder.PromtNotificationOnDraftToProcessed(formContext);
    }
}
//#endregion

//#region Helper Functions
RHSScripts.BatchOrder.PromtNotificationOnDraftToProcessed = async function(formContext) {
    let batchOrderId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let batchOrder = await Xrm.WebApi.retrieveRecord("rhs_batchorder", batchOrderId);
    
    let preImageStatusReason = batchOrder.statuscode;
    let postImageStatusReason = formContext.getAttribute("statuscode").getValue();

    if (preImageStatusReason == 1/*Draft*/ && postImageStatusReason == 120000001/*Processed*/ && !awaitingPromptResponse) {
        let batchOrderLines = (await Xrm.WebApi.retrieveMultipleRecords("rhs_batchorderline", `?$filter=_rhs_batchorder_value eq ${batchOrderId}`)).entities;
        let [count, matchCount, mismatchCount] = await RHSScripts.BatchOrder.CompareBatchOrderWithBatchOrderLines(batchOrder, batchOrderLines);

        let confirmStrings = { "confirmButtonLabel": "Yes", "cancelButtonLabel": "No" };
        if (matchCount == count) {
            confirmStrings["title"] = "Success";
            confirmStrings["text"] = "".concat(
                "Number of Transactions matches the number specified in the batch.",
                "\n\n",
                "Transaction Total matches the total specified in the batch.",
                "\n\n",
                "Do you want to add more entries?"
            );
        } else {
            confirmStrings["title"] = "Mismatch";
            confirmStrings["text"] = "".concat(
                `${mismatchCount} transaction${mismatchCount > 1 ? "s" : ""} mismatch${mismatchCount > 1 ? "" : "es"} with the batch.`,
                "\n\n",
                "Do you want to add more entries?"
            );
        }

        formContext.getAttribute("statuscode").setValue(1/*Draft*/);
        awaitingPromptResponse = true;
        Xrm.Navigation.openConfirmDialog(confirmStrings).then( // made this asynchronous so that it won't prompt an error when the user does not respond fast enough
            async function (response) {    
                if (response?.confirmed == true) {
                    formContext.getAttribute("statuscode").setValue(1/*Draft*/);

                    let entityFormOptions = { entityName: "rhs_batchorderline" };
                    let formParameters = { 
                        rhs_batchorder: formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase(), 
                        rhs_batchordername: formContext.getAttribute("rhs_name").getValue(), 
                        rhs_batchordertype: "rhs_batchorder"
                    }
                    Xrm.Navigation.openForm(entityFormOptions, formParameters);
                } else if (response.confirmed == false) {
                    formContext.getAttribute("statuscode").setValue(120000001/*Processed*/);
                } else {
                    formContext.getAttribute("statuscode").setValue(1/*Draft*/);
                }

                await formContext.data.save();
                awaitingPromptResponse = false;
            }
        );
    }
}

RHSScripts.BatchOrder.CompareBatchOrderWithBatchOrderLines = async function(batchOrder, batchOrderLines) {

    let count = batchOrderLines.length, matchCount = null, mismatchCount = null;
    if (batchOrder.rhs_type = 120000000/*New Membership*/) {
        matchCount = batchOrderLines.filter(batchOrderLine =>
            batchOrderLine.rhs_totalamount == batchOrder.rhs_totalamount &&
            batchOrderLine.rhs_paymentmethodcode == batchOrder.rhs_paymentmethodcode &&
            batchOrderLine._rhs_thirdpartypaymenttype_value == batchOrder._rhs_thirdpartypaymenttype_value &&
            batchOrderLine._rhs_pricelist_value == batchOrder._rhs_pricelist_value &&
            batchOrderLine.rhs_channelsource == batchOrder.rhs_channelsource &&
            batchOrderLine._rhs_location_value == batchOrder._rhs_location_value &&
            batchOrderLine._rhs_campaign_value == batchOrder._rhs_campaigncode_value &&
            batchOrderLine._rhs_membershipproduct_value == batchOrder._rhs_membershipproduct_value
        ).length;

        mismatchCount = count - matchCount;

        // mismatchCount = batchOrderLines.filter(batchOrderLine =>
        //     batchOrderLine.rhs_totalamount != batchOrder.rhs_totalamount ||
        //     batchOrderLine.rhs_paymentmethod != batchOrder.rhs_paymentmethod ||
        //     batchOrderLine._rhs_thirdpartypaymenttype_value != batchOrder._rhs_thirdpartypaymenttype_value ||
        //     batchOrderLine._rhs_pricelist_value != batchOrder._rhs_pricelist_value ||
        //     batchOrderLine.rhs_channelsource != batchOrder.rhs_channelsource ||
        //     batchOrderLine._rhs_location_value != batchOrder._rhs_location_value ||
        //     batchOrderLine._rhs_campaign_value != batchOrder._rhs_campaigncode_value ||
        //     batchOrderLine._rhs_membershipproduct_value != batchOrder._rhs_membershipproduct_value
        // ).length;
    }

    return [count, matchCount, mismatchCount];
}
//#endregion