/*You can use setGiftPackOnCampaignCodeChange function both on campaign code change and product change*/
async function setGiftPackOnCampaignCodeChange(formExecutionContext) {
    let formContext = formExecutionContext.getFormContext();

    let giftPackCampaignLogicalName = "rhs_campaignid";
    let giftPackCampaignValue = formContext.getAttribute(giftPackCampaignLogicalName).getValue();

    if(giftPackCampaignValue != undefined && giftPackCampaignValue != null)
    {
        let campaignId = giftPackCampaignValue[0]["id"].replace("{", "").replace("}", "").toLowerCase();
        let campaign = await retrieveCampaignUsingId(campaignId);

        if (await validateGiftPackCampaignCode(formContext, campaign)) {
            // await setGiftPackUsingCampaignCode(formContext, campaign); // similar logic already occurs on plugin
            formContext.getControl(giftPackCampaignLogicalName).clearNotification();
        }
    } else {
        // await resetGiftPack(formContext);
        formContext.getControl(giftPackCampaignLogicalName).clearNotification();
    }
}

async function retrieveCampaignUsingId(campaignId) {
    let campaignLogicalName = "campaign";
    let campaignOptions = "?$select=campaignid,codename,_rhs_productid_value,_pricelistid_value";

    return await Xrm.WebApi.retrieveRecord(campaignLogicalName, campaignId, campaignOptions).then(
        function success(result) {
            let campaign = result;
            return campaign;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function retrieveCampaignUsingCampaignCode(campaignCode) {
    let campaignLogicalName = "campaign";
    let campaignOptions = "".concat(
        "?$select=codename,_rhs_productid_value,_pricelistid_value",
        `&$filter=(codename eq '${campaignCode}')`,
        "&$top=1"
    )

    return await Xrm.WebApi.retrieveMultipleRecords(campaignLogicalName, campaignOptions).then(
        function success(result) {
            let campaign = result.entities[0];
            return campaign;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function retrievePriceListItem(productId, priceListId) {
    let priceListItemLogicalName = "productpricelevel";
    let priceListItemOptions = "".concat(
        "?$select=_productid_value,productpricelevelid,amount",
        `&$filter=(_productid_value eq ${productId} and _pricelevelid_value eq ${priceListId})`,
        "&$top=1"
    )

    return await Xrm.WebApi.retrieveMultipleRecords(priceListItemLogicalName, priceListItemOptions).then(
        function success(result) {
            let priceListItem = result.entities[0];
            return priceListItem;
        },
        function (error) {
            console.log(error.message);
        }
    );
}

async function retrieveCampaignProductIds(campaignId) {
    let fetchXML = "?fetchXml=".concat(
        `<fetch>`,
            `<entity name='product'>`,
                `<attribute name='productid' />`,
                `<link-entity name='campaignitem' from='entityid' to='productid' intersect='true'>`,
                `<filter>`,
                    `<condition attribute='campaignid' operator='eq' value='${campaignId}' />`,
                `</filter>`,
                `</link-entity>`,
            `</entity>`,
        `</fetch>`
    )

    let campaignProducts = (await Xrm.WebApi.retrieveMultipleRecords("product", fetchXML)).entities;
    let campaignProductIds = campaignProducts.map(product => product.productid);
    return campaignProductIds;
}

async function validateGiftPackCampaignCode(formContext, campaign) {
    let giftPackCampaignLogicalName = "rhs_campaignid";
    let errorMessage;

    //Validate if a campaign is selected for the membership
    if (campaign == undefined || campaign == null)
        {
            errorMessage = "Invalid Campaign Code, please enter the correct one.";
            
            formContext.getControl(giftPackCampaignLogicalName).setNotification(errorMessage);
            //Xrm.Navigation.openAlertDialog(errorMessage);
            
            return false;
        }

    //Validate if a product is selected for the membership
    let giftPackProductLogicalName = "rhs_product";
    let giftPackProductValue = formContext.getAttribute(giftPackProductLogicalName).getValue();

    if (giftPackProductValue == undefined || giftPackProductValue == null) {
        errorMessage = "Invalid Campaign Code, please enter the correct one. Campaign product does not match gift pack product.";
        
        formContext.getControl(giftPackCampaignLogicalName).setNotification(errorMessage);
        //Xrm.Navigation.openAlertDialog(errorMessage);

        return false;
    }

    //Validate if campaign product is same as the gift pack product
    let giftPackProductId = giftPackProductValue[0]["id"].replace("{", "").replace("}", "").toLowerCase();
    let campaignId = campaign["campaignid"];
    let campaignProductIds = await retrieveCampaignProductIds(campaignId);

    if (!campaignProductIds.includes(giftPackProductId)) { // rework
        errorMessage = "Invalid Campaign Code, please enter the correct one. Campaign product does not match gift pack product.";
        
        formContext.getControl(giftPackCampaignLogicalName).setNotification(errorMessage);
        //Xrm.Navigation.openAlertDialog(errorMessage);
        
        return false;
    }

    //Validate if campaign contains a price for the product
    let campaignPriceListValueLogicalName = "_pricelistid_value";
    let campaignPriceListValue = campaign[campaignPriceListValueLogicalName];

    let priceListItem = await retrievePriceListItem(giftPackProductId, campaignPriceListValue);

    if (priceListItem == undefined || priceListItem == null) {
        errorMessage = "Invalid Campaign Code, please enter the correct one. Campaign does not contain a price for the product.";
        
        formContext.getControl(giftPackCampaignLogicalName).setNotification(errorMessage);
        //Xrm.Navigation.openAlertDialog(errorMessage);
        
        return false;
    }

    //Return true if the campaign passes all validations
    return true;
}

async function setGiftPackUsingCampaignCode(formContext, campaign) {
    let giftPackCampaignLogicalName = "rhs_campaignid";
    let giftPackTotalPriceLogicalName = "rhs_totalprice";
    let giftPackProductLogicalName = "rhs_product";
    let campaignPriceListValueLogicalName = "_pricelistid_value";
    let priceListItemAmountLogicalName = "amount";

    let giftPackProductValue = formContext.getAttribute(giftPackProductLogicalName).getValue();
    let giftPackProductId = giftPackProductValue[0]["id"].replace("{", "").replace("}", "").toLowerCase();
    let campaignPriceListId = campaign[campaignPriceListValueLogicalName];

    let priceListItem = await retrievePriceListItem(giftPackProductId, campaignPriceListId);
    let priceListItemAmount = priceListItem[priceListItemAmountLogicalName];

    let giftPackTotalPriceValue = priceListItemAmount;

    formContext.getAttribute(giftPackTotalPriceLogicalName).setValue(giftPackTotalPriceValue);
    // formContext.getControl(giftPackCampaignLogicalName).clearNotification();
}

async function resetGiftPack(formContext) {
    let giftPackCampaignLogicalName = "rhs_campaignid";
    let giftPackTotalPriceLogicalName = "rhs_totalprice";

    // formContext.getControl(giftPackCampaignLogicalName).clearNotification();
    formContext.getAttribute(giftPackTotalPriceLogicalName).setValue(null);
}