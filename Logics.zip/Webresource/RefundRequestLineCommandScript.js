//RefundRequestLine Command Script
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.RefundRequestLine) === "undefined") { RHSScripts.RefundRequestLine = {}; }

//#region Command Functions
RHSScripts.RefundRequestLine.MarkAsRefundedFromMainForm = async function (primaryControl) {
    'use strict';
    debugger;

    let formContext = primaryControl;

    let refundRequestLineId = primaryControl.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let pageInput = {
        pageType: "custom",
        name: "rhs_actionrequestrefund_bc483",
        entityName: "rhs_refundrequestline",
        recordId: refundRequestLineId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Action Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};

RHSScripts.RefundRequestLine.MarkAsRefundedFromMainGrid = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let gridContext = primaryControl;

    let pageInput = {
        pageType: "custom",
        name: "rhs_actionrequestrefund_bc483",
        entityName: "rhs_refundrequestline",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Action Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};

RHSScripts.RefundRequestLine.MarkAsRefundedFromSubGrid = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let formContext = primaryControl;

    let pageInput = {
        pageType: "custom",
        name: "rhs_actionrequestrefund_bc483",
        entityName: "rhs_refundrequestline",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Action Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            formContext.data.refresh();
        }
    ).catch (
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
};
//#endregion