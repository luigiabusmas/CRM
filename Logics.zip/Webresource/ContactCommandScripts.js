if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Contact) === "undefined") { RHSScripts.Contact = {}; }

/*RHSScripts.Contact.ConsentsCommand = function (primaryControl) {
    'use strict';

    var formContext = primaryControl;
    var entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    var customPageName = "rhs_contactpointconsentspage_0516f";  
    var pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "contact",
        recordId: entityId
    };

    var navigationOptions = {
        target: 1,
        position: 1
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(function () {
            console.log("Custom page opened successfully in the workspace.");
        })
        .catch(function (error) {
            console.error("Error navigating to the custom page:", error.message);
        });
}*/


RHSScripts.Contact.GiftAidDeclarationCommand = function (primaryControl) {
    'use strict';

    var formContext = primaryControl;
    var postCode = formContext.getAttribute("address1_postalcode")?.getValue();
    var city = formContext.getAttribute("address1_city")?.getValue();
    var addressLine1 = formContext.getAttribute("address1_line1")?.getValue();
    var houseName = formContext.getAttribute("rhs_loqatehomeaddresshousename")?.getValue();
    var country = formContext.getAttribute("address1_country")?.getValue();
    var normalCountry = country ? country.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\W_-]+/g, '') : '';
    var isUK = normalCountry === 'unitedkingdom' || normalCountry === 'uk';
    var normalCountry = country ? country.replace(/\s+/g, ' ').replace(/[^\w\s]/g, '').toLowerCase():'';

    if (normalCountry && isUK) {
        if (!postCode || !city || !(addressLine1 || houseName)) {
            var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Contact does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
            var alertOptions = { height: 240, width: 590 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }
    } else if (!normalCountry) {
        var alertStrings = { text: "You are unable to proceed with a Gift Aid Declaration as this Contact does not have Home Address details. \n\nPlease add a Home Address and try again.", title: "Action Required" };
        var alertOptions = { height: 240, width: 590 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
        return;
    }
    var entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    var customPageName = "rhs_newgiftaiddeclaration_fff4a";
    var pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "contact",
        recordId: entityId
    };

    var navigationOptions = {
        target: 1,
        position: 1
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions)
        .then(function () {
            console.log("Custom page opened successfully in the workspace.");
        })
        .catch(function (error) {
            console.error("Error navigating to the custom page:", error.message);
        });

}
//===== OLD SCRIPT ======//
// RHSScripts.Contact.GiftAidDeclarationCommand = function (primaryControl) {
//     'use strict';

//     var formContext = primaryControl;
//     var entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
//     var customPageName = "rhs_giftaiddeclaration_56d67";
//     var pageInput = {
//         pageType: "custom",
//         name: customPageName,
//         entityName: "contact",
//         recordId: entityId
//     };

//     var navigationOptions = {
//         target: 1,
//         position: 1
//     };

//     Xrm.Navigation.navigateTo(pageInput, navigationOptions)
//         .then(function () {
//             console.log("Custom page opened successfully in the workspace.");
//         })
//         .catch(function (error) {
//             console.error("Error navigating to the custom page:", error.message);
//         });
// }
//===== OLD SCRIPT ======//

RHSScripts.Contact.AgentScriptsCommand = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;

    let customPageName = "rhs_membershipagentscripts_dcfe6";
    let pageInput = {
        pageType: "custom",
        name: customPageName
    };

    let paneOptions = {
        title: "Agent Scripts",
        paneId: "AgentScripts",
        canClose: true,
        width: 500
    };

    Xrm.App.sidePanes.createPane(paneOptions).then((pane) => {
        pane.navigate(pageInput);
    })
}