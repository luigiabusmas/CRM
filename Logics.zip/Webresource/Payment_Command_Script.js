//Payment Command Script
if (typeof (RHSScripts) === "undefined") { RHSScripts = {}; }
if (typeof (RHSScripts.Payment) === "undefined") { RHSScripts.Payment = {}; }

//#region Command Functions
RHSScripts.Payment.Refund = function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    let paymentId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
    let totalAmount = formContext.getAttribute("rhs_amount").getValue();
    let paymentMethod = formContext.getAttribute("rhs_paymentmethodtype").getValue();
    let payer = formContext.getAttribute("rhs_payer").getValue();
    let paymentType = formContext.getAttribute("rhs_paymenttype").getValue();
    let paymentSchedule = formContext.getAttribute("rhs_paymentschedule").getValue();
    let giftAidEligibility = formContext.getAttribute("rhs_giftaideligibility").getValue();
    let giftAidClaimAmount = formContext.getAttribute("rhs_giftaidclaimamount").getValue();
    let transaction = formContext.getAttribute("rhs_transaction").getValue();

    // Build the parameters for the new form
    let parameters = {};

    let originalPaymentLookup = [];
    originalPaymentLookup[0] = {};
    originalPaymentLookup[0].id = paymentId;
    //originalPaymentLookup[0].name = null;
    originalPaymentLookup[0].entityType = "rhs_payment";

    let payerLookup = [];
    if (payer) {
        payerLookup[0] = {};
        payerLookup[0].id = payer[0].id;
        payerLookup[0].name = payer[0].name;
        payerLookup[0].entityType = payer[0].entityType;
    }

    let transactionLookup = [];
    if (transaction) {
        transactionLookup[0] = {};
        transactionLookup[0].id = transaction[0].id;
        transactionLookup[0].name = transaction[0].name;
        transactionLookup[0].entityType = transaction[0].entityType;
    }
    let paymentScheduleLookup = [];
    if (paymentSchedule) {
        paymentScheduleLookup[0] = {};
        paymentScheduleLookup[0].id = paymentSchedule[0].id;
        paymentScheduleLookup[0].name = paymentSchedule[0].name;
        paymentScheduleLookup[0].entityType = paymentSchedule[0].entityType;
    }

    // Pre-fill the fields in the new membership form
    parameters["rhs_refund"] = true;
    parameters["rhs_refundoriginalpayment"] = originalPaymentLookup;
    parameters["rhs_payer"] = payerLookup;
    parameters["rhs_transaction"] = transactionLookup;
    parameters["rhs_paymentschedule"] = paymentScheduleLookup;
    parameters["rhs_amount"] = totalAmount;
    parameters["rhs_paymentmethodtype"] = paymentMethod;
    parameters["rhs_paymenttype"] = paymentType;
    parameters["rhs_type"] = 120000000/*Full Payment*/;
    parameters["rhs_paidon"] = new Date();
    parameters["rhs_duedate"] = new Date();
    parameters["rhs_exporttofinance"] = false;
    parameters["rhs_giftaideligibility"] = giftAidEligibility;
    parameters["rhs_giftaidclaimamount"] = giftAidClaimAmount;
    parameters["statecode"] = 0;
    parameters["statuscode"] = 1;

    //if payment type is GIFT PACK
    if (paymentType === 120000001) {
        var alertStrings = { confirmButtonLabel: "Yes", text: "The Associated Gift Pack will be cancelled and Refund will be initiated.", title: "" };
        var alertOptions = { height: 100, width: 300 };
        Xrm.Navigation.openConfirmDialog(alertStrings, alertOptions).then(
            async function (success) {
                if (success.confirmed) {
                    // This means the user clicked "Yes"
                    try {
                        // Your code functionality for success
                        var transactionId = transactionLookup[0].id.replace("{", "").replace("}", "").toLowerCase();
                        console.log(transactionId);
                        //Retrieve Gift Pack associated to the Transaction
                        Xrm.WebApi.retrieveRecord("rhs_transaction", transactionId, "?$select=_rhs_giftpackid_value").then(
                            function success(result) {
                                var giftPackId = result._rhs_giftpackid_value;
                                //Update Gift Pack Statuscode value to Cancelled
                                var entityLogicalName = "rhs_giftpack";
                                var giftPackGuid = giftPackId;
                                console.log("giftPackGuid: " + giftPackGuid);
                                var data = {
                                    statecode: 1 /*Inactive*/,
                                    statuscode: 120000001/*Cancelled*/
                                };
                                Xrm.WebApi.updateRecord(entityLogicalName, giftPackGuid, data).then(
                                    function (result) {
                                        console.log("Record updated: " + result.uri);
                                    },
                                    function (error) {
                                        console.log("Error: " + error.message);
                                    }
                                );
                            },
                            function (error) {
                                console.log(error.message);
                                // handle error conditions
                            }
                        );

                        //Open New form with populated values
                        RHSScripts.Payment.OpenNewPaymentForm(parameters);
                        console.log("Success transaction");
                    } catch (error) {
                        console.log('Error: ' + error.message);
                    }
                } else {
                    // This means the user clicked "No" or closed the dialog (X button)
                    console.log("Process cancelled by user.");
                }
            },
            function (error) {
                // If there is an error opening the dialog
                console.log('Error opening confirmation dialog: ' + error.message);
            }
        );
    }
    else {
        //Open New form with populated values
        RHSScripts.Payment.OpenNewPaymentForm(parameters);
    }

}

RHSScripts.Payment.MarkIneligibleCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    let overrideComment = prompt("This will apply a gift aid override to this payment, thus marking it as ineligible for gift aid. Please provide a comment and confirm that you wish to continue.");

    if (overrideComment !== undefined && overrideComment !== null) {
        let paymentId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();
        const userId = Xrm.Utility.getGlobalContext().userSettings.userId;
        const cleanedUserId = "/systemusers(" + userId.replace(/[{}]/g, "") + ")"
        await Xrm.WebApi.updateRecord("rhs_payment", paymentId, {
            "rhs_giftaidoverrideineligible": true,
            "rhs_giftaidoverridedate": new Date(),
            "rhs_giftaidoverrideineligiblecomment": overrideComment,
            "rhs_GiftAidOverrideUser@odata.bind": cleanedUserId
        });
        await formContext.data.refresh(true);
    }
}

RHSScripts.Payment.PaymentManualReviewCommand = async function (primaryControl) {
    'use strict';
    let formContext = primaryControl;

    let startDate = prompt("You are about to download a csv file containing all payments within a given range where the payer name match the name given on the direct debit.\n\nPlease input the range's start date below in this format: DD-MM-YYYY.");
    let endDate = prompt("You are about to download a csv file containing all payments within a given range where the payer name match the name given on the direct debit.\n\nPlease input the range's end date below in this format: DD-MM-YYYY.");

    if ((startDate != undefined && startDate != null && startDate != "") && (endDate != undefined && endDate != null && endDate != "")) {
        try {
            startDate = startDate.slice(0, 10).split("-").reverse().join("-");  // convert DD-MM-YYYY to YYYY-MM-DD
            endDate = endDate.slice(0, 10).split("-").reverse().join("-");      // convert DD-MM-YYYY to YYYY-MM-DD
            let jsonData = await RHSScripts.Payment.RetrieveDataForManualReview(startDate, endDate);

            let csvData = RHSScripts.Payment.JsonToCsv(jsonData);
            let csvContent = "data:text/csv;charset=utf-8," + csvData;
            let encodedUri = encodeURI(csvContent);
            window.open(encodedUri);
            await Xrm.Navigation.openAlertDialog({ title: "CSV File Generation Successful", text: "CSV file containing payment records for review should download." });
        } catch (error) {
            await Xrm.Navigation.openAlertDialog({ title: "CSV File Generation Failed", text: "An error occured while generating the csv file." });
        }
    } else {
        await Xrm.Navigation.openAlertDialog({ title: "CSV File Generation Failed", text: "Missing start date or end date." });
    }
}
//#endregion

//#region Helper Functions
RHSScripts.Payment.OpenNewPaymentForm = function (parameters) {
    'use strict';
    let entityFormOptions = {
        entityName: "rhs_payment",
        openInNewWindow: true,
        useQuickCreateForm: false,
    };

    // Open the new form with pre-populated values
    Xrm.Navigation.openForm(entityFormOptions, parameters).then(
        function (success) {
            console.log("New Payment form opened successfully");
        },
        function (error) {
            console.error("Error opening new Payment form: ", error.message);
        }
    );
}

RHSScripts.Payment.RetrieveDataForManualReview = async function (startDate, endDate) {
    let jsonData = [];

    let fetchData = {
        "rhs_refund": "0",
        "rhs_directdebitmandate": "",
        "rhs_duedate": startDate,
        "rhs_duedate2": endDate,
        "rhs_paidon": startDate,
        "rhs_paidon2": endDate
    };
    let fetchXml = [
        "<fetch>",
        "  <entity name='rhs_payment'>",
        "    <attribute name='rhs_paymentsid'/>",
        "    <attribute name='rhs_product'/>",
        "    <attribute name='rhs_paidon'/>",
        "    <attribute name='rhs_duedate'/>",
        "    <attribute name='rhs_amount'/>",
        "    <attribute name='rhs_giftaideligibility'/>",
        "    <attribute name='rhs_payer'/>",
        "    <filter type='and'>",
        "      <condition attribute='rhs_refund' operator='eq' value='", fetchData.rhs_refund, "'/>",
        "      <condition entityname='Transaction' attribute='rhs_directdebitmandate' operator='not-null' value='", fetchData.rhs_directdebitmandate/**/, "'/>",
        "      <filter type='or'>",
        "        <filter type='and'>",
        "          <condition attribute='rhs_duedate' operator='on-or-after' value='", fetchData.rhs_duedate, "'/>",
        "          <condition attribute='rhs_duedate' operator='on-or-before' value='", fetchData.rhs_duedate2, "'/>",
        "        </filter>",
        "        <filter type='and'>",
        "          <condition attribute='rhs_paidon' operator='on-or-after' value='", fetchData.rhs_paidon, "'/>",
        "          <condition attribute='rhs_paidon' operator='on-or-before' value='", fetchData.rhs_paidon2, "'/>",
        "        </filter>",
        "      </filter>",
        "    </filter>",
        "    <link-entity name='rhs_transaction' from='rhs_transactionid' to='rhs_transaction' alias='Transaction'>",
        "      <link-entity name='rhs_directdebitdetails' from='rhs_directdebitdetailsid' to='rhs_directdebitmandate' alias='DirectDebitDetails'>",
        "        <attribute name='rhs_name'/>",
        "      </link-entity>",
        "    </link-entity>",
        "  </entity>",
        "</fetch>"
    ].join("");

    let retrievedJsonData = (await Xrm.WebApi.retrieveMultipleRecords("rhs_payment", "?fetchXml=" + fetchXml)).entities;
    let filteredJsonData = retrievedJsonData.filter(item =>
        item["_rhs_payer_value@OData.Community.Display.V1.FormattedValue"] != undefined && item["_rhs_payer_value@OData.Community.Display.V1.FormattedValue"] != null &&
        item["DirectDebitDetails.rhs_name"] != undefined && item["DirectDebitDetails.rhs_name"] != null &&
        item["_rhs_payer_value@OData.Community.Display.V1.FormattedValue"].toUpperCase() != item["DirectDebitDetails.rhs_name"].toUpperCase()
    );
    let mappedJsonData = filteredJsonData.map(item => {
        let newItem = {};
        newItem["Payment ID"] = item["rhs_paymentsid"] != undefined ? item["rhs_paymentsid"] : null;
        newItem["Product"] = item["_rhs_product_value@OData.Community.Display.V1.FormattedValue"] != undefined ? item["_rhs_product_value@OData.Community.Display.V1.FormattedValue"] : null;
        newItem["Paid On ( DD-MM-YYYY)"] = item["rhs_paidon"] != undefined && item["rhs_paidon"] != null ?
            " " + item["rhs_paidon"].slice(0, 10).split("-").reverse().join("-")/* convert YYYY-MM-DDTHH:mm:ss.sssZ to DD-MM-YYYY*/ : null;
        newItem["Due Date ( DD-MM-YYYY)"] = item["rhs_duedate"] != undefined && item["rhs_duedate"] != null ?
            " " + item["rhs_duedate"].slice(0, 10).split("-").reverse().join("-")/* convert YYYY-MM-DDTHH:mm:ss.sssZ to DD-MM-YYYY*/ : null;
        newItem["Amount"] = item["rhs_amount"] != undefined ? item["rhs_amount"] : null;
        newItem["Gift Aid Eligible"] = item["rhs_giftaideligibility"] != undefined ? item["rhs_giftaideligibility"] : null;
        newItem["Full Name (Payer)"] = item["_rhs_payer_value@OData.Community.Display.V1.FormattedValue"] != undefined ? item["_rhs_payer_value@OData.Community.Display.V1.FormattedValue"] : null;
        newItem["Name of Account Holder (Direct Debit Details)"] = item["DirectDebitDetails.rhs_name"] != undefined ? item["DirectDebitDetails.rhs_name"] : null;

        return newItem;
    });
    if (mappedJsonData.length == 0) {
        let blankItem = {};
        blankItem["Payment ID"] = null;
        blankItem["Product"] = null;
        blankItem["Paid On ( DD-MM-YYYY)"] = null;
        blankItem["Due Date ( DD-MM-YYYY)"] = null;
        blankItem["Amount"] = null;
        blankItem["Gift Aid Eligible"] = null;
        blankItem["Full Name (Payer)"] = null;
        blankItem["Name of Account Holder (Direct Debit Details)"] = null;

        mappedJsonData.push(blankItem);
    }

    jsonData = mappedJsonData;
    return jsonData;
}

RHSScripts.Payment.JsonToCsv = function (jsonData) {
    let csv = '';

    // Extract headers
    const headers = Object.keys(jsonData[0]);
    csv += headers.join(',') + '\n';

    // Extract values
    jsonData.forEach(obj => {
        const values = headers.map(header => obj[header]);
        csv += values.join(',') + '\n';
    });

    return csv;
}

RHSScripts.Payment.RequestRefundCommandForm = async function (primaryControl) {
    'use strict';

    let formContext = primaryControl;
    let entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let customPageName = "rhs_paymentrequestrefund_c1533";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: entityId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Payment Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Payment.RequestRefundSubGrid = async function (primaryControl, selectedItemIds) {
    'use strict';
    debugger;

    let formContext = primaryControl;
    let customPageName = "rhs_paymentrequestrefund_c1533";

    // Replace 'Payments_Subgrid' with the actual subgrid name on your form
    var gridControl = formContext.getControl("Subgrid_new_1");

    if (!gridControl) {
        alert("Subgrid not found.");
        return;
    }

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Payment Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );

};

RHSScripts.Payment.RequestRefundCommandGrid = async function (primaryControl, selectedItemIds) {
    'use strict'
    let gridContext = primaryControl;
    let customPageName = "rhs_paymentrequestrefund_c1533";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Payment Request Refund"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            gridContext.refresh();
        }
    ).catch(
        function (error) {
            console.error("Error encountered on custom page:", error.message);
        }
    );
}

RHSScripts.Payment.RequestReversalCommandForm = async function (primaryControl) {
    let formContext = primaryControl;
    let entityId = formContext.data.entity.getId().replace("{", "").replace("}", "").toLowerCase();

    let customPageName = "rhs_paymentreversalpage_42681";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: entityId
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Reverse Payment Page"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            primaryControl.data.refresh();
        }
    ).catch(
        function (error) {
        }
    );
}

RHSScripts.Payment.RequestReversalCommandSubgrid = async function (primaryControl, selectedItemIds) {
    let formContext = primaryControl;
    let customPageName = "rhs_paymentreversalpage_42681";
    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Reverse Payment Page"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            primaryControl.refresh();
        }
    ).catch(
        function (error) {
        }
    );

};

RHSScripts.Payment.RequestReversalCommandGrid = async function (primaryControl, selectedItemIds) {
    let formContext = primaryControl;
    let customPageName = "rhs_paymentreversalpage_42681";

    let pageInput = {
        pageType: "custom",
        name: customPageName,
        entityName: "rhs_payment",
        recordId: selectedItemIds
    };
    let navigationOptions = {
        target: 2,
        position: 2,
        width: { value: 500, unit: "px" },
        title: "Reverse Payment Page"
    };

    Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
        function () {
            primaryControl.refresh();
        }
    ).catch(
        function (error) {
        }
    );

};

RHSScripts.Payment.RequestReversalFormCommandDisplayRule = function (primaryControl) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;

    if (primaryControl.ui.getFormType() === 1) {
        return false;
    }

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers" && primaryControl.getAttribute("statuscode").getValue() != 120000006) {
            return true;
        }
    }

    return false;
};

RHSScripts.Payment.RequestReversalGridCommandDisplayRule = function (primaryControl) {
    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers") {
            return true;
        }
    }
    return false;
};

RHSScripts.Payment.ApproveForNavCommandGrid = async function (primaryControl, selectedItemIds) {
    let formContext = primaryControl;

    console.log("Selected Payment IDs for Approval: ", selectedItemIds);


    const confirmResult = await Xrm.Navigation.openConfirmDialog({
        title: "Approve for NAV",
        text: "Are you sure you want to approve the selected payment record(s) for NAV?"
    });

    if (!confirmResult.confirmed) {
        return;
    }

    try {
        const updatePromises = [];

        selectedItemIds.forEach(function (id) {

            const cleanId = id.replace(/[{}]/g, "");

            const updateData = {
                rhs_approvedfornav: true,
               
            };

            updatePromises.push(
                Xrm.WebApi.updateRecord("rhs_payment", cleanId, updateData)
            );
        });

        await Promise.all(updatePromises);

        primaryControl.refresh();

    } catch (error) {
        await Xrm.Navigation.openAlertDialog({
            text: "An error occurred while approving records: " + error.message
        });
    }

};

RHSScripts.Payment.ApproveForNavGridCommandDisplayRule = function (primaryControl, selectedItemIds) {

    console.log("Selected Payment IDs for Approval:", selectedItemIds);


    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
    var hasRequiredRole = false;

    for (var i = 0; i < roles.getLength(); i++) {
        var role = roles.get(i);
        if (role.name.toLowerCase() === "rhs membership team leads and managers") {
            hasRequiredRole = true;
            break;
        }
    }

    if (!hasRequiredRole) {
        return false;
    }

    if (!selectedItemIds || selectedItemIds.length === 0) {
        return false;
    }


    var filterIds = selectedItemIds
        .map(id => id.replace(/[{}]/g, ""))
        .map(id => `rhs_paymentid eq ${id}`)
        .join(" or ");

    var query =
        `?$select=rhs_paymentid` +
        `&$filter=rhs_approvedfornav eq true and (${filterIds})` +
        `&$top=1`;

    return Xrm.WebApi.retrieveMultipleRecords("rhs_payment", query)
        .then(function (result) {

            return result.entities.length === 0;
        })
        .catch(function (error) {
            console.error(error.message);
            return false;
        });
};


//#endregion