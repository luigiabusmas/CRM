using System.Collections.Generic;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.Entities.Generated;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Shouldly;

namespace Cultivate.Data.Tests
{
    [TestClass]
    public class ContactRepositoryTests
    {
        private ContactRepository _repro;
        private IXrmService _xrmService;
        private IXrmContext _xrmContext;
        private List<Contact> _contacts;

        [TestInitialize]
        public void Setup()
        {
            var logger = Substitute.For<ILogger>();
            var operationContext = Substitute.For<IOperationContext>();
            var dependencyContainer = Substitute.For<IDependencyContainer>();
            _contacts = new List<Contact>();
            _xrmService = Substitute.For<IXrmService>();

            _xrmContext = Substitute.For<IXrmContext>();
            _xrmContext.CreateQuery<Contact>().Returns(_contacts.AsQueryable());

            _repro = new ContactRepository(logger, operationContext, _xrmContext, dependencyContainer, _xrmService);
        }

        [TestMethod]
        public void OnlyReturnsActiveContacts()
        {
            _contacts.Add(new Contact {StateCode = ContactState.Inactive});
            _contacts.Add(new Contact() { StateCode = ContactState.Active });

            var contacts = _repro.GetAll();
            contacts.Count().ShouldBe(1);
            contacts.First().StateCode.ShouldBe(ContactState.Active);
        }
    }
}