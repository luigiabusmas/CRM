using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.Data
{
    public interface ICultivateConfigurationRepository : IRepository<Cultivateconfigurations>
    {
        Cultivateconfigurations GetPricelIstConfig(string configName);
    }

    public class CultivateConfigurationRepository : Repository<Cultivateconfigurations>, ICultivateConfigurationRepository
    {
        public CultivateConfigurationRepository(ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public Cultivateconfigurations GetPricelIstConfig(string configName)
        {
            return GetAll().Where(c=> c.Name == configName).FirstOrDefault();
        }
    }
}