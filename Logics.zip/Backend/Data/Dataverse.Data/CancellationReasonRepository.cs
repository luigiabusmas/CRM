using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface ICancellationReasonRepository : IRepository<CancellationReason>
    {
        CancellationReason GetCancellationReasonbyName(string name);
    }

    public class CancellationReasonRepository : Repository<CancellationReason>, ICancellationReasonRepository
    {
        public CancellationReasonRepository(ILogger logger, 
            IOperationContext context, 
            IXrmContext xrmContext, 
            IDependencyContainer container, 
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public CancellationReason GetCancellationReasonbyName(string name)
        {
            return base.GetAll().FirstOrDefault(c => c.Name == name);
        }
    }
}