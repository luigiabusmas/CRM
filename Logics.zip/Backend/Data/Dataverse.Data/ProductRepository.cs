using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IProductRepository : IRepository<Product>
    {
        Product GetByProductNumber(string productNumber);
    }

    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(
            ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService)
            : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public Product GetByProductNumber(string productNumber)
        {
            return base.GetAll().FirstOrDefault(p => p.ProductNumber == productNumber);
        }
    }
}