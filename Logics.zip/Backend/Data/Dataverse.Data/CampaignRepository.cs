using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.Data
{
    public interface ICampaignRepository : IRepository<Campaign>
    {
        Campaign GetByCodeAndProduct(string code, Guid productId);
    }

    public class CampaignRepository : Repository<Campaign>, ICampaignRepository
    {
        public CampaignRepository(ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public Campaign GetByCodeAndProduct(string code, Guid productId)
        {
            return (from campaign in GetAll()
                    join campaignItem in Join<CampaignItem>() on campaign.Id equals campaignItem.CampaignId.Id
                    where campaign.CampaignCode == code
                       && campaignItem.EntityId == productId
                    select campaign)
                .Distinct().FirstOrDefault();
        }
    }
}