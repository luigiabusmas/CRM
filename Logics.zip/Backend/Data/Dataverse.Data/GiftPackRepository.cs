using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IGiftPackRepository : IRepository<GiftPack>
    {
        GiftPack GetByGiftPackCode(string giftPackCode);
    }

    public class GiftPackRepository : Repository<GiftPack>, IGiftPackRepository
    {
        public GiftPackRepository(ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public GiftPack GetByGiftPackCode(string giftPackCode)
        {
            return GetAll()
                .Where(e => e.GiftPackCode == giftPackCode)
                .Select(gp => new GiftPack { Id = gp.Id, Product = gp.Product, Statuscode = gp.Statuscode })
                .FirstOrDefault();
        }
    }
}