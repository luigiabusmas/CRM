using System;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IPortalSessionContactRepository : IRepository<Portalsessioncontact>
    {
        IQueryable<Portalsessioncontact> GetByPortalSessionId(Guid portalSessionId);
    }

    public class PortalSessionContactRepository : Repository<Portalsessioncontact>, IPortalSessionContactRepository
    {
        public PortalSessionContactRepository(ILogger logger, 
            IOperationContext context, 
            IXrmContext xrmContext, 
            IDependencyContainer container, 
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public IQueryable<Portalsessioncontact> GetByPortalSessionId(Guid portalSessionId)
        {
            return GetAll()
                .Where(c => c.PortalSession != null && c.PortalSession.Id == portalSessionId);
        }
    }
}