using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IContactRepository : IRepository<Contact>
    {
        IQueryable<Contact> GetByNameEmailPostCode(string firstName, string lastName, string email, string postCode);
    }

    public class ContactRepository : Repository<Contact>, IContactRepository
    {
        public ContactRepository(ILogger logger, 
            IOperationContext context, 
            IXrmContext xrmContext, 
            IDependencyContainer container, 
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public override IQueryable<Contact> GetAll()
        {
            return base.GetAll().Where(e => e.StateCode == ContactState.Active);
        }

        public IQueryable<Contact> GetByNameEmailPostCode(string firstName, string lastName, string email, string postCode)
        {
            var query = base.GetAll().Where(e => e.FirstName == firstName && e.LastName == lastName && e.Address1_PostalCode == postCode);

            if (!string.IsNullOrWhiteSpace(email))
            {
                query = query.Where(e => e.EMailAddress1 == email);
            }

            return query;
        }
    }
}