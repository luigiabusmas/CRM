using System;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IAnnotationRepository : IRepository<Annotation>
    {
        IQueryable<Annotation> GetByRegardingId(Guid objectId, string objectTypeCode);
    }

    public class AnnotationRepository : Repository<Annotation>, IAnnotationRepository
    {
        public AnnotationRepository(
            ILogger logger, 
            IOperationContext context, 
            IXrmContext xrmContext, 
            IDependencyContainer container, 
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public IQueryable<Annotation> GetByRegardingId(Guid objectId, string objectTypeCode)
        {
            return base.GetAll()
           .Where(a => a.ObjectId.Id == objectId && a.ObjectTypeCode == objectTypeCode);
        }
    }
}