using System;
using System.Collections.Generic;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IMembershipRepository : IRepository<Membership>
    {
        Membership GetActiveMembershipByContactAndProduct(Guid contactId, Guid productId);
        IEnumerable<Membership> GetActiveOrPendingMembershipsByContactAndProduct(Guid contactId, Guid productId, Guid? additionalMemberId = null);
    }

    public class MembershipRepository : Repository<Membership>, IMembershipRepository
    {
        public MembershipRepository(
            ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService)
            : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public Membership GetActiveMembershipByContactAndProduct(Guid contactId, Guid productId)
        {
            return base.GetAll().FirstOrDefault(m =>
                m.Contact.Id == contactId &&
                m.MembershipProductIdProductRef != null &&
                m.MembershipProductIdProductRef.Id == productId &&
                m.Statecode == MembershipState.Active);
        }

        public IEnumerable<Membership> GetActiveOrPendingMembershipsByContactAndProduct(Guid contactId, Guid productId, Guid? additionalMemberId = null)
        {
            var query = base.GetAll().Where(m =>
                m.Contact.Id == contactId &&
                m.MembershipProductIdProductRef != null &&
                m.MembershipProductIdProductRef.Id == productId &&
                (m.Statuscode == MembershipStatus.Active_Active ||
                 m.Statuscode == MembershipStatus.Active_PendingPayment));

            if (additionalMemberId.HasValue)
            {
                query = query.Where(m => m.Member2 != null && m.Member2.Id == additionalMemberId.Value);
            }

            return query.ToList();
        }
    }
}