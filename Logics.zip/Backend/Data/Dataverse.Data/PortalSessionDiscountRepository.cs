using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.Data
{
    public interface IPortalSessionDiscountRepository : IRepository<PortalSessionDiscount>
    {
        PortalSessionDiscount GetByPortalSesssionId(Guid portalSessionId);
    }

    public class PortalSessionDiscountRepository : Repository<PortalSessionDiscount>, IPortalSessionDiscountRepository
    {
        public PortalSessionDiscountRepository(ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public PortalSessionDiscount GetByPortalSesssionId(Guid portalSessionId)
        {
            return GetAll().Where(p=> p.PortalSession.Id == portalSessionId).FirstOrDefault();
        }
    }
}