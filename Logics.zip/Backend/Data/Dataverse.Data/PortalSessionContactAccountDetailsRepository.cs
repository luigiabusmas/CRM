using System;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Repositories;
using Cultivate.Entities.Generated;

namespace Cultivate.Data
{
    public interface IPortalSessionContactAccountDetailsRepository : IRepository<PortalSessionContactAccountDetails>
    {
        PortalSessionContactAccountDetails GetByPayerId(Guid payerId);
    }

    public class PortalSessionContactAccountDetailsRepository : Repository<PortalSessionContactAccountDetails>, IPortalSessionContactAccountDetailsRepository
    {
        public PortalSessionContactAccountDetailsRepository(ILogger logger,
            IOperationContext context,
            IXrmContext xrmContext,
            IDependencyContainer container,
            IXrmService xrmService) : base(logger, context, xrmContext, container, xrmService)
        {
        }

        public PortalSessionContactAccountDetails GetByPayerId(Guid payerId)
        {
            return GetAll()
                .Where(e => e.PortalSessionContact.Id == payerId)                
                .FirstOrDefault();
        }
    }
}