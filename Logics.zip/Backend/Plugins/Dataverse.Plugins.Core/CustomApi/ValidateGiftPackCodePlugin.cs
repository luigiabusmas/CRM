﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Extensions;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;
using System;
using System.Runtime.Serialization;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class ValidateGiftPackCodeApiRequest
    {
        [DataMember(Name = nameof(GiftPackCode))]
        public string GiftPackCode { get; set; }
    }

    public class ValidateGiftPackCodeApiResponse
    {
        [DataMember(Name = nameof(Message))]
        public string Message { get; set; }

        [DataMember(Name = nameof(IsValid))]
        public bool IsValid { get; set; }

        [DataMember(Name = nameof(IsRedeemed))]
        public bool IsRedeemed { get; set; }

        [DataMember(Name = nameof(MinimumAge))]
        public int? MinimumAge { get; set; }

        [DataMember(Name = nameof(GiftPackProductName))]
        public string GiftPackProductName { get; set; }

        [DataMember(Name = nameof(GiftPackProductId))]
        public Guid? GiftPackProductId { get; set; }

        [DataMember(Name = nameof(GiftPackId))]
        public Guid? GiftPackId { get; set; }

        [DataMember(Name = nameof(IsDobRequired))]
        public bool IsDobRequired { get; set; }

        [DataMember(Name = nameof(Success))]
        public bool Success { get; set; }

        [DataMember(Name = nameof(Error))]
        public string Error { get; set; }
    }

    [PluginRegistration]
    public class ValidateGiftPackCodePlugin : CustomApiPlugin<ValidateGiftPackCodeApiRequest, ValidateGiftPackCodeApiResponse>, IPlugin

    {
        public override ValidateGiftPackCodeApiResponse Execute(IDependencyContainer container, ValidateGiftPackCodeApiRequest request)
        {
            try
            {
                var logger = container.Resolve<ILogger>();
                var giftPackService = container.Resolve<IGiftPackService>();
                var context = container.Resolve<IPluginExecutionContext>();

                logger.TraceInformation($"Starting plugin.");

                if (context.MessageName != "rhs_validategiftpackcode_new")
                {
                    throw new InvalidPluginExecutionException("Incorrect message name.");
                }

                var giftPackCodeResult = giftPackService.ValidateGiftPackCode(request.GiftPackCode);

                return new ValidateGiftPackCodeApiResponse
                {
                    IsRedeemed = giftPackCodeResult.IsRedeemed,
                    IsValid = giftPackCodeResult.IsValid,
                    Message = giftPackCodeResult.Message,
                    MinimumAge = giftPackCodeResult.MinimumAge ?? null,
                    GiftPackProductName = giftPackCodeResult.GiftPackProductName,
                    GiftPackProductId = giftPackCodeResult.GiftPackProductId ?? null,
                    GiftPackId = giftPackCodeResult.GiftPackId ?? null,
                    IsDobRequired = giftPackCodeResult.IsDobRequired,
                    Success = true,
                };
            }
            catch (Exception e)
            {
                return new ValidateGiftPackCodeApiResponse
                {
                    Success = false,
                    Error = e.FormatMessage()
                };
            }
        }
    }
}