﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class CancelDDRequest
    {
        [JsonProperty(PropertyName = nameof(MembershipId))]
        public Guid MembershipId { get; set; }
    }

    public class CancelDDResponse 
    {
        [JsonProperty(PropertyName = nameof(TransactionId))]
        public Guid? TransactionId { get; set; }

        [JsonProperty(PropertyName = nameof(PayementScheduleId))]
        public Guid? PayementScheduleId { get; set; }
    }

    public class CancelDDPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var service = container.Resolve<IOrganizationService>();
            var cancelDDService = container.Resolve<CancelDDService>();

            logger.TraceInformation($"Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");
            if (context.MessageName == "rhs_cancelDD_new")
            {
                logger.TraceInformation($"Retrieving input parameters.");
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new CancelDDResponse();

                var membershipEntity = service.Retrieve(EntityNames.Membership.EntityLogicalName, inputRequest.MembershipId, new ColumnSet(true));
                var (cancelledTransactionIds, cancelledPaymentScheduleIds, cancelledPaymentIds) = cancelDDService.CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(membershipEntity);
                var cancelledDirectDebitIds = cancelDDService.CancelDirectDebitsOfEntity(membershipEntity);

                if (cancelledTransactionIds.Count > 0)
                    outputResponse.TransactionId = cancelledTransactionIds.First();
                if (cancelledPaymentScheduleIds.Count > 0)
                    outputResponse.PayementScheduleId = cancelledPaymentScheduleIds.First();

                SetOutputParameters(context, outputResponse, logger);
                logger.TraceInformation($"Ending plugin.");
            }
            else
            {
                logger.TraceError($"Incorrect message name.");
                throw new InvalidPluginExecutionException($"Incorrect message name.");
            }
        }

        private CancelDDRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            //Get custom API request
            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<CancelDDRequest>(inputJson);

            //Log request property values
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");
            }

            logger.TraceInformation($"Ending helper method.");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, CancelDDResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation($"Ending helper method.");
        }
    }
}
