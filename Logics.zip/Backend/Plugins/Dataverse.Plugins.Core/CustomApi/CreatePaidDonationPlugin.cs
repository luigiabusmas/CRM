﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class CreatePaidDonationApiRequest
    {
        [JsonProperty(PropertyName = nameof(IsStandaloneDonation))]
        public bool? IsStandaloneDonation { get; set; }

        [JsonProperty(PropertyName = nameof(DonationAmount))]
        public decimal? DonationAmount { get; set; }

        [JsonProperty(PropertyName = nameof(BatchOrderLineId))]
        public Guid? BatchOrderLineId { get; set; }

        [JsonProperty(PropertyName = nameof(MembershipId))]
        public Guid? MembershipId { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionId))]
        public Guid? TransactionId { get; set; }
    }

    public class CreatePaidDonationApiResponse
    {
        [JsonProperty(PropertyName = nameof(DonationId))]
        public Guid DonationId { get; set; }
    }

    public class CreatePaidDonationPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var createPaidDonationService = container.Resolve<ICreatePaidDonationService>();

            logger.TraceInformation($"context.MessageName = {context.MessageName}.");
            if (context.MessageName != "rhs_createpaiddonation_new")
                throw new InvalidPluginExecutionException("Incorrect message name.");

            try
            {
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new CreatePaidDonationApiResponse() { DonationId = Guid.Empty };

                if (inputRequest.IsStandaloneDonation == true)
                {
                    if (inputRequest.BatchOrderLineId.HasValue)
                    {
                        var donation = createPaidDonationService.CreateStandaloneDonationFromBatchOrderLine((Guid)inputRequest.BatchOrderLineId);
                        createPaidDonationService.CreateDonationRelatedRecords(donation);
                        createPaidDonationService.ActivateDonationWhenApplicable(donation.Id, donation.PaymentMethodCode);
                        outputResponse.DonationId = donation.Id;
                    }
                }
                else
                {
                    if (inputRequest.MembershipId.HasValue && inputRequest.TransactionId.HasValue && inputRequest.DonationAmount > 0)
                    {
                        var membershipEntity = createPaidDonationService.GetMembershipDetails(inputRequest.MembershipId.Value);
                        var membership = membershipEntity.ToEntity<Membership>();
                        var donationId = membershipEntity != null ? createPaidDonationService.ProcessDonationAndPayment(membershipEntity, inputRequest.TransactionId.Value, new Money((decimal)inputRequest.DonationAmount)) : Guid.Empty;
                        createPaidDonationService.ActivateDonationWhenApplicable(outputResponse.DonationId, (PaymentMethodType_GlobalOptionSet?)membership.PaymentMethod);
                        outputResponse.DonationId = donationId;
                    }
                }

                SetOutputParameters(context, outputResponse, logger);
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    throw new InvalidPluginExecutionException(ex.InnerException.Message);
                else
                    throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private CreatePaidDonationApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation("Starting GetInputParameters");

            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<CreatePaidDonationApiRequest>(inputJson);

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");
            }

            logger.TraceInformation("Ending GetInputParameters");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, CreatePaidDonationApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation("Starting SetOutputParameters");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation("Ending SetOutputParameters");
        }
    }
}
