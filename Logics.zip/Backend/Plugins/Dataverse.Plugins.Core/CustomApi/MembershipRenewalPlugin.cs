﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using System.Security.Policy;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class MembershipRenewalApiRequest
    {
        [JsonProperty(PropertyName = nameof(MembershipId))]
        public Guid? MembershipId { get; set; }

        [JsonProperty(PropertyName = nameof(AdvancePayment))]
        public bool? AdvancePayment { get; set; }
    }

    public class MembershipRenewalApiResponse
    {
        [JsonProperty(PropertyName = nameof(Result))]
        public string? Result { get; set; }
    }

    public class MembershipRenewalPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var membershipRepository = container.Resolve<IRepository<Membership>>();
            var membershipRenewalService = container.Resolve<IMembershipRenewalService>();

            var productService = container.Resolve<IProductService>();

            logger.TraceInformation("Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");

            if (context.MessageName == "rhs_membership_renewals_new")
            {
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new MembershipRenewalApiResponse();

                var originalMembership = membershipRepository.GetById((Guid)inputRequest.MembershipId);
                var updatedMembership = membershipRenewalService.UpdateRenewalFields(originalMembership, inputRequest.AdvancePayment);

                outputResponse.Result = "Success"; 
                SetOutputParameters(context, outputResponse, logger);

                logger.TraceInformation("Ending plugin.");
            }
            else
            {
                throw new InvalidPluginExecutionException("Incorrect message name.");
            }
        }

        private MembershipRenewalApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation("Starting helper method.");

            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<MembershipRenewalApiRequest>(inputJson);

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");

                if ((name == "MembershipId" && (value == null || (Guid)value == Guid.Empty)))
                {
                    var errorMessage = $"Please input a value for {name}.";
                    logger.TraceError(errorMessage);
                    throw new InvalidPluginExecutionException(errorMessage);
                }
            }

            logger.TraceInformation("Ending helper method.");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, MembershipRenewalApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation("Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation("Ending helper method.");
        }
    }
}
