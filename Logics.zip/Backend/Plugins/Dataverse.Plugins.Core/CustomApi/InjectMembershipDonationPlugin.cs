﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class InjectMembershipDonationApiRequest
    {
        [JsonProperty(PropertyName = nameof(MembershipId))]
        public Guid? MembershipId { get; set; }
    }

    public class InjectMembershipDonationApiResponse
    {
        [JsonProperty(PropertyName = nameof(DonationId))]
        public Guid? DonationId { get; set; }
    }

    public class InjectMembershipDonationPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var membershipRepository = container.Resolve<IRepository<Membership>>();
            var injectMembershipDonationService = container.Resolve<ICreatePaidDonationService>();

            logger.TraceInformation($"context.MessageName = {context.MessageName}.");
            if (context.MessageName != "rhs_injectmembershipdonation_new")
                throw new InvalidPluginExecutionException("Incorrect message name.");

            try
            {
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new InjectMembershipDonationApiResponse();

                logger.TraceInformation($"Retrieving needed data for donation injection into membership.");
                var membership = membershipRepository.GetById((Guid)inputRequest.MembershipId);
                var transaction = injectMembershipDonationService.RetrieveMembershipTransaction((Guid)inputRequest.MembershipId);

                logger.TraceInformation($"Injecting donation and associated records into membership");
                outputResponse.DonationId = injectMembershipDonationService.ProcessUnpaidDonationAndPayment(membership, transaction.Id, membership.DonationAmount);

                SetOutputParameters(context, outputResponse, logger);
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                    throw new InvalidPluginExecutionException(ex.InnerException.Message);
                else
                    throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private InjectMembershipDonationApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation("Starting GetInputParameters");

            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<InjectMembershipDonationApiRequest>(inputJson);

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");
            }

            logger.TraceInformation("Ending GetInputParameters");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, InjectMembershipDonationApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation("Starting SetOutputParameters");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation("Ending SetOutputParameters");
        }
    }
}
