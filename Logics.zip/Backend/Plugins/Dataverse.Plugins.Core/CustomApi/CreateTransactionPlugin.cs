﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class CreateTransactionApiResponse
    {
        [JsonProperty(PropertyName = nameof(TransactionId))]
        public Guid? TransactionId { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionNumber))]
        public string TransactionNumber { get; set; }
    }

    public class CreateTransactionPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var transactionService = container.Resolve<TransactionService>();

            logger.TraceInformation($"Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");

            if (context.MessageName != "rhs_createtransaction_new")
            {
                throw new InvalidPluginExecutionException("Incorrect message name.");
            }

            var transaction = transactionService.CreateAndRetrieveTransaction();

            var transactionResponse = new CreateTransactionApiResponse
            {
                TransactionId = transaction.Id,
                TransactionNumber = transaction.TransacID
            }
            ;
            SetOutputParameters(context, transactionResponse, logger);
        }

        private static void SetOutputParameters(IPluginExecutionContext context, CreateTransactionApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation($"Ending helper method.");
        }
    }
}