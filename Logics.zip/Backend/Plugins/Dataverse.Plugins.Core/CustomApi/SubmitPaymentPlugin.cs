﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class SubmitPaymentApiRequest
    {
        [JsonProperty(PropertyName = nameof(PaymentMethod))]
        public int? PaymentMethod { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionType))]
        public int? TransactionType { get; set; }

        [JsonProperty(PropertyName = nameof(Type))]
        public int? Type { get; set; }

        [JsonProperty(PropertyName = nameof(RecordId))]
        public Guid? RecordId { get; set; }

        [JsonProperty(PropertyName = nameof(PayerId))]
        public Guid? PayerId { get; set; }

        [JsonProperty(PropertyName = nameof(PayerEntity))]
        public string? PayerEntity { get; set; }

        [JsonProperty(PropertyName = nameof(TotalAmount))]
        public Money? TotalAmount { get; set; }

        [JsonProperty(PropertyName = nameof(PaymentFrequency))]
        public int? PaymentFrequency { get; set; }

        [JsonProperty(PropertyName = nameof(IsContiniousPayment))]
        public bool? IsContiniousPayment { get; set; }

        [JsonProperty(PropertyName = nameof(OutstandingAmount))]
        public Money? OutstandingAmount { get; set; }

        [JsonProperty(PropertyName = nameof(WrittenOffAmount))]
        public Money? WrittenOffAmount { get; set; }

        [JsonProperty(PropertyName = nameof(PaymentReference))]
        public string? PaymentReference { get; set; }

        [JsonProperty(PropertyName = nameof(PayingInSlipNumber))]
        public int? PayingInSlipNumber { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionId))]
        public Guid? TransactionId { get; set; }
    }

    public class SubmitPaymentApiResponse
    {
        [JsonProperty(PropertyName = nameof(TransactionId))]
        public Guid? TransactionId { get; set; }

        [JsonProperty(PropertyName = nameof(PaymentId))]
        public Guid? PaymentId { get; set; }

        [JsonProperty(PropertyName = nameof(PayementScheduleId))]
        public Guid? PayementScheduleId { get; set; }
    }

    public class SubmitPaymentPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var submitPaymentService = container.Resolve<SubmitPaymentService>();

            logger.TraceInformation($"Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");

            if (context.MessageName == "rhs_submitpayment_new")
            {
                var inputRequest = GetInputParameters(context, logger);
                var command = new SubmitPaymentCommand
                {
                    PaymentMethod = inputRequest.PaymentMethod,
                    TransactionType = inputRequest.TransactionType,
                    Type = inputRequest.Type,
                    RecordId = inputRequest.RecordId,
                    PayerId = inputRequest.PayerId,
                    PayerEntity = inputRequest.PayerEntity,
                    TotalAmount = inputRequest.TotalAmount,
                    PaymentFrequency = inputRequest.PaymentFrequency,
                    IsContiniousPayment = inputRequest.IsContiniousPayment,
                    OutstandingAmount = inputRequest.OutstandingAmount,
                    WrittenOffAmount = inputRequest.WrittenOffAmount,
                    PaymentReference = inputRequest.PaymentReference,
                    PayingInSlipNumber = inputRequest.PayingInSlipNumber,
                    TransactionId = inputRequest.TransactionId
                };
                var result = submitPaymentService.SubmitPayment(command);
                var outputResponse = new SubmitPaymentApiResponse
                {
                    TransactionId = result.TransactionId,
                    PaymentId = result.PaymentId,
                    PayementScheduleId = result.PaymentScheduleId
                };

                SetOutputParameters(context, outputResponse, logger);
                logger.TraceInformation($"Ending plugin.");
            }
            else
            {
                throw new InvalidPluginExecutionException("Incorrect message name.");
            }
        }

        private SubmitPaymentApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            //Get custom API request
            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<SubmitPaymentApiRequest>(inputJson);

            //Log request property values
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");

                if ((name == "TransactionType" && (value == null || (int)value == 0)) ||
                    (name == "RecordId" && (value == null || (Guid)value == new Guid())))
                {
                    var errorMessage = $"Please input a value for {name}.";
                    logger.TraceError(errorMessage);
                    throw new InvalidPluginExecutionException(errorMessage);
                }
            }

            logger.TraceInformation($"Ending helper method.");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, SubmitPaymentApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation($"Ending helper method.");
        }
    }
}
