﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class CancelDDIRequest
    {
        [JsonProperty(PropertyName = nameof(RecordId))]
        public Guid RecordId { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionType))]
        public int TransactionType { get; set; }
    }

    public class CancelDDIResponse 
    {
        [JsonProperty(PropertyName = nameof(TransactionIds))]
        public string[] TransactionIds { get; set; }

        [JsonProperty(PropertyName = nameof(PayementScheduleIds))]
        public string[] PayementScheduleIds { get; set; }

        [JsonProperty(PropertyName = nameof(PayementIds))]
        public string[] PayementIds { get; set; }
    }

    public class CancelDDIPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var service = container.Resolve<IOrganizationService>();
            var CancelDDIService = container.Resolve<CancelDDService>();

            logger.TraceInformation($"Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");
            if (context.MessageName == "rhs_cancelDDI_new")
            {
                logger.TraceInformation($"Retrieving input parameters.");
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new CancelDDIResponse();

                logger.TraceInformation($"Retrieving entity of Record Id.");
                Entity entity = null;
                switch(inputRequest.TransactionType)
                {
                    case (int)NewTransactionType_GlobalOptionSet.Membership:
                        entity = service.Retrieve("rhs_membership", inputRequest.RecordId, new ColumnSet(true));
                        break;
                    case (int)NewTransactionType_GlobalOptionSet.Subscriptions:
                        entity = service.Retrieve("rhs_subscription", inputRequest.RecordId, new ColumnSet(true));
                        break;
                    case (int)NewTransactionType_GlobalOptionSet.Donation:
                        entity = service.Retrieve("rhs_donation", inputRequest.RecordId, new ColumnSet(true));
                        break;
                }

                logger.TraceInformation($"Cancelling associated records of entity.");
                var (cancelledTransactionIds, cancelledPaymentScheduleIds, cancelledPaymentIds) = CancelDDIService.CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(entity);
                var cancelledDirectDebitIds = CancelDDIService.CancelDirectDebitsOfEntity(entity);

                outputResponse.TransactionIds = cancelledTransactionIds.Select(id => id.ToString()).ToArray();
                outputResponse.PayementScheduleIds = cancelledPaymentScheduleIds.Select(id => id.ToString()).ToArray();
                outputResponse.PayementIds = cancelledPaymentIds.Select(id => id.ToString()).ToArray();

                SetOutputParameters(context, outputResponse, logger);
                logger.TraceInformation($"Ending plugin.");
            }
            else
            {
                logger.TraceError($"Incorrect message name.");
                throw new InvalidPluginExecutionException($"Incorrect message name.");
            }
        }

        private CancelDDIRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            //Get custom API request
            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<CancelDDIRequest>(inputJson);

            //Log request property values
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");
            }

            logger.TraceInformation($"Ending helper method.");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, CancelDDIResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation($"Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation($"Ending helper method.");
        }
    }
}
