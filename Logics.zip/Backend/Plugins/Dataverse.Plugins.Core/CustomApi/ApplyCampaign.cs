﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Extensions;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;
using System;
using System.Runtime.Serialization;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class ApplyCampaignApiRequest
    {
        [DataMember(Name = nameof(ProductId))]
        public Guid? ProductId { get; set; }

        [DataMember(Name = nameof(CampaignCode))]
        public string CampaignCode { get; set; }

        [DataMember(Name = nameof(PaymentMethod))]
        public int? PaymentMethod { get; set; }

        [DataMember(Name = nameof(PortalSessionId))]
        public Guid? PortalSessionId { get; set; }
    }

    public class ApplyCampaignApiResponse
    {
        [DataMember(Name = nameof(OriginalAmount))]
        public Money OriginalAmount { get; set; }

        [DataMember(Name = nameof(FinalAmount))]
        public Money FinalAmount { get; set; }

        [DataMember(Name = nameof(DiscountAmount))]
        public Money DiscountAmount { get; set; }

        [DataMember(Name = nameof(IsValid))]
        public bool IsValid { get; set; }

        [DataMember(Name = nameof(Message))]
        public string Message { get; set; }

        [DataMember(Name = nameof(DiscountLabel))]
        public string DiscountLabel { get; set; }

        [DataMember(Name = nameof(DiscountRate))]
        public double DiscountRate { get; set; }

        [DataMember(Name = nameof(Success))]
        public bool Success { get; set; }

        [DataMember(Name = nameof(Error))]
        public string Error { get; set; }
    }

    [PluginRegistration]
    public class ApplyCampaignPlugin : CustomApiPlugin<ApplyCampaignApiRequest, ApplyCampaignApiResponse>, IPlugin
    {
        public override ApplyCampaignApiResponse Execute(IDependencyContainer container, ApplyCampaignApiRequest request)
        {
            try
            {
                var logger = container.Resolve<ILogger>();
                var campaignService = container.Resolve<IApplyCampaignService>();

                logger.TraceInformation($"Starting plugin.");               

                var applyCampaignResult = campaignService.GetDiscountBasedOnCodeAndProduct(request.CampaignCode, request.ProductId.Value, request.PaymentMethod.Value, request.PortalSessionId.GetValueOrDefault());

                var applyCampaignApiResponse = new ApplyCampaignApiResponse
                {
                    DiscountAmount = applyCampaignResult.DiscountAmount,
                    DiscountLabel = applyCampaignResult.DiscountLabel,
                    DiscountRate = applyCampaignResult.DiscountRate,
                    FinalAmount = applyCampaignResult.FinalAmount,
                    IsValid = applyCampaignResult.IsValid,
                    Message = applyCampaignResult.Message,
                    OriginalAmount = applyCampaignResult.OriginalAmount,
                    Success = true,
                };

                return applyCampaignApiResponse;
            }
            catch (Exception e)
            {
                return new ApplyCampaignApiResponse
                {
                    Success = false,
                    Error = e.FormatMessage()
                };
            }
        }
    }
}