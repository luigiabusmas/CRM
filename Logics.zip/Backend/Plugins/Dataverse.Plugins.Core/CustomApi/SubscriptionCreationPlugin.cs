﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Linq;
using System.Security.Policy;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class SubscriptionCreationApiRequest
    {
        [JsonProperty(PropertyName = nameof(MembershipId))]
        public Guid? MembershipId { get; set; }
    }

    public class SubscriptionCreationApiResponse
    {
        [JsonProperty(PropertyName = nameof(SubscriptionId))]
        public Guid? SubscriptionId { get; set; }
        [JsonProperty(PropertyName = nameof(Error))]
        public string Error { get; set; }

    }

    public class SubscriptionCreationPlugin : Plugin
    {
        SubscriptionCreationApiResponse outputResponse = new SubscriptionCreationApiResponse();

        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var organisationService = container.Resolve<IOrganizationService>();
            var subscriptionService = container.Resolve<ISubscriptionService>();

            logger.TraceInformation("Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");

            try
            {
                if (context.MessageName == "rhs_subscription_creation_new")
                {
                    var subscriptionId = Guid.Empty;
                    var inputRequest = GetInputParameters(context, logger);

                    if (inputRequest.MembershipId.HasValue)
                    {
                        var membershipEntity = subscriptionService.GetMembershipDetails(inputRequest.MembershipId.Value);
                        var membershipProduct = membershipEntity.Contains(EntityNames.Membership.MembershipProductId) ? membershipEntity.GetAttributeValue<EntityReference>(EntityNames.Membership.MembershipProductId) : null;
                        logger.TraceInformation("Membership product: " + membershipProduct.Id + membershipProduct.Name);
                        var isPatronFellow = membershipProduct != null ? (membershipProduct.Name.ToLower()).Contains("patron fellow") : false;
                        logger.TraceInformation("Is Patron Fellow: " + isPatronFellow.ToString());

                        subscriptionId = membershipEntity != null ? subscriptionService.CreateInitialSubscription(membershipEntity, isPatronFellow) : Guid.Empty;

                        if (subscriptionId != Guid.Empty && isPatronFellow)
                        {
                            var membershipPayer = membershipEntity.Contains(EntityNames.Membership.PayerV2) ? membershipEntity.GetAttributeValue<EntityReference>(EntityNames.Membership.PayerV2) : null;
                            subscriptionService.ProcessFreePayment(subscriptionId, membershipPayer);
                            subscriptionService.ActivateSubscription(subscriptionId, isPatronFellow);
                        };
                    }

                    outputResponse.SubscriptionId = subscriptionId;
                    SetOutputParameters(context, outputResponse, logger);

                    logger.TraceInformation("Ending plugin.");
                }
            }
            catch (Exception ex)
            {
                outputResponse.Error = ex.Message;
                SetOutputParameters(context, outputResponse, logger);
            }
        }

        private SubscriptionCreationApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation("Start GetInputParameters");

            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<SubscriptionCreationApiRequest>(inputJson);

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");

                if ((name == "TransactionId" && (value == null || (Guid)value == Guid.Empty)))
                {
                    var errorMessage = $"Please input a value for {name}.";
                    logger.TraceError(errorMessage);
                    throw new InvalidPluginExecutionException(errorMessage);
                }
            }

            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, SubscriptionCreationApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation("Start SetOutputParameters");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }
        }


    }
}
