﻿using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class CirrusPaymentApiRequest
    {

        [JsonProperty(PropertyName = nameof(CirrusKeyVaultUrl))]
        public string? CirrusKeyVaultUrl { get; set; }

        [JsonProperty(PropertyName = nameof(EntityRecord))]
        public Guid EntityRecord { get; set; }

        [JsonProperty(PropertyName = nameof(PayerRecord))]
        public Guid PayerRecord { get; set; }

        [JsonProperty(PropertyName = nameof(PayerEntity))]
        public string? PayerEntity { get; set; }

        [JsonProperty(PropertyName = nameof(TotalAmount))]
        public Money TotalAmount { get; set; }

        [JsonProperty(PropertyName = nameof(TransactionType))]
        public int? TransactionType { get; set; }

        [JsonProperty(PropertyName = nameof(CirrusUsername))]
        public string? CirrusUsername { get; set; }
    }

    public class CirrusPaymentApiResponse
    {
        [JsonProperty(PropertyName = nameof(CirrusPaymentURL))]
        public string? CirrusPaymentURL { get; set; }
    }
    public class CirrusPaymentPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var logger = container.Resolve<ILogger>();
            var service = container.Resolve<IOrganizationService>();
            var cirrusPaymentService = container.Resolve<ICirrusPaymentService>();

            logger.TraceInformation("Starting plugin.");
            logger.TraceInformation($"context.MessageName = {context.MessageName}.");

            if (context.MessageName == "rhs_cirruspaymenturl_new")
            {
                var inputRequest = GetInputParameters(context, logger);
                var outputResponse = new CirrusPaymentApiResponse();
                Entity entity = null;

                switch (inputRequest.TransactionType)
                {
                    case (int)NewTransactionType_GlobalOptionSet.Membership:
                        entity = service.Retrieve("rhs_membership", inputRequest.EntityRecord, new ColumnSet(true));
                        break;
                    case (int)NewTransactionType_GlobalOptionSet.Subscriptions:
                        entity = service.Retrieve("rhs_subscription", inputRequest.EntityRecord, new ColumnSet(true));
                        break;
                    case (int)NewTransactionType_GlobalOptionSet.Donation:
                        entity = service.Retrieve("rhs_donation", inputRequest.EntityRecord, new ColumnSet(true));
                        break;
                    case (int)NewTransactionType_GlobalOptionSet.GiftPack:
                        entity = service.Retrieve("rhs_giftpackorder", inputRequest.EntityRecord, new ColumnSet(true));
                        break;
                }

                Entity payer = service.Retrieve(inputRequest.PayerEntity, inputRequest.PayerRecord, new ColumnSet(true));
                string response = cirrusPaymentService.BuildCirrusURL(entity, payer, inputRequest.CirrusKeyVaultUrl, inputRequest.TotalAmount, inputRequest.CirrusUsername);
                //var responseJson = JsonConvert.DeserializeObject<Dictionary<string, string>>(response);

                outputResponse.CirrusPaymentURL = response;
                SetOutputParameters(context, outputResponse, logger);

                logger.TraceInformation("Ending plugin.");
            }
            else
            {
                throw new InvalidPluginExecutionException("Incorrect message name.");
            }
        }

        private CirrusPaymentApiRequest GetInputParameters(IPluginExecutionContext context, ILogger logger)
        {
            logger.TraceInformation("Starting helper method.");

            var inputParameters = context.InputParameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value);
            var inputJson = JsonConvert.SerializeObject(inputParameters);
            var inputRequest = JsonConvert.DeserializeObject<CirrusPaymentApiRequest>(inputJson);

            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(inputRequest))
            {
                string name = descriptor.Name;
                object value = descriptor.GetValue(inputRequest);
                logger.TraceInformation($"{name} = {value}");

                if ((name == "EntityRecord" && (value == null || (Guid)value == new Guid())) || (name == "CirrusKeyVaultUrl" && value == null))
                {
                    var errorMessage = $"Please input a value for {name}.";
                    logger.TraceError(errorMessage);
                    throw new InvalidPluginExecutionException(errorMessage);
                }
            }

            logger.TraceInformation("Ending helper method.");
            return inputRequest;
        }

        private void SetOutputParameters(IPluginExecutionContext context, CirrusPaymentApiResponse outputResponse, ILogger logger)
        {
            logger.TraceInformation("Starting helper method.");

            foreach (var property in outputResponse.GetType().GetProperties())
            {
                context.OutputParameters.AddOrUpdateIfNotNull(property.Name, property.GetValue(outputResponse, null));
                logger.TraceInformation($"{property.Name} = {property.GetValue(outputResponse, null)}");
            }

            logger.TraceInformation("Ending helper method.");
        }
    }
}
