﻿using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;
using System;
using System.Runtime.Serialization;

namespace Cultivate.Plugins.Core.CustomApi
{
    public class ConsentCreationApiRequest
    {
        [DataMember(Name = nameof(ContactId))]
        public string ContactId { get; set; }

        [DataMember(Name = "Data Sets")]
        public int DataSet { get; set; }
    }

    public class ConsentCreationApiResponse
    {
        [DataMember(Name = nameof(Result))]
        public bool Result { get; set; }

        [DataMember(Name = nameof(Error))]
        public string Error { get; set; }
    }

    public class ContactPointConsentCreationPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var tracingService = container.Resolve<ITracingService>();
            var service = container.Resolve<IOrganizationService>();

            try
            {
                if (context.MessageName != "rhs_consentscreation")
                {
                    throw new InvalidPluginExecutionException("Message Name is incorrect");
                }

                /// Get the input parameters from the custom API request
                var inputParameters = GetInputParameters(context, tracingService);

                // Retrieve the input parameters (contactid and dataset)
                if (string.IsNullOrEmpty(inputParameters.ContactId))
                {
                    throw new InvalidPluginExecutionException("Missing required 'contactid' input parameter.");
                }
                if (inputParameters.DataSet <= 0)
                {
                    throw new InvalidPluginExecutionException("Missing or invalid 'dataset' input parameter.");
                }

                tracingService.Trace($"Contact Id: {inputParameters.ContactId}");
                tracingService.Trace($"Data Set: {inputParameters.DataSet}");

                // Try to parse Contact Id into a GUID
                if (Guid.TryParse(inputParameters.ContactId, out Guid contactId))
                {
                    int dataSet = inputParameters.DataSet;

                    var contactPointConsentCreationService = new ContactPointConsentCreationService(tracingService, context, service);
                    contactPointConsentCreationService.ContactPointConsentCreationNewMember(contactId, dataSet);

                    // Return success result
                    var outputResponse = new ConsentCreationApiResponse
                    {
                        Error = string.Empty,
                        Result = true
                    };

                    SetOutputParameters(context, outputResponse);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace("ContactPointConsentCreationPlugin: {0}", ex.ToString());

                // Return error and failure result
                var outputResponseError = new ConsentCreationApiResponse
                {
                    Error = ex.Message,
                    Result = false
                };
                SetOutputParameters(context, outputResponseError);
            }
        }

        private ConsentCreationApiRequest GetInputParameters(IPluginExecutionContext context, ITracingService tracingService)
        {
            tracingService.Trace("Retrieving input parameters...");

            foreach (var key in context.InputParameters.Keys)
            {
                tracingService.Trace($"Key: {key}, Value: {context.InputParameters[key]?.ToString()}");
            }

            var inputParameters = new ConsentCreationApiRequest
            {
                ContactId = context.InputParameters.Contains("contactid") ? (string)context.InputParameters["contactid"] : null,
                DataSet = context.InputParameters.Contains("dataset") ? (int)context.InputParameters["dataset"] : 0
            };

            tracingService.Trace($"ContactId: {inputParameters.ContactId}, DataSet: {inputParameters.DataSet}");

            return inputParameters;
        }

        private void SetOutputParameters(IPluginExecutionContext context, ConsentCreationApiResponse outputResponse)
        {
            context.OutputParameters["error"] = outputResponse.Error;
            context.OutputParameters["result"] = outputResponse.Result;
        }
    }
}