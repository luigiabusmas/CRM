﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Donation.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class DonationUpdatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var donationService = container.Resolve<IDonationService>();
            var preImageName = "PreImageDonation";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Donation.EntityLogicalName)
                    {
                        var targetDonation = target.ToEntity<Donation>();
                        var preImageDonation = context.PreEntityImages[preImageName].ToEntity<Donation>();
                        var postImageDonation = new Donation()
                        {
                            Id = targetDonation.Id,
                            PaymentMethodCode = target.Contains(EntityNames.Donation.PaymentMethodCode) ? targetDonation.PaymentMethodCode : preImageDonation.PaymentMethodCode,
                            CancelDonation = target.Contains(EntityNames.Donation.CancelDonation) ? targetDonation.CancelDonation : preImageDonation.CancelDonation,
                            Issubmitpayment = target.Contains(EntityNames.Donation.Issubmitpayment) ? targetDonation.Issubmitpayment : preImageDonation.Issubmitpayment,
                            Startdate = target.Contains(EntityNames.Donation.Startdate) ? targetDonation.Startdate : preImageDonation.Startdate,
                            Enddate = target.Contains(EntityNames.Donation.Enddate) ? targetDonation.Enddate : preImageDonation.Enddate,
                            PayoutDate = target.Contains(EntityNames.Donation.PayoutDate) ? targetDonation.PayoutDate : preImageDonation.PayoutDate,
                            Statecode = target.Contains(EntityNames.Donation.Statecode) ? targetDonation.Statecode : preImageDonation.Statecode,
                            Statuscode = target.Contains(EntityNames.Donation.Statuscode) ? targetDonation.Statuscode : preImageDonation.Statuscode,
                        };

                        if (targetDonation.CancelDonation == true)
                        {
                            donationService.CancelDonation(targetDonation, postImageDonation);
                        }

                        if (target.Contains(EntityNames.Donation.Campaign) && preImageDonation.Campaign != targetDonation.Campaign)
                        {
                            donationService.PopulateDonationTypeResrictedFund(targetDonation);
                        }

                        if (donationService.ValidateIfPaymentSubmissionWasTriggered(preImageDonation, postImageDonation) ||
                            donationService.ValidateIfActivatedWithoutStartDate(preImageDonation, postImageDonation))
                        {
                            donationService.SetStartDate(ref target, ref postImageDonation);
                            donationService.SetEndDate(ref target, ref postImageDonation);
                            if (postImageDonation.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
                                donationService.SetPayoutDate(ref target, ref postImageDonation);
                        }
                    }
                }
            }
        }
    }
}
