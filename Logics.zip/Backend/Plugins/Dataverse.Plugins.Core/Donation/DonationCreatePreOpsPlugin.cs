﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
     [PluginRegistration(
        EntityLogicalName = EntityNames.Donation.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class DonationCreatePreOpsPlugin: Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var donationService = container.Resolve<IDonationService>();

            if (context.MessageName == "Create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity target = (Entity)context.InputParameters["Target"];

                if (target.LogicalName == EntityNames.Donation.EntityLogicalName)
                {
                    var targetDonation = target.ToEntity<Donation>();

                    if (target.Contains(EntityNames.Donation.Campaign))
                    {
                        donationService.PopulateDonationTypeResrictedFund(targetDonation);
                    }

                    if (targetDonation.Statuscode == DonationStatus.Active_ActivePaid || 
                        targetDonation.Statuscode == DonationStatus.Active_ActiveOngoing)
                    {
                        if (targetDonation.Startdate == null)
                            donationService.SetStartDate(ref target, ref targetDonation);
                        if (targetDonation.Enddate == null)
                            donationService.SetEndDate(ref target, ref targetDonation);
                        if (targetDonation.PayoutDate == null && targetDonation.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
                            donationService.SetPayoutDate(ref target, ref targetDonation);
                    }
                }
            }
        }
    }
}
