﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Donation.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class DonationUpdatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var paymentService = container.Resolve<IPaymentService>();
            var donationService = container.Resolve<IDonationService>();
            var postImageName = "PostImageDonation";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PostEntityImages.Contains(postImageName) && context.PostEntityImages[postImageName] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Donation.EntityLogicalName)
                    {
                        var postImageEntity = context.PostEntityImages[postImageName];

                        if (target.Contains("statuscode") && postImageEntity.GetAttributeValue<OptionSetValue>("statuscode").Value == 1)
                        {
                            donationService.CreateRecognitionRecord(target, postImageEntity);
                        }

                    }
                }
            }
        }
    }
}
