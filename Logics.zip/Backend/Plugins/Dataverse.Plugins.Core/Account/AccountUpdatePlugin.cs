//using Avanade.BizApps.Core.Constants;
//using Avanade.BizApps.Core.Plugins;
//using Avanade.BizApps.Core.Plugins.DependencyInjection;
//using Cultivate.BusinessLogic.Services;
//using Cultivate.Entities.Generated;
//using Microsoft.Xrm.Sdk;
//using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

//namespace Cultivate.Plugins.Core
//{
//    [PluginRegistration(
//        EntityLogicalName = Account.EntityLogicalName,
//        MessageName = MessageNames.Update,
//        Stage = Stage.PostOperation,
//        Mode = SdkMessageProcessingStepMode.Asynchronous,
//        FilteringAttributes = new []
//        {
//            EntityNames.Account.PrimaryContactId,
//            EntityNames.Account.Address1_City,
//            EntityNames.Account.Address1_Country,
//            EntityNames.Account.Address1_County,
//            EntityNames.Account.Address1_StateOrProvince,
//            EntityNames.Account.Address1_PostalCode,
//            EntityNames.Account.Address1_Line1,
//            EntityNames.Account.Address1_Line2,
//            EntityNames.Account.Address1_Line3,
//            EntityNames.Account.Address1_Name,
//        },
//        IncludePreImage = true,
//        PreImageAttributes = new [] { "*" }
//    )]
//    public class AccountUpdatePlugin : Plugin<Account>, IPlugin
//    {
//        public override void Execute(IDependencyContainer container, Account account)
//        {
//            var syncService = container.Resolve<IAccountContactSyncService>();
//            syncService.SyncAccountDetailsToPrimaryContact(account);
//        }
//    }
//}