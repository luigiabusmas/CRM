﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = Account.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class AccountUpdatePreOpslugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var accountUpdateService = container.Resolve<AccountUpdateService>();
            var preImageName = "PreImageAccount";

            if (context.MessageName == "Update" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Account.EntityLogicalName)
                {
                    var targetAccount = targetEntity.ToEntity<Account>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageAccount = preImageEntity.ToEntity<Account>();

                    if ((targetEntity.Contains(EntityNames.Account.Loqate_Latitude) && preImageAccount.Loqate_Latitude != targetAccount.Loqate_Latitude) ||
                         (targetEntity.Contains(EntityNames.Account.Loqate_Longitude) && preImageAccount.Loqate_Longitude != targetAccount.Loqate_Longitude) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress1County) && preImageAccount.LoqateAddress1County != targetAccount.LoqateAddress1County) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress1HouseName) && preImageAccount.LoqateAddress1HouseName != targetAccount.LoqateAddress1HouseName) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress2County) && preImageAccount.LoqateAddress2County != targetAccount.LoqateAddress2County) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress2HouseName) && preImageAccount.LoqateAddress2HouseName != targetAccount.LoqateAddress2HouseName) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress2Latitude) && preImageAccount.LoqateAddress2Latitude != targetAccount.LoqateAddress2Latitude) ||
                         (targetEntity.Contains(EntityNames.Account.LoqateAddress2Longitude) && preImageAccount.LoqateAddress2Longitude != targetAccount.LoqateAddress2Longitude))
                    {
                        accountUpdateService.SetLatLongCountyAddress12(targetEntity, preImageAccount, targetAccount);
                    }

                    accountUpdateService.PopulateGDPRDeletionDate(targetAccount);
                }
            }
        }
    }
}