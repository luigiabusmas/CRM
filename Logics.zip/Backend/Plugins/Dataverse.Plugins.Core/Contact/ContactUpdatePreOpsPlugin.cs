﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Contact.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class ContactUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var contactUpdateService = container.Resolve<ContactUpdateService>();
            var preImageName = "PreImageContact";
            var commonService = container.Resolve<ICommonService>();

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Contact.EntityLogicalName)
                    {
                        var preImageContact = context.PreEntityImages[preImageName].ToEntity<Contact>();

                        // Determine what the New First Name and New Last Name will be
                        // If it's in the Target, use the new value. If not, use the Pre-Image value.
                        string currentFName = target.Contains(EntityNames.Contact.FirstName)
                            ? target.GetAttributeValue<string>(EntityNames.Contact.FirstName)
                            : preImageContact.FirstName;

                        string currentLName = target.Contains(EntityNames.Contact.LastName)
                            ? target.GetAttributeValue<string>(EntityNames.Contact.LastName)
                            : preImageContact.LastName;

                        tracingService.Trace("ContactUpdatePreOpsPlugin: Processing Name Capitalization for Update.");

                        if (target.Contains(EntityNames.Contact.FirstName))
                        {
                            currentFName = commonService.capitalizeNameInput(currentFName, false);
                            target[EntityNames.Contact.FirstName] = currentFName;
                        }
                        if (target.Contains(EntityNames.Contact.LastName))
                        {
                            currentLName = commonService.capitalizeNameInput(currentLName, true);
                            target[EntityNames.Contact.LastName] = currentLName;
                        }

                        // Force fullname update
                        // Ensures the header and lookups refresh immediately without a page reload
                        target[EntityNames.Contact.FullName] = $"{currentFName} {currentLName}".Trim();

                        var targetContact = target.ToEntity<Contact>();

                        var postImageContact = new Contact()
                        {
                            Id = targetContact.Id,
                            FullName = target.Contains(EntityNames.Contact.FullName) ? targetContact.FullName : preImageContact.FullName,

                            Address1_Name = target.Contains(EntityNames.Contact.Address1_Name) ? targetContact.Address1_Name : preImageContact.Address1_Name,
                            Address2_County = target.Contains(EntityNames.Contact.Address2_County) ? targetContact.Address2_County : preImageContact.Address2_County,

                            //Address 1
                            Address1_City = target.Contains(EntityNames.Contact.Address1_City) ? targetContact.Address1_City : preImageContact.Address1_City,
                            Address1_Country = target.Contains(EntityNames.Contact.Address1_Country) ? targetContact.Address1_Country : preImageContact.Address1_Country,
                            Address1_PostalCode = target.Contains(EntityNames.Contact.Address1_PostalCode) ? targetContact.Address1_PostalCode : preImageContact.Address1_PostalCode,
                            Address1_Line1 = target.Contains(EntityNames.Contact.Address1_Line1) ? targetContact.Address1_Line1 : preImageContact.Address1_Line1,
                            Address1_Line2 = target.Contains(EntityNames.Contact.Address1_Line2) ? targetContact.Address1_Line2 : preImageContact.Address1_Line2,
                            Address1_Line3 = target.Contains(EntityNames.Contact.Address1_Line3) ? targetContact.Address1_Line3 : preImageContact.Address1_Line3,
                            Address1_StateOrProvince = target.Contains(EntityNames.Contact.Address1_StateOrProvince) ? targetContact.Address1_StateOrProvince : preImageContact.Address1_StateOrProvince,
                            LoqateHomeAddressHouseName = target.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? targetContact.LoqateHomeAddressHouseName : preImageContact.LoqateHomeAddressHouseName,
                            LoqateAddress1County = target.Contains(EntityNames.Contact.LoqateAddress1County) ? targetContact.LoqateAddress1County : preImageContact.LoqateAddress1County,

                            //Address 2
                            Address2_City = target.Contains(EntityNames.Contact.Address2_City) ? targetContact.Address2_City : preImageContact.Address2_City,
                            Address2_Country = target.Contains(EntityNames.Contact.Address2_Country) ? targetContact.Address2_Country : preImageContact.Address2_Country,
                            Address2_PostalCode = target.Contains(EntityNames.Contact.Address2_PostalCode) ? targetContact.Address2_PostalCode : preImageContact.Address2_PostalCode,
                            Address2_Line1 = target.Contains(EntityNames.Contact.Address2_Line1) ? targetContact.Address2_Line1 : preImageContact.Address2_Line1,
                            Address2_Line2 = target.Contains(EntityNames.Contact.Address2_Line2) ? targetContact.Address2_Line2 : preImageContact.Address2_Line2,
                            Address2_Line3 = target.Contains(EntityNames.Contact.Address2_Line3) ? targetContact.Address2_Line3 : preImageContact.Address2_Line3,
                            Address2_StateOrProvince = target.Contains(EntityNames.Contact.Address2_StateOrProvince) ? targetContact.Address2_StateOrProvince : preImageContact.Address2_StateOrProvince,
                            LoqateAddress2County = target.Contains(EntityNames.Contact.LoqateAddress2County) ? targetContact.LoqateAddress2County : preImageContact.LoqateAddress2County,
                            LoqateAddress2HouseName = target.Contains(EntityNames.Contact.LoqateAddress2HouseName) ? targetContact.LoqateAddress2HouseName : preImageContact.LoqateAddress2HouseName,
                            SecondaryAddressTypeCode = target.Contains(EntityNames.Contact.SecondaryAddressTypeCode) ? targetContact.SecondaryAddressTypeCode : preImageContact.SecondaryAddressTypeCode,

                            //Loqate Address

                            LoqateAddress3City = target.Contains(EntityNames.Contact.LoqateAddress3City) ? targetContact.LoqateAddress3City : preImageContact.LoqateAddress3City,
                            LoqateAddress3Country = target.Contains(EntityNames.Contact.LoqateAddress3Country) ? targetContact.LoqateAddress3Country : preImageContact.LoqateAddress3Country,
                            LoqateAddress3County = target.Contains(EntityNames.Contact.LoqateAddress3County) ? targetContact.LoqateAddress3County : preImageContact.LoqateAddress3County,
                            LoqateAddress3HouseName = target.Contains(EntityNames.Contact.LoqateAddress3HouseName) ? targetContact.LoqateAddress3HouseName : preImageContact.LoqateAddress3HouseName,
                            LoqateAddress3Line1 = target.Contains(EntityNames.Contact.LoqateAddress3Line1) ? targetContact.LoqateAddress3Line1 : preImageContact.LoqateAddress3Line1,
                            LoqateAddress3Line2 = target.Contains(EntityNames.Contact.LoqateAddress3Line2) ? targetContact.LoqateAddress3Line2 : preImageContact.LoqateAddress3Line2,
                            LoqateAddress3Line3 = target.Contains(EntityNames.Contact.LoqateAddress3Line3) ? targetContact.LoqateAddress3Line3 : preImageContact.LoqateAddress3Line3,
                            LoqateAddress3Line4 = target.Contains(EntityNames.Contact.LoqateAddress3Line4) ? targetContact.LoqateAddress3Line4 : preImageContact.LoqateAddress3Line4,
                            LoqateAddress3Postcode = target.Contains(EntityNames.Contact.LoqateAddress3Postcode) ? targetContact.LoqateAddress3Postcode : preImageContact.LoqateAddress3Postcode,
                            AlternateAddressTypeCode = target.Contains(EntityNames.Contact.AlternateAddressTypeCode) ? targetContact.AlternateAddressTypeCode : preImageContact.AlternateAddressTypeCode

                            // 
                        };

                        tracingService.Trace("Got Pre Image Contact");
                        var fields = new List<(string value, string name, string fieldName)>();

                        if (target.Contains(EntityNames.Contact.FirstName) && preImageContact.FirstName != targetContact.FirstName)
                        {
                            fields.Add((targetContact.FirstName, "First Name", EntityNames.Contact.FirstName));
                            if ((!target.Contains(EntityNames.Contact.Initials) && string.IsNullOrWhiteSpace(targetContact.Initials)) ||
                                (target.Contains(EntityNames.Contact.Initials) && string.IsNullOrWhiteSpace(targetContact.Initials)))
                            {
                                contactUpdateService.contactPopulateInitials(targetContact);
                            }
                        }

                        if (target.Contains(EntityNames.Contact.LastName) && preImageContact.LastName != targetContact.LastName)
                        {
                            fields.Add((targetContact.LastName, "Last Name", EntityNames.Contact.LastName));
                        }

                        if (target.Contains(EntityNames.Contact.NickName) && preImageContact.NickName != targetContact.NickName)
                        {
                            fields.Add((targetContact.NickName, "Preferred Name", EntityNames.Contact.NickName));
                        }

                        if (target.Contains(EntityNames.Contact.Initials) && preImageContact.Initials != targetContact.Initials)
                        {
                            fields.Add((targetContact.Initials, "Initials", EntityNames.Contact.Initials));
                        }

                        if (fields.Count > 0)
                        {
                            contactUpdateService.validatedNameInputUpdate(targetContact, fields.ToArray());
                        }

                        if (targetContact.BirthDate != null && preImageContact.BirthDate != targetContact.BirthDate)
                        {
                            contactUpdateService.contactPopulateAge(targetContact);
                        }

                        if ((target.Contains(EntityNames.Contact.Address1_PostalCode) && preImageContact.Address1_PostalCode != targetContact.Address1_PostalCode) ||
                           (target.Contains(EntityNames.Contact.Loqate_Latitude) && preImageContact.Loqate_Latitude != targetContact.Loqate_Latitude) ||
                           (target.Contains(EntityNames.Contact.Loqate_Longitude) && preImageContact.Loqate_Longitude != targetContact.Loqate_Longitude) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress1County) && preImageContact.LoqateAddress1County != targetContact.LoqateAddress1County) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2County) && preImageContact.LoqateAddress2County != targetContact.LoqateAddress2County) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2HouseName) && preImageContact.LoqateAddress2HouseName != targetContact.LoqateAddress2HouseName) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2Latitude) && preImageContact.LoqateAddress2Latitude != targetContact.LoqateAddress2Latitude) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2Longitude) && preImageContact.LoqateAddress2Longitude != targetContact.LoqateAddress2Longitude) ||
                           (target.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) && preImageContact.LoqateHomeAddressHouseName != targetContact.LoqateHomeAddressHouseName)
                        )
                        {
                            contactUpdateService.populateAddressOnUpdate(target, preImageContact, targetContact);
                        }

                        if ((target.Contains(EntityNames.Contact.LoqateAddress3City) && preImageContact.LoqateAddress3City != targetContact.LoqateAddress3City) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Country) && preImageContact.LoqateAddress3Country != targetContact.LoqateAddress3Country) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3County) && preImageContact.LoqateAddress3County != targetContact.LoqateAddress3County) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3HouseName) && preImageContact.LoqateAddress3HouseName != targetContact.LoqateAddress3HouseName) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Latitude) && preImageContact.LoqateAddress3Latitude != targetContact.LoqateAddress3Latitude) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line1) && preImageContact.LoqateAddress3Line1 != targetContact.LoqateAddress3Line1) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line2) && preImageContact.LoqateAddress3Line2 != targetContact.LoqateAddress3Line2) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line3) && preImageContact.LoqateAddress3Line3 != targetContact.LoqateAddress3Line3) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line4) && preImageContact.LoqateAddress3Line4 != targetContact.LoqateAddress3Line4) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Longitude) && preImageContact.LoqateAddress3Longitude != targetContact.LoqateAddress3Longitude) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Postcode) && preImageContact.LoqateAddress3Postcode != targetContact.LoqateAddress3Postcode)
                        )
                        {
                            contactUpdateService.populateLoqateAddressOnUpdate(target, preImageContact, targetContact);
                        }



                        //Triger whenever contact is updated (no filter)
                        contactUpdateService.contactPopulateGDPRDeletionDate(targetContact);
                    }
                }
            }
        }

    }
}