using Avanade.BizApps.Core.CommandDispatcher.EntryPoint;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Contact.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class ContactCreatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var contactCreateService = container.Resolve<IContactCreateService>();
            var commonService = container.Resolve<ICommonService>();

            if (context.MessageName == "Create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Contact.EntityLogicalName)
                {
                    // Get current values
                    string fName = targetEntity.GetAttributeValue<string>(EntityNames.Contact.FirstName) ?? "";
                    string lName = targetEntity.GetAttributeValue<string>(EntityNames.Contact.LastName) ?? "";

                    tracingService.Trace("ContactCreatePreOpsPlugin: Capitalizing names.");

                    // Fix the casing in the target fields
                    string capitalizedFirstName = commonService.capitalizeNameInput(fName, false);
                    string capitalizedLastName = commonService.capitalizeNameInput(lName, true);

                    targetEntity[EntityNames.Contact.FirstName] = capitalizedFirstName;
                    targetEntity[EntityNames.Contact.LastName] = capitalizedLastName;

                    // Force fullname update (fixes the header and lookups)
                    // Combine them manually so the system doesn't use the old lowercase version
                    targetEntity[EntityNames.Contact.FullName] = $"{capitalizedFirstName} {capitalizedLastName}".Trim();

                    // Map to targetContact for the rest of the services
                    var targetContact = targetEntity.ToEntity<Contact>();

                    if (targetContact.LogicalName == Contact.EntityLogicalName)
                    {
                        contactCreateService.contactPopulateFieldOnCreate(targetContact);
                        contactCreateService.validatedNameInputOnCreate(targetContact);
                        contactCreateService.contactPopulateSalutation(targetContact);
                        contactCreateService.contactPopulateLabelName(targetContact);
                        contactCreateService.contactSetAddressFieldsOnCreate(targetContact);
                    }

                }
            }
        }
    }
}