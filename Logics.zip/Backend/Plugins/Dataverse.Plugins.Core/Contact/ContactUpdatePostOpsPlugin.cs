using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Contact.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        Mode = SdkMessageProcessingStepMode.Asynchronous,
        FilteringAttributes = new []
        {
            EntityNames.Contact.Address1_City,
            EntityNames.Contact.Address1_Line1,
            EntityNames.Contact.Address1_Name,
            EntityNames.Contact.EMailAddress1, 
            EntityNames.Contact.Telephone1, 
            EntityNames.Contact.Address1_PostalCode,
            EntityNames.Contact.Title,
        },
        IncludePreImage = true,
        PreImageAttributes = new [] 
        {
            EntityNames.Contact.Address1_City,
            EntityNames.Contact.Address1_Line1,
            EntityNames.Contact.Address1_Name,
            EntityNames.Contact.EMailAddress1,
            EntityNames.Contact.Telephone1,
            EntityNames.Contact.Address1_PostalCode,
            EntityNames.Contact.Title,
        }
    )]
    public class ContactUpdatePostOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var contactUpdateService = container.Resolve<ContactUpdateService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var productService = container.Resolve<IProductService>();
            var preImageName = "PreImageContact";
            var postImageName = "PostImageContact";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];
                    var targetContact = target.ToEntity<Contact>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageContact = preImageEntity.ToEntity<Contact>();
                    var postImageContact = new Contact()
                    {
                        Id = targetContact.Id,
                        Title = target.Contains(EntityNames.Contact.Title) ? targetContact.Title : preImageContact.Title,
                        FirstName = target.Contains(EntityNames.Contact.FirstName) ? targetContact.FirstName : preImageContact.FirstName,
                        LastName = target.Contains(EntityNames.Contact.LastName) ? targetContact.LastName : preImageContact.LastName,
                        Initials = target.Contains(EntityNames.Contact.Initials) ? targetContact.Initials : preImageContact.Initials,
                        FullName = target.Contains(EntityNames.Contact.FullName) ? targetContact.FullName : preImageContact.FullName,
                        Suffix = target.Contains(EntityNames.Contact.Suffix) ? targetContact.Suffix : preImageContact.Suffix,

                        Address1_Name = target.Contains(EntityNames.Contact.Address1_Name) ? targetContact.Address1_Name : preImageContact.Address1_Name,
                        Address2_County = target.Contains(EntityNames.Contact.Address2_County) ? targetContact.Address2_County : preImageContact.Address2_County,

                        //Address 1
                        Address1_City = target.Contains(EntityNames.Contact.Address1_City) ? targetContact.Address1_City : preImageContact.Address1_City,
                        Address1_Country = target.Contains(EntityNames.Contact.Address1_Country) ? targetContact.Address1_Country : preImageContact.Address1_Country,
                        Address1_PostalCode = target.Contains(EntityNames.Contact.Address1_PostalCode) ? targetContact.Address1_PostalCode : preImageContact.Address1_PostalCode,
                        Address1_Line1 = target.Contains(EntityNames.Contact.Address1_Line1) ? targetContact.Address1_Line1 : preImageContact.Address1_Line1,
                        Address1_Line2 = target.Contains(EntityNames.Contact.Address1_Line2) ? targetContact.Address1_Line2 : preImageContact.Address1_Line2,
                        Address1_Line3 = target.Contains(EntityNames.Contact.Address1_Line3) ? targetContact.Address1_Line3 : preImageContact.Address1_Line3,
                        Address1_StateOrProvince = target.Contains(EntityNames.Contact.Address1_StateOrProvince) ? targetContact.Address1_StateOrProvince : preImageContact.Address1_StateOrProvince,
                        LoqateHomeAddressHouseName = target.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? targetContact.LoqateHomeAddressHouseName : preImageContact.LoqateHomeAddressHouseName,
                        LoqateAddress1County = target.Contains(EntityNames.Contact.LoqateAddress1County) ? targetContact.LoqateAddress1County : preImageContact.LoqateAddress1County,

                        //Address 2
                        Address2_City = target.Contains(EntityNames.Contact.Address2_City) ? targetContact.Address2_City : preImageContact.Address2_City,
                        Address2_Country = target.Contains(EntityNames.Contact.Address2_Country) ? targetContact.Address2_Country : preImageContact.Address2_Country,
                        Address2_PostalCode = target.Contains(EntityNames.Contact.Address2_PostalCode) ? targetContact.Address2_PostalCode : preImageContact.Address2_PostalCode,
                        Address2_Line1 = target.Contains(EntityNames.Contact.Address2_Line1) ? targetContact.Address2_Line1 : preImageContact.Address2_Line1,
                        Address2_Line2 = target.Contains(EntityNames.Contact.Address2_Line2) ? targetContact.Address2_Line2 : preImageContact.Address2_Line2,
                        Address2_Line3 = target.Contains(EntityNames.Contact.Address2_Line3) ? targetContact.Address2_Line3 : preImageContact.Address2_Line3,
                        Address2_StateOrProvince = target.Contains(EntityNames.Contact.Address2_StateOrProvince) ? targetContact.Address2_StateOrProvince : preImageContact.Address2_StateOrProvince,
                        LoqateAddress2County = target.Contains(EntityNames.Contact.LoqateAddress2County) ? targetContact.LoqateAddress2County : preImageContact.LoqateAddress2County,
                        LoqateAddress2HouseName = target.Contains(EntityNames.Contact.LoqateAddress2HouseName) ? targetContact.LoqateAddress2HouseName : preImageContact.LoqateAddress2HouseName,
                        SecondaryAddressTypeCode = target.Contains(EntityNames.Contact.SecondaryAddressTypeCode) ? targetContact.SecondaryAddressTypeCode : preImageContact.SecondaryAddressTypeCode,

                        //Loqate Address

                        LoqateAddress3City = target.Contains(EntityNames.Contact.LoqateAddress3City) ? targetContact.LoqateAddress3City : preImageContact.LoqateAddress3City,
                        LoqateAddress3Country = target.Contains(EntityNames.Contact.LoqateAddress3Country) ? targetContact.LoqateAddress3Country : preImageContact.LoqateAddress3Country,
                        LoqateAddress3County = target.Contains(EntityNames.Contact.LoqateAddress3County) ? targetContact.LoqateAddress3County : preImageContact.LoqateAddress3County,
                        LoqateAddress3HouseName = target.Contains(EntityNames.Contact.LoqateAddress3HouseName) ? targetContact.LoqateAddress3HouseName : preImageContact.LoqateAddress3HouseName,
                        LoqateAddress3Line1 = target.Contains(EntityNames.Contact.LoqateAddress3Line1) ? targetContact.LoqateAddress3Line1 : preImageContact.LoqateAddress3Line1,
                        LoqateAddress3Line2 = target.Contains(EntityNames.Contact.LoqateAddress3Line2) ? targetContact.LoqateAddress3Line2 : preImageContact.LoqateAddress3Line2,
                        LoqateAddress3Line3 = target.Contains(EntityNames.Contact.LoqateAddress3Line3) ? targetContact.LoqateAddress3Line3 : preImageContact.LoqateAddress3Line3,
                        LoqateAddress3Line4 = target.Contains(EntityNames.Contact.LoqateAddress3Line4) ? targetContact.LoqateAddress3Line4 : preImageContact.LoqateAddress3Line4,
                        LoqateAddress3Postcode = target.Contains(EntityNames.Contact.LoqateAddress3Postcode) ? targetContact.LoqateAddress3Postcode : preImageContact.LoqateAddress3Postcode,
                        AlternateAddressTypeCode = target.Contains(EntityNames.Contact.AlternateAddressTypeCode) ? targetContact.AlternateAddressTypeCode : preImageContact.AlternateAddressTypeCode
                    };
                    bool updateLabelName = false;
                    if (target.LogicalName == EntityNames.Contact.EntityLogicalName)
                    {
                        #region Deceased
                        if (target.Contains(EntityNames.Contact.Deceased) && targetContact.Deceased == true)
                        {
                            contactUpdateService.CancelDDIsOfContact(targetContact);
                            contactUpdateService.GetMembershipWhereMemberIsDeceased(targetContact, propertyRetrievalService, productService);
                            contactUpdateService.CancelSubscriptionContactIsDeceased(targetContact);
                            contactUpdateService.CancelDonationsOfContactWhenDeceased(targetContact);
                        }
                        #endregion

                        #region Student Cancellation
                        if (target.Contains(EntityNames.Contact.StudentIdverified) && target[EntityNames.Contact.StudentIdverified] != null && ((OptionSetValue)target[EntityNames.Contact.StudentIdverified]).Value == 120000002)
                        {
                            //var contactService = new ContactUpdateService(tracingService, context, service);
                            contactUpdateService.HandleStudentCancellation(target, tracingService, service);
                        }
                        #endregion


                        if ((target.Contains(EntityNames.Contact.Suffix) && preImageContact.Suffix != postImageContact.Suffix) ||
                            (target.Contains(EntityNames.Contact.Title) && preImageContact.Title != postImageContact.Title) ||
                            (target.Contains(EntityNames.Contact.LastName) && preImageContact.LastName != postImageContact.LastName) ||
                            (target.Contains(EntityNames.Contact.Initials) && preImageContact.Initials != postImageContact.Initials)

                            )
                        {
                            contactUpdateService.contactPopulateSalutation(postImageContact);
                            contactUpdateService.contactPopulateLabelName(postImageContact);
                          
                        }

                        //If FirstName, LastName, Initials, or Title is updated trigger Name Change Record creation
                        if ((target.Contains(EntityNames.Contact.Title) && preImageContact.Title != postImageContact.Title) ||
                            (target.Contains(EntityNames.Contact.FirstName) && preImageContact.FirstName != postImageContact.FirstName) ||
                            (target.Contains(EntityNames.Contact.LastName) && preImageContact.LastName != postImageContact.LastName) ||
                            (target.Contains(EntityNames.Contact.Initials) && preImageContact.Initials != postImageContact.Initials)
                            )
                        {
                            contactUpdateService.contactCreateNameChange(postImageContact, preImageContact);

                        }

                        if ((target.Contains(EntityNames.Contact.Address1_City) && preImageContact.Address1_City != targetContact.Address1_City) ||
                           (target.Contains(EntityNames.Contact.Address1_Country) && preImageContact.Address1_Country != targetContact.Address1_Country) ||
                           (target.Contains(EntityNames.Contact.Address1_PostalCode) && preImageContact.Address1_PostalCode != targetContact.Address1_PostalCode) ||
                           (target.Contains(EntityNames.Contact.Address1_Line1) && preImageContact.Address1_Line1 != targetContact.Address1_Line1) ||
                           (target.Contains(EntityNames.Contact.Address1_Line2) && preImageContact.Address1_Line2 != targetContact.Address1_Line2) ||
                           (target.Contains(EntityNames.Contact.Address1_Line3) && preImageContact.Address1_Line3 != targetContact.Address1_Line3) ||
                           (target.Contains(EntityNames.Contact.Address1_StateOrProvince) && preImageContact.Address1_StateOrProvince != targetContact.Address1_StateOrProvince) ||
                           (target.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) && preImageContact.LoqateHomeAddressHouseName != targetContact.LoqateHomeAddressHouseName) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress1County) && preImageContact.LoqateAddress1County != targetContact.LoqateAddress1County)
                        )
                        {
                            contactUpdateService.contactCreateAddress1Change(postImageContact, preImageContact);
                        }

                        if ((target.Contains(EntityNames.Contact.Address2_City) && preImageContact.Address2_City != targetContact.Address2_City) ||
                           (target.Contains(EntityNames.Contact.Address2_Country) && preImageContact.Address2_Country != targetContact.Address2_Country) ||
                           (target.Contains(EntityNames.Contact.Address2_PostalCode) && preImageContact.Address2_PostalCode != targetContact.Address2_PostalCode) ||
                           (target.Contains(EntityNames.Contact.Address2_Line1) && preImageContact.Address2_Line1 != targetContact.Address2_Line1) ||
                           (target.Contains(EntityNames.Contact.Address2_Line2) && preImageContact.Address2_Line2 != targetContact.Address2_Line2) ||
                           (target.Contains(EntityNames.Contact.Address2_Line3) && preImageContact.Address2_Line3 != targetContact.Address2_Line3) ||
                           (target.Contains(EntityNames.Contact.Address2_StateOrProvince) && preImageContact.Address2_StateOrProvince != targetContact.Address2_StateOrProvince) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2HouseName) && preImageContact.LoqateAddress2HouseName != targetContact.LoqateAddress2HouseName) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress2County) && preImageContact.LoqateAddress2County != targetContact.LoqateAddress2County) ||
                           (target.Contains(EntityNames.Contact.SecondaryAddressTypeCode) && preImageContact.SecondaryAddressTypeCode != targetContact.SecondaryAddressTypeCode)
                        )
                        {
                            contactUpdateService.contactCreateAddress2Change(postImageContact, preImageContact);
                        }

                        if ((target.Contains(EntityNames.Contact.LoqateAddress3City) && preImageContact.LoqateAddress3City != targetContact.LoqateAddress3City) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Country) && preImageContact.LoqateAddress3Country != targetContact.LoqateAddress3Country) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Postcode) && preImageContact.LoqateAddress3Postcode != targetContact.LoqateAddress3Postcode) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line1) && preImageContact.LoqateAddress3Line1 != targetContact.LoqateAddress3Line1) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line2) && preImageContact.LoqateAddress3Line2 != targetContact.LoqateAddress3Line2) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line3) && preImageContact.LoqateAddress3Line3 != targetContact.LoqateAddress3Line3) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3Line4) && preImageContact.LoqateAddress3Line4 != targetContact.LoqateAddress3Line4) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3HouseName) && preImageContact.LoqateAddress3HouseName != targetContact.LoqateAddress3HouseName) ||
                           (target.Contains(EntityNames.Contact.LoqateAddress3County) && preImageContact.LoqateAddress3County != targetContact.LoqateAddress3County) ||
                           (target.Contains(EntityNames.Contact.AlternateAddressTypeCode) && preImageContact.AlternateAddressTypeCode != targetContact.AlternateAddressTypeCode)
                        )
                        {
                            contactUpdateService.contactCreateLoqateAddressChange(postImageContact, preImageContact);
                        }

                    }
                }
            }
        }

    }
}