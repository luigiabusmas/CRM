using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Contact.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        Mode = SdkMessageProcessingStepMode.Asynchronous,
        FilteringAttributes = new []
        {
            EntityNames.Contact.Address1_City,
            EntityNames.Contact.Address1_Line1,
            EntityNames.Contact.Address1_Name,
            EntityNames.Contact.EMailAddress1, 
            EntityNames.Contact.Telephone1, 
            EntityNames.Contact.Address1_PostalCode,
        },
        IncludePreImage = true,
        PreImageAttributes = new [] 
        {
            EntityNames.Contact.Address1_City,
            EntityNames.Contact.Address1_Line1,
            EntityNames.Contact.Address1_Name,
            EntityNames.Contact.EMailAddress1,
            EntityNames.Contact.Telephone1,
            EntityNames.Contact.Address1_PostalCode,
        }
    )]
    public class ContactUpdatePostOpsAsyncPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var contactUpdateService = container.Resolve<ContactUpdateService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var productService = container.Resolve<IProductService>();

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    var targetContact = target.ToEntity<Contact>();

                    if (target.LogicalName == EntityNames.Contact.EntityLogicalName)
                    {
                        if (context.PreEntityImages.Contains("PreImageContact") && context.PreEntityImages["PreImageContact"] is Entity)
                        {
                            Entity preImage = (Entity)context.PreEntityImages["PreImageContact"];

                            if (target.Contains(EntityNames.Contact.EMailAddress1) || target.Contains(EntityNames.Contact.Telephone1) || target.Contains(EntityNames.Contact.Address1_PostalCode) || target.Contains(EntityNames.Contact.FullName))
                            {
                                contactUpdateService.CreateDeactivateConsents(target, preImage);
                            }
                        }
                    }
                }
            }
        }

    }
}