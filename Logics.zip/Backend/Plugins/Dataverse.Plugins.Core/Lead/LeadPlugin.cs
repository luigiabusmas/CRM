﻿using Microsoft.Xrm.Sdk;
using System;
using System.Text.RegularExpressions;

namespace Cultivate.Plugins.Core.Lead
{
    public class LastNameValidatorPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // Check if the target entity is Lead
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity entity)
                {
                    if (entity.LogicalName != "lead")
                        return;

                    // No additional functionality, just logging for now
                    tracingService.Trace("Processing Lead entity operation.");
                }
            }
            catch (Exception ex)
            {
                // Trace and rethrow the exception
                tracingService.Trace($"Exception: {ex.Message}");
                throw new InvalidPluginExecutionException(ex.Message, ex);
            }
        }
    }
}
