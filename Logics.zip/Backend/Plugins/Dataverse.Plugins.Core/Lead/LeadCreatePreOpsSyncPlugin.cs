﻿using Microsoft.Xrm.Sdk;
using System;
using System.Text.RegularExpressions;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = "lead",
        MessageName = "Create",
        Stage = Stage.PreOperation,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class LeadCreatePreOpsSyncPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var leadService = container.Resolve<ILeadService>();
            var tracingService = container.Resolve<ITracingService>();

            try
            {
                // Check if the target entity is Lead
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity entity)
                {
                    if (entity.LogicalName != "lead")
                        return;

                    // Process the Create operation for Lead
                    tracingService.Trace("Processing Create operation for Lead.");
                    leadService.ValidateLastName(entity, tracingService);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Exception: {ex.Message}");
                throw new InvalidPluginExecutionException(ex.Message, ex);
            }
        }
    }
}