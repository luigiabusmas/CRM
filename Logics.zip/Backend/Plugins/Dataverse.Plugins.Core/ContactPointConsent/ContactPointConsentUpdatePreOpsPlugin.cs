﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous,
        FilteringAttributes = new[]
        {
            EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value,
            EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason,
            EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf,
            EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source,
            EntityNames.Msdynmkt_contactpointconsent4.ConsentSource
        }
    )]
    public class ContactPointConsentUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var preImageName = "PreImageContactPointConsent";
            var contactPointConsentService = container.Resolve<IContactPointConsentUpdateService>();
            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                Entity targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName)
                {
                    var preImageEntity = context.PreEntityImages[preImageName];

                    if (targetEntity.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value)
                        || targetEntity.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason)
                        || targetEntity.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf)
                        || targetEntity.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source)
                        || targetEntity.Contains(EntityNames.Msdynmkt_contactpointconsent4.ConsentSource))
                    {
                        targetEntity.Id = contactPointConsentService.CreateConsentAuditTrailHistory(targetEntity, preImageEntity);
                    }
                }
            }
        }
    }
}