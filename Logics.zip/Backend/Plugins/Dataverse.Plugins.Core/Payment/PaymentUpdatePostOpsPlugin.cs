﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Payment.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class PaymentUpdatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var paymentService = container.Resolve<IPaymentService>();
            var postImageName = "PostImagePayment";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PostEntityImages.Contains(postImageName) && context.PostEntityImages[postImageName] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Payment.EntityLogicalName)
                    {
                        var postImageEntity = context.PostEntityImages[postImageName];
                        var postImagePayment = postImageEntity.ToEntity<Payment>();
                      
                        paymentService.GiftAidOverrideToEligible(postImageEntity);
                        paymentService.SetApprovedForNavBy_PreOp(postImagePayment, context.InitiatingUserId);
                        //paymentService.CompareGiftAidThresholdOnUpdate(postImageEntity);


                        var transaction = paymentService.RetrieveTransaction(postImagePayment);
                        if (transaction != null)
                        {
                            paymentService.UpdateTransactionOustandingAmountOnPay(postImagePayment, transaction);
                            paymentService.CancelAssociatedRecordsWhenDDPaymentCountReachThreshold(postImagePayment, transaction);
                            paymentService.UpdateDonationAmountOnPayOrOverdue(postImagePayment, transaction);
                        }

                        var paymentSchedule = paymentService.RetrievePaymentSchedule(postImagePayment);
                        if (paymentSchedule != null)
                        {
                            paymentService.SetPaymentScheduleStatus(postImagePayment, paymentSchedule);
                        }
                    }
                }
            }
        }
    }
}
