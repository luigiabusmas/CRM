﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Payment.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class PaymentUpdatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var paymentService = container.Resolve<IPaymentService>();
            var preImageName = "PreImagePayment";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
                {
                    var targetEntity = (Entity)context.InputParameters["Target"];

                    if (targetEntity.LogicalName == EntityNames.Payment.EntityLogicalName)
                    {
                        #region Initialization
                        var targetPayment = targetEntity.ToEntity<Payment>();
                        var preImageEntity = context.PreEntityImages[preImageName];
                        var preImagePayment = preImageEntity.ToEntity<Payment>();
                        var postImagePayment = new Payment()
                        {
                            Id = targetPayment.Id,
                            Transaction = targetEntity.Contains(EntityNames.Payment.Transaction) ? targetPayment.Transaction : preImagePayment.Transaction,
                            PaymentSchedule = targetEntity.Contains(EntityNames.Payment.PaymentSchedule) ? targetPayment.PaymentSchedule : preImagePayment.PaymentSchedule,
                            Statecode = targetEntity.Contains(EntityNames.Payment.Statecode) ? targetPayment.Statecode : preImagePayment.Statecode,
                            Statuscode = targetEntity.Contains(EntityNames.Payment.Statuscode) ? targetPayment.Statuscode : preImagePayment.Statuscode,
                            PaymentMethodType = targetEntity.Contains(EntityNames.Payment.PaymentMethodType) ? targetPayment.PaymentMethodType : preImagePayment.PaymentMethodType,
                            Amount = targetEntity.Contains(EntityNames.Payment.Amount) ? targetPayment.Amount : preImagePayment.Amount,
                            PaidOn = targetEntity.Contains(EntityNames.Payment.PaidOn) ? targetPayment.PaidOn : preImagePayment.PaidOn,
                            PaymentType = targetEntity.Contains(EntityNames.Payment.PaymentType) ? targetPayment.PaymentType : preImagePayment.PaymentType,
                            GiftAidEligibility = targetEntity.Contains(EntityNames.Payment.GiftAidEligibility) ? targetPayment.GiftAidEligibility : preImagePayment.GiftAidEligibility,
                            Product = targetEntity.Contains(EntityNames.Payment.Product) ? targetPayment.Product : preImagePayment.Product,
                            Createdfromthirdpartydonation = targetEntity.Contains(EntityNames.Payment.Createdfromthirdpartydonation) ? targetPayment.Createdfromthirdpartydonation : preImagePayment.Createdfromthirdpartydonation,
                        };
                        #endregion

                        #region Plugin Logics
                        paymentService.SetPaymentDateWhenPaid(ref targetEntity, ref postImagePayment);
                        paymentService.SetPaymentGiftAidStatus(ref targetEntity, preImagePayment, ref postImagePayment);

                        var transaction = paymentService.RetrieveTransaction(postImagePayment);
                        if (transaction != null)
                            paymentService.UpdateTransactionStatus(postImagePayment, transaction);

                        var paymentSchedule = paymentService.RetrievePaymentSchedule(postImagePayment);
                        if (paymentSchedule != null)
                            paymentService.UpdatePaymentDueOfPaymentScheduleWhenPartiallyPaid(postImagePayment, paymentSchedule);
                        #endregion
                    }
                }
            }
        }
    }
}
