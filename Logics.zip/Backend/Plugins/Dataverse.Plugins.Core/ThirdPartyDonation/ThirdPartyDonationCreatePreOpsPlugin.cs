﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
     [PluginRegistration(
        EntityLogicalName = "rhs_thirdpartydonation",
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class ThirdPartyDonationCreatePreOpsPlugin: Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var campaignRepository = container.Resolve<IRepository<Campaign>>();
            var campaignService = container.Resolve<ICampaignService>();

            if (context.MessageName == "Create" && 
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity target = (Entity)context.InputParameters["Target"];

                if (target.LogicalName == "rhs_thirdpartydonation")
                {
                    // Code below only triggers on campaign change
                    if (target.Contains("rhs_campaign"))
                    {
                        var campaign = campaignRepository.GetById(target.GetAttributeValue<EntityReference>("rhs_campaign").Id);
                        campaignService.ValidateDonationCampaign(campaign);
                    }
                }
            }
        }
    }
}
