using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = "rhs_subscription",
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class SubscriptionUpdatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var postImageName = "PostImageSubscription";

            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            
            var subscriptionUpdateService = container.Resolve<ISubscriptionService>();

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PostEntityImages.Contains(postImageName) && context.PostEntityImages[postImageName] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == "rhs_subscription")
                    {
                        var postImageEntity = context.PostEntityImages[postImageName];

                        subscriptionUpdateService.ValidateSubscriptionSetRenewalMHStatus(postImageEntity);

                    }
                }
            }
        }
    }
}
