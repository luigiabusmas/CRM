﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using System.Web.Security;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = "rhs_subscription",
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class SubscriptionUpdatePreOpsPlugin : Plugin
    {
        private const string subscriptionNumberLogicalName = "rhs_number";
        private const string subscriptionCampaignLogicalName = "rhs_campaigncode";
        private const string subscriptionProductLogicalName = "rhs_subscriptionproduct";
        private const string subscriptionRecipientLogicalName = "rhs_recipient";
        private const string subscriptionPayerLogicalName = "rhs_subscriptionpayer";
        private const string subscriptionPriceListLogicalName = "rhs_pricelist";
        private const string subscriptionPriceLogicalName = "rhs_subscriptionprice";
        private const string subscriptionPostalChargeLogicalName = "rhs_postalcharges";
        private const string subscriptionCampaignAmountLogicalName = "rhs_campaignamount";
        private const string subscriptionTotalAmountLogicalName = "rhs_totalamount";
        private const string subscriptionPaymentMethodLogicalName = "rhs_paymentmethodcode";
        private const string subscriptionPaymentFrequencyLogicalName = "rhs_billingfrequency";
        private const string subscriptionPayoutDateLogicalName = "rhs_paymentschedule";
        private const string subscriptionStartDateLogicalName = "rhs_startdate";
        private const string subscriptionEndDateLogicalName = "rhs_enddate";
        private const string subscriptionSubmitPaymentLogicalName = "rhs_ispaymentsubmitted";
        private const string subscriptionRenewalsCampaignLogicalName = "rhs_renewalscampaign";
        private const string subscriptionRenewalsProductLogicalName = "rhs_renewalssubscriptionproduct";
        private const string subscriptionRenewalsPayerLogicalName = "rhs_renewalspayer";
        private const string subscriptionInRenewalStageLogicalName = "rhs_inrenewalsstage";
        private const string subscriptionRenewalStatusLogicalName = "rhs_renewalsstatus";
        private const string subscriptionRenewalPriceListLogicalName = "rhs_renewalssubscriptionprice";
        private const string subscriptionRenewalPriceLogicalName = "rhs_renewalssubscriptionpricevalue";
        private const string subscriptionRenewalPostalChargeLogicalName = "rhs_renewalpostalcharge";
        private const string subscriptionRenewalsTotalAmountLogicalName = "rhs_renewalstotalamount";
        private const string subscriptionRenewalsPaymentMethodLogicalName = "rhs_renewalspaymentmethodcode";
        private const string subscriptionRenewalsPaymentFrequencyLogicalName = "rhs_renewalbillingfrequency";
        private const string subscriptionRenewalPayoutDateLogicalName = "rhs_renewalpaymentschedule";
        private const string subscriptionRenewalsStartDateLogicalName = "rhs_renewalsstartdate";
        private const string subscriptionRenewalsEndDateLogicalName = "rhs_renewalsenddate";
        private const string subscriptionCancelSubscriptionLogicalName = "rhs_cancelsubscription";
        private const string subscriptionCancellationTypeLogicalName = "rhs_subscriptioncancellationtype";
        private const string subscriptionCancellationReasonLogicalName = "rhs_cancellationreason";
        private const string subscriptionStatusLogicalName = "statecode";
        private const string subscriptionStatusReasonLogicalName = "statuscode";
        private const string freeSubscriptionLogicalName = "rhs_freesubscription";

        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var subscriptionService = container.Resolve<ISubscriptionService>();
            var customAPIInvocationService = container.Resolve<ICustomAPIInvocationService>();

            var preImageName = "PreImageSubscription";
            
            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                var target = (Entity)context.InputParameters["Target"];
                var preImage = (Entity)context.PreEntityImages[preImageName];
                if (target.LogicalName == "rhs_subscription")
                {
                    var postImage = new Entity(target.LogicalName, target.Id);
                    #region Post Image Initialization
                    postImage[subscriptionCampaignLogicalName] = target.Contains(subscriptionCampaignLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName);
                    postImage[subscriptionProductLogicalName] = target.Contains(subscriptionProductLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionProductLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);
                    postImage[subscriptionRecipientLogicalName] = target.Contains(subscriptionRecipientLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionRecipientLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionRecipientLogicalName);
                    postImage[subscriptionPayerLogicalName] = target.Contains(subscriptionPayerLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionPayerLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionPayerLogicalName);
                    postImage[subscriptionPriceListLogicalName] = target.Contains(subscriptionPriceListLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionPriceListLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionPriceListLogicalName);
                    postImage[subscriptionPriceLogicalName] = target.Contains(subscriptionPriceLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionPriceLogicalName) : preImage.GetAttributeValue<Money>(subscriptionPriceLogicalName);
                    postImage[subscriptionCampaignAmountLogicalName] = target.Contains(subscriptionCampaignAmountLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionCampaignAmountLogicalName) : preImage.GetAttributeValue<Money>(subscriptionCampaignAmountLogicalName);
                    postImage[subscriptionTotalAmountLogicalName] = target.Contains(subscriptionTotalAmountLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionTotalAmountLogicalName) : preImage.GetAttributeValue<Money>(subscriptionTotalAmountLogicalName);
                    postImage[subscriptionPaymentMethodLogicalName] = target.Contains(subscriptionPaymentMethodLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionPaymentMethodLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionPaymentMethodLogicalName);
                    postImage[subscriptionPaymentFrequencyLogicalName] = target.Contains(subscriptionPaymentFrequencyLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionPaymentFrequencyLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionPaymentFrequencyLogicalName);
                    postImage[subscriptionPayoutDateLogicalName] = target.Contains(subscriptionPayoutDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionPayoutDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionPayoutDateLogicalName);
                    postImage[subscriptionStartDateLogicalName] = target.Contains(subscriptionStartDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionStartDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionStartDateLogicalName);
                    postImage[subscriptionEndDateLogicalName] = target.Contains(subscriptionEndDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionEndDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionEndDateLogicalName);
                    postImage[subscriptionSubmitPaymentLogicalName] = target.Contains(subscriptionSubmitPaymentLogicalName) ?
                        target.GetAttributeValue<bool?>(subscriptionSubmitPaymentLogicalName) : preImage.GetAttributeValue<bool?>(subscriptionSubmitPaymentLogicalName);
                    postImage[subscriptionRenewalsCampaignLogicalName] = target.Contains(subscriptionRenewalsCampaignLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName);
                    postImage[subscriptionRenewalsProductLogicalName] = target.Contains(subscriptionRenewalsProductLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName);
                    postImage[subscriptionRenewalsPayerLogicalName] = target.Contains(subscriptionRenewalsPayerLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionRenewalsPayerLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionRenewalsPayerLogicalName);
                    postImage[subscriptionInRenewalStageLogicalName] = target.Contains(subscriptionInRenewalStageLogicalName) ?
                       target.GetAttributeValue<bool?>(subscriptionInRenewalStageLogicalName) : preImage.GetAttributeValue<bool?>(subscriptionInRenewalStageLogicalName);
                    postImage[subscriptionRenewalStatusLogicalName] = target.Contains(subscriptionRenewalStatusLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionRenewalStatusLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalStatusLogicalName);
                    postImage[subscriptionRenewalPriceListLogicalName] = target.Contains(subscriptionRenewalPriceListLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionRenewalPriceListLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionRenewalPriceListLogicalName);
                    postImage[subscriptionRenewalPriceLogicalName] = target.Contains(subscriptionRenewalPriceLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionRenewalPriceLogicalName) : preImage.GetAttributeValue<Money>(subscriptionRenewalPriceLogicalName);
                    postImage[subscriptionRenewalPostalChargeLogicalName] = target.Contains(subscriptionRenewalPostalChargeLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionRenewalPostalChargeLogicalName) : preImage.GetAttributeValue<Money>(subscriptionRenewalPostalChargeLogicalName);
                    postImage[subscriptionRenewalsTotalAmountLogicalName] = target.Contains(subscriptionRenewalsTotalAmountLogicalName) ?
                        target.GetAttributeValue<Money>(subscriptionRenewalsTotalAmountLogicalName) : preImage.GetAttributeValue<Money>(subscriptionRenewalsTotalAmountLogicalName);
                    postImage[subscriptionRenewalsPaymentMethodLogicalName] = target.Contains(subscriptionRenewalsPaymentMethodLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName);
                    postImage[subscriptionRenewalPayoutDateLogicalName] = target.Contains(subscriptionRenewalPayoutDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionRenewalPayoutDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionRenewalPayoutDateLogicalName);
                    postImage[subscriptionRenewalsPaymentFrequencyLogicalName] = target.Contains(subscriptionRenewalsPaymentFrequencyLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentFrequencyLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentFrequencyLogicalName);
                    postImage[subscriptionRenewalsStartDateLogicalName] = target.Contains(subscriptionRenewalsStartDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionRenewalsStartDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionRenewalsStartDateLogicalName);
                    postImage[subscriptionRenewalsEndDateLogicalName] = target.Contains(subscriptionRenewalsEndDateLogicalName) ?
                        target.GetAttributeValue<DateTime?>(subscriptionRenewalsEndDateLogicalName) : preImage.GetAttributeValue<DateTime?>(subscriptionRenewalsEndDateLogicalName);
                    postImage[subscriptionCancelSubscriptionLogicalName] = target.Contains(subscriptionCancelSubscriptionLogicalName) ?
                        target.GetAttributeValue<bool?>(subscriptionCancelSubscriptionLogicalName) : preImage.GetAttributeValue<bool?>(subscriptionCancelSubscriptionLogicalName);
                    postImage[subscriptionCancellationTypeLogicalName] = target.Contains(subscriptionCancellationTypeLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionCancellationTypeLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionCancellationTypeLogicalName);
                    postImage[subscriptionCancellationReasonLogicalName] = target.Contains(subscriptionCancellationReasonLogicalName) ?
                        target.GetAttributeValue<EntityReference>(subscriptionCancellationReasonLogicalName) : preImage.GetAttributeValue<EntityReference>(subscriptionCancellationReasonLogicalName);
                    postImage[subscriptionStatusLogicalName] = target.Contains(subscriptionStatusLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionStatusLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionStatusLogicalName);
                    postImage[subscriptionStatusReasonLogicalName] = target.Contains(subscriptionStatusReasonLogicalName) ?
                        target.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName) : preImage.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName);
                    postImage[freeSubscriptionLogicalName] = target.Contains(freeSubscriptionLogicalName) ?
                       target.GetAttributeValue<bool?>(freeSubscriptionLogicalName) : preImage.GetAttributeValue<bool?>(freeSubscriptionLogicalName);
                    #endregion

                    if (subscriptionService.ValidateIfPaymentFieldsNeedToBeRepopulated(preImage, postImage))
                    {
                        subscriptionService.ValidateCampaignInSubscriptionEntity(postImage);
                        target = subscriptionService.SetPriceListOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetCampaignAmountOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetSubscriptionPriceOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetPostChargeOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetTotalAmountOnSubscriptionEntity(target, postImage);
                    }

                    if (subscriptionService.ValidateIfPaymentSubmissionWasTriggered(preImage, postImage) ||
                        subscriptionService.ValidateIfActivatedWithoutStartDate(preImage, postImage))
                    {
                        target = subscriptionService.PopulateSubscriptionDates(target, postImage);
                    }

                    if (subscriptionService.ValidateIfRenewalPaymentFieldsNeedToBeRepopulated(preImage, postImage))
                    {
                        subscriptionService.ValidateRenewalCampaignInSubscriptionEntity(postImage);
                        target = subscriptionService.SetRenewalPriceListOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetRenewalSubscriptionPriceOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetRenewalPostChargeOnSubscriptionEntity(target, postImage);
                        target = subscriptionService.SetRenewalTotalAmountOnSubscriptionEntity(target, postImage);
                    }

                    if (subscriptionService.ValidateIfRenewalsPayoutDateShouldBeRecalculated(preImage, postImage))
                    {
                        subscriptionService.SetRenewalsPayoutDate(target, postImage);
                    }

                    if (subscriptionService.ValidateIfDDSubscriptionWasCancelled(postImage))
                    {
                        customAPIInvocationService.InvokeCancelDDICustomAPI(postImage.Id, NewTransactionType_GlobalOptionSet.Subscriptions);
                    }
                }
            }
        }
    }

}

