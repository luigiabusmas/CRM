﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System.Web.Security;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{ 
    [PluginRegistration(
        EntityLogicalName = "rhs_subscription",
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class SubscriptionCreatePreOpsPlugin :Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var subscriptionService = container.Resolve<ISubscriptionService>();

            if (context.MessageName == "Create" && 
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity target = (Entity)context.InputParameters["Target"];

                if (target.LogicalName == "rhs_subscription")
                {
                    subscriptionService.ValidateCampaignInSubscriptionEntity(target);

                    if (!target.Contains("rhs_number") || target["rhs_number"] == null)
                        target = subscriptionService.SetSubscriptionOrderNumberOnSubscriptionEntity(target);
                    if (!target.Contains("rhs_pricelist") || target["rhs_pricelist"] == null)
                        target = subscriptionService.SetPriceListOnSubscriptionEntity(target, target);
                    if (!target.Contains("rhs_campaignamount") || target["rhs_campaignamount"] == null)
                        target = subscriptionService.SetCampaignAmountOnSubscriptionEntity(target, target);
                    if (!target.Contains("rhs_subscriptionprice") || target["rhs_subscriptionprice"] == null)
                        target = subscriptionService.SetSubscriptionPriceOnSubscriptionEntity(target, target);
                    if (!target.Contains("rhs_postalcharges") || target["rhs_postalcharges"] == null)
                        target = subscriptionService.SetPostChargeOnSubscriptionEntity(target, target);
                    if (!target.Contains("rhs_totalamount") || target["rhs_totalamount"] == null)
                        target = subscriptionService.SetTotalAmountOnSubscriptionEntity(target, target);

                    if (target.Contains("rhs_ismigrated") && (bool?)target["rhs_ismigrated"] == true)
                        target["rhs_outstandingamount"] = new Money(0);

                    if (target.Contains("statuscode") && target.GetAttributeValue<OptionSetValue>("statuscode").Value == 1)
                    {
                        target = subscriptionService.PopulateSubscriptionDates(target, target);
                    }
                }
            }
        }
    }
}

