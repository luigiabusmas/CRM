﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class BatchOrderLineUpdatePostOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var batchOrderLineService = container.Resolve<BatchOrderLineService>();
            var preImageName = "PreImageBatchOrderLine";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];
                    var targetBatchOrderLine = target.ToEntity<Batchorderline>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageBatchOrderLine = preImageEntity.ToEntity<Batchorderline>();
                    var postImageBatchOrderLine = new Batchorderline()
                    {
                        DonationCampaign = target.Contains(EntityNames.Batchorderline.DonationCampaign) ? targetBatchOrderLine.DonationCampaign : preImageBatchOrderLine.DonationCampaign
                    };

                    batchOrderLineService.ValidateDonationCampaignOnUpdate(postImageBatchOrderLine);

                }
            }
        }
    }
}
