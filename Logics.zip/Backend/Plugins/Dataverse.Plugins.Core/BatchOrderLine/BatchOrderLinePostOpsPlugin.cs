﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Batchorderline.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class BatchOrderLineCreatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var batchOrderRepository = container.Resolve<IRepository<Batchorder>>();
            var batchOrderLineService = container.Resolve<IBatchOrderLineService>();
            var customAPIInvokationService = container.Resolve<ICustomAPIInvocationService>();

            if (context.MessageName == "Create" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Batchorderline.EntityLogicalName &&
                    targetEntity.Contains(EntityNames.Batchorderline.Batchorder))
                {
                    var batchOrderLine = targetEntity.ToEntity<Batchorderline>();

                    //commented code as is not part of new LLDS for BatchOrderline
                    //var batchOrder = batchOrderRepository.GetById(batchOrderLine.Batchorder.Id);

                    //switch(batchOrder.Type)
                    //{
                    //    case BatchOrderType_GlobalOptionSet.NewMembership:
                    //        var membership = batchOrderLineService.CreateLinkedMembership(batchOrderLine);
                    //        var (transactionId, paymentId, paymentScheduleId) = customAPIInvokationService.InvokeSubmitPaymentCustomAPI(
                    //            (int?)membership.PaymentMethod,
                    //            (int?)NewTransactionType_GlobalOptionSet.Membership,
                    //            (int?)Typetransaction_GlobalOptionSet.FullPayment,
                    //            membership.Id,
                    //            membership.Payer?.Id,
                    //            membership.Payer?.LogicalName,
                    //            membership.TotalAmount,
                    //            (int?)membership.PaymentFrequency,
                    //            membership.IsContinuousPayment,
                    //            membership.OutstandingAmount,
                    //            batchOrderLine.WriteOffAmount,
                    //            batchOrderLine.PaymentReference,
                    //            batchOrderLine.PayingInSlipNumber
                    //        );
                    //        batchOrderLineService.PayAndActivateMembershipWhenApplicable(membership, paymentId);
                    //        if (batchOrderLine.DonationCampaign != null && batchOrderLine.DonationAmount != null)
                    //        {
                    //            var membershipDonationId = customAPIInvokationService.InvokeCreatePaidDonationCustomAPI(false, batchOrderLine.DonationAmount.Value, batchOrderLine.Id, membership.Id, transactionId.Value);
                    //            batchOrderLineService.LinkDonationIdWithBatchOrderLine(batchOrderLine, (Guid)membershipDonationId);
                    //        }
                    //        break;
                    //    case BatchOrderType_GlobalOptionSet.Fundraising_Donation:
                    //        var donationId = customAPIInvokationService.InvokeCreatePaidDonationCustomAPI(true, batchOrderLine.DonationAmount.Value, batchOrderLine.Id, Guid.Empty, Guid.Empty);
                    //        batchOrderLineService.LinkDonationIdWithBatchOrderLine(batchOrderLine, (Guid)donationId);
                    //        break;
                    //}
                }
            }
        }
    }
}