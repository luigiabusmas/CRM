﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.GiftPackBulkPurchase.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous,
        FilteringAttributes = new string[] { EntityNames.GiftPackBulkPurchase.Statuscode }
    )]
    public class GiftPackBulkPurchaseUpdatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();

            logger.TraceInformation("Starting GiftPackBulkPurchaseUpdatePostOpsPlugin.");

            context.PreEntityImages.TryGetValue("GPBPPreImage", out var preImageObj);
            context.PostEntityImages.TryGetValue("GPBPPostImage", out var postImageObj);

            var preImage = preImageObj as Entity;
            var postImage = postImageObj as Entity;

            var target = context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity
                ? (Entity)context.InputParameters["Target"]
                : null;

            var workingEntity = postImage ?? target;

            if (workingEntity == null)
            {
                logger.TraceInformation("No PostImage or Target entity found. Exiting plugin.");
                return;
            }

            const int PurchasedStatusCode = 120000001;

            var preStatus = preImage?.GetAttributeValue<OptionSetValue>(EntityNames.GiftPackBulkPurchase.Statuscode);

            var postStatus = workingEntity.Contains(EntityNames.GiftPackBulkPurchase.Statuscode)
                ? workingEntity.GetAttributeValue<OptionSetValue>(EntityNames.GiftPackBulkPurchase.Statuscode)
                : null;

            if (preStatus?.Value != PurchasedStatusCode && postStatus?.Value == PurchasedStatusCode)
            {
                logger.TraceInformation("Gift Pack Bulk Purchase status changed to Purchased. Calling business logic to update child Gift Packs.");

                var giftPackBulkPurchaseService = container.Resolve<IGiftPackBulkPurchaseService>();

                try
                {
                    giftPackBulkPurchaseService.UpdateChildGiftPacksOnStatusChange(workingEntity);
                }
                catch (InvalidPluginExecutionException ex)
                {
                    logger.TraceError($"Error updating child gift packs: {ex.Message}");
                    throw;
                }
            }
            else
            {
                logger.TraceInformation("Status change condition not met. No child updates required.");
            }

            logger.TraceInformation("Ending GiftPackBulkPurchaseUpdatePostOpsPlugin.");
        }
    }
}
