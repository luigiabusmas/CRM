using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.GiftPackBulkPurchase.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous,
        FilteringAttributes = [
            EntityNames.GiftPackBulkPurchase.Amount,
            EntityNames.GiftPackBulkPurchase.BuyanotherMembershipGiftPackCode,
            EntityNames.GiftPackBulkPurchase.IsPaymentSubmitted,
            EntityNames.GiftPackBulkPurchase.DeliveryContact,
            EntityNames.GiftPackBulkPurchase.DeliveryAddressCode,
            EntityNames.GiftPackBulkPurchase.PostalCharges
            ]
    )]

    public class GiftPackBulkPurchaseUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftPackBulkPurchaseService = container.Resolve<IGiftPackBulkPurchaseService>();
            var preImageName = "PreImageGiftPackBulkPurchase";

            logger.TraceInformation($"Starting plugin.");

            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                Entity targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.GiftPackBulkPurchase.EntityLogicalName)
                {
                    var targetGiftPackBulkPurchase = targetEntity.ToEntity<GiftPackBulkPurchase>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageGiftPackBulkPurchase = preImageEntity.ToEntity<GiftPackBulkPurchase>();
                    var postImageGiftPackBulkPurchase = new GiftPackBulkPurchase()
                    {
                        Id = targetGiftPackBulkPurchase.Id,
                        Title = targetGiftPackBulkPurchase.Title != null ? targetGiftPackBulkPurchase.Title : preImageGiftPackBulkPurchase.Title,
                        ReferenceNumber = targetGiftPackBulkPurchase.ReferenceNumber != null ? targetGiftPackBulkPurchase.ReferenceNumber : preImageGiftPackBulkPurchase.ReferenceNumber,
                        Product = targetGiftPackBulkPurchase.Product != null ? targetGiftPackBulkPurchase.Product : preImageGiftPackBulkPurchase.Product,
                        Amount = targetGiftPackBulkPurchase.Amount != null ? targetGiftPackBulkPurchase.Amount : preImageGiftPackBulkPurchase.Amount,
                        PurchasedBy = targetGiftPackBulkPurchase.PurchasedBy != null ? targetGiftPackBulkPurchase.PurchasedBy : preImageGiftPackBulkPurchase.PurchasedBy,
                        Channel = targetGiftPackBulkPurchase.Channel != null ? targetGiftPackBulkPurchase.Channel : preImageGiftPackBulkPurchase.Channel,
                        PricePerProduct = targetGiftPackBulkPurchase.PricePerProduct != null ? targetGiftPackBulkPurchase.PricePerProduct : preImageGiftPackBulkPurchase.PricePerProduct,
                        PriceListUsed = targetGiftPackBulkPurchase.PriceListUsed != null ? targetGiftPackBulkPurchase.PriceListUsed : preImageGiftPackBulkPurchase.PriceListUsed,
                        PostalCharges = targetGiftPackBulkPurchase.PostalCharges != null ? targetGiftPackBulkPurchase.PostalCharges : preImageGiftPackBulkPurchase.PostalCharges,
                        //TotalPrice = targetGiftPackBulkPurchase.TotalPrice != null ? targetGiftPackBulkPurchase.TotalPrice : preImageGiftPackBulkPurchase.TotalPrice,
                        PaymentMethod = targetGiftPackBulkPurchase.PaymentMethod != null ? targetGiftPackBulkPurchase.PaymentMethod : preImageGiftPackBulkPurchase.PaymentMethod,
                        IsPaymentSubmitted = targetGiftPackBulkPurchase.IsPaymentSubmitted != null ? targetGiftPackBulkPurchase.IsPaymentSubmitted : preImageGiftPackBulkPurchase.IsPaymentSubmitted,
                        IsPaymentReceived = targetGiftPackBulkPurchase.IsPaymentReceived != null ? targetGiftPackBulkPurchase.IsPaymentReceived : preImageGiftPackBulkPurchase.IsPaymentReceived,
                        BuyanotherMembershipGiftPackCode = targetGiftPackBulkPurchase.BuyanotherMembershipGiftPackCode != null ? targetGiftPackBulkPurchase.BuyanotherMembershipGiftPackCode : preImageGiftPackBulkPurchase.BuyanotherMembershipGiftPackCode,
                        DeliveryContact = targetGiftPackBulkPurchase.DeliveryContact != null ? targetGiftPackBulkPurchase.DeliveryContact : preImageGiftPackBulkPurchase.DeliveryContact,
                        DeliveryAddressCode = targetGiftPackBulkPurchase.DeliveryAddressCode != null ? targetGiftPackBulkPurchase.DeliveryAddressCode : preImageGiftPackBulkPurchase.DeliveryAddressCode,
                    };

                    if (postImageGiftPackBulkPurchase.IsPaymentSubmitted == true &&
                        postImageGiftPackBulkPurchase.BuyanotherMembershipGiftPackCode == Doyouwanttobuyanothergiftpack_GlobalOptionSet.No)
                    {
                        var transaction = giftPackBulkPurchaseService.CreateTransactionForGiftPackBulkPurchase(preImageGiftPackBulkPurchase);
                        var payment = giftPackBulkPurchaseService.CreatePaymentForGiftPackBulkPurchase(preImageGiftPackBulkPurchase, transaction.ToEntityReference());
                    }

                    if (postImageGiftPackBulkPurchase.Amount != preImageGiftPackBulkPurchase.Amount &&
                        postImageGiftPackBulkPurchase.IsPaymentSubmitted == true &&
                        postImageGiftPackBulkPurchase.BuyanotherMembershipGiftPackCode == Doyouwanttobuyanothergiftpack_GlobalOptionSet.Yes)
                    {
                        if (giftPackBulkPurchaseService.ValidateAmountWhenBuyingAnotherMembershipGiftPack(preImageGiftPackBulkPurchase, postImageGiftPackBulkPurchase))
                        {
                            var giftPackAmountDifference = giftPackBulkPurchaseService.GetGiftPackBulkPurchaseNewAmountDifference(postImageGiftPackBulkPurchase);
                            giftPackBulkPurchaseService.CreateGiftPackInstancesOfGiftPackBulkPurchase(postImageGiftPackBulkPurchase, giftPackAmountDifference);
                            targetEntity = giftPackBulkPurchaseService.SetEntityFieldsWhenBuyingAnotherMembershipGiftPack(targetEntity, postImageGiftPackBulkPurchase);
                        }
                    }

                    if (targetEntity.Contains(EntityNames.GiftPackBulkPurchase.DeliveryContact) 
                        || targetEntity.Contains(EntityNames.GiftPackBulkPurchase.DeliveryAddressCode)
                        || targetEntity.Contains(EntityNames.GiftPackBulkPurchase.PostalCharges))
                    {
                        targetEntity = giftPackBulkPurchaseService.GiftPackBulkPurchaseAdditionalPostageCalculations(targetEntity, preImageEntity);
                    }
                }
            }

            logger.TraceInformation($"Ending plugin.");
        }
    }
}