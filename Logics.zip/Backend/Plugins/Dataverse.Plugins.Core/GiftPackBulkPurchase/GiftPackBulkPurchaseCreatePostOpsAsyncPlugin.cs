using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.GiftPackBulkPurchase.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Asynchronous
    )]

    public class GiftPackBulkPurchaseCreatePostOpsAsyncPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftPackBulkPurchaseService = container.Resolve<IGiftPackBulkPurchaseService>();

            logger.TraceInformation($"Starting plugin.");

            if (context.MessageName == "Create" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.GiftPackBulkPurchase.EntityLogicalName)
                {
                    var targetGiftPackBulkPurchase = targetEntity.ToEntity<GiftPackBulkPurchase>();

                    giftPackBulkPurchaseService.GiftPackBulkPurchaseCreateConsents(targetGiftPackBulkPurchase);
                }
            }

            logger.TraceInformation($"Ending plugin.");
        }
    }
}