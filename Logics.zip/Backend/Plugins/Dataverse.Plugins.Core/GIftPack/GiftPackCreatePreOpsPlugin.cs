using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Reflection;
using System.Web.Security;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class GiftPackCreatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftPackService = container.Resolve<IGiftPackService>();

            logger.TraceInformation($"Starting plugin.");

            if (context.MessageName == "Create" &&
                context.InputParameters.Contains("Target") && 
                context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.GiftPack.EntityLogicalName)
                {
                    var targetGiftPack = targetEntity.ToEntity<GiftPack>();

                    if (targetGiftPack.Title == null)
                        targetEntity = giftPackService.SetGiftPackTitleOnEntity(targetEntity, targetGiftPack);
                    if (targetGiftPack.PriceListUsed == null && targetGiftPack.Price == null)
                        targetEntity = giftPackService.SetGiftPackPriceAndPriceListOnEntity(targetEntity);
                    if (targetGiftPack.GiftPackCode == null)
                        targetEntity = giftPackService.SetGiftPackCodeOnEntity(targetEntity, targetGiftPack);
                    if (targetGiftPack.PostalCharges == null && targetGiftPack.CampaignAmount == null)
                        targetEntity = giftPackService.SetPricePostageAndCampaignAmount(targetEntity, null);
                    if (targetGiftPack.ExpireDate == null)
                        targetEntity = giftPackService.SetExpirationDate(targetEntity);
                }
            }

            logger.TraceInformation($"Ending plugin.");
        }
    }
}