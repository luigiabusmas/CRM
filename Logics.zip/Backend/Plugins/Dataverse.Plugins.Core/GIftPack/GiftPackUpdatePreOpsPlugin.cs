using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Avanade.BizApps.Core.Diagnostics;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous,
        FilteringAttributes = [
            EntityNames.GiftPack.IsPaymentSubmitted,
            EntityNames.GiftPack.DeliveryContactId,
            EntityNames.GiftPack.DeliveryAddress,
            EntityNames.GiftPack.PostalCharges,
            EntityNames.GiftPack.ReinstateActivationCode,
            EntityNames.GiftPack.CancelActivationCode
            ]
    )]

    public class GiftPackUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var giftPackService = container.Resolve<IGiftPackService>();
            var preImageName = "PreImageGiftPack";

            logger.TraceInformation($"Starting plugin.");

            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.GiftPack.EntityLogicalName)
                {
                    var targetGiftPack = targetEntity.ToEntity<GiftPack>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageGiftPack = preImageEntity.ToEntity<GiftPack>();
                    var postImageGiftPack = new GiftPack()
                    {
                        Id = targetGiftPack.Id,
                        PurchaserReferenceNumber = targetEntity.Contains(EntityNames.GiftPack.PurchaserReferenceNumber) ? targetGiftPack.PurchaserReferenceNumber : preImageGiftPack.PurchaserReferenceNumber,
                        Title = targetEntity.Contains(EntityNames.GiftPack.Title) ? targetGiftPack.Title : preImageGiftPack.Title,
                        GiftPackCode = targetEntity.Contains(EntityNames.GiftPack.GiftPackCode) ? targetGiftPack.GiftPackCode : preImageGiftPack.GiftPackCode,
                        CampaignId = targetEntity.Contains(EntityNames.GiftPack.CampaignId) ? targetGiftPack.CampaignId : preImageGiftPack.CampaignId,
                        Product = targetEntity.Contains(EntityNames.GiftPack.Product) ? targetGiftPack.Product : preImageGiftPack.Product,
                        PurchasedBy = targetEntity.Contains(EntityNames.GiftPack.PurchasedBy) ? targetGiftPack.PurchasedBy : preImageGiftPack.PurchasedBy,
                        PriceListUsed = targetEntity.Contains(EntityNames.GiftPack.PriceListUsed) ? targetGiftPack.PriceListUsed : preImageGiftPack.PriceListUsed,
                        DeliveryContactId = targetEntity.Contains(EntityNames.GiftPack.DeliveryContactId) ? targetGiftPack.DeliveryContactId : preImageGiftPack.DeliveryContactId,
                        DeliveryAddress = targetEntity.Contains(EntityNames.GiftPack.DeliveryAddress) ? targetGiftPack.DeliveryAddress : preImageGiftPack.DeliveryAddress,
                        PostalCharges = targetEntity.Contains(EntityNames.GiftPack.PostalCharges) ? targetGiftPack.PostalCharges : preImageGiftPack.PostalCharges,
                        Price = targetEntity.Contains(EntityNames.GiftPack.Price) ? targetGiftPack.Price : preImageGiftPack.Price,
                        Channel = targetEntity.Contains(EntityNames.GiftPack.Channel) ? targetGiftPack.Channel : preImageGiftPack.Channel,
                        ExpireDate = targetEntity.Contains(EntityNames.GiftPack.ExpireDate) ? targetGiftPack.ExpireDate : preImageGiftPack.ExpireDate,
                        RedeemOn = targetEntity.Contains(EntityNames.GiftPack.RedeemOn) ? targetGiftPack.RedeemOn : preImageGiftPack.RedeemOn,
                        GiftMessage = targetEntity.Contains(EntityNames.GiftPack.GiftMessage) ? targetGiftPack.GiftMessage : preImageGiftPack.GiftMessage,
                        GiftPackBulkPurchase = targetEntity.Contains(EntityNames.GiftPack.GiftPackBulkPurchase) ? targetGiftPack.GiftPackBulkPurchase : preImageGiftPack.GiftPackBulkPurchase,
                        PaymentMethod = targetEntity.Contains(EntityNames.GiftPack.PaymentMethod) ? targetGiftPack.PaymentMethod : preImageGiftPack.PaymentMethod,
                        IsPaymentSubmitted = targetEntity.Contains(EntityNames.GiftPack.IsPaymentSubmitted) ? targetGiftPack.IsPaymentSubmitted : preImageGiftPack.IsPaymentSubmitted,
                        IsPaymentReceived = targetEntity.Contains(EntityNames.GiftPack.IsPaymentReceived) ? targetGiftPack.IsPaymentReceived : preImageGiftPack.IsPaymentReceived,
                    };

                    /* Payment logic is commented because it's logic has been moved to the 'Make Payment' button
                    //if (giftPackService.ValidateIfPaymentWasSubmitted(postImageGiftPack))
                    //{
                    //    var transaction = giftPackService.CreateTransactionForGiftPack(postImageGiftPack);
                    //    var payment = giftPackService.CreatePaymentForGiftPack(postImageGiftPack, transaction.ToEntityReference());
                    //}
                    */

                    // Price Recalculation
                    if (giftPackService.ValidateIfPricesNeededToBeRecalculated(targetEntity))
                    {
                        targetEntity = giftPackService.SetPricePostageAndCampaignAmount(targetEntity, preImageEntity);
                    }

                    // Activation Code and Title Repopulation
                    if (preImageGiftPack.Product?.Id != postImageGiftPack.Product?.Id)
                    {
                        targetEntity = giftPackService.SetGiftPackTitleOnEntity(targetEntity, postImageGiftPack, preImageGiftPack.CreatedOn);
                        targetEntity = giftPackService.SetGiftPackCodeOnEntity(targetEntity, postImageGiftPack);
                    }

                    // Business logic for reactivation and cancellation
                    giftPackService.HandleCodeReactivation(targetGiftPack);
                    giftPackService.HandleCodeCancellation(targetGiftPack, preImageGiftPack);
                }
            }

            logger.TraceInformation($"Ending plugin.");
        }
    }
}