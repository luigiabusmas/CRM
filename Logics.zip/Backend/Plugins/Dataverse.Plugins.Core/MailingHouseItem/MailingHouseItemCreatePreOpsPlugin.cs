﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Mailinghouseitem.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class MailingHouseItemCreatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var mailingHouseItemService = container.Resolve<IMailingHouseItemService>();
            var contactRepository = container.Resolve<IRepository<Contact>>();
            var accountRepository = container.Resolve<IRepository<Account>>();

            logger.TraceInformation("Starting plugin logic");
            if (context.MessageName == "Create")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Mailinghouseitem.EntityLogicalName)
                    {
                        var mailingHouseItem = target.ToEntity<Mailinghouseitem>();

                        logger.TraceInformation("Retrieving associated records.");
                        var contact = mailingHouseItem.Contact != null ? contactRepository.GetById(mailingHouseItem.Contact.Id) : null;
                        var account = mailingHouseItem.Organisationid != null ? accountRepository.GetById(mailingHouseItem.Organisationid.Id) : null;

                        logger.TraceInformation("Executing business logics.");
                        mailingHouseItemService.SetName(ref target, ref mailingHouseItem, contact, account);
                    }
                }
            }
            logger.TraceInformation("Ending plugin logic");
        }
    }
}
