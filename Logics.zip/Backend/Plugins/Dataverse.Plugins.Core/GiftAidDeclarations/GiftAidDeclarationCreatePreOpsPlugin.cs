﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
       EntityLogicalName = EntityNames.GiftAidDeclaration.EntityLogicalName,
       MessageName = MessageNames.Create,
       Stage = Stage.PreOperation,
       IncludePreImage = true,
       Mode = SdkMessageProcessingStepMode.Synchronous
   )]
    public class GiftAidDeclarationCreatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftAidDeclarationUpdateService = container.Resolve<IGiftAidDeclarationUpdateService>();

            if (context.MessageName == "Create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity target = (Entity)context.InputParameters["Target"];

                if (target.LogicalName == EntityNames.GiftAidDeclaration.EntityLogicalName)
                {
                    var targetGiftAid = target.ToEntity<GiftAidDeclaration>();

                    if (target.Contains(EntityNames.GiftAidDeclaration.StartDate) || target.Contains(EntityNames.GiftAidDeclaration.EndDate))
                    {
                        giftAidDeclarationUpdateService.SetDateRangeLastUpdated(targetGiftAid);
                    }

                }
            }
        }
    }
}
