﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Reflection;
using System.Web.Security;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName =EntityNames.GiftAidDeclaration.EntityLogicalName,// Logical name of the Gift Aid Declaration entity
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class GiftAidDeclarationUpdatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var tracingService = container.Resolve<ITracingService>();
            var orgService = container.Resolve<IOrganizationService>();
            var giftAidUpdateService = container.Resolve<IGiftAidDeclarationUpdateService>();
            var preImageName = "PreImageGiftAid";

            logger.TraceInformation("Starting GiftAidDeclarationUpdatePreOpsPlugin.");

            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity &&
                targetEntity.LogicalName == EntityNames.GiftAidDeclaration.EntityLogicalName &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                // Create an instance of GiftAidDeclarationUpdateService
                Entity target = (Entity)context.InputParameters["Target"];
                var targetGiftAid = target.ToEntity<GiftAidDeclaration>();
                var preImageGiftAid = context.PreEntityImages[preImageName].ToEntity<GiftAidDeclaration>();
                var updateService = new GiftAidDeclarationUpdateService(tracingService, context, orgService, logger);

                try
                {
                    updateService.ValidateDateOverlap(targetEntity);
                    if ((target.Contains(EntityNames.GiftAidDeclaration.StartDate) && targetGiftAid.StartDate != preImageGiftAid.StartDate) ||
                        (target.Contains(EntityNames.GiftAidDeclaration.EndDate) && targetGiftAid.EndDate != preImageGiftAid.EndDate))
                    {
                        giftAidUpdateService.SetDateRangeLastUpdated(targetGiftAid);
                    }
                }
                catch (InvalidPluginExecutionException ex)
                {
                    logger.TraceError($"Validation failed: {ex.Message}");
                    throw;
                }
            }

            logger.TraceInformation($"Ending plugin.");
        }
    }
}
