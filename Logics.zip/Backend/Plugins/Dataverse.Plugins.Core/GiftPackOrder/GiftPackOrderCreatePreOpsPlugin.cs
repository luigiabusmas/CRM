﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Reflection;
using System.Web.Security;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{

    public class GiftPackOrderCreatePreOpsPlugin: Plugin, IPlugin
    {

        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftPackOrderService = container.Resolve<IGiftPackOrderService>();

            logger.TraceInformation($"Starting plugin.");

            if (context.MessageName == "Create" &&
                context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Giftpackorder.EntityLogicalName)
                {
                    var targetGiftPackOrder = targetEntity.ToEntity<Giftpackorder>();

                    if (targetGiftPackOrder.Pricelistuse == null && targetGiftPackOrder.Unitprice == null)
                        targetEntity = giftPackOrderService.SetGiftPackPriceAndPriceListOnEntity(targetEntity);



                }
            }

            logger.TraceInformation($"Ending plugin.");
        }


    }
}
