﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Avanade.BizApps.Core.Diagnostics;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;


namespace Cultivate.Plugins.Core
{
    public class GiftPackOrderUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var giftPackOrderService = container.Resolve<IGiftPackOrderService>();

            logger.TraceInformation($"Starting GiftPackOrderUpdatePreOpsPlugin.");

            if (context.MessageName == MessageNames.Update &&
                context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity targetEntity &&
                targetEntity.LogicalName == EntityNames.Giftpackorder.EntityLogicalName)
            {
                logger.TraceInformation($"Product field updated — recalculating price.");
                giftPackOrderService.SetGiftPackPriceAndPriceListOnEntity(targetEntity);
            }

            logger.TraceInformation($"Ending GiftPackOrderUpdatePreOpsPlugin.");
        }
    }
}
