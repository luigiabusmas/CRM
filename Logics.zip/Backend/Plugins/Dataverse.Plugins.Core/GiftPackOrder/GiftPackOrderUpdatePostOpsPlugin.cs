﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    public class GiftPackOrderUpdatePostOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var giftPackOrderService = container.Resolve<IGiftPackOrderService>();
            var preImageName = "PreImageGiftPackOrder";
            var postImageName = "PostImageGiftPackOrder";

            logger.TraceInformation($"Starting GiftPackOrderUpdatePostOpsPlugin.");

            if (context.MessageName == MessageNames.Update &&
                context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity targetEntity &&
                targetEntity.LogicalName == EntityNames.Giftpackorder.EntityLogicalName &&
                context.PreEntityImages.Contains(preImageName) &&
                context.PostEntityImages.Contains(postImageName))
            {
                logger.TraceInformation($"Detected Gift Pack Order update.");

                #region Initilization
                Entity preImage = context.PreEntityImages[preImageName];
                var preImageGiftPackOrder = preImage.ToEntity<Giftpackorder>();

                Entity postImage = context.PostEntityImages[postImageName];
                var postImageGiftPackOrder = postImage.ToEntity<Giftpackorder>();
                #endregion

                #region Logics
                if (preImageGiftPackOrder.Product?.Id != postImageGiftPackOrder.Product?.Id)
                    giftPackOrderService.UpdateProductOfGiftPacks(postImage);
                if (preImageGiftPackOrder.Campaign?.Id != postImageGiftPackOrder.Campaign?.Id)
                    giftPackOrderService.UpdateCampaignOfGiftPacks(postImage);
                if (preImageGiftPackOrder.PaymentMethodCode != postImageGiftPackOrder.PaymentMethodCode)
                    giftPackOrderService.UpdatePaymentMethodOfGiftPacks(postImageGiftPackOrder);
                #endregion
            }

            logger.TraceInformation($"Ending GiftPackOrderUpdatePostOpsPlugin.");
        }
    }
}