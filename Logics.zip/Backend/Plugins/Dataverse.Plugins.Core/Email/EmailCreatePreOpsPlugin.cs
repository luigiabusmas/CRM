﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Email.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class EmailCreatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var emailService = container.Resolve<IEmailService>();

            tracingService.Trace("Starting EmailCreatePreOpsPlugin.");

            if (context.MessageName == "Create" && context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity &&
                targetEntity.LogicalName == EntityNames.Email.EntityLogicalName)
            {
                try
                {
                    tracingService.Trace("Proceeding to set the GDPR deletion date.");
                    emailService.SetGdprDeletionDate(targetEntity);
                }
                catch (InvalidPluginExecutionException ex)
                {
                    tracingService.Trace($"GDPR Deletion Date setting failed: {ex.Message}");
                    throw;
                }
            }
            tracingService.Trace("Ending EmailCreatePreOpsPlugin.");
        }
    }
}