﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Email.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class EmailUpdatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();

            tracingService.Trace("Starting EmailUpdatePreOpsPlugin.");

            var emailService = container.Resolve<IEmailService>();

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity targetEntity &&
                targetEntity.LogicalName == EntityNames.Email.EntityLogicalName)
            {
                tracingService.Trace($"Plugin executed for entity '{context.PrimaryEntityName}' with id '{context.PrimaryEntityId}' for message '{context.MessageName}'.");

                try
                {
                    tracingService.Trace("Proceeding to set the GDPR deletion date.");
                    emailService.SetGdprDeletionDate(targetEntity);
                }
                catch (InvalidPluginExecutionException ex)
                {
                    tracingService.Trace($"GDPR Deletion Date setting failed: {ex.Message}");
                    throw;
                }
            }

            tracingService.Trace("Ending EmailUpdatePreOpsPlugin.");
        }
    }
}