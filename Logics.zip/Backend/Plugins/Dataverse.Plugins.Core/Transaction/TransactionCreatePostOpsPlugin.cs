﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Transaction.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class TransactionCreatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var transactionService = container.Resolve<ITransactionService>();

            if (context.MessageName == "Create")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    var target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Transaction.EntityLogicalName)
                    {
                        var transaction = target.ToEntity<Transaction>();

                        var membership = transactionService.RetrieveMembership(transaction);
                        var subscriptionEntity = transactionService.RetrieveSubscriptionEntity(transaction);

                        transactionService.SetInitialOutstandingAmount(ref target, ref transaction, membership, subscriptionEntity);
                        if (membership != null && membership.IsMigrated != true)
                            transactionService.PopulateOutstandingAmountOnMembership(transaction);
                        if (subscriptionEntity != null && subscriptionEntity.GetAttributeValue<bool?>("rhs_migrated") != true)
                            transactionService.PopulateOutstandingAmountOnSubscription(transaction);
                    }
                }
            }
        }
    }
}
