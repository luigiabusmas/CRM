﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Transaction.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class TransactionUpdatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var transactionService = container.Resolve<ITransactionService>();
            var preImageName = "PreImageTransaction";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
                {
                    var targetEntity = (Entity)context.InputParameters["Target"];

                    if (targetEntity.LogicalName == EntityNames.Transaction.EntityLogicalName)
                    {
                        var targetTransaction = targetEntity.ToEntity<Transaction>();
                        var preImageEntity = context.PreEntityImages[preImageName];
                        var preImageTransaction = preImageEntity.ToEntity<Transaction>();
                        var postImageTransaction = new Transaction()
                        {
                            Id = targetTransaction.Id,
                            TransactionType = targetEntity.Contains(EntityNames.Transaction.TransactionType) ? targetTransaction.TransactionType : preImageTransaction.TransactionType,
                            MembershipId = targetEntity.Contains(EntityNames.Transaction.MembershipId) ? targetTransaction.MembershipId : preImageTransaction.MembershipId,
                            SubscriptionId = targetEntity.Contains(EntityNames.Transaction.SubscriptionId) ? targetTransaction.SubscriptionId : preImageTransaction.SubscriptionId,
                            OutstandingAmount = targetEntity.Contains(EntityNames.Transaction.OutstandingAmount) ? targetTransaction.OutstandingAmount : preImageTransaction.OutstandingAmount,
                            Statecode = targetEntity.Contains(EntityNames.Transaction.Statecode) ? targetTransaction.Statecode : preImageTransaction.Statecode,
                            Statuscode = targetEntity.Contains(EntityNames.Transaction.Statuscode) ? targetTransaction.Statuscode : preImageTransaction.Statuscode,
                        };

                        if (targetEntity.Contains(EntityNames.Transaction.OutstandingAmount))
                        { 
                            // Logics inside this condition only runs when the outstanding amount was changed
                            transactionService.SetStatusOnOutstandingAmountUpdate(ref targetEntity, ref postImageTransaction);
                        }
                    }
                }
            }
        }
    }
}
