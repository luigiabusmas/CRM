﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Transaction.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = true,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class TransactionUpdatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var transactionService = container.Resolve<ITransactionService>();
            var postImageName = "PostImageTransaction";

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PostEntityImages.Contains(postImageName) && context.PostEntityImages[postImageName] is Entity)
                {
                    var targetEntity = (Entity)context.InputParameters["Target"];

                    if (targetEntity.LogicalName == EntityNames.Transaction.EntityLogicalName)
                    {
                        #region Initialization
                        var targetTransaction = targetEntity.ToEntity<Transaction>();
                        var postImageEntity = context.PostEntityImages[postImageName];
                        var postImageTransaction = postImageEntity.ToEntity<Transaction>();

                        var membership = transactionService.RetrieveMembership(postImageTransaction);
                        var subscriptionEntity = transactionService.RetrieveSubscriptionEntity(postImageTransaction);
                        var giftPack = transactionService.RetrieveGiftPack(postImageTransaction);
                        var giftPackBulkPurchase = transactionService.RetrieveGiftPackBulkPurchase(postImageTransaction);
                        #endregion

                        #region Plugin Logic
                        if (targetEntity.Contains(EntityNames.Transaction.OutstandingAmount))
                        {
                            // Logics inside this condition only runs when the outstanding amount was changed
                            if (membership != null && membership.IsMigrated != true)
                                transactionService.PopulateOutstandingAmountOnMembership(postImageTransaction);
                            if (subscriptionEntity != null && subscriptionEntity.GetAttributeValue<bool?>("rhs_migrated") != true)
                                transactionService.PopulateOutstandingAmountOnSubscription(postImageTransaction);
                        }

                        //if (postImageTransaction.GiftPackId != null && giftPack != null)
                        //    transactionService.UpdateGiftPackStatus(giftPack);
                        if (postImageTransaction.GiftPackBulkPurchaseId != null && giftPackBulkPurchase != null)
                            transactionService.UpdateBulkGiftPackStatus(giftPackBulkPurchase);
                        #endregion
                    }
                }
            }
        }
    }
}
