﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = Portalsession.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = true,
        PreImageAttributes = [EntityNames.Portalsession.Additionalmemberid,
            EntityNames.Portalsession.Memberid,
            EntityNames.Portalsession.Payerid,
            EntityNames.Portalsession.PaymentFrequency,
            EntityNames.Portalsession.Memberid,
            EntityNames.Portalsession.PaymentMethodCode,
            EntityNames.Portalsession.PaymentType,
            EntityNames.Portalsession.Productid,
            EntityNames.Portalsession.ProductType,
            EntityNames.Portalsession.CheckoutSessionId,
            EntityNames.Portalsession.CheckoutURL,
            EntityNames.Portalsession.PaymentIntentId,
            EntityNames.Portalsession.TransactionID,
            EntityNames.Portalsession.TransactionNumber],
        Mode = SdkMessageProcessingStepMode.Asynchronous,
        FilteringAttributes = [EntityNames.Portalsession.Statuscode]
        )]
    public class PortalSessionUpdatePostOpsPlugin : Plugin<Portalsession>, IPlugin
    {
        public override void Execute(IDependencyContainer container, Portalsession portalSession)
        {
            if (portalSession.Statuscode != PortalsessionStatus.Active_PaymentCompleted && portalSession.Statuscode != PortalsessionStatus.Active_DirectDebitMandateCompleted) return;

            var paymentService = container.Resolve<IPortalSessionService>();
            paymentService.ProcessOrder(portalSession);
        }
    }
}