﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Product.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class ProductUpdatePreValPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            #region Initialization
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var productService = container.Resolve<IProductService>();

            var targetEntity = (Entity)context.InputParameters["Target"];
            var targetProduct = targetEntity.ToEntity<Product>();
            var preImageEntity = context.PreEntityImages["PreImageProduct"];
            var preImageProduct = preImageEntity.ToEntity<Product>();
            var postImageProduct = new Product()
            {
                Id = targetProduct.Id,
                ProductNumber = targetEntity.Contains(EntityNames.Product.ProductNumber) ? targetProduct.ProductNumber : preImageProduct.ProductNumber,
            };
            #endregion

            #region Loogics
            productService.ValidateProductIDLength(postImageProduct);
            #endregion
        }
    }
}