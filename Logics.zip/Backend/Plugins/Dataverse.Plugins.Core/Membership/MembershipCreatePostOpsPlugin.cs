﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class MembershipCreatePostOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var membershipCreateService = container.Resolve<IMembershipCreateService>();
            var membershipUpdateService = container.Resolve<IMembershipUpdateService>();
            var customAPIInvocationService = container.Resolve<ICustomAPIInvocationService>();

            if (context.MessageName == "Create")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity targetEntity = (Entity)context.InputParameters["Target"];

                    if (targetEntity.LogicalName == EntityNames.Membership.EntityLogicalName)
                    {
                        Membership targetMembership = targetEntity.ToEntity<Membership>();

                        membershipCreateService.MembershipUpdatePrimaryAndSecondaryMember(targetEntity);
                        membershipUpdateService.ValidateIfMembershipRenewalPackMHStatusShouldBeSetToPending(targetMembership);
                        membershipUpdateService.SetCardIssueNumber(targetMembership);
                        membershipCreateService.SubmitPaymentForGiftPackRedeemedMembership(targetMembership);
                        membershipCreateService.RedeemGiftPack(targetMembership);

                        if (targetMembership.Statuscode == MembershipStatus.Active_Active)
                            membershipUpdateService.PopulatePrimaryMembershipOfMembers(targetMembership);
                    }
                }
            }
        }
    }
}