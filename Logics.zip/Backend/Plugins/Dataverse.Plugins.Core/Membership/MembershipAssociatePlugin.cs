﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        //EntityLogicalName = Account.EntityLogicalName,
        MessageName = MessageNames.Associate,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class MembershipAssociatePlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            var tracingService = container.Resolve<ITracingService>();
            var service = container.Resolve<IOrganizationService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();

            string relationshipName = string.Empty;

            if (context.MessageName.ToLower() == "associate")
            {
                if (context.InputParameters.Contains("Relationship"))
                {
                    relationshipName = ((Relationship)context.InputParameters["Relationship"]).SchemaName;
                    tracingService.Trace("relationshipName: " + relationshipName);
                    if (relationshipName != "rhs_rhs_membership_contact_MM")
                    {
                        return;
                    }

                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                    {
                        var membershipAssociateService = new MembershipAssociateService(tracingService, context, service, propertyRetrievalService);
                        membershipAssociateService.MembershipAssociateValidation();
                    }
                }
            }
        }
    }
}
