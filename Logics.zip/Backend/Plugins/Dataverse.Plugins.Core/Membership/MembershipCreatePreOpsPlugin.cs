﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class MembershipCreatePreOpsPlugin :Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();
            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var membershipCreateService = container.Resolve<IMembershipCreateService>();
            var membershipUpdateService = container.Resolve<IMembershipUpdateService>();

            if (context.MessageName == "Create" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                var targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Membership.EntityLogicalName)
                {
                    var membership = targetEntity.ToEntity<Membership>();

                    #region Validations
                    membershipCreateService.ValidateAgeRequirementsInMembership(targetEntity);
                    membershipCreateService.ValidateAddressInMembership(targetEntity);
                    membershipCreateService.ValidateDuplicateMembership(targetEntity);
                    membershipCreateService.ValidateCampaignInMembership(targetEntity);
                    membershipCreateService.ValidateCampaignEndDate(targetEntity);
                    membershipCreateService.PopulateJoiningDateField(targetEntity);
                    #endregion

                    #region Field Population
                    if (membership.PriceList == null)
                        targetEntity = membershipCreateService.SetPriceListOnMembershipEntity(targetEntity, membership);
                    if (membership.CampaignAmount == null)
                        targetEntity = membershipCreateService.SetCampaignAmountOnMembershipEntity(targetEntity, membership);
                    if (membership.MembershipPrice == null)
                        targetEntity = membershipCreateService.SetMembershipPriceOnMembershipEntity(targetEntity, membership);
                    if (membership.TotalAmount == null)
                        targetEntity = membershipCreateService.SetTotalAmountOnMembershipEntity(targetEntity, membership);
                    if (membership.OutstandingAmount == null)
                        targetEntity = membershipUpdateService.SetOutstandingAmounteOnMembershipEntity(targetEntity, membership);
                    if (membership.IsDDDiscountAvailed == null)
                        targetEntity = membershipCreateService.SetIsDDDiscountAvailedOnMembership(targetEntity, membership);
                    targetEntity = membershipCreateService.SetPaymentAvailabilityOnChangeMembership(targetEntity);
                    targetEntity = membershipCreateService.SetPatronMembershipOnMembership(targetEntity);

                    #region Date Population
                    if (membership.Statuscode == MembershipStatus.Active_Active)
                    {
                        if (membership.Startdate == null)
                            targetEntity = membershipUpdateService.SetStartDateOnMembershipEntity(targetEntity, membership);
                        if (membership.Enddate == null)
                            targetEntity = membershipUpdateService.SetEndDateOnMembershipEntity(targetEntity, membership);
                        if (membership.RenewalsStartDate == null)
                            targetEntity = membershipUpdateService.SetRenewalsStartDateOnMembershipEntity(targetEntity, membership);
                        if (membership.RenewalsEndDate == null)
                            targetEntity = membershipUpdateService.SetRenewalsEndDateOnMembershipEntity(targetEntity, membership);

                        if (membershipUpdateService.ValidateIfMembershipPackMHStatusShouldBeSetToPending(membership))
                            targetEntity = membershipUpdateService.SetNewMembershipPackMHStatusOnMembershipEntity(targetEntity, membership);

                        targetEntity = membershipUpdateService.SetMembershipCardDetails(targetEntity, membership);
                        targetEntity = membershipUpdateService.SetPatronMembershipOnMembership(targetEntity, membership);
                    }
                    
                    if (membershipCreateService.ValidateIfLinkedWithMembershipOfDifferentProduct(membership))
                    {   
                        // Needed to fix Bug 81487 and update dates when changing product of active membership outside renewal stage.
                        targetEntity = membershipUpdateService.SetStartDateOnMembershipEntity(targetEntity, membership);
                        targetEntity = membershipUpdateService.SetEndDateOnMembershipEntity(targetEntity, membership);
                        targetEntity = membershipUpdateService.SetRenewalsStartDateOnMembershipEntity(targetEntity, membership);
                        targetEntity = membershipUpdateService.SetRenewalsEndDateOnMembershipEntity(targetEntity, membership);
                    }
                    #endregion

                    #endregion
                }
            }
        }
    }

}

