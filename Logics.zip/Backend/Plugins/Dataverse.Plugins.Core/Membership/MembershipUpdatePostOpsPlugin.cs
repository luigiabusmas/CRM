using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class MembershipUpdatePostOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var postImageName = "PostImageMembership";

            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            
            var membershipCreateService = container.Resolve<IMembershipCreateService>();
            var membershipUpdateService = container.Resolve<IMembershipUpdateService>();

            if (context.MessageName == "Update")
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                     context.PostEntityImages.Contains(postImageName) && context.PostEntityImages[postImageName] is Entity)
                {
                    Entity target = (Entity)context.InputParameters["Target"];

                    if (target.LogicalName == EntityNames.Membership.EntityLogicalName)
                    {
                        var postImageEntity = context.PostEntityImages[postImageName];
                        var postImageMembership = postImageEntity.ToEntity<Membership>();

                        membershipUpdateService.ValidateIfMembershipRenewalPackMHStatusShouldBeSetToPending(postImageEntity);
                        membershipUpdateService.SetCardIssueNumber(postImageMembership);
                        membershipCreateService.SubmitPaymentForGiftPackRedeemedMembership(postImageMembership);
                        membershipUpdateService.RedeemGiftPack(postImageMembership);
                    }
                }
            }
        }
    }
}
