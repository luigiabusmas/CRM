using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = EntityNames.Membership.EntityLogicalName,
        MessageName = MessageNames.Update,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]

    public class MembershipUpdatePreOpsPlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var tracingService = container.Resolve<ITracingService>();
            var context = container.Resolve<IPluginExecutionContext>();
            var service = container.Resolve<IOrganizationService>();

            var propertyRetrievalService = container.Resolve<IPropertyRetrievalService>();
            var membershipCreateService = container.Resolve<IMembershipCreateService>();
            var membershipUpdateService = container.Resolve<MembershipUpdateService>();
            var customAPIInvocationService = container.Resolve<CustomAPIInvocationService>();

            var preImageName = "PreImageMembership";

            if (context.MessageName == "Update" &&
                context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity &&
                context.PreEntityImages.Contains(preImageName) && context.PreEntityImages[preImageName] is Entity)
            {
                Entity targetEntity = (Entity)context.InputParameters["Target"];

                if (targetEntity.LogicalName == EntityNames.Membership.EntityLogicalName)
                {
                    var targetMembership = targetEntity.ToEntity<Membership>();
                    var preImageEntity = context.PreEntityImages[preImageName];
                    var preImageMembership = preImageEntity.ToEntity<Membership>();
                    var postImageMembership = new Membership()
                    {
                        Id = targetMembership.Id,
                        IsMigrated = targetEntity.Contains(EntityNames.Membership.IsMigrated) ? targetMembership.IsMigrated : preImageMembership.IsMigrated,
                        LinkedMembership = targetEntity.Contains(EntityNames.Membership.LinkedMembership) ? targetMembership.LinkedMembership : preImageMembership.LinkedMembership,
                        Contact = targetEntity.Contains(EntityNames.Membership.Contact) ? targetMembership.Contact : preImageMembership.Contact,
                        Member2 = targetEntity.Contains(EntityNames.Membership.Member2) ? targetMembership.Member2 : preImageMembership.Member2,
                        PayerV2 = targetEntity.Contains(EntityNames.Membership.PayerV2) ? targetMembership.PayerV2 : preImageMembership.PayerV2,
                        MembershipProductId = targetEntity.Contains(EntityNames.Membership.MembershipProductId) ? targetMembership.MembershipProductId : preImageMembership.MembershipProductId,
                        IsMembershipForSomeone = targetEntity.Contains(EntityNames.Membership.IsMembershipForSomeone) ? targetMembership.IsMembershipForSomeone : preImageMembership.IsMembershipForSomeone,
                        CampaignId = targetEntity.Contains(EntityNames.Membership.CampaignId) ? targetMembership.CampaignId : preImageMembership.CampaignId,
                        CampaignDonation = targetEntity.Contains(EntityNames.Membership.CampaignDonation) ? targetMembership.CampaignDonation : preImageMembership.CampaignDonation,
                        CampaignAmount = targetEntity.Contains(EntityNames.Membership.CampaignAmount) ? targetMembership.CampaignAmount : preImageMembership.CampaignAmount,
                        PriceList = targetEntity.Contains(EntityNames.Membership.PriceList) ? targetMembership.PriceList : preImageMembership.PriceList,
                        MembershipPrice = targetEntity.Contains(EntityNames.Membership.MembershipPrice) ? targetMembership.MembershipPrice : preImageMembership.MembershipPrice,
                        CarriedOverAmount = targetEntity.Contains(EntityNames.Membership.CarriedOverAmount) ? targetMembership.CarriedOverAmount : preImageMembership.CarriedOverAmount,
                        DonationAmount = targetEntity.Contains(EntityNames.Membership.DonationAmount) ? targetMembership.DonationAmount : preImageMembership.DonationAmount,
                        TotalAmount = targetEntity.Contains(EntityNames.Membership.TotalAmount) ? targetMembership.TotalAmount : preImageMembership.TotalAmount,
                        PaymentMethod = targetEntity.Contains(EntityNames.Membership.PaymentMethod) ? targetMembership.PaymentMethod : preImageMembership.PaymentMethod,
                        IsContinuousPayment = targetEntity.Contains(EntityNames.Membership.IsContinuousPayment) ? targetMembership.IsContinuousPayment : preImageMembership.IsContinuousPayment,
                        PaymentFrequency = targetEntity.Contains(EntityNames.Membership.PaymentFrequency) ? targetMembership.PaymentFrequency : preImageMembership.PaymentFrequency,
                        OutstandingAmount = targetEntity.Contains(EntityNames.Membership.OutstandingAmount) ? targetMembership.OutstandingAmount : preImageMembership.OutstandingAmount,
                        Startdate = targetEntity.Contains(EntityNames.Membership.Startdate) ? targetMembership.Startdate : preImageMembership.Startdate,
                        Enddate = targetEntity.Contains(EntityNames.Membership.Enddate) ? targetMembership.Enddate : preImageMembership.Enddate,
                        IsSubmitPayment = targetEntity.Contains(EntityNames.Membership.IsSubmitPayment) ? targetMembership.IsSubmitPayment : preImageMembership.IsSubmitPayment,
                        Statecode = targetEntity.Contains(EntityNames.Membership.Statecode) ? targetMembership.Statecode : preImageMembership.Statecode,
                        Statuscode = targetEntity.Contains(EntityNames.Membership.Statuscode) ? targetMembership.Statuscode : preImageMembership.Statuscode,
                        CancellationType = targetEntity.Contains(EntityNames.Membership.CancellationType) ? targetMembership.CancellationType : preImageMembership.CancellationType,
                        CheckoutURL = targetEntity.Contains(EntityNames.Membership.CheckoutURL) ? targetMembership.CheckoutURL : preImageMembership.CheckoutURL,
                        IsRenewal = targetEntity.Contains(EntityNames.Membership.IsRenewal) ? targetMembership.IsRenewal : preImageMembership.IsRenewal,
                        InRenewalsStage = targetEntity.Contains(EntityNames.Membership.InRenewalsStage) ? targetMembership.InRenewalsStage : preImageMembership.InRenewalsStage,
                        RenewalsCampaign = targetEntity.Contains(EntityNames.Membership.RenewalsCampaign) ? targetMembership.RenewalsCampaign : preImageMembership.RenewalsCampaign,
                        RenewalsMembershipProduct = targetEntity.Contains(EntityNames.Membership.RenewalsMembershipProduct) ? targetMembership.RenewalsMembershipProduct : preImageMembership.RenewalsMembershipProduct,
                        RenewalsPayer = targetEntity.Contains(EntityNames.Membership.RenewalsPayer) ? targetMembership.RenewalsPayer : preImageMembership.RenewalsPayer,
                        RenewalsStatus = targetEntity.Contains(EntityNames.Membership.RenewalsStatus) ? targetMembership.RenewalsStatus : preImageMembership.RenewalsStatus,
                        RenewalsPriceList = targetEntity.Contains(EntityNames.Membership.RenewalsPriceList) ? targetMembership.RenewalsPriceList : preImageMembership.RenewalsPriceList,
                        RenewalsMembershipPrice = targetEntity.Contains(EntityNames.Membership.RenewalsMembershipPrice) ? targetMembership.RenewalsMembershipPrice : preImageMembership.RenewalsMembershipPrice,
                        RenewalsTotalAmount = targetEntity.Contains(EntityNames.Membership.RenewalsTotalAmount) ? targetMembership.RenewalsTotalAmount : preImageMembership.RenewalsTotalAmount,
                        RenewalsPaymentMethod = targetEntity.Contains(EntityNames.Membership.RenewalsPaymentMethod) ? targetMembership.RenewalsPaymentMethod : preImageMembership.RenewalsPaymentMethod,
                        Isrenewalcontinuouspayment = targetEntity.Contains(EntityNames.Membership.Isrenewalcontinuouspayment) ? targetMembership.Isrenewalcontinuouspayment : preImageMembership.Isrenewalcontinuouspayment,
                        RenewalPaymentFrequency = targetEntity.Contains(EntityNames.Membership.RenewalPaymentFrequency) ? targetMembership.RenewalPaymentFrequency : preImageMembership.RenewalPaymentFrequency,
                        RenewalPaymentSchedule = targetEntity.Contains(EntityNames.Membership.RenewalPaymentSchedule) ? targetMembership.RenewalPaymentSchedule : preImageMembership.RenewalPaymentSchedule,
                        PatronMembership = targetEntity.Contains(EntityNames.Membership.PatronMembership) ? targetMembership.PatronMembership : preImageMembership.PatronMembership,
                        RenewalsStartDate = targetEntity.Contains(EntityNames.Membership.RenewalsStartDate) ? targetMembership.RenewalsStartDate : preImageMembership.RenewalsStartDate,
                        RenewalsEndDate = targetEntity.Contains(EntityNames.Membership.RenewalsEndDate) ? targetMembership.RenewalsEndDate : preImageMembership.RenewalsEndDate,
                        PaymentReceived = targetEntity.Contains(EntityNames.Membership.PaymentReceived) ? targetMembership.PaymentReceived : preImageMembership.PaymentReceived,
                    };

                    #region Membership Setup Logics
                    if (membershipUpdateService.ValidateIfMemberValidationShouldBeDone(preImageMembership, postImageMembership))
                    {
                        membershipUpdateService.MembershipMembersValidationV2(postImageMembership);
                        membershipUpdateService.ValidateAddressInMembership(targetEntity, preImageMembership);
                    }

                    if (membershipUpdateService.ValidateIfCampaignAmountShouldBeRepopulated(preImageMembership, postImageMembership))
                    {
                        membershipCreateService.ValidateCampaignInMembership(postImageMembership);
                        targetEntity = membershipCreateService.SetCampaignAmountOnMembershipEntity(targetEntity, postImageMembership);
                    }
                    if (membershipUpdateService.ValidateIfTotalAmountShouldBeRecalculated(preImageMembership, postImageMembership))
                    {
                        var originalTotalAmount = postImageMembership.TotalAmount;
                        targetEntity = membershipCreateService.SetPriceListOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipCreateService.SetMembershipPriceOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipCreateService.SetCampaignAmountOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipCreateService.SetTotalAmountOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipUpdateService.RevertTotalAmountIfMembershipContainsDonation(targetEntity, postImageMembership, originalTotalAmount);
                        targetEntity = membershipUpdateService.SetOutstandingAmounteOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipCreateService.SetIsDDDiscountAvailedOnMembership(targetEntity, postImageMembership);
                    }
                    if (membershipUpdateService.ValidateIfDonationAmountShouldBeRecalculated(preImageMembership, postImageMembership))
                    {
                        membershipUpdateService.ValidatePatronTotalAmount(postImageMembership);
                        targetEntity = membershipUpdateService.SetDonationAmountOnMembershipEntity(targetEntity, postImageMembership);
                        targetEntity = membershipUpdateService.SetOutstandingAmounteOnMembershipEntity(targetEntity, postImageMembership);
                    }
                    if (membershipUpdateService.ValidateIfPaymentSubmissionWasTriggered(preImageMembership, postImageMembership) ||
                        membershipUpdateService.ValidateIfActivatedWithoutStartDate(preImageMembership, postImageMembership))
                    {
                        targetEntity = membershipUpdateService.SetStartDateOnMembershipEntity(targetEntity, postImageMembership);
                        if (membershipUpdateService.ValidateIfEndDateRequiresRecalculation(preImageMembership, postImageMembership))
                        {
                            targetEntity = membershipUpdateService.SetEndDateOnMembershipEntity(targetEntity, postImageMembership);
                            targetEntity = membershipUpdateService.SetRenewalsStartDateOnMembershipEntity(targetEntity, postImageMembership);
                            targetEntity = membershipUpdateService.SetRenewalsEndDateOnMembershipEntity(targetEntity, postImageMembership);
                        }
                        if (postImageMembership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit)
                        {
                            targetEntity = membershipUpdateService.SetPayoutDate(targetEntity, postImageMembership);
                        }
                    }
                    #endregion

                    #region Active Membership Logics
                    // Activation
                    if (membershipUpdateService.ValidateIfMembershipWasActivated(preImageMembership, postImageMembership))
                    {
                        if (membershipUpdateService.ValidateIfMembershipPackMHStatusShouldBeSetToPending(postImageMembership))
                            targetEntity = membershipUpdateService.SetNewMembershipPackMHStatusOnMembershipEntity(targetEntity, postImageMembership);

                        membershipUpdateService.PopulatePrimaryMembershipOfMembers(postImageMembership);
                    }
                    if (membershipUpdateService.ValidateIfMembershipWasActivated(preImageMembership, postImageMembership)) //needs to occur after end date gets populated
                    {
                        targetEntity = membershipUpdateService.SetMembershipCardDetails(targetEntity, postImageMembership);
                    }

                    membershipUpdateService.SetStatusOnMembershipEntity(targetEntity, preImageMembership, postImageMembership);
                    membershipUpdateService.SetPatronMembershipOnMembership(targetEntity, postImageMembership);

                    #endregion

                    #region Cancelled Membership Logics
                    // Cancellation
                    if (membershipUpdateService.ValidateIfDDMembershipWasCancelled(postImageMembership))
                    {
                        customAPIInvocationService.InvokeCancelDDICustomAPI(postImageMembership.Id, NewTransactionType_GlobalOptionSet.Membership);
                    }
                    if (targetEntity.Contains(EntityNames.Membership.MembershipCancellationReasonId))
                    {
                        membershipUpdateService.MembershipCancellation(targetEntity);
                    }
                    #endregion

                    #region Payment Info Change Logics
                    // Payer change
                    if (membershipUpdateService.ValidateIfPayerWasChangedForDDMembership(preImageMembership, postImageMembership))
                    {
                        customAPIInvocationService.InvokeCancelDDICustomAPI(postImageMembership.Id, NewTransactionType_GlobalOptionSet.Membership);
                        targetEntity = membershipUpdateService.MakeMembershipPayableWhenOutstandingAmountGreaterThanZero(targetEntity, postImageMembership);
                        targetEntity = membershipUpdateService.SetPaymentMethodToCard(targetEntity, postImageMembership);
                    }

                    // Payment method change
                    if (membershipUpdateService.ValidateIfPaymentMethodWasChangedFromDD(preImageMembership, postImageMembership))
                    {
                        customAPIInvocationService.InvokeCancelDDICustomAPI(postImageMembership.Id, NewTransactionType_GlobalOptionSet.Membership);
                        targetEntity = membershipUpdateService.MakeMembershipPayableWhenOutstandingAmountGreaterThanZero(targetEntity, postImageMembership);
                    }
                    #endregion

                    #region Renewal Logics
                    // Renewal
                    if (postImageMembership.InRenewalsStage == true && postImageMembership.RenewalsStatus == RenewalsStatus_GlobalOptionSet.PendingRenewal)
                    {
                        membershipUpdateService.ValidateRenewalCampaignInMembership(postImageMembership);

                        if (membershipUpdateService.ValidateIfRenewalsTotalAmountShouldBeRecalculated(targetEntity))
                        {
                            targetEntity = membershipUpdateService.SetRenewalMembershipPriceOnMembershipEntity(targetEntity, postImageMembership);
                            targetEntity = membershipUpdateService.SetRenewalTotalAmountOnMembershipEntity(targetEntity, postImageMembership);
                        }

                        if (membershipUpdateService.ValidateIfRenewalsPayoutDateShouldBeRecalculated(preImageMembership, postImageMembership))
                        {
                            targetEntity = membershipUpdateService.SetRenewalsPayoutDate(targetEntity, postImageMembership);
                        }
                    }
                    #endregion
                }
            }
        }
    }
}