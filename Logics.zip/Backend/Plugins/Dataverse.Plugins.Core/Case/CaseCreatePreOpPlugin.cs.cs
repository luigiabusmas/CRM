﻿using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.Core
{
    [PluginRegistration(
        EntityLogicalName = "incident",
        MessageName = "Create",
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class CaseCreatePreOpsPlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var logger = container.Resolve<ILogger>();
            var context = container.Resolve<IPluginExecutionContext>();
            var caseService = container.Resolve<ICaseService>();

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity target)
            {
                if (target.LogicalName == "incident")
                {
                    logger.TraceInformation("Executing CaseCreatePreOpsPlugin.");

                    // Sets the GDPR Deletion Date
                    caseService.PopulateGdprDeletionDate(target);

                    // Sets the routecase value
                    caseService.SetRouteCase(target);
                }
            }
        }
    }
}