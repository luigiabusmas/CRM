﻿using System;
using System.Diagnostics.CodeAnalysis;

[assembly:CLSCompliant(false)]
[assembly: SuppressMessage("Microsoft.Naming", "IDE0058:ExpressionValueIsNeverUsed", Justification = "",
    Scope = "module")]
[assembly: SuppressMessage("Style", "IDE0046:Convert to conditional expression",
    Scope = "namespaceanddescendants",
    Target = "~N:Avanade.BizApps.Core")]