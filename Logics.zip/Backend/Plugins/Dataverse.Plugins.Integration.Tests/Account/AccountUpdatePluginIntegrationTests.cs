using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Xrm.Sdk;
using Shouldly;
using System;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Services;
using Avanade.BizApps.Core.Services.Contracts;
using Cultivate.Entities.Generated;
using Cultivate.IntegrationTests.Common;

namespace Cultivate.Plugins.Integration.Tests
{
	[TestClass]
	[Ignore]
	public class AccountUpdatePluginIntegrationTests : IntegrationTestsBase
	{
		[TestInitialize]
        public override void Initialize()
        {
            base.Initialize();
        }

        [TestMethod]
		[TestCategory("Integration")]
		public void Given_Account_PrimaryContactId_Change_When_Validate_Then_UpdateAccountOptionI()
		{
			//Arrange
            var accountRepository = DependencyContainer.Resolve<IRepository<Account>>();
            var account = accountRepository.GetById(Guid.Parse("0a0ed80b-c729-eb11-a813-000d3a6541e8"));

			account.PrimaryContactId = new EntityReference(Contact.EntityLogicalName, Guid.Parse("211dd11b-0373-4ca3-bc8c-3ea4935278dc"));

			//Act & Assert
			Should.NotThrow(() => Connection.CrmService.Update(account));
		}

        [TestMethod]
		[TestCategory("Integration")]
		public void Given_Account_PrimaryContactId_Change_When_Validate_Then_UpdateAccountOptionII()
		{
			// Arrange
            var accountRepository = DependencyContainer.Resolve<IRepository<Account>>();
            var preImage = accountRepository.GetById(Guid.Parse("0a0ed80b-c729-eb11-a813-000d3a6541e8"));

			var target = new Account
            {
				Id = preImage.Id,
				PrimaryContactId =
				new EntityReference(
					Contact.EntityLogicalName,
					new Guid("511dd11b-0373-4ca3-bc8c-3ea4935278dc")
				)
			};

			DependencyContainer.RegisterInstance<IAttributeChangedService<Account>>(new AttributeChangedService<Account>(preImage, target));

			// Act
			// ** Uncomment to debug plugin logic
			//plugin = new AccountUpdatePlugin();
			//plugin.DoExecute(DependencyContainer, target);

            accountRepository.Update(target);

			var accountAfterPluginExecution = accountRepository.GetById(Guid.Parse("0a0ed80b-c729-eb11-a813-000d3a6541e8"));

			// Assert
			accountAfterPluginExecution.PrimaryContactId.ShouldBe(target.PrimaryContactId);
		}

        [TestMethod]
		[TestCategory("Integration")]
		public void Given_AccountCustomerTypeCodeBusiness_PrimaryContactId_Change_When_Validate_Then_ThrowException()
		{
			// Arrange
            var accountRepository = DependencyContainer.Resolve<IRepository<Account>>();
            var account = accountRepository.GetById(Guid.Parse("1E95A98E-E617-4E59-8AE8-C022F0E7487F"));

			account.PrimaryContactId = new EntityReference(Contact.EntityLogicalName, new Guid("511dd11b-0373-4ca3-bc8c-3ea4935278dc"));

			//Act & Assert
            Should.Throw(() => Connection.CrmService.Update(account), typeof(InvalidPluginExecutionException));
		}
	}
}