using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Cultivate.Plugins.ExampleSolution;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace Cultivate.Plugins.Tests
{
    [TestClass]
    public class AccountUpdatePluginTests
    {
        private IDependencyContainer _container;
        private IAccountContactSyncService _service;
        private AccountUpdatePlugin _plugin;

        [TestInitialize]
        public void Setup()
        {
            _container = Substitute.For<IDependencyContainer>();

            _service = Substitute.For<IAccountContactSyncService>();
            _container.Resolve<IAccountContactSyncService>().Returns(_service);

            _plugin = new AccountUpdatePlugin();
        }

        [TestMethod]
        public void DispatchesCallsToService()
        {
            _plugin.Execute(_container, new Account());
            _service.Received().SyncAccountDetailsToPrimaryContact(Arg.Any<Account>());
        }
    }
}
