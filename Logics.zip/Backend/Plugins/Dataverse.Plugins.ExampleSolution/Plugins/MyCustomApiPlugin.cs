using System;
using System.Runtime.Serialization;
using Avanade.BizApps.Core.Extensions;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Microsoft.Xrm.Sdk;

namespace Cultivate.Plugins.ExampleSolution
{
    [PluginRegistration()]
    public class MyCustomApiPlugin : CustomApiPlugin<MyCustomApiRequest, MyCustomApiResponse>, IPlugin
    {
        public override MyCustomApiResponse Execute(IDependencyContainer container, MyCustomApiRequest request)
        {
            try
            {
                var service = container.Resolve<IAccountContactSyncService>();
                service.SyncAccountDetailsToPrimaryContact(request.AccountId);

                return new MyCustomApiResponse { Success = true };
            }
            catch (Exception e)
            {
                return new MyCustomApiResponse
                {
                    Success = false,
                    Error = e.FormatMessage()
                };
            }
        }
    }

    public class MyCustomApiRequest
    {
        [DataMember(Name = nameof(AccountId))]
        public Guid AccountId { get; set; }

        [DataMember(Name = "MySecondValue")]
        public string SecondProperty { get; set; }
    }

    public class MyCustomApiResponse
    {
        [DataMember(Name = nameof(Success))]
        public bool Success { get; set; }

        [DataMember(Name = nameof(Error))]
        public string Error { get; set; }
    }
}
