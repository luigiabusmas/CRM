using Avanade.BizApps.Core.CommandDispatcher.Entities;
using Avanade.BizApps.Core.CommandDispatcher.EntryPoint;
using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Microsoft.Xrm.Sdk;

namespace Cultivate.Plugins.ExampleSolution
{
    [PluginRegistration(
        EntityLogicalName = Command.EntityLogicalName,
        Stage = Stage.PreOperation,
        MessageName = MessageNames.Create
    )]
    public class CommandPlugin : Plugin<Command>, IPlugin
    {
        public override void Execute(IDependencyContainer container, Command command)
        {
            var commandService = container.Resolve<ICommandService>();
            commandService.ExecuteCommand(command);
        }
    }
}