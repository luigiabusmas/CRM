using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.ExampleSolution
{
    [PluginRegistration(
        EntityLogicalName = Account.EntityLogicalName,
        MessageName = MessageNames.Create,
        Stage = Stage.PostOperation,
        IncludePreImage = false,
        ExecutionOrder = 1,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class AccountCreatePostOpslugin : Plugin<Account>, IPlugin
    {
        public override void Execute(IDependencyContainer container, Account account)
        {
            var service = container.Resolve<IAccountContactSyncService>();
            service.CreateContactFromAccount(account);
        }
    }
}