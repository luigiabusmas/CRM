using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.ExampleSolution
{
    [PluginRegistration(
        EntityLogicalName = Account.EntityLogicalName,
        MessageName = MessageNames.Delete,
        Stage = Stage.PreOperation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class AccountDeletePlugin : Plugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var executionContext = container.Resolve<IPluginExecutionContext>();
            var deleteRequest = new DeleteRequest { Parameters = executionContext.InputParameters };

            var cleanUpService = container.Resolve<IAccountCleanupService>();
            cleanUpService.CleanUp(deleteRequest.Target.Id);
        }
    }
}