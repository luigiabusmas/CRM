using Avanade.BizApps.Core.Constants;
using Avanade.BizApps.Core.Plugins;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Services;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Plugin = Avanade.BizApps.Core.Plugins.Plugin;

namespace Cultivate.Plugins.ExampleSolution
{
    [PluginRegistration(
        EntityLogicalName = Account.EntityLogicalName,
        MessageName = MessageNames.RetrieveMultiple,
        Stage = Stage.PreValidation,
        IncludePreImage = false,
        Mode = SdkMessageProcessingStepMode.Synchronous
    )]
    public class AccountRetrieveMultiplePlugin : Plugin, IPlugin
    {
        public override void Execute(IDependencyContainer container)
        {
            var context = container.Resolve<IPluginExecutionContext>();
            if (context.InputParameters.Contains(InputParameters.Query))
            {
                var messageService = container.Resolve<IDataverseMessageService>();

                var condition = new ConditionExpression
                {
                    AttributeName = EntityNames.Account.Name,
                    Operator = ConditionOperator.DoesNotBeginWith,
                    Values = { "EXCLUDE_FROM_HOME_VIEW" }
                };

                if (context.InputParameters[InputParameters.Query] is QueryExpression qe)
                {
                    qe.Criteria.AddCondition(condition);
                }
                else if (context.InputParameters[InputParameters.Query] is FetchExpression fe)
                {
                    var fetchXmlToQueryExpressionRequest = new FetchXmlToQueryExpressionRequest
                    {
                        FetchXml = fe.Query
                    };

                    var response = messageService.ExecuteRequest<FetchXmlToQueryExpressionResponse>(fetchXmlToQueryExpressionRequest);
                    response.Query.Criteria.AddCondition(condition);

                    context.InputParameters[InputParameters.Query] = response.Query;
                }
            }
        }
    }
}