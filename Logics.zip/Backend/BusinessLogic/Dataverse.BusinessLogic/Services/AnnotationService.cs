using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    /// <summary>
    /// Service for handling annotation operations, including copying annotations between entities.
    /// </summary>
    public interface IAnnotationService
    {
        /// <summary>
        /// Copies all annotations from a portal session to specified contacts.
        /// </summary>
        /// <param name="portalSession">The source portal session</param>
        /// <param name="member">The primary contact to copy annotations to</param>
        /// <param name="additionalMember">Optional secondary contact to copy annotations to</param>
        void CopyPortalSessionAnnotationsToContacts(
            Portalsession portalSession,
            Contact member,
            Contact additionalMember = null
        );
    }

    public class AnnotationService : IAnnotationService
    {
        #region Fields

        private readonly ITracingService _tracingService;
        private readonly IOrganizationService _service;
        private readonly IAnnotationRepository _annotationRepository;

        #endregion Fields

        #region Constructor

        public AnnotationService(
            ITracingService tracingService,
            IOrganizationService service,
            IAnnotationRepository annotationRepository
        )
        {
            _tracingService = tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _service = service ?? throw new ArgumentNullException(nameof(service));
            _annotationRepository = annotationRepository ?? throw new ArgumentNullException(nameof(annotationRepository));
        }

        #endregion Constructor

        #region Public Methods

        public void CopyPortalSessionAnnotationsToContacts(
            Portalsession portalSession,
            Contact member,
            Contact additionalMember = null
        )
        {
            _tracingService.Trace("Checking for annotations attached to portal session.");

            try
            {
                var annotations = _annotationRepository
               .GetByRegardingId(portalSession.Id, EntityNames.Portalsession.EntityLogicalName)
                          .ToList();

                if (annotations.Count == 0)
                {
                    _tracingService.Trace("No annotations found for portal session.");
                    return;
                }

                _tracingService.Trace($"Found {annotations.Count} annotation(s) to copy.");

                foreach (var annotation in annotations)
                {
                    CopyAnnotationToContact(annotation, member);

                    if (additionalMember != null)
                    {
                        CopyAnnotationToContact(annotation, additionalMember);
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace($"Error copying annotations: {ex.Message}");
                // Log but don't fail the entire process
            }
        }

        #endregion Public Methods

        #region Private Methods

        private void CopyAnnotationToContact(Annotation sourceAnnotation, Contact contact)
        {
            try
            {
                var newAnnotation = new Annotation
                {
                    ObjectId = contact.ToEntityReference(),
                    ObjectTypeCode = EntityNames.Contact.EntityLogicalName,
                };

                if (sourceAnnotation.Subject != null)
                {
                    newAnnotation.Subject = sourceAnnotation.Subject;
                }

                if (sourceAnnotation.NoteText != null)
                {
                    newAnnotation.NoteText = sourceAnnotation.NoteText;
                }

                if (sourceAnnotation.FileName != null)
                {
                    newAnnotation.FileName = sourceAnnotation.FileName;
                }

                if (sourceAnnotation.MimeType != null)
                {
                    newAnnotation.MimeType = sourceAnnotation.MimeType;
                }

                if (sourceAnnotation.DocumentBody != null)
                {
                    newAnnotation.DocumentBody = sourceAnnotation.DocumentBody;
                }

                if (sourceAnnotation.IsDocument.HasValue)
                {
                    newAnnotation.IsDocument = sourceAnnotation.IsDocument;
                }

                _service.Create(newAnnotation);
                _tracingService.Trace($"Copied annotation to contact {contact.Id}");
            }
            catch (Exception ex)
            {
                _tracingService.Trace(
               $"Error copying annotation to contact {contact.Id}: {ex.Message}"
                         );
                // Log but continue with other annotations
            }
        }

        #endregion Private Methods
    }
}