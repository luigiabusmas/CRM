using System;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;

namespace Cultivate.BusinessLogic.Services
{
    /// <summary>
    /// Service for processing membership orders from portal sessions.
    /// </summary>
    public interface IMembershipOrderService
    {
        /// <summary>
        /// Processes a membership order from a portal session.
        /// </summary>
        /// <param name="portalSession">The portal session containing the order details.</param>
        /// <param name="discount">Optional discount to apply.</param>
        void ProcessMembershipOrder(
            Portalsession portalSession,
            PortalSessionDiscount discount = null
        );
    }

    /// <summary>
    /// Handles membership order creation and processing from portal sessions.
    /// </summary>
    public class MembershipOrderService : IMembershipOrderService
    {
        #region Constants

        private const string MembershipTypeJoint = "Joint";
        private const string MembershipTypeIndividual = "Individual";
        private const string CancellationReasonDuplicate = "Duplicate";

        #endregion Constants

        #region Fields

        private readonly ITracingService _tracingService;
        private readonly IMembershipContactCreateService _membershipContactCreateService;
        private readonly IRecordDateCalculationService _recordDateCalculationService;
        private readonly IPaymentProcessingService _paymentProcessingService;
        private readonly IAnnotationService _annotationService;
        private readonly ICommonService _commonService;

        private readonly IPortalSessionContactRepository _portalSessionContactRepository;
        private readonly IMembershipRepository _membershipRepository;
        private readonly IRepository<GiftAidDeclaration> _giftAidDeclarationRepository;
        private readonly IPortalSessionDiscountRepository _portalSessionDiscountRepository;
        private readonly ICancellationReasonRepository _cancellationReasonRepository;
        private readonly IContactRepository _contactRepository;
        private readonly IProductRepository _productRepository;

        #endregion Fields

        #region Constructor

        public MembershipOrderService(
            ITracingService tracingService,
            IMembershipContactCreateService membershipContactCreateService,
            IRecordDateCalculationService recordDateCalculationService,
            IPaymentProcessingService paymentProcessingService,
            IAnnotationService annotationService,
            IPortalSessionContactRepository portalSessionContactRepository,
            IMembershipRepository membershipRepository,
            IRepository<GiftAidDeclaration> giftAidDeclarationRepository,
            IPortalSessionDiscountRepository portalSessionDiscountRepository,
            ICancellationReasonRepository cancellationReasonRepository,
            IContactRepository contactRepository,
            IProductRepository productRepository,
            ICommonService commonService
        )
        {
            _tracingService =
                tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _membershipContactCreateService =
                membershipContactCreateService
                ?? throw new ArgumentNullException(nameof(membershipContactCreateService));
            _recordDateCalculationService =
                recordDateCalculationService
                ?? throw new ArgumentNullException(nameof(recordDateCalculationService));
            _paymentProcessingService =
                paymentProcessingService
                ?? throw new ArgumentNullException(nameof(paymentProcessingService));
            _annotationService =
                annotationService ?? throw new ArgumentNullException(nameof(annotationService));
            _portalSessionContactRepository =
                portalSessionContactRepository
                ?? throw new ArgumentNullException(nameof(portalSessionContactRepository));
            _membershipRepository =
                membershipRepository
                ?? throw new ArgumentNullException(nameof(membershipRepository));
            _giftAidDeclarationRepository =
                giftAidDeclarationRepository
                ?? throw new ArgumentNullException(nameof(giftAidDeclarationRepository));
            _portalSessionDiscountRepository =
                portalSessionDiscountRepository
                ?? throw new ArgumentNullException(nameof(portalSessionDiscountRepository));
            _cancellationReasonRepository =
                cancellationReasonRepository
                ?? throw new ArgumentNullException(nameof(cancellationReasonRepository));
            _contactRepository =
                contactRepository ?? throw new ArgumentNullException(nameof(contactRepository));
            _productRepository =
                productRepository ?? throw new ArgumentNullException(nameof(productRepository));
            _commonService = commonService ?? throw new ArgumentNullException(nameof(commonService));
        }

        #endregion Constructor

        #region Public Methods

        /// <inheritdoc />
        public void ProcessMembershipOrder(
            Portalsession portalSession,
            PortalSessionDiscount discount = null
        )
        {
            var product = GetProductFromSession(portalSession);
            string productNumber = product?.ProductNumber;

            ValidateMembershipProduct(portalSession, productNumber);

            var memberContact = GetContactFromSession(portalSession.Memberid.Id);
            Contact member = ResolveOrCreateContact(memberContact, portalSession.PaymentMethodCode);

            Contact additionalMember = null;
            DateTime? membershipStartDate = null;

            if (_commonService.IsTescoVoucherPayment(portalSession))
            {
                (additionalMember, membershipStartDate) = ProcessTescoVoucherMembershipLogic(
                    portalSession,
                    member,
                    productNumber
                );
            }
            else
            {
                additionalMember = GetAdditionalMember(portalSession);
            }

            var payer = GetPayer(portalSession, member);

            if (!_commonService.IsTescoVoucherPayment(portalSession))
            {
                CreateGiftAidDeclarationIfNeeded(memberContact, member);
            }

            if (member != null)
            {
                var portalSessionDiscount =
                    discount
                    ?? _portalSessionDiscountRepository.GetByPortalSesssionId(portalSession.Id);
                var campaign = portalSessionDiscount?.Campaign;

                var membership = CreateMembership(
                    portalSession,
                    member,
                    additionalMember,
                    payer,
                    memberContact,
                    campaign,
                    membershipStartDate
                );
                membership = _membershipRepository.GetById(membership.Id);

                _paymentProcessingService.HandleMembershipPayment(
                    portalSession,
                    membership,
                    payer,
                    portalSessionDiscount
                );

                // Copy any annotations from portal session to member contact(s)
                _annotationService.CopyPortalSessionAnnotationsToContacts(
                    portalSession,
                    member,
                    additionalMember
                );
            }
        }

        #endregion Public Methods

        #region Tesco Voucher Membership Logic

        private (Contact additionalMember, DateTime? startDate) ProcessTescoVoucherMembershipLogic(
            Portalsession portalSession,
            Contact member,
            string productNumber
        )
        {
            Contact additionalMember = null;
            DateTime? newMembershipStartDate = null;
            DateTime? additionalMemberNewStartDate = null;

            (additionalMember, newMembershipStartDate) = HandleMembershipTypeSwitching(
                portalSession,
                member,
                productNumber
            );
            newMembershipStartDate = HandleMembershipRenewalOrExpiry(
                member,
                null,
                newMembershipStartDate,
                out additionalMemberNewStartDate,
                productNumber
            );

            // Use the later of the two start dates if both exist
            if (
                additionalMemberNewStartDate.HasValue
                && (
                    !newMembershipStartDate.HasValue
                    || additionalMemberNewStartDate > newMembershipStartDate
                )
            )
            {
                newMembershipStartDate = additionalMemberNewStartDate;
            }

            return (additionalMember, newMembershipStartDate);
        }

        private (Contact additionalMember, DateTime? newMembershipStartDate) HandleMembershipTypeSwitching(
            Portalsession portalSession,
            Contact member,
            string productNumber
        )
        {
            bool isJoint = IsJointMembership(productNumber);
            bool isIndividual = IsIndividualMembership(productNumber);

            if (isJoint)
            {
                var cancelled = CancelActiveMembershipIfExists(member, MembershipTypeIndividual);
                return (null, cancelled ? DateTime.UtcNow : null);
            }

            if (isIndividual && HasAdditionalMember(portalSession))
            {
                var additionalMemberContact = GetContactFromSession(
                    portalSession.Additionalmemberid.Id
                );
                Contact additionalMember = ResolveOrCreateContact(
                    additionalMemberContact,
                    portalSession.PaymentMethodCode
                );
                var cancelled = CancelActiveMembershipIfExists(member, MembershipTypeJoint);
                return (additionalMember, cancelled ? DateTime.UtcNow : null);
            }

            return (null, null);
        }

        private DateTime? HandleMembershipRenewalOrExpiry(
            Contact member,
            Contact additionalMember,
            DateTime? newMembershipStartDate,
            out DateTime? additionalMemberNewStartDate,
            string productNumber
        )
        {
            additionalMemberNewStartDate = null;

            if (IsIndividualMembership(productNumber) && newMembershipStartDate == null)
            {
                return HandleRenewalForType(
                    member,
                    MembershipTypeIndividual,
                    out additionalMemberNewStartDate,
                    null
                );
            }

            if (
                IsJointMembership(productNumber)
                && newMembershipStartDate == null
                && additionalMember != null
            )
            {
                return HandleRenewalForType(
                    member,
                    MembershipTypeJoint,
                    out additionalMemberNewStartDate,
                    additionalMember
                );
            }

            return newMembershipStartDate;
        }

        private DateTime? HandleRenewalForType(
            Contact member,
            string membershipType,
            out DateTime? additionalMemberNewStartDate,
            Contact additionalMember = null
        )
        {
            additionalMemberNewStartDate = null;
            var cancellationReason = _cancellationReasonRepository.GetCancellationReasonbyName(
                CancellationReasonDuplicate
            );
            var product = GetProductByNumberOrThrow(membershipType);

            var memberships =
                _membershipRepository.GetActiveOrPendingMembershipsByContactAndProduct(
                    member.Id,
                    product.Id,
                    additionalMember?.Id
                );

            var membership = memberships?.FirstOrDefault();
            if (membership == null)
                return null;

            if (membership.Enddate < DateTime.UtcNow)
            {
                CancelMembership(
                    membership,
                    cancellationReason,
                    Membershipcancellationtypecode_GlobalOptionSet.Now
                );
                LogMembershipCancellation(
                    membershipType,
                    member,
                    additionalMember,
                    "Cancelled expired"
                );
                return null;
            }

            membership.CancellationDate = membership.Enddate;
            CancelMembership(
                membership,
                cancellationReason,
                Membershipcancellationtypecode_GlobalOptionSet.Atendofmembership
            );
            LogMembershipCancellation(
                membershipType,
                member,
                additionalMember,
                "Scheduled future cancellation for active",
                membership.Enddate
            );

            return membership.Enddate?.AddDays(1);
        }

        #endregion Tesco Voucher Membership Logic

        #region Membership Cancellation

        private bool CancelActiveMembershipIfExists(Contact member, string membershipType)
        {
            var cancellationReason = _cancellationReasonRepository.GetCancellationReasonbyName(
                CancellationReasonDuplicate
            );
            var product = GetProductByNumberOrThrow(membershipType);
            var membership = _membershipRepository.GetActiveMembershipByContactAndProduct(
                member.Id,
                product.Id
            );

            if (membership == null)
                return false;

            CancelMembership(
                membership,
                cancellationReason,
                Membershipcancellationtypecode_GlobalOptionSet.Now
            );

            var cancellationMessage =
                membershipType == MembershipTypeJoint
                    ? $"Cancelled active Joint membership for contacts {member.Id} due to Individual purchase"
                    : $"Cancelled active Individual membership for contact {member.Id} due to Joint purchase";

            _tracingService.Trace(cancellationMessage);
            return true;
        }

        private void CancelMembership(
            Membership membership,
            CancellationReason cancellationReason,
            Membershipcancellationtypecode_GlobalOptionSet cancellationType
        )
        {
            membership.Statuscode = MembershipStatus.Inactive_Cancelled;
            membership.Statecode = MembershipState.Inactive;
            membership.CancelMembership = true;
            membership.CancellationType = cancellationType;
            membership.MembershipCancellationReasonId = cancellationReason?.ToEntityReference();
            _membershipRepository.Update(membership);
        }

        #endregion Membership Cancellation

        #region Membership Creation

        private Membership CreateMembership(
            Portalsession portalSession,
            Contact member,
            Contact additionalMember,
            Contact payer,
            Portalsessioncontact portalSessionContact,
            EntityReference campaign,
            DateTime? customStartDate = null
        )
        {
            _tracingService.Trace("Creating membership.");
            var startDate = customStartDate ?? _recordDateCalculationService.CalculateMembershipStartDate();

            var membership = new Membership
            {
                MembershipProductId = portalSession.Productid,
                IsMembershipForSomeone = member.Id != payer?.Id,
                Contact = member.ToEntityReference(),
                Member2 = additionalMember?.ToEntityReference(),
                PayerV2 = payer.ToEntityReference(),
                PaymentMethod = portalSession.PaymentMethodCode,
                IsReferredByExistingMember = false,
                GDPRRead = true,
                CancellationRead = true,
                IsRegistrationForGiftAid =
                    portalSessionContact.ActiveGiftAidDeclaration.HasValue
                    && portalSessionContact.ActiveGiftAidDeclaration.Value,
                Startdate = startDate,
                Enddate = _recordDateCalculationService.CalculateEndDateOfRecord(
                    startDate,
                    portalSession.Productid.Id,
                    campaign?.Id
                ),
                Channel = ChannelOptionChoice_GlobalOptionSet.Online,
                Source = Incident_caseorigincode_GlobalOptionSet.OnlineWebPortal,
                PaymentSchedule =
                   portalSession.PaymentMethodCode
                    == PaymentMethodType_GlobalOptionSet.DirectDebit
                        ? startDate
                        : null,
                PaymentFrequency =
                    portalSession.PaymentMethodCode
                    == PaymentMethodType_GlobalOptionSet.DirectDebit
                        ? portalSession.PaymentFrequency
                        : null,
                CheckoutSessionId = portalSession.CheckoutSessionId,
                CheckoutURL = portalSession.CheckoutURL,
                PaymentIntentId = portalSession.PaymentIntentId,
                Statuscode = MembershipStatus.Active_Active,
                Statecode = MembershipState.Active,
                IsContinuousPayment = _commonService.IsContinuousPayment(portalSession),
                CampaignId = campaign,
                PriceList = GetPriceListReference(portalSession),
                GardenMagazine =
                    portalSessionContact.ReceivesPrintedMagazine.HasValue
                    && portalSessionContact.ReceivesPrintedMagazine.Value,
            };

            return _membershipRepository.Create(membership);
        }

        #endregion Membership Creation

        #region Contact Management

        private Contact GetPayer(Portalsession portalSession, Contact member)
        {
            _tracingService.Trace("Checking for payer in portal session.");

            if (portalSession.Payerid == null || portalSession.Payerid.Id == Guid.Empty)
                return null;

            // If payer is the same as member
            if (
                member != null
                && portalSession.Memberid != null
                && portalSession.Payerid.Id == portalSession.Memberid.Id
            )
            {
                return member;
            }

            var portalSessionContactPayer = _portalSessionContactRepository.GetById(
                portalSession.Payerid.Id
            );
            if (portalSessionContactPayer == null || portalSessionContactPayer.Id == Guid.Empty)
                return null;

            // Check if payer and member have same details
            if (member != null && portalSession.Memberid != null)
            {
                var portalSessionContactMember = _portalSessionContactRepository.GetById(
                    portalSession.Memberid.Id
                );
                if (
                    portalSessionContactMember != null
                    && AreContactDetailsSame(portalSessionContactPayer, portalSessionContactMember)
                )
                {
                    return member;
                }
            }

            var payerContact = ResolveOrCreateContact(
                portalSessionContactPayer,
                portalSession.PaymentMethodCode
            );
            return payerContact
                ?? _membershipContactCreateService.Create(portalSessionContactPayer);
        }

        private Contact GetAdditionalMember(Portalsession portalSession)
        {
            if (
                portalSession.Additionalmemberid == null
                || !portalSession.Contains(EntityNames.Portalsession.Additionalmemberid)
            )
                return null;

            var additionalMemberContact = GetContactFromSession(
                portalSession.Additionalmemberid.Id
            );
            if (additionalMemberContact == null)
                return null;

            return _membershipContactCreateService.Create(additionalMemberContact);
        }

        private Contact ResolveOrCreateContact(
            Portalsessioncontact contact,
            PaymentMethodType_GlobalOptionSet? paymentMethod
        )
        {
            if ((PaymentMethodType_GlobalOptionSet) paymentMethod != PaymentMethodType_GlobalOptionSet.TescoVoucher)
            {
                return _membershipContactCreateService.Create(contact);
            }

            var existingContact = FindExistingContact(contact);
            return existingContact != null
                ? _contactRepository.GetById(existingContact.Id)
                : _membershipContactCreateService.Create(contact);
        }

        private Contact FindExistingContact(Portalsessioncontact contact)
        {
            var query = string.IsNullOrWhiteSpace(contact.Emailaddress1)
                ? _contactRepository.GetByNameEmailPostCode(
                    contact.Firstname,
                    contact.Lastname,
                    null,
                    contact.Address1_postalcode
                )
                : _contactRepository.GetByNameEmailPostCode(
                    contact.Firstname,
                    contact.Lastname,
                    contact.Emailaddress1,
                    contact.Address1_postalcode
                );

            return query.FirstOrDefault();
        }

        private void CreateGiftAidDeclarationIfNeeded(
            Portalsessioncontact memberContact,
            Contact member
        )
        {
            _tracingService.Trace(
                "Checking if Gift Aid Declaration is needed for the member contact."
            );

            if (
                !memberContact.Contains(EntityNames.Portalsessioncontact.ActiveGiftAidDeclaration)
                || !memberContact.ActiveGiftAidDeclaration.HasValue
                || !memberContact.ActiveGiftAidDeclaration.Value
            )
            {
                return;
            }

            var giftAidDeclaration = new GiftAidDeclaration
            {
                Source = Giftaiddeclarationsource_GlobalOptionSet.Electronic,
                StartDate = _recordDateCalculationService.CalculateGiftAidStartDate(),
                DeclarationDate = DateTime.UtcNow,
                CustomerId = member.ToEntityReference(),
                CreationRoute = GiftAidDeclarationCreationRoute_GlobalOptionSet.Standalone,
                ScriptRead = true,
                Name = string.Empty,
                AddressHouseName = member.Address1_Name,
                AddressLine1 = member.Address1_Line1,
                AddressLine2 = member.Address1_Line2,
                AddressCity = member.Address1_City,
                AddressPostcode = member.Address1_PostalCode,
            };

            _giftAidDeclarationRepository.Create(giftAidDeclaration);
        }

        #endregion Contact Management

        #region Validation

        private void ValidateMembershipProduct(
            Portalsession portalSession,
            string productNumber
        )
        {
            if (
                portalSession.ProductType != NewTransactionType_GlobalOptionSet.Membership
                && portalSession.ProductType != NewTransactionType_GlobalOptionSet.GiftPack
            )
            {
                throw new ArgumentException(
                    "Portal Session Product Type must be either Membership or GiftPack."
                );
            }

            if (_commonService.IsTescoVoucherPayment(portalSession))
            {
                ValidateTescoVoucherMembershipProduct(portalSession, productNumber);
            }
        }

        private static void ValidateTescoVoucherMembershipProduct(
            Portalsession portalSession,
            string productNumber
        )
        {
            if (portalSession.ProductType != NewTransactionType_GlobalOptionSet.Membership)
            {
                throw new ArgumentException(
                    "Tesco voucher can only be used for Membership product type."
                );
            }

            if (!IsJointMembership(productNumber) && !IsIndividualMembership(productNumber))
            {
                throw new ArgumentException(
                    "Tesco voucher can only be used for Individual or Joint memberships."
                );
            }
        }

        #endregion Validation

        #region Helper Methods

        private static bool EqualsIgnoreCase(string a, string b) =>
            string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);

        private static bool EqualsIfBothProvided(string a, string b) =>
            string.IsNullOrWhiteSpace(a) || string.IsNullOrWhiteSpace(b) || EqualsIgnoreCase(a, b);

        private static bool AreContactDetailsSame(
            Portalsessioncontact payer,
            Portalsessioncontact member)
        {
            if (payer == null || member == null)
                return false;

            return EqualsIgnoreCase(payer.Firstname, member.Firstname)
                && EqualsIgnoreCase(payer.Lastname, member.Lastname)
                && EqualsIfBothProvided(payer.Emailaddress1, member.Emailaddress1)
                && EqualsIgnoreCase(payer.Address1_postalcode, member.Address1_postalcode)
                && EqualsIgnoreCase(payer.Address1_line1, member.Address1_line1);
        }

        private static bool IsJointMembership(string productNumber) =>
            string.Equals(productNumber, MembershipTypeJoint, StringComparison.OrdinalIgnoreCase);

        private static bool IsIndividualMembership(string productNumber) =>
            string.Equals(
                productNumber,
                MembershipTypeIndividual,
                StringComparison.OrdinalIgnoreCase
            );

        private static bool HasAdditionalMember(Portalsession portalSession) =>
            portalSession.Additionalmemberid != null
            && portalSession.Contains(EntityNames.Portalsession.Additionalmemberid);

        private static EntityReference GetPriceListReference(Portalsession portalSession)
        {
            if (
                portalSession.Contains(EntityNames.Portalsession.PriceListID)
                && !string.IsNullOrEmpty(portalSession.PriceListID)
            )
            {
                return new EntityReference(
                    EntityNames.PriceLevel.EntityLogicalName,
                    new Guid(portalSession.PriceListID)
                );
            }
            return null;
        }

        private void LogMembershipCancellation(
            string membershipType,
            Contact member,
            Contact additionalMember,
            string action,
            DateTime? endDate = null
        )
        {
            var memberInfo =
                additionalMember != null
                    ? $"{member.Id} and {additionalMember.Id}"
                    : member.Id.ToString();

            var message = endDate.HasValue
                ? $"{action} {membershipType} membership for contact(s) {memberInfo} at {endDate}"
                : $"{action} {membershipType} membership for contact(s) {memberInfo}";

            _tracingService.Trace(message);
        }

        #endregion Helper Methods

        #region Repository Access Helpers

        private Portalsessioncontact GetContactFromSession(Guid contactId) =>
            _portalSessionContactRepository.GetById(contactId);

        private Product GetProductFromSession(Portalsession portalSession)
        {
            return
                portalSession.ProductidProductRef != null
                && portalSession.ProductidProductRef.Id != Guid.Empty
                ? _productRepository.GetById(portalSession.ProductidProductRef.Id)
                : null;
        }

        private Product GetProductByNumberOrThrow(string productNumber)
        {
            var product = _productRepository.GetByProductNumber(productNumber);
            return product
                ?? throw new InvalidOperationException(
                    $"Product with ProductNumber '{productNumber}' not found."
                );
        }

        #endregion Repository Access Helpers
    }
}