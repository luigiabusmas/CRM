﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using System.Reflection;
using System.Diagnostics;

namespace Cultivate.BusinessLogic.Services
{
    public interface IGiftPackService
    {
        Entity SetGiftPackTitleOnEntity(Entity targetEntity, GiftPack giftPack, DateTime? createdOn = null);
        Entity SetGiftPackPriceAndPriceListOnEntity(Entity targetEntity);
        Entity SetGiftPackCodeOnEntity(Entity targetEntity, GiftPack postImageGiftPack);
        string ComposeGiftPackTitle(GiftPack giftPack, DateTime? createdOn);
        string GenerateGiftPackActivationCode(Guid productId);
        bool ValidateIfPaymentWasSubmitted(GiftPack giftPack);
        Transaction CreateTransactionForGiftPack(GiftPack giftPack);
        Payment CreatePaymentForGiftPack(GiftPack giftPack, EntityReference transactionEntityReference);
        void GiftPackCreateConsents(Entity giftPack);
        bool ValidateIfPricesNeededToBeRecalculated(Entity targetEntity);
        Entity SetPricePostageAndCampaignAmount(Entity giftPack, Entity preImage);
        Entity SetExpirationDate(Entity giftPack);
        ValidateGiftPackCodeResult ValidateGiftPackCode(string giftPackCode);
        void HandleCodeReactivation(GiftPack targetGiftPack);
        void HandleCodeCancellation(GiftPack targetGiftPack, GiftPack preImageGiftPack);
    }

    public class GiftPackService : IGiftPackService
    {
        private ILogger _logger;
        private IOrganizationService _organizationService;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;
        private IPropertyRetrievalService _propertyRetrievalService;
        private IProductService _productService;
        private IRepository<Campaign> _campaignRepository;
        private readonly IGiftPackRepository _giftPackRepository;
        private IRepository<Paymentdiscountconfiguration> _paymentDiscountConfigurationRepository;
        private IRepository<DynamicProperty> _dynamicPropertyRepository;
        private IRepository<ProductAssociation> _productAssociationRepository;

        #region Constants
        const string customAPI = "rhs_consentscreation";
        const int newMemberDataSet = 120000000;
        const int nonMemberDataSet = 120000002;
        const int retailChannel = 120000003;
        #endregion Constants

        public GiftPackService(
            ILogger logger, IOrganizationService service,
            IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository,
            IPropertyRetrievalService propertyRetrievalService, IProductService productService, IRepository<Campaign> campaignRepository, IGiftPackRepository giftPackRepository, IRepository<Paymentdiscountconfiguration> paymentDiscountConfigurationRepository, IRepository<DynamicProperty> dynamicPropertyRepository, IRepository<ProductAssociation> productAssociationRepository)
        {
            _logger = logger;
            _organizationService = service;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _propertyRetrievalService = propertyRetrievalService;
            _productService = productService;
            _campaignRepository = campaignRepository;
            _giftPackRepository = giftPackRepository;
            _paymentDiscountConfigurationRepository = paymentDiscountConfigurationRepository;
            _dynamicPropertyRepository = dynamicPropertyRepository;
            _productAssociationRepository = productAssociationRepository;
        }

        public Entity SetExpirationDate(Entity giftPack)
        {
            _logger.TraceInformation("SetExpirationDate Start");

            // Determine if the gift pack is Retail or Non-Retail based on rhs_giftpackbulkpurchase
            bool isRetail = giftPack.Contains(EntityNames.GiftPack.GiftPackBulkPurchase) && giftPack[EntityNames.GiftPack.GiftPackBulkPurchase] != null;

            // Retrieve the valid until value from Cultivate Configurations table
            int validUntilYears = GetValidUntilYears(isRetail);

            // Calculate expiration date based on validUntilYears
            DateTime expirationDate = DateTime.Today.AddYears(validUntilYears);
            giftPack[EntityNames.GiftPack.ExpireDate] = expirationDate;

            _logger.TraceInformation($"SetExpirationDate End - Expiration Date set to: {expirationDate}");

            return giftPack;
        }

        //  method to retrieve validUntilYears from Cultivate Configurations
        private int GetValidUntilYears(bool isRetail)
        {
            // Define the configuration name is retail or non-retail
            string configurationName = isRetail ? "RetailGiftPackValidUntil" : "NonRetailGiftPackValidUntil";
            int defaultYears = isRetail ? 3 : 2; // Default values

            // Query rhs_cultivateconfigurations to retrieve the rhs_value for the specified configuration
            QueryExpression query = new QueryExpression(EntityNames.Cultivateconfigurations.EntityLogicalName)
            {
                ColumnSet = new ColumnSet(EntityNames.Cultivateconfigurations.Value),
                Criteria =
                {
            Conditions =
                    {
                new ConditionExpression(EntityNames.Cultivateconfigurations.Name, ConditionOperator.Equal, configurationName)
                    }
                }
            };

            EntityCollection results = _organizationService.RetrieveMultiple(query);

            if (results.Entities.Count > 0)
            {
                Entity configuration = results.Entities.FirstOrDefault();

                if (configuration != null && configuration.Contains(EntityNames.Cultivateconfigurations.Value))
                {
                    // parse rhs_value as an integer
                    if (int.TryParse(configuration[EntityNames.Cultivateconfigurations.Value].ToString(), out int validUntilYears))
                    {
                        return validUntilYears;
                    }
                    else
                    {
                        _logger.TraceWarning($"Invalid configuration value for '{configurationName}'. Defaulting to {defaultYears} years.");
                    }
                }
            }
            else
            {
                _logger.TraceWarning($"Configuration '{configurationName}' not found. Defaulting to {defaultYears} years.");
            }

            // If configuration not found or invalid, use the default value
            return defaultYears;
        }


        public Entity SetGiftPackTitleOnEntity(Entity targetEntity, GiftPack giftPack, DateTime? createdOn = null)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (giftPack.PurchasedBy == null || giftPack.Product == null)
                throw new InvalidPluginExecutionException("Please select a Product and Purchaser (Purchased By) to set up this record's Title.");

            if (giftPack.Title == null || !giftPack.Title.EndsWith("Batch Order"))
                targetEntity[EntityNames.GiftPack.Title] = ComposeGiftPackTitle(giftPack, createdOn);

            _logger.TraceInformation($"Ending business logic.");
            return targetEntity;
        }

        public Entity SetGiftPackPriceAndPriceListOnEntity(Entity targetEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var targetGiftPack = targetEntity.ToEntity<GiftPack>();

            if (targetGiftPack.Product == null)
                throw new InvalidPluginExecutionException("Please select a Product to set up this record's Price and Price List Used.");

            if (targetGiftPack.PriceListUsed == null)
                targetEntity[EntityNames.GiftPack.PriceListUsed] = _productService.GetPriceListUsedOnProduct(targetGiftPack.Product.Id);
            if (targetGiftPack.Price == null)
                targetEntity[EntityNames.GiftPack.Price] = _productService.GetProductPrice(targetGiftPack.Product.Id);

            _logger.TraceInformation($"Ending business logic.");
            return targetEntity;
        }

        public Entity SetGiftPackCodeOnEntity(Entity targetEntity, GiftPack postImageGiftPack)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Attempting to set the gift pack code.");
            targetEntity[EntityNames.GiftPack.GiftPackCode] = GenerateGiftPackActivationCode(postImageGiftPack.Product.Id);

            _logger.TraceInformation($"Ending business logic.");
            return targetEntity;
        }

        public string ComposeGiftPackTitle(GiftPack giftPack, DateTime? createdOn)
        {
            _logger.TraceInformation($"Starting business logic.");
            var purchasedBy = giftPack.PurchasedBy;
            var productId = giftPack.Product.Id;

            _logger.TraceInformation($"Retrieving gift pack purchaser.");
            Contact purchasedByContact = new Contact();
            Account purchasedByAccount = new Account();
            switch (purchasedBy.LogicalName)
            {
                case EntityNames.Contact.EntityLogicalName:
                    purchasedByContact = _organizationService.Retrieve(
                        EntityNames.Contact.EntityLogicalName,
                        purchasedBy.Id,
                        new ColumnSet(EntityNames.Contact.FullName)
                    ).ToEntity<Contact>();
                    break;
                case EntityNames.Account.EntityLogicalName:
                    purchasedByAccount = _organizationService.Retrieve(
                        EntityNames.Account.EntityLogicalName,
                        purchasedBy.Id,
                        new ColumnSet(EntityNames.Account.Name)
                    ).ToEntity<Account>();
                    break;
            }
            var purchaserName = purchasedByContact.FullName + purchasedByAccount.Name;

            _logger.TraceInformation($"Retrieving gift pack creation datetime.");
            var createdOnString = (createdOn != null ? createdOn : DateTime.UtcNow).ToString();

            _logger.TraceInformation($"Retrieving gift pack product name.");
            var product = _organizationService.Retrieve(
                EntityNames.Product.EntityLogicalName,
                productId,
                new ColumnSet(EntityNames.Product.Name)
            ).ToEntity<Product>();
            var productName = product.Name;

            _logger.TraceInformation($"Composing gift pack title.");
            var title = $"{purchaserName} {createdOnString} {productName}";

            _logger.TraceInformation($"Ending business logic.");
            return title;
        }

        private string GenerateRandomTwelveDigitString()
        {
            var random = new Random();
            var firstFourDigits = random.Next(0000, 9999);
            var secondFourDigits = random.Next(0000, 9999);
            var thirdFourDigits = random.Next(0000, 9999);
            var randomTwelveDigitString = firstFourDigits.ToString("D4") + secondFourDigits.ToString("D4") + thirdFourDigits.ToString("D4");

            return randomTwelveDigitString;
        }

        public string GenerateGiftPackActivationCode(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving Activation Code Prefix product property.");
            var activationCodePrefix = _propertyRetrievalService.GetDefaultStringOfProductProperty(productId, "Activation Code Prefix");
            var giftPackActivationCode = string.Empty;
            var isGiftPackCodeUnique = false;

            while (!isGiftPackCodeUnique)
            {
                _logger.TraceInformation($"Generating a random 12 digit number.");
                var random12Digit = GenerateRandomTwelveDigitString();

                _logger.TraceInformation($"Generating gift pack activation code.");
                giftPackActivationCode = activationCodePrefix + random12Digit;
                isGiftPackCodeUnique = IsGiftPackCodeUnique(giftPackActivationCode);
            }

            _logger.TraceInformation($"Ending business logic.");
            return giftPackActivationCode;
        }

        private bool IsGiftPackCodeUnique(string giftPackCode)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression(EntityNames.GiftPack.EntityLogicalName);
            query.ColumnSet.AddColumn(EntityNames.GiftPack.GiftPackCode);
            query.Criteria.AddCondition(EntityNames.GiftPack.GiftPackCode, ConditionOperator.Equal, giftPackCode);
            var entities = _organizationService.RetrieveMultiple(query).Entities;

            var isGiftPackCodeUnique = entities.Count == 0;
            _logger.TraceInformation($"Is gift pack code unique? {isGiftPackCodeUnique}");

            _logger.TraceInformation($"Ending business logic.");
            return isGiftPackCodeUnique;
        }

        public bool ValidateIfPaymentWasSubmitted(GiftPack giftPack)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (giftPack.IsPaymentSubmitted == true)
            {
                _logger.TraceInformation($"Payment was submitted.");
            }
            else
            {
                _logger.TraceInformation($"Payment was not submitted.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return giftPack.IsPaymentSubmitted == true;
        }

        public Transaction CreateTransactionForGiftPack(GiftPack giftPack)
        {
            _logger.TraceInformation($"Starting business logic.");

            var transaction = _transactionRepository.Create(
                new Transaction()
                {
                    TransacID = null,
                    GiftPackId = giftPack.ToEntityReference(),
                    Product = giftPack.Product,
                    Customer = giftPack.PurchasedBy,
                    PaymentScheduleTransaction = null,
                    Statecode = TransactionState.Active,
                    Statuscode = TransactionStatus.Active_PendingPayment,
                    Amount = giftPack.Price,
                    Type = Typetransaction_GlobalOptionSet.FullPayment,
                    TransactionType = NewTransactionType_GlobalOptionSet.GiftPack,
                    GiftAidEligibility = null,
                    WrittenOffAmount = null,
                    PaidOn = DateTime.UtcNow
                }
            );

            _logger.TraceInformation($"Ending business logic.");
            return transaction;
        }

        public Payment CreatePaymentForGiftPack(GiftPack giftPack, EntityReference transactionEntityReference)
        {
            _logger.TraceInformation($"Starting business logic.");

            var payment = _paymentRepository.Create(
                new Payment()
                {
                    PaymentsID = null,
                    Type = Typetransaction_GlobalOptionSet.FullPayment,
                    Amount = giftPack.Price,
                    PaymentMethodType = giftPack.PaymentMethod,
                    Payer = giftPack.PurchasedBy,
                    Transaction = transactionEntityReference,
                    PaymentSchedule = null,
                    PaymentType = NewTransactionType_GlobalOptionSet.GiftPack,
                    PaidOn = DateTime.UtcNow,
                    ExporttoFinance = false,
                    GiftAidEligibility = null,
                    //GiftAidDeclaration = null,
                    GiftAidDeclarationId = null,
                    DueDate = DateTime.UtcNow,
                    Statuscode = PaymentStatus.Active_PendingPayment
                }
            );

            _logger.TraceInformation($"Ending business logic.");
            return payment;
        }

        public void GiftPackCreateConsents(Entity giftPack)
        {
            _logger.TraceInformation($"GiftPackCreateConsents Start");

            var dataSet = 0;
            Guid? purchasedById = giftPack.Contains(EntityNames.GiftPack.PurchasedBy) &&
                                    ((EntityReference)giftPack[EntityNames.GiftPack.PurchasedBy]).LogicalName == EntityNames.Contact.EntityLogicalName ?
                                    ((EntityReference)giftPack[EntityNames.GiftPack.PurchasedBy]).Id : (Guid?)null;

            Guid? giftPackBulkPurchase = giftPack.Contains(EntityNames.GiftPack.GiftPackBulkPurchase) ?
                                    ((EntityReference)giftPack[EntityNames.GiftPack.PurchasedBy]).Id : (Guid?)null;

            int? channel = giftPack.Contains(EntityNames.GiftPack.Channel) ?
                                    ((OptionSetValue)giftPack[EntityNames.GiftPack.Channel]).Value : (int?)null;

            if (purchasedById.HasValue && channel.HasValue && !giftPackBulkPurchase.HasValue)
            {
                _logger.TraceInformation($"Purchase By Id: {purchasedById.Value}");
                _logger.TraceInformation($"Channel: {channel.Value}");

                if (channel.Value != retailChannel)
                {
                    bool hasMembership = IsContactMember(purchasedById.Value);
                    _logger.TraceInformation($"Has Membership: {hasMembership.ToString()}");

                    if (hasMembership)
                        dataSet = newMemberDataSet;
                    else
                        dataSet = nonMemberDataSet;

                    _logger.TraceInformation($"Dataset: {hasMembership}");
                    InvokeConsentCreationApi(purchasedById.Value.ToString(), dataSet);
                }
            }

            _logger.TraceInformation($"GiftPackCreateConsents Start");

        }

        private bool IsContactMember(Guid contactId)
        {
            bool isMember = false;

            try
            {
                var query = new FetchExpression($@"<fetch>
                  <entity name='contact'>
                    <attribute name='contactid' />
                    <filter type='and'>
                      <condition attribute='statecode' operator='eq' value='0' />
                      <condition attribute='contactid' operator='eq' value='{contactId}' />
                    </filter>
                    <filter type='or'>
                      <link-entity name='rhs_membership' from='rhs_contact' to='contactid' link-type='any' alias='primary'>
                        <filter>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='statuscode' operator='eq' value='1' />
                        </filter>
                      </link-entity>
                      <link-entity name='rhs_membership' from='rhs_member2' to='contactid' link-type='any' alias='secondary'>
                        <filter>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='statuscode' operator='eq' value='1' />
                        </filter>
                      </link-entity>
                    </filter>
                  </entity>
                </fetch>");

                var contact = _organizationService.RetrieveMultiple(query);

                if (contact != null && contact.Entities.Count > 0)
                    isMember = true;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Error IsContactMember: {ex.Message}", ex);
            }

            return isMember;
        }

        private void InvokeConsentCreationApi(string contactId, int memberDataSet)
        {
            try
            {
                OrganizationRequest apiRequest = new OrganizationRequest(customAPI)
                {
                    Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", memberDataSet }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse apiResponse = _organizationService.Execute(apiRequest);

                // Check the response for success or failure
                if (apiResponse != null && apiResponse.Results.Contains("result") && (bool)apiResponse.Results["result"])
                {
                    _logger.TraceInformation("Consent creation via API was successful.");
                }
                else if (apiResponse != null && apiResponse.Results.Contains("error"))
                {
                    string error = apiResponse.Results["error"].ToString();
                    _logger.TraceInformation($"Consent creation via API failed. Error: {error}");
                    throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
                }

                _logger.TraceInformation("Custom API executed successfully.");

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Error invoking Custom API: {ex.Message}", ex);
            }
        }

        public bool ValidateIfPricesNeededToBeRecalculated(Entity targetEntity)
        {
            _logger.TraceInformation("Starting business logic.");

            var isDeliveryContactChanged = targetEntity.Contains(EntityNames.GiftPack.DeliveryContactId);
            _logger.TraceInformation($"Is delivery contact changed? {isDeliveryContactChanged}");

            var isDeliveryAddressChanged = targetEntity.Contains(EntityNames.GiftPack.DeliveryAddress);
            _logger.TraceInformation($"Is delivery address changed? {isDeliveryAddressChanged}");

            var isPostalChargesChanged = targetEntity.Contains(EntityNames.GiftPack.PostalCharges);
            _logger.TraceInformation($"Is postal charges changed? {isPostalChargesChanged}");

            var isProductChanged = targetEntity.Contains(EntityNames.GiftPack.Product);
            _logger.TraceInformation($"Is postal charges changed? {isPostalChargesChanged}");

            var isCampaignChanged = targetEntity.Contains(EntityNames.GiftPack.CampaignId);
            _logger.TraceInformation($"Is postal charges changed? {isPostalChargesChanged}");


            var arePricesNeededToBeRecalculated = isDeliveryContactChanged || isDeliveryAddressChanged || isPostalChargesChanged || isProductChanged || isCampaignChanged;
            _logger.TraceInformation($"Are prices needed to be recalculated? {arePricesNeededToBeRecalculated}");

            _logger.TraceInformation("Ending business logic.");
            return arePricesNeededToBeRecalculated;
        }

        public Entity SetPricePostageAndCampaignAmount(Entity giftPack, Entity preImage)
        {
            _logger.TraceInformation($"AdditionalPostageCalculations Start");

            string entityType = string.Empty;
            Guid deliveryContactId = Guid.Empty;
            EntityReference deliveryContact = null;
            Guid? productId = Guid.Empty;
            int deliveryAddressType = 0;
            Money postalCharge = new Money(0m);
            EntityReference campaignRef = null;
            Money campaignAmount = new Money(0m);
            decimal totalAmount = 0m;

            if (giftPack.Contains(EntityNames.GiftPack.DeliveryContactId) && giftPack[EntityNames.GiftPack.DeliveryContactId] is EntityReference)
            {
                deliveryContact = (EntityReference)giftPack[EntityNames.GiftPack.DeliveryContactId];
            }
            else if (preImage?.Contains(EntityNames.GiftPack.DeliveryContactId) == true && preImage[EntityNames.GiftPack.DeliveryContactId] is EntityReference)
            {
                deliveryContact = (EntityReference)preImage[EntityNames.GiftPack.DeliveryContactId];
            }

            if (deliveryContact != null)
            {
                entityType = (deliveryContact.LogicalName == EntityNames.Account.EntityLogicalName ||
                              deliveryContact.LogicalName == EntityNames.Contact.EntityLogicalName)
                             ? deliveryContact.LogicalName
                             : string.Empty;

                deliveryContactId = deliveryContact.Id;
            }

            _logger.TraceInformation($"Delivery Contact EntityType: {entityType}");
            _logger.TraceInformation($"Delivery Contact Id: {deliveryContactId}");

            if (giftPack.Contains(EntityNames.GiftPack.DeliveryAddress) && giftPack[EntityNames.GiftPack.DeliveryAddress] is OptionSetValue)
            {
                deliveryAddressType = ((OptionSetValue)giftPack[EntityNames.GiftPack.DeliveryAddress]).Value;
            }
            else if (preImage?.Contains(EntityNames.GiftPack.DeliveryAddress) == true && preImage[EntityNames.GiftPack.DeliveryAddress] is OptionSetValue)
            {
                deliveryAddressType = ((OptionSetValue)preImage[EntityNames.GiftPack.DeliveryAddress]).Value;
            }
            _logger.TraceInformation($"Delivery Address Type: {deliveryAddressType}");

            if (giftPack.Contains(EntityNames.GiftPack.Product) && giftPack[EntityNames.GiftPack.Product] is EntityReference)
            {
                productId = ((EntityReference)giftPack[EntityNames.GiftPack.Product]).Id;
            }
            else if (preImage?.Contains(EntityNames.GiftPack.Product) == true && preImage[EntityNames.GiftPack.Product] is EntityReference)
            {
                productId = ((EntityReference)preImage[EntityNames.GiftPack.Product]).Id;
            }


            Money price = productId.HasValue ? _productService.GetProductPrice(productId.Value) : new Money(0m);
            _logger.TraceInformation($"Price: {price?.Value ?? 0m}");

            bool postalChargeChanged = giftPack.Contains(EntityNames.GiftPack.PostalCharges);
            bool deliveryAddressCodeChanged = giftPack.Contains(EntityNames.GiftPack.DeliveryAddress);

            if (deliveryAddressType != 0 && deliveryContactId != Guid.Empty)
            {
                string countryName = GetCountry(entityType, deliveryContactId, deliveryAddressType);
                if (!string.IsNullOrEmpty(countryName))
                {
                    _logger.TraceInformation($"Country Name: {countryName}");

                    decimal postalChargeValue = GetPostalCharges(countryName);

                    if (postalCharge == null || postalCharge.Value == 0m)
                    {
                        postalCharge = new Money(postalChargeValue);
                    }
                    else if (postalChargeChanged && !deliveryAddressCodeChanged)
                    {
                        postalCharge = new Money(postalCharge.Value);
                    }
                    else if (deliveryAddressCodeChanged)
                    {
                        postalCharge = new Money(postalChargeValue);
                    }
                }
                else
                {
                    if (postalCharge == null || postalCharge.Value == 0m)
                    {
                        throw new InvalidPluginExecutionException("Postal charges are missing for the selected delivery address of the delivery contact. Please enter same!");
                    }
                }
            }

            _logger.TraceInformation($"Postal Charges: {postalCharge?.Value ?? 0m}");

            ///Insert for setting the Campaign Amount
            if (giftPack.Contains(EntityNames.GiftPack.CampaignId) && giftPack[EntityNames.GiftPack.CampaignId] is EntityReference)
            {
                campaignRef = (EntityReference)giftPack[EntityNames.GiftPack.CampaignId];
            }
            else if (giftPack.Contains(EntityNames.GiftPack.CampaignId) && giftPack[EntityNames.GiftPack.CampaignId] is null)
            {
                campaignRef = null;
            }
            else if (preImage?.Contains(EntityNames.GiftPack.CampaignId) == true && preImage[EntityNames.GiftPack.CampaignId] is EntityReference)
            {
                campaignRef = (EntityReference)preImage[EntityNames.GiftPack.CampaignId];
            }

            if (campaignRef != null)
            {
                var campaign = _campaignRepository.GetById(campaignRef.Id);
                if (campaign != null)
                {
                    if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                    {
                        //campaignAmount = productId.HasValue ? _productService.GetCampaignProductPrice(productId.Value, campaign.Id) : new Money(0m);
                        //_logger.TraceInformation($"Campaign Amount: {campaignAmount?.Value ?? 0m}");

                        //totalAmount = (campaignAmount?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
                        if (campaign.Paymentdiscountconfiguration != null)
                        {
                            var paymentDiscountConfiguration = _paymentDiscountConfigurationRepository.GetById(campaign.Paymentdiscountconfiguration.Id);

                            if(paymentDiscountConfiguration.DiscountPercentage != null)
                            {
                                price = new Money(price.Value - (price.Value * (paymentDiscountConfiguration.DiscountPercentage.Value / 100m)));
                                totalAmount= (price?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
                            }
                            if(paymentDiscountConfiguration.DiscountAmount != null)
                            {
                                price= new Money(price.Value - paymentDiscountConfiguration.DiscountAmount.Value);
                                totalAmount= (price?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
                            }
                        }
                        else
                        {
                            totalAmount = (price?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
                        }
                    }
                    else
                    {
                        totalAmount = (price?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
                    }
                }
            }
            else
            {
                campaignAmount = new Money(0m);
                totalAmount = (price?.Value ?? 0m) + (postalCharge?.Value ?? 0m);
            }

            _logger.TraceInformation($"Total Amount: {totalAmount}");

            giftPack["rhs_campaignamount"] = new Money(campaignAmount?.Value ?? 0m);
            giftPack[EntityNames.GiftPack.Price] = new Money(price?.Value ?? 0m);
            giftPack[EntityNames.GiftPack.PostalCharges] = postalCharge;
            giftPack[EntityNames.GiftPack.TotalPrice] = new Money(totalAmount);

            _logger.TraceInformation($"AdditionalPostageCalculations End");

            return giftPack;
        }

        private string GetCountry(string entityType, Guid deliveryContactId, int deliveryAddressType)
        {
            string countryName = string.Empty;

            if (string.IsNullOrEmpty(entityType) || deliveryContactId == Guid.Empty || deliveryAddressType == 0)
                return countryName;

            if (entityType == EntityNames.Contact.EntityLogicalName)
            {
                Entity contact = _organizationService.Retrieve(entityType, deliveryContactId, new ColumnSet(
                    EntityNames.Contact.PrimaryIdAttribute, EntityNames.Contact.PrimaryNameAttribute,
                    EntityNames.Contact.Address1_Country, EntityNames.Contact.Address2_Country,
                    EntityNames.Contact.LoqateAddress3Country, EntityNames.Contact.SecondaryAddressTypeCode,
                    EntityNames.Contact.AlternateAddressTypeCode
                ));

                int secondaryAddressType = contact.Contains(EntityNames.Contact.SecondaryAddressTypeCode) ? ((OptionSetValue)contact[EntityNames.Contact.SecondaryAddressTypeCode]).Value : 0;
                int alternateAddressType = contact.Contains(EntityNames.Contact.AlternateAddressTypeCode) ? ((OptionSetValue)contact[EntityNames.Contact.AlternateAddressTypeCode]).Value : 0;

                _logger.TraceInformation($"SecondaryAddressType: {secondaryAddressType}");
                _logger.TraceInformation($"AlternateAddressType: {alternateAddressType}");

                switch (deliveryAddressType)
                {
                    case 844060000:
                        countryName = contact.Contains(EntityNames.Contact.Address1_Country) ? (string)contact[EntityNames.Contact.Address1_Country] : string.Empty;
                        break;

                    case 844060001:
                    case 844060002:
                    case 844060003:
                        countryName = deliveryAddressType == secondaryAddressType && contact.Contains(EntityNames.Contact.Address2_Country)
                                    ? (string)contact[EntityNames.Contact.Address2_Country]
                                    : deliveryAddressType == alternateAddressType && contact.Contains(EntityNames.Contact.LoqateAddress3Country)
                                    ? (string)contact[EntityNames.Contact.LoqateAddress3Country]
                                    : string.Empty;
                        break;
                    default:
                        _logger.TraceInformation("Unknown address type. No country name found.");
                        countryName = string.Empty;
                        break;
                }
            }
            else
            {
                Entity account = _organizationService.Retrieve(entityType, deliveryContactId, new ColumnSet(
                EntityNames.Contact.Address1_Country, EntityNames.Contact.Address2_Country
                ));

                switch (deliveryAddressType)
                {
                    case 844060000:
                        countryName = account.Contains(EntityNames.Contact.Address1_Country) ? (string)account[EntityNames.Contact.Address1_Country] : string.Empty;
                        break;

                    case 844060001:
                    case 844060002:
                    case 844060003:
                        countryName = account.Contains(EntityNames.Contact.Address2_Country) ? (string)account[EntityNames.Contact.Address2_Country] : string.Empty;
                        break;

                    default:
                        countryName = string.Empty;
                        break;
                }
            }

            return countryName;
        }

        private decimal GetPostalCharges(string countryName)
        {
            decimal postalChargesValue = 0.00M;

            QueryExpression queryCountry = new QueryExpression(EntityNames.Country.EntityLogicalName);
            queryCountry.TopCount = 1;
            queryCountry.ColumnSet.AddColumns(EntityNames.Country.PrimaryIdAttribute, EntityNames.Country.PrimaryNameAttribute, EntityNames.Country.PostalCharges);
            queryCountry.Criteria.AddCondition(EntityNames.Country.PrimaryNameAttribute, ConditionOperator.Like, $"%{countryName}%");

            EntityCollection countries = _organizationService.RetrieveMultiple(queryCountry);

            if (countries.Entities.Any())
            {
                Entity country = countries.Entities.First();
                if (country.Contains(EntityNames.Country.PostalCharges) && country[EntityNames.Country.PostalCharges] is Money postalCharges)
                {
                    postalChargesValue = postalCharges.Value;
                }
            }

            _logger.TraceInformation($"Postal Charges from {countryName}: {postalChargesValue}");

            return postalChargesValue;
        }

        public ValidateGiftPackCodeResult ValidateGiftPackCode(string giftPackCode)
        {
            _logger.TraceInformation("Starting business logic.");
            var giftPack = _giftPackRepository.GetByGiftPackCode(giftPackCode);

            if (giftPack == null)
            {
                return new ValidateGiftPackCodeResult
                {
                    Message = "This code is invalid. Please re-enter the code or contact Membership Services by phone 020 3176 5810 or email membership@rhs.org.uk"
                };
            }

            switch (giftPack.Statuscode)
            {
                case GiftPackStatus.Inactive_Redeemed:
                    return new ValidateGiftPackCodeResult
                    {
                        Message = "This code has already been redeemed. Please contact Membership Services by phone 020 3176 5810 or email membership@rhs.org.uk",
                        IsRedeemed = true
                    };

                case GiftPackStatus.Active_Purchased:                  

                    var product = _productAssociationRepository.GetAll()
                        .FirstOrDefault(pa => pa.ProductId.Id == giftPack.Product.Id)?.AssociatedProduct;

                    bool isDobRequired = _dynamicPropertyRepository.GetAll()
                        .OrderByDescending(dp => dp.CreatedOn)
                        .FirstOrDefault(dp => dp.Name == "DOB Required" && dp.IsRequired == true && dp.RegardingObjectId == product) != null;

                    int? minimumAge = _dynamicPropertyRepository.GetAll()
                        .OrderByDescending(dp => dp.CreatedOn)
                        .FirstOrDefault(dp => dp.Name == "Minimum Age" && dp.IsRequired == true && dp.RegardingObjectId == product)?.DefaultValueInteger;


                    return new ValidateGiftPackCodeResult
                    {
                        Message = "Gift pack code is valid.",
                        IsValid = true,
                        MinimumAge = minimumAge,
                        GiftPackProductName = giftPack.Product.Name,
                        GiftPackProductId = giftPack.Product.Id,
                        GiftPackId = giftPack.Id,
                        IsDobRequired = isDobRequired
                    };

                default:
                    return new ValidateGiftPackCodeResult
                    {
                        Message = "This code is invalid. Please re-enter the code or contact Membership Services by phone 020 3176 5810 or email membership@rhs.org.uk"
                    };
            }
        }

        public void HandleCodeReactivation(GiftPack targetGiftPack)
        {
            _logger.TraceInformation("Starting HandleCodeReactivation in GiftPackService.");
            if (targetGiftPack.ReinstateActivationCode.GetValueOrDefault())
            {
                targetGiftPack.ExpireDate = DateTime.Today.AddDays(2);
                _logger.TraceInformation($"Expiration date extended by 2 days to: {targetGiftPack.ExpireDate}.");
            }
            _logger.TraceInformation("Ending HandleCodeReactivation in GiftPackService.");
        }

        public void HandleCodeCancellation(GiftPack targetGiftPack, GiftPack preImageGiftPack)
        {
            _logger.TraceInformation("Starting HandleCodeCancellation in GiftPackService.");
            if (targetGiftPack.CancelActivationCode.GetValueOrDefault())
            {
                var originalCode = preImageGiftPack.GiftPackCode;
                if (!string.IsNullOrEmpty(originalCode) && originalCode.Length >= 3)
                {
                    targetGiftPack.CancelledActivationCode = originalCode;
                    var random = new Random();
                    var newRandomNumber = new string(Enumerable.Repeat("0123456789", 12)
                                                        .Select(s => s[random.Next(s.Length)]).ToArray());
                    targetGiftPack.GiftPackCode = originalCode.Substring(0, 3) + newRandomNumber;
                    _logger.TraceInformation($"Gift pack code cancelled. Original code: {originalCode}. New code generated.");
                }
            }
            _logger.TraceInformation("Ending HandleCodeCancellation in GiftPackService.");
        }

    }


    public class ValidateGiftPackCodeResult
    {
        public string Message { get; set; }
        public bool IsValid { get; set; }
        public bool IsRedeemed { get; set; }
        public int? MinimumAge { get; set; }
        public string GiftPackProductName { get; set; }
        public Guid? GiftPackProductId { get; set; }
        public Guid? GiftPackId { get; set; }
        public bool IsDobRequired { get; set; }
    }

}