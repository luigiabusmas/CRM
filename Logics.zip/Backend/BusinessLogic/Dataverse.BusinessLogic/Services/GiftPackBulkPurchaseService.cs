﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

namespace Cultivate.BusinessLogic.Services
{
    public interface IGiftPackBulkPurchaseService
    {
        Entity SetPriceListUsedOnGiftPackBulkPurchaseEntity(Entity entity);
        Entity SetPricePerProductOnGiftPackBulkPurchaseEntity(Entity entity);
        Entity SetTotalPriceOnGiftPackBulkPurchaseEntity(Entity entity);
        Entity SetTitleOnGiftPackBulkPurchaseEntity(Entity entity);
        int GetGiftPackBulkPurchaseNewAmountDifference(GiftPackBulkPurchase giftPackBulkPurchase);
        void CreateGiftPackInstancesOfGiftPackBulkPurchase(GiftPackBulkPurchase giftPackBulkPurchase, int noOfInstancesToCreate);
        string ComposeGiftPackBulkPurchaseTitle(GiftPackBulkPurchase giftPackBulkPurchase);
        string ComposeGiftPackInstanceTitle(GiftPackBulkPurchase giftPackBulkPurchase);
        Transaction CreateTransactionForGiftPackBulkPurchase(GiftPackBulkPurchase giftPack);
        Payment CreatePaymentForGiftPackBulkPurchase(GiftPackBulkPurchase giftPack, EntityReference transactionEntityReference);
        bool ValidateAmountWhenBuyingAnotherMembershipGiftPack(GiftPackBulkPurchase preImageGiftPackBulkPurchase, GiftPackBulkPurchase postImageGiftPackBulkPurchase);
        Entity SetEntityFieldsWhenBuyingAnotherMembershipGiftPack(Entity targetEntity, GiftPackBulkPurchase postImageGiftPackBulkPurchase);
        void GiftPackBulkPurchaseCreateConsents(Entity giftPackBulkPurchase);
        Entity GiftPackBulkPurchaseAdditionalPostageCalculations(Entity giftPackBulkPurchase, Entity preImage);
        void ProcessSubmitPayment(Guid giftPackBulkPurchaseId);
        void UpdateChildGiftPacksOnStatusChange(Entity giftPackBulkPurchase);
    }

    public class GiftPackBulkPurchaseService : IGiftPackBulkPurchaseService
    {
        private ILogger _logger;
        private IOrganizationService _organizationService;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;
        private IRepository<GiftPack> _giftPackRepository;
        private IProductService _productService;
        private IGiftPackService _giftPackService;

        #region Constants
        const string customAPI = "rhs_consentscreation";
        const int newMemberDataSet = 120000000;
        const int nonMemberDataSet = 120000002;
        const int retailChannel = 120000003;
        #endregion Constants

        public GiftPackBulkPurchaseService(
            ILogger logger, IOrganizationService service,
            IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository, IRepository<GiftPack> giftPackRepository,
            IProductService productService, IGiftPackService giftPackService)
        {
            _logger = logger;
            _organizationService = service;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _giftPackRepository = giftPackRepository;
            _productService = productService;
            _giftPackService = giftPackService;
        }

        #region Public Methods
        public Entity SetPricePerProductOnGiftPackBulkPurchaseEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var giftPackBulkPurchase = entity.ToEntity<GiftPackBulkPurchase>();

            if (giftPackBulkPurchase.Product == null)
                throw new InvalidPluginExecutionException("Please select a Product to set up this record's Price Per Product.");

            entity[EntityNames.GiftPackBulkPurchase.PricePerProduct] = _productService.GetProductPrice(giftPackBulkPurchase.Product.Id);

            _logger.TraceInformation($"Ending business logic");
            return entity;
        }

        public Entity SetPriceListUsedOnGiftPackBulkPurchaseEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var giftPackBulkPurchase = entity.ToEntity<GiftPackBulkPurchase>();

            if (giftPackBulkPurchase.Product == null)
                throw new InvalidPluginExecutionException("Please select a Product to set up this record's Price List Used.");

            entity[EntityNames.GiftPackBulkPurchase.PriceListUsed] = _productService.GetPriceListUsedOnProduct(giftPackBulkPurchase.Product.Id);

            _logger.TraceInformation($"Ending business logic");
            return entity;
        }
        
        public Entity SetTotalPriceOnGiftPackBulkPurchaseEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var giftPackBulkPurchase = entity.ToEntity<GiftPackBulkPurchase>();

            if (giftPackBulkPurchase.Amount == null || giftPackBulkPurchase.PricePerProduct == null)
                throw new InvalidPluginExecutionException("Please input an Amount and Price Per Product to set up this record's Total Price.");

            var totalPrice = new Money() 
            {
                Value = (int)giftPackBulkPurchase.Amount * giftPackBulkPurchase.PricePerProduct.Value,
                ExtensionData = giftPackBulkPurchase.ExtensionData
            };
            entity[EntityNames.GiftPackBulkPurchase.TotalPrice] = totalPrice;

            _logger.TraceInformation($"Ending business logic");
            return entity;
        }

        public Entity SetTitleOnGiftPackBulkPurchaseEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");
            var giftPackBulkPurchase = entity.ToEntity<GiftPackBulkPurchase>();

            if (giftPackBulkPurchase.PurchasedBy == null || giftPackBulkPurchase.Product == null)
                throw new InvalidPluginExecutionException("Please input a Purchaser (Purchased By) and Product to set up this record's Title.");

            entity[EntityNames.GiftPackBulkPurchase.Title] = ComposeGiftPackBulkPurchaseTitle(giftPackBulkPurchase);

            _logger.TraceInformation($"Ending business logic");
            return entity;
        }

        public int GetGiftPackBulkPurchaseNewAmountDifference(GiftPackBulkPurchase giftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            var giftPacksOfGiftPackBulkPurchase = _giftPackRepository.GetAll().Where(giftPack => giftPack.GiftPackBulkPurchase != null && giftPack.GiftPackBulkPurchase.Id == giftPackBulkPurchase.Id).ToList();
            
            _logger.TraceInformation($"GiftPackBulkPurchase.Amount = {giftPackBulkPurchase.Amount}.");
            _logger.TraceInformation($"GiftPackBulkPurchase associated gift pack count = {giftPacksOfGiftPackBulkPurchase.Count}.");

            var giftPackBulkPurchaseAmountDifference = (int)giftPackBulkPurchase.Amount - giftPacksOfGiftPackBulkPurchase.Count;
            _logger.TraceInformation($"Amount - Gift Pack Count = {giftPackBulkPurchaseAmountDifference}.");

            _logger.TraceInformation($"Ending business logic");
            return giftPackBulkPurchaseAmountDifference;
        }

        public void CreateGiftPackInstancesOfGiftPackBulkPurchase(GiftPackBulkPurchase giftPackBulkPurchase, int noOfInstancesToCreate)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Attempting to create the gift pack instances for the bulk purchase.");
            for (int counter = 1; counter <= noOfInstancesToCreate; counter++)
            {
                var giftPack = new GiftPack()
                {
                    GiftPackCode = _giftPackService.GenerateGiftPackActivationCode(giftPackBulkPurchase.Product.Id),
                    Title = ComposeGiftPackInstanceTitle(giftPackBulkPurchase),
                    GiftPackBulkPurchase = giftPackBulkPurchase.ToEntityReference(),
                    Product = giftPackBulkPurchase.Product,
                    PriceListUsed = giftPackBulkPurchase.PriceListUsed,
                    Price = giftPackBulkPurchase.PricePerProduct,
                    Channel = giftPackBulkPurchase.Channel,
                    //ExpireDate = null,
                    PurchasedBy = giftPackBulkPurchase.PurchasedBy,
                    DeliveryContactId = giftPackBulkPurchase.DeliveryContact,
                    DeliveryAddress = giftPackBulkPurchase.DeliveryAddressCode,
                    IsPaymentReceived = true

                };

                var giftPackEntity = giftPack.ToEntity<Entity>();
                _organizationService.Create(giftPackEntity);
            }

            _logger.TraceInformation($"Ending business logic");
        }

        public void ProcessSubmitPayment(Guid giftPackBulkPurchaseId)
        {
            GiftPackBulkPurchase giftPackBulkPurchase = new GiftPackBulkPurchase()
            {
                Id = giftPackBulkPurchaseId,
                IsPaymentSubmitted = true,
                Statuscode = GiftPackBulkPurchaseStatus.Active_Purchased
            };
            _organizationService.Update(giftPackBulkPurchase);
        }

        public Transaction CreateTransactionForGiftPackBulkPurchase(GiftPackBulkPurchase giftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            var transaction = _transactionRepository.Create(
                new Transaction()
                {
                    TransacID = null,
                    GiftPackBulkPurchaseId = giftPackBulkPurchase.ToEntityReference(),
                    Product = giftPackBulkPurchase.Product,
                    Customer = giftPackBulkPurchase.PurchasedBy,
                    PaymentScheduleTransaction = null,
                    //Statecode = TransactionState.Active,
                    //Statuscode = TransactionStatus.Active_PendingPayment,
                    Amount = giftPackBulkPurchase.TotalPrice,
                    Type = Typetransaction_GlobalOptionSet.FullPayment,
                    TransactionType = NewTransactionType_GlobalOptionSet.GiftPack,
                    GiftAidEligibility = null,
                    WrittenOffAmount = null,
                    PaidOn = DateTime.UtcNow
                }
            );

            _logger.TraceInformation($"Starting update transaction.");

            _transactionRepository.Update(
                new Transaction()
                {
                    Id = transaction.Id,
                    Statecode = TransactionState.Inactive,
                    Statuscode = TransactionStatus.Inactive_Paid
                }
            );

            _logger.TraceInformation($"Ending business logic.");
            return transaction;
        }

        public Payment CreatePaymentForGiftPackBulkPurchase(GiftPackBulkPurchase giftPackBulkPurchase, EntityReference transactionEntityReference)
        {
            _logger.TraceInformation($"Starting business logic.");
            
            var payment = _paymentRepository.Create(
                new Payment()
                {
                    PaymentsID = null,
                    Type = Typetransaction_GlobalOptionSet.FullPayment,
                    Amount = giftPackBulkPurchase.TotalPrice,
                    PaymentMethodType = giftPackBulkPurchase.PaymentMethod,
                    Payer = giftPackBulkPurchase.PurchasedBy,
                    Transaction = transactionEntityReference,
                    PaymentSchedule = null,
                    PaymentType = NewTransactionType_GlobalOptionSet.GiftPack,
                    PaidOn = DateTime.UtcNow,
                    ExporttoFinance = false,
                    GiftAidEligibility = null,
                    //GiftAidDeclaration = null,
                    GiftAidDeclarationId = null,
                    DueDate = DateTime.UtcNow,
                    //Statuscode = PaymentStatus.Active_PendingPayment
                    
                }
            );

            _logger.TraceInformation($"Starting update payment.");
            _paymentRepository.Update(
                new Payment()
                {
                    Id = payment.Id,
                    Statecode = PaymentState.Inactive,
                    Statuscode = PaymentStatus.Inactive_Paid
                }
            );

            _logger.TraceInformation($"Ending business logic.");
            return payment;
        }

        public bool ValidateAmountWhenBuyingAnotherMembershipGiftPack(GiftPackBulkPurchase preImageGiftPackBulkPurchase, GiftPackBulkPurchase postImageGiftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Validating if previous amount of gift pack bulk purchase is less than the new amount.");
            if (preImageGiftPackBulkPurchase.Amount < postImageGiftPackBulkPurchase.Amount)
            {
                _logger.TraceInformation($"Previous amount is less than the new amount.");
            }
            else
            {
                _logger.TraceInformation($"Previous amount is not less than the new amount.");
                throw new InvalidPluginExecutionException("Please enter the total Amount for the Bulk Gift Pack!");
            }

            _logger.TraceInformation($"Ending business logic.");
            return true;
        }

        public Entity SetEntityFieldsWhenBuyingAnotherMembershipGiftPack(Entity targetEntity, GiftPackBulkPurchase postImageGiftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Setting new 'Total Price' of gift pack bulk purchase.");
            targetEntity[EntityNames.GiftPackBulkPurchase.TotalPrice] = new Money()
            {
                Value = (int)postImageGiftPackBulkPurchase.Amount * postImageGiftPackBulkPurchase.PricePerProduct.Value,
                ExtensionData = postImageGiftPackBulkPurchase.ExtensionData
            };

            _logger.TraceInformation($"Setting 'Do you want to buy another Membership Gift Pack?' to blank.");
            targetEntity[EntityNames.GiftPackBulkPurchase.BuyanotherMembershipGiftPackCode] = null;

            _logger.TraceInformation($"Ending business logic.");
            return targetEntity;
        }

        public void GiftPackBulkPurchaseCreateConsents(Entity giftPackBulkPurchase)
        {
            _logger.TraceInformation($"GiftPackBulkPurchaseCreateConsents Start");

            var dataSet = 0;
            Guid? purchasedById = giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.PurchasedBy) &&
                                    ((EntityReference)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PurchasedBy]).LogicalName == EntityNames.Contact.EntityLogicalName ?
                                    ((EntityReference)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PurchasedBy]).Id : (Guid?)null;

            int? channel = giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.Channel) ?
                                    ((OptionSetValue)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Channel]).Value : (int?)null;

            if (purchasedById.HasValue && channel.HasValue)
            {
                _logger.TraceInformation($"Purchase By Id: {purchasedById.Value}");
                _logger.TraceInformation($"Channel: {channel.Value}");

                if (channel.Value != retailChannel)
                {
                    bool hasMembership = IsContactMember(purchasedById.Value);
                    _logger.TraceInformation($"Has Membership: {hasMembership}");

                    if (hasMembership)
                        dataSet = newMemberDataSet;
                    else
                        dataSet = nonMemberDataSet;

                    _logger.TraceInformation($"Dataset: {hasMembership}");
                    InvokeConsentCreationApi(purchasedById.Value.ToString(), dataSet);

                }
            }

            _logger.TraceInformation($"GiftPackCreateConsents Start");

        }

        private bool IsContactMember(Guid contactId)
        {
            bool isMember = false;

            try
            {
                var query = new FetchExpression(@"<fetch>
                  <entity name='contact'>
                    <attribute name='contactid' />
                    <filter type='and'>
                      <condition attribute='statecode' operator='eq' value='0' />
                      <condition attribute='contactid' operator='eq' value='{contactId}' />
                    </filter>
                    <filter type='or'>
                      <link-entity name='rhs_membership' from='rhs_contact' to='contactid' link-type='any' alias='primary'>
                        <filter>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='statuscode' operator='eq' value='1' />
                        </filter>
                      </link-entity>
                      <link-entity name='rhs_membership' from='rhs_member2' to='contactid' link-type='any' alias='secondary'>
                        <filter>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='statuscode' operator='eq' value='1' />
                        </filter>
                      </link-entity>
                    </filter>
                  </entity>
                </fetch>");

                var contact = _organizationService.RetrieveMultiple(query);

                if (contact != null && contact.Entities.Count > 0)
                    isMember = true;
            }
            catch(Exception ex)
            {
                throw new InvalidPluginExecutionException($"Error IsContactMember: {ex.Message}", ex);

            }

            return isMember;
        }


        public Entity GiftPackBulkPurchaseAdditionalPostageCalculations(Entity giftPackBulkPurchase, Entity preImage)
        {
            _logger.TraceInformation($"AdditionalPostageCalculations Start");

            string entityType = string.Empty;
            Guid deliveryContactId = Guid.Empty;
            EntityReference deliveryContact = null;
            Guid? productId = null;
            int deliveryAddressType = 0;
            int amount = 0;
            Money postalCharge = null;
            int channel = 0;
            int[] disAllowedChannels = [120000003, 120000004, 120000005];

            if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.Channel) && giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Channel] != null)
            {
                channel = ((OptionSetValue)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Channel]).Value;
            }
            else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.Channel) && preImage[EntityNames.GiftPackBulkPurchase.Channel] != null)
            {
                channel = ((OptionSetValue)preImage[EntityNames.GiftPackBulkPurchase.Channel]).Value;
            }
            _logger.TraceInformation($"Channel: {channel}");

            if (disAllowedChannels.Contains(channel))
            {
                _logger.TraceInformation($"Skipping AdditionalPostageCalculations");

                if (preImage == null && (!giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.PostalCharges) || giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PostalCharges] == null))
                {
                    _logger.TraceInformation($"Setting null postal charge to 0.");
                    giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PostalCharges] = new Money();
                }
                return giftPackBulkPurchase;
            }
            else
            {
                if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.DeliveryContact) && giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.DeliveryContact] != null)
                {
                    deliveryContact = (EntityReference)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.DeliveryContact];
                }
                else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.DeliveryContact) && preImage[EntityNames.GiftPackBulkPurchase.DeliveryContact] != null)
                {
                    deliveryContact = (EntityReference)preImage[EntityNames.GiftPackBulkPurchase.DeliveryContact];
                }

                if (deliveryContact != null)
                {
                    entityType = (deliveryContact.LogicalName == EntityNames.Account.EntityLogicalName ||
                                  deliveryContact.LogicalName == EntityNames.Contact.EntityLogicalName)
                                 ? deliveryContact.LogicalName
                                 : string.Empty;

                    deliveryContactId = deliveryContact.Id;
                }

                _logger.TraceInformation($"Delivery Contact EntityType: {entityType}");
                _logger.TraceInformation($"Delivery Contact Id: {deliveryContactId}");

                if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.DeliveryAddressCode) && giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.DeliveryAddressCode] != null)
                {
                    deliveryAddressType = ((OptionSetValue)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.DeliveryAddressCode]).Value;
                }
                else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.DeliveryAddressCode) && preImage[EntityNames.GiftPackBulkPurchase.DeliveryAddressCode] != null)
                {
                    deliveryAddressType = ((OptionSetValue)preImage[EntityNames.GiftPackBulkPurchase.DeliveryAddressCode]).Value;
                }
                _logger.TraceInformation($"Delivery Address Type: {deliveryAddressType}");

                if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.Product) && giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Product] != null)
                {
                    productId = ((EntityReference)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Product]).Id;
                }
                else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.Product) && preImage[EntityNames.GiftPackBulkPurchase.Product] != null)
                {
                    productId = ((EntityReference)preImage[EntityNames.GiftPackBulkPurchase.Product]).Id;
                }

                Money price = productId.HasValue ? _productService.GetProductPrice(productId.Value) : new Money(0m);
                _logger.TraceInformation($"Price: {price.Value}");

                if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.Amount))
                {
                    amount = (int)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.Amount];
                }
                else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.Amount))
                {
                    amount = (int)preImage[EntityNames.GiftPackBulkPurchase.Amount];
                }
                _logger.TraceInformation($"Amount: {amount}");

                if (giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.PostalCharges) && giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PostalCharges] != null)
                {
                    postalCharge = (Money)giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PostalCharges];
                }
                else if (preImage != null && preImage.Contains(EntityNames.GiftPackBulkPurchase.PostalCharges) && preImage[EntityNames.GiftPackBulkPurchase.PostalCharges] != null)
                {
                    postalCharge = (Money)preImage[EntityNames.GiftPackBulkPurchase.PostalCharges];
                }

                bool postalChargeChanged = giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.PostalCharges);
                bool deliveryAddressCodeChanged = giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.DeliveryAddressCode);

                if (deliveryAddressType != 0 && deliveryContactId != Guid.Empty)
                {
                    string countryName = GetCountry(entityType, deliveryContactId, deliveryAddressType);
                    if (!string.IsNullOrEmpty(countryName))
                    {
                        _logger.TraceInformation($"Country Name: {countryName}");

                        decimal postalChargeValue = GetPostalCharges(countryName);

                        if (postalCharge == null || postalCharge.Value == 0m)
                        {
                            postalCharge = new Money(postalChargeValue);
                        }
                        else if (postalChargeChanged && !deliveryAddressCodeChanged)
                        {
                            postalCharge = new Money(postalCharge.Value);
                        }
                        else if (deliveryAddressCodeChanged)
                        {
                            postalCharge = new Money(postalChargeValue);
                        }
                    }
                    else
                    {
                        if (postalCharge == null || postalCharge.Value == 0m)
                        {
                            throw new InvalidPluginExecutionException("Postal charges are missing for the selected delivery address of the delivery contact. Please enter same!");
                        }
                    }
                }

                _logger.TraceInformation($"Postal Charges: {postalCharge.Value}");

                decimal totalAmount = (amount * price?.Value ?? 0m) + postalCharge.Value;
                _logger.TraceInformation($"Total Amount: {totalAmount}");

                Money totalPrice = new Money(totalAmount);
                _logger.TraceInformation($"Total Price: {totalPrice.Value}");

                giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.PostalCharges] = postalCharge;
                giftPackBulkPurchase[EntityNames.GiftPackBulkPurchase.TotalPrice] = totalPrice;

                _logger.TraceInformation($"AdditionalPostageCalculations End");

                return giftPackBulkPurchase;
            }
        }

        public void UpdateChildGiftPacksOnStatusChange(Entity giftPackBulkPurchase)
        {
            _logger.TraceInformation("UpdateChildGiftPacksOnStatusChange started.");

            if (!giftPackBulkPurchase.Contains(EntityNames.GiftPackBulkPurchase.GiftPackBulkPurchaseId))
            {
                _logger.TraceInformation("Gift Pack Bulk Purchase entity does not contain an ID.");
                return;
            }

            Guid bulkPurchaseId = giftPackBulkPurchase.Id;

            // Purchased child GiftPack status = 120000003
            const int PurchasedGiftPackStatusCode = 120000003;

            QueryExpression query = new QueryExpression(EntityNames.GiftPack.EntityLogicalName)
            {
                ColumnSet = new ColumnSet(EntityNames.GiftPack.GiftPackId)
            };
            query.Criteria.AddCondition(EntityNames.GiftPack.GiftPackBulkPurchase, ConditionOperator.Equal, bulkPurchaseId);

            EntityCollection giftPacks = _organizationService.RetrieveMultiple(query);

            _logger.TraceInformation($"Found {giftPacks.Entities.Count} child Gift Pack(s) to update.");

            foreach (Entity gp in giftPacks.Entities)
            {
                Entity update = new Entity(EntityNames.GiftPack.EntityLogicalName, gp.Id)
                {
                    [EntityNames.GiftPack.Statuscode] = new OptionSetValue(PurchasedGiftPackStatusCode),
                    [EntityNames.GiftPack.IsPaymentReceived] = true
                };

                _organizationService.Update(update);

                _logger.TraceInformation($"Gift Pack {gp.Id} updated to Purchased with IsPaymentReceived = true.");
            }

            _logger.TraceInformation("UpdateChildGiftPacksOnStatusChange finished.");
        }


        #endregion

        #region Private Methods 
        public string ComposeGiftPackBulkPurchaseTitle(GiftPackBulkPurchase giftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving gift pack bulk purchase purchaser.");
            var purchasedByEntityReference = giftPackBulkPurchase.PurchasedBy;
            Contact purchasedByContact = new Contact();
            Account purchasedByAccount = new Account();
            switch (purchasedByEntityReference.LogicalName)
            {
                case EntityNames.Contact.EntityLogicalName:
                    purchasedByContact = _organizationService.Retrieve(
                        EntityNames.Contact.EntityLogicalName,
                        purchasedByEntityReference.Id,
                        new ColumnSet(EntityNames.Contact.FullName)
                    ).ToEntity<Contact>();
                    break;
                case EntityNames.Account.EntityLogicalName:
                    purchasedByAccount = _organizationService.Retrieve(
                        EntityNames.Account.EntityLogicalName,
                        purchasedByEntityReference.Id,
                        new ColumnSet(EntityNames.Account.Name)
                    ).ToEntity<Account>();
                    break;
            }
            var purchaserName = purchasedByContact.FullName + purchasedByAccount.Name;

            _logger.TraceInformation($"Retrieving gift pack bulk purchase product name.");
            var productId = giftPackBulkPurchase.Product.Id;
            var product = _organizationService.Retrieve(
                EntityNames.Product.EntityLogicalName,
                productId,
                new ColumnSet(EntityNames.Product.Name)
            ).ToEntity<Product>();
            var productName = product.Name;

            _logger.TraceInformation($"Retrieving gift pack bulk purchase reference number.");
            var referenceNumber = giftPackBulkPurchase.ReferenceNumber == null ? string.Empty : giftPackBulkPurchase.ReferenceNumber;

            _logger.TraceInformation($"Composing gift pack bulk purchase title.");
            var title = $"{purchaserName} {productName} {referenceNumber}";

            _logger.TraceInformation($"Ending business logic");
            return title;
        }

        public string ComposeGiftPackInstanceTitle(GiftPackBulkPurchase giftPackBulkPurchase)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving gift pack bulk purchase purchaser.");
            var purchasedByEntityReference = giftPackBulkPurchase.PurchasedBy;
            Contact purchasedByContact = new Contact();
            Account purchasedByAccount = new Account();
            switch (purchasedByEntityReference.LogicalName)
            {
                case EntityNames.Contact.EntityLogicalName:
                    purchasedByContact = _organizationService.Retrieve(
                        EntityNames.Contact.EntityLogicalName,
                        purchasedByEntityReference.Id,
                        new ColumnSet(EntityNames.Contact.FullName)
                    ).ToEntity<Contact>();
                    break;
                case EntityNames.Account.EntityLogicalName:
                    purchasedByAccount = _organizationService.Retrieve(
                        EntityNames.Account.EntityLogicalName,
                        purchasedByEntityReference.Id,
                        new ColumnSet(EntityNames.Account.Name)
                    ).ToEntity<Account>();
                    break;
            }
            var purchaserName = purchasedByContact.FullName + purchasedByAccount.Name;

            _logger.TraceInformation($"Retrieving gift pack bulk purchase product name.");
            var productId = giftPackBulkPurchase.Product.Id;
            var product = _organizationService.Retrieve(
                EntityNames.Product.EntityLogicalName,
                productId,
                new ColumnSet(EntityNames.Product.Name)
            ).ToEntity<Product>();
            var productName = product.Name;

            _logger.TraceInformation($"Composing gift pack bulk purchase title.");
            var title = $"{purchaserName} {productName} Batch Order";

            _logger.TraceInformation($"Ending business logic");
            return title;
        }

        private void InvokeConsentCreationApi(string contactId, int newMemberDataSet)
        {
            try
            {
                OrganizationRequest apiRequest = new OrganizationRequest(customAPI)
                {
                    Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", newMemberDataSet }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse apiResponse = _organizationService.Execute(apiRequest);

                // Check the response for success or failure
                if (apiResponse != null && apiResponse.Results.Contains("result") && (bool)apiResponse.Results["result"])
                {
                    _logger.TraceInformation("Consent creation via API was successful.");
                }
                else if (apiResponse != null && apiResponse.Results.Contains("error"))
                {
                    string error = apiResponse.Results["error"].ToString();
                    _logger.TraceInformation($"Consent creation via API failed. Error: {error}");
                    throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
                }

                _logger.TraceInformation("Custom API executed successfully.");

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Error invoking Custom API: {ex.Message}", ex);
            }
        }

        private string GetCountry(string entityType, Guid deliveryContactId, int deliveryAddressType)
        {
            string countryName = string.Empty;

            if (entityType == EntityNames.Contact.EntityLogicalName)
            {
                Entity contact = _organizationService.Retrieve(entityType, deliveryContactId, new ColumnSet(
                    EntityNames.Contact.PrimaryIdAttribute, EntityNames.Contact.PrimaryNameAttribute,
                    EntityNames.Contact.Address1_Country, EntityNames.Contact.Address2_Country,
                    EntityNames.Contact.LoqateAddress3Country, EntityNames.Contact.SecondaryAddressTypeCode,
                    EntityNames.Contact.AlternateAddressTypeCode
                ));

                int secondaryAddressType = contact.Contains(EntityNames.Contact.SecondaryAddressTypeCode) ? ((OptionSetValue)contact[EntityNames.Contact.SecondaryAddressTypeCode]).Value : 0;
                int alternateAddressType = contact.Contains(EntityNames.Contact.AlternateAddressTypeCode) ? ((OptionSetValue)contact[EntityNames.Contact.AlternateAddressTypeCode]).Value : 0;

                _logger.TraceInformation($"SecondaryAddressType: {secondaryAddressType}");
                _logger.TraceInformation($"AlternateAddressType: {alternateAddressType}");

                switch (deliveryAddressType)
                {
                    case 844060000:
                        countryName = contact.Contains(EntityNames.Contact.Address1_Country) ? (string)contact[EntityNames.Contact.Address1_Country] : string.Empty;
                        break;

                    case 844060001:
                    case 844060002:
                    case 844060003:
                        countryName = deliveryAddressType == secondaryAddressType && contact.Contains(EntityNames.Contact.Address2_Country)
                                    ? (string)contact[EntityNames.Contact.Address2_Country]
                                    : deliveryAddressType == alternateAddressType && contact.Contains(EntityNames.Contact.LoqateAddress3Country)
                                    ? (string)contact[EntityNames.Contact.LoqateAddress3Country]
                                    : string.Empty;
                        break;
                    default:
                        _logger.TraceInformation("Unknown address type. No country name found.");
                        countryName = string.Empty;
                        break;
                }
            }
            else
            {
                Entity account = _organizationService.Retrieve(entityType, deliveryContactId, new ColumnSet(
                EntityNames.Contact.Address1_Country, EntityNames.Contact.Address2_Country
                ));

                switch (deliveryAddressType)
                {
                    case 844060000:
                        countryName = account.Contains(EntityNames.Contact.Address1_Country) ? (string)account[EntityNames.Contact.Address1_Country] : string.Empty;
                        break;

                    case 844060001:
                    case 844060002:
                    case 844060003:
                        countryName = account.Contains(EntityNames.Contact.Address2_Country) ? (string)account[EntityNames.Contact.Address2_Country] : string.Empty;
                        break;

                    default:
                        countryName = string.Empty;
                        break;
                }
            }

            return countryName;
        }

        private decimal GetPostalCharges(string countryName)
        {
            decimal postalChargesValue = 0.00M;

            QueryExpression queryCountry = new QueryExpression(EntityNames.Country.EntityLogicalName);
            queryCountry.TopCount = 1;
            queryCountry.ColumnSet.AddColumns(EntityNames.Country.PrimaryIdAttribute, EntityNames.Country.PrimaryNameAttribute, EntityNames.Country.PostalCharges);
            queryCountry.Criteria.AddCondition(EntityNames.Country.PrimaryNameAttribute, ConditionOperator.Like, $"%{countryName}%");

            EntityCollection countries = _organizationService.RetrieveMultiple(queryCountry);

            if (countries.Entities.Any())
            {
                Entity country = countries.Entities.First();
                if (country.Contains(EntityNames.Country.PostalCharges) && country[EntityNames.Country.PostalCharges] is Money postalCharges)
                {
                    postalChargesValue = postalCharges.Value;
                }
            }

            _logger.TraceInformation($"Postal Charges from {countryName}: {postalChargesValue}");

            return postalChargesValue;
        }

        #endregion
    }
}