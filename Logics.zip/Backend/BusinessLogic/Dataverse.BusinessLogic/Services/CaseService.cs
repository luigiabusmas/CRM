using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICaseService
    {
        void PopulateGdprDeletionDate(Entity caseRecord);
        void SetRouteCase(Entity caseRecord);
    }

    public class CaseService : ICaseService
    {
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;

        public CaseService(ILogger logger, IOrganizationService service)
        {
            _logger = logger;
            _service = service;
        }

        public void PopulateGdprDeletionDate(Entity caseRecord)
        {
            _logger.TraceInformation("Starting PopulateGdprDeletionDate business logic.");

            const string gdprConfigEntityName = "rhs_gdprconfigurationsettings";
            const string retentionPeriodAttribute = "rhs_retentionperiod";
            const string entityNameCodeAttribute = "rhs_entitynamecode";
            const string gdprDeletionDateAttribute = "rhs_gdprdeletiondate";

            OptionSetValue caseEntityCode = new OptionSetValue(120000002);

            QueryExpression query = new QueryExpression(gdprConfigEntityName)
            {
                ColumnSet = new ColumnSet(retentionPeriodAttribute),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression(entityNameCodeAttribute, ConditionOperator.Equal, caseEntityCode.Value)
                    }
                }
            };

            Entity gdprConfigRecord = _service.RetrieveMultiple(query).Entities.FirstOrDefault();

            if (gdprConfigRecord != null && gdprConfigRecord.Contains(retentionPeriodAttribute))
            {
                int retentionPeriod = gdprConfigRecord.GetAttributeValue<int>(retentionPeriodAttribute);
                _logger.TraceInformation($"Found retention period: {retentionPeriod} days.");

                if (retentionPeriod > 0)
                {
                    DateTime gdprDeletionDate = DateTime.Now.AddDays(retentionPeriod);
                    _logger.TraceInformation($"Calculated GDPR deletion date: {gdprDeletionDate.ToShortDateString()}");

                    caseRecord[gdprDeletionDateAttribute] = gdprDeletionDate;
                }
                else
                {
                    _logger.TraceInformation("Retention period is zero or negative. Not setting the deletion date.");
                }
            }
            else
            {
                _logger.TraceInformation("No GDPR configuration found or retention period is blank. Not setting the deletion date.");
            }

            _logger.TraceInformation("Ending PopulateGdprDeletionDate business logic.");
        }

        public void SetRouteCase(Entity caseRecord)
        {
            _logger.TraceInformation("Starting SetRouteCase business logic.");

            const string routeCaseAttribute = "routecase";

            // Always set routecase to Yes (true), even if already populated
            caseRecord[routeCaseAttribute] = true;
            _logger.TraceInformation("Routecase field forced to 'Yes' (true).");

            _logger.TraceInformation("Ending SetRouteCase business logic.");
        }

    }
}
