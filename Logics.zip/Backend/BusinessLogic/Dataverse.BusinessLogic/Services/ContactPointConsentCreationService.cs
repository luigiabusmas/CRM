﻿using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IContactPointConsentCreationService
    {
        void ContactPointConsentCreationNewMember(Guid contactId, int dataSet);
    }
    public class ContactPointConsentCreationService : IContactPointConsentCreationService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IPluginExecutionContext _context;

        public ContactPointConsentCreationService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service)
        {
            _tracingService = tracingService;
            _service = service;
            _context = context;
        }

        public void ContactPointConsentCreationNewMember(Guid contactId, int dataSet)
        {
            try
            {
                _tracingService.Trace($"Contact Id: {contactId}");
                _tracingService.Trace($"Data Set: {dataSet}");

                Guid userId = _context.UserId;

                // Retrieve the user's full name from the SystemUser entity
                Entity userEntity = _service.Retrieve(EntityNames.SystemUser.EntityLogicalName, userId, new ColumnSet(EntityNames.SystemUser.FullName));
                string userName = string.Empty;
                if (userEntity != null && userEntity.Contains(EntityNames.SystemUser.FullName))
                {
                    userName = userEntity[EntityNames.SystemUser.FullName].ToString();

                    _tracingService.Trace($"Process triggered by user: {userName}");
                }

                Entity contact = GetContactDetails(contactId);
                _tracingService.Trace("Contact details retrieved successfully.");

                string emailAddress = contact.Contains(EntityNames.Contact.EMailAddress1) ? (string)contact[EntityNames.Contact.EMailAddress1] : null;
                string telephone = contact.Contains(EntityNames.Contact.Telephone1) ? (string)contact[EntityNames.Contact.Telephone1] : null;
                string postalCode = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;
                string contactFullName = contact.Contains(EntityNames.Contact.FullName) ? (string)contact[EntityNames.Contact.FullName] : null;

                _tracingService.Trace($"Email: {emailAddress}, Telephone: {telephone}, Postal Code: {postalCode}, Full Name: {contactFullName}");

                string countryCodePhone = string.Empty;
                string formattedTelephone = string.Empty;
                string concatenatedContactPointValue = string.Empty;

                //Contact Point Channel
                var emailContactPoint = 534120000;
                var phoneContactPoint = 534120001;
                var customContactPoint = 534120002;

                if (!string.IsNullOrEmpty(emailAddress))
                {
                    //Query all the Consent Configuration where Channel = Email
                    EntityCollection consentConfigurationWithEmailCollection = ConsentConfigurationByDataSetAndChannel(dataSet, emailContactPoint);

                    if (consentConfigurationWithEmailCollection.Entities.Count > 0)
                    {
                        _tracingService.Trace($"Creating/Updating email consent for {emailAddress}");
                        _tracingService.Trace($"Consent Configuration w/ Email Channel Count: {consentConfigurationWithEmailCollection.Entities.Count}");
                        CreateOrUpdateContactPointConsent(emailAddress, contactId, consentConfigurationWithEmailCollection, userName, dataSet);
                    }
                }

                if (!string.IsNullOrEmpty(telephone))
                {
                    EntityReference countryCodePhoneRef = contact.Contains(EntityNames.Contact.CountryPhone1) ? (EntityReference)contact[EntityNames.Contact.CountryPhone1] : null;
                    if (countryCodePhoneRef != null)
                    {
                        _tracingService.Trace("Retrieving country code for telephone...");
                        Entity countryCodeEntityPhone = _service.Retrieve(countryCodePhoneRef.LogicalName, countryCodePhoneRef.Id, new ColumnSet(EntityNames.Country.PrimaryIdAttribute, EntityNames.Country.CallingCode));
                        if (countryCodeEntityPhone != null && countryCodeEntityPhone.Contains(EntityNames.Country.CallingCode))
                        {
                            countryCodePhone = (string)countryCodeEntityPhone[EntityNames.Country.CallingCode];
                            _tracingService.Trace($"Country code: {countryCodePhone}");
                        }
                    }

                    //Query all the Consent Configuration where Channel = Text message
                    EntityCollection consentConfigurationWithPhoneCollection = ConsentConfigurationByDataSetAndChannel(dataSet, phoneContactPoint);

                    if (consentConfigurationWithPhoneCollection.Entities.Count > 0)
                    {
                        formattedTelephone = !string.IsNullOrEmpty(countryCodePhone) ? countryCodePhone + telephone : "+44" + telephone;
                        _tracingService.Trace($"Creating/Updating phone consent for {formattedTelephone}");
                        _tracingService.Trace($"Consent Configuration w/ Phone Channel Count: {consentConfigurationWithPhoneCollection.Entities.Count}");
                        CreateOrUpdateContactPointConsent(formattedTelephone, contactId, consentConfigurationWithPhoneCollection, userName, dataSet);
                    }
                }

                if (!string.IsNullOrEmpty(postalCode) && !string.IsNullOrEmpty(contactFullName))
                {
                    //Query all the Consent Configuration where Channel = Custom
                    EntityCollection consentConfigurationWithPostCollection = ConsentConfigurationByDataSetAndChannel(dataSet, customContactPoint);

                    if (consentConfigurationWithPostCollection.Entities.Count > 0)
                    {
                        concatenatedContactPointValue = $"{contactFullName} - {postalCode}";
                        _tracingService.Trace($"Creating/Updating postal consent for {concatenatedContactPointValue}");
                        _tracingService.Trace($"Consent Configuration w/ Custom Channel Count: {consentConfigurationWithPostCollection.Entities.Count}");
                        CreateOrUpdateContactPointConsent(concatenatedContactPointValue, contactId, consentConfigurationWithPostCollection, userName, dataSet);
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Error in ContactPointConsentCreationNewMember: {ex.Message}", ex);
            }
        }

        public Entity GetContactDetails(Guid contactId)
        {
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactId,
                    new ColumnSet(
                        EntityNames.Contact.EMailAddress1, EntityNames.Contact.Telephone1, EntityNames.Contact.Address1_PostalCode,
                        EntityNames.Contact.CountryPhone1, EntityNames.Contact.FullName
                    ));
            return contact;
        }

        public EntityCollection ConsentConfigurationByDataSetAndChannel(int dataSet, int contactPointType)
        {
            QueryExpression queryConsentConfiguration = new QueryExpression(EntityNames.ConsentConfiguration.EntityLogicalName);
            queryConsentConfiguration.ColumnSet.AddColumns(
                EntityNames.ConsentConfiguration.PrimaryIdAttribute,
                EntityNames.ConsentConfiguration.Value,
                EntityNames.ConsentConfiguration.TopicId,
                EntityNames.ConsentConfiguration.DataSets,
                EntityNames.ConsentConfiguration.ChannelContactPoint);

            queryConsentConfiguration.Criteria.AddCondition(EntityNames.ConsentConfiguration.DataSets, ConditionOperator.Equal, dataSet);
            queryConsentConfiguration.Criteria.AddCondition(EntityNames.ConsentConfiguration.ChannelContactPoint, ConditionOperator.Equal, contactPointType);

            EntityCollection consentConfigurations = _service.RetrieveMultiple(queryConsentConfiguration);

            return consentConfigurations;
        }

        private void CreateOrUpdateContactPointConsent(string contactPointValue, Guid contactId, EntityCollection consentConfigurationsCollection, string userName, int dataSet)
        {
            if (!string.IsNullOrEmpty(contactPointValue))
            {
                _tracingService.Trace($"Contact Point Value: {contactPointValue}");

                foreach (var consentConfig in consentConfigurationsCollection.Entities)
                {
                    var contactPointType = (OptionSetValue)consentConfig[EntityNames.ConsentConfiguration.ChannelContactPoint];
                    var consentStatus = (OptionSetValue)consentConfig[EntityNames.ConsentConfiguration.Value];
                    var topicRef = (EntityReference)consentConfig[EntityNames.ConsentConfiguration.TopicId];
                    var dataSetValue = (OptionSetValue)consentConfig[EntityNames.ConsentConfiguration.DataSets];

                    if(topicRef != null)
                    {
                        Entity topicEntity = _service.Retrieve(EntityNames.Msdynmkt_topic.EntityLogicalName, topicRef.Id, new ColumnSet(EntityNames.Msdynmkt_topic.PrimaryIdAttribute, EntityNames.Msdynmkt_topic.Msdynmkt_purposeId));
                        var purposeRef = (EntityReference)topicEntity[EntityNames.Msdynmkt_topic.Msdynmkt_purposeId];

                        EntityCollection duplicateConsents = CheckDuplicateConsents(contactPointValue, contactPointType, purposeRef.Id.ToString(), topicRef.Id.ToString());
                        _tracingService.Trace($"Duplicate Consents Count: {duplicateConsents.Entities.Count}");

                        if (duplicateConsents.Entities.Count > 0)
                        {
                            foreach (var existingConsent in duplicateConsents.Entities)
                            {
                                Guid existingConsentId = existingConsent.Id;
                                _tracingService.Trace($"Existing Consent ID: {existingConsentId}");

                                int existingDataSet = existingConsent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Dataset) ? ((OptionSetValue)existingConsent[EntityNames.Msdynmkt_contactpointconsent4.Dataset]).Value : 0;
                                _tracingService.Trace($"Existing DataSet: {existingDataSet}");

                                int existingConsentSource = existingConsent.Contains(EntityNames.Msdynmkt_contactpointconsent4.ConsentSource) ? ((OptionSetValue)existingConsent[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource]).Value : 0;
                                _tracingService.Trace($"Existing ConsentSource: {existingConsentSource}");

                                int existingStatus = existingConsent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Statecode) ? ((OptionSetValue)existingConsent[EntityNames.Msdynmkt_contactpointconsent4.Statecode]).Value : -1;
                                _tracingService.Trace($"Existing Status: {existingStatus}");

                                int existingValue = existingConsent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value) ? ((OptionSetValue)existingConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value]).Value : 0;
                                _tracingService.Trace($"Existing Value: {existingValue}");

                                //Check if Contact is associated to the consent
                                bool isAssociated = IsContactAssociatedWithConsent(contactId.ToString(), existingConsentId.ToString());

                                if (existingDataSet == 0 || existingDataSet == ((int)DataSetsCode_GlobalOptionSet.Contact) || existingDataSet == ((int)DataSetsCode_GlobalOptionSet.NewMember) || existingDataSet == ((int)DataSetsCode_GlobalOptionSet.NonMember))
                                {
                                    //Update LI package only to prevent overwritten of existing consent value
                                    if (consentStatus.Value == ((int)Msdynmkt_consentvalue_GlobalOptionSet.OptedIn) && consentStatus.Value != existingValue)
                                        UpdateContactPointConsents(existingConsentId, consentStatus, existingConsentSource, dataSet, userName);

                                    if (!isAssociated)
                                        AssociateContactToContactPointConsent(existingConsentId, contactId);
                                    if (existingStatus == 1)
                                        ActivateContactPointConsent(existingConsentId);
                                }
                            }
                        }
                        else
                        {
                            Guid contactPointConsentId = CreateContactPointConsents(contactId, contactPointValue, contactPointType, consentStatus, purposeRef, topicRef, dataSetValue, userName);

                            _tracingService.Trace($"Existing Consent Id: {contactPointConsentId}");

                            AssociateContactToContactPointConsent(contactPointConsentId, contactId);
                        }
                    }
                }
            }
        }

        private EntityCollection CheckDuplicateConsents(string contactPointValue, OptionSetValue contactPointType, string purposeId, string topicId)
        {
            QueryExpression queryDuplicateContactPointConsents = new QueryExpression(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName);
            queryDuplicateContactPointConsents.ColumnSet.AddColumns(
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointvalue,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value,
                EntityNames.Msdynmkt_contactpointconsent4.ConsentSource,
                EntityNames.Msdynmkt_contactpointconsent4.Dataset,
                EntityNames.Msdynmkt_contactpointconsent4.Statecode,
                EntityNames.Msdynmkt_contactpointconsent4.Statuscode
            );

            queryDuplicateContactPointConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointvalue, ConditionOperator.Equal, contactPointValue);
            queryDuplicateContactPointConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointtype, ConditionOperator.Equal, contactPointType.Value);
            queryDuplicateContactPointConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId, ConditionOperator.Equal, purposeId);
            queryDuplicateContactPointConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId, ConditionOperator.Equal, topicId);
            
            EntityCollection records = _service.RetrieveMultiple(queryDuplicateContactPointConsents);

            return records;
        }

        private bool IsContactAssociatedWithConsent(string contactId, string consentId)
        {
            _tracingService.Trace("Checking if Contact is associated with Consent...");

            QueryExpression queryCheckContactAssociation = new QueryExpression(EntityNames.Contact_msdynmkt_contactpointconsent4.EntityLogicalName)
            {
                ColumnSet = new ColumnSet(false)
            };

            queryCheckContactAssociation.Criteria.AddCondition(EntityNames.Contact_msdynmkt_contactpointconsent4.Contactid, ConditionOperator.Equal, contactId);
            queryCheckContactAssociation.Criteria.AddCondition(EntityNames.Contact_msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsent4id, ConditionOperator.Equal, consentId);

            var result = _service.RetrieveMultiple(queryCheckContactAssociation);

            // If any records are returned, the contact is already associated with the consent
            bool isAssociated = result.Entities.Any();

            _tracingService.Trace($"Is Contact associated with Consent: {isAssociated}");

            return isAssociated;
        }

        private Guid CreateContactPointConsents(Guid contactId, string contactPointValue, OptionSetValue contactPointType, OptionSetValue consentStatus, EntityReference purpose, EntityReference topic, OptionSetValue dataSetValue, string userName)
        {
            Entity contactPointConsent = new Entity(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointvalue] = contactPointValue;
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointtype] = new OptionSetValue(contactPointType.Value);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsenttype] = new OptionSetValue(534120001);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value] = new OptionSetValue(consentStatus.Value);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId] = new EntityReference(EntityNames.Msdynmkt_purpose.EntityLogicalName, purpose.Id);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId] = new EntityReference(EntityNames.Msdynmkt_topic.EntityLogicalName, topic.Id);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason] = new OptionSetValue(534120000);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf] = userName;
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source] = new OptionSetValue(534120000);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource] = new OptionSetValue(120000003);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Dataset] = new OptionSetValue(dataSetValue.Value);

            Guid consentId = _service.Create(contactPointConsent);
            _tracingService.Trace($"Consent ID: {consentId}");
            return consentId;
        }

        private void UpdateContactPointConsents(Guid existingConsentId, OptionSetValue consentStatus, int consentSource, int dataset, string userName)
        {
            _tracingService.Trace($"Execute UpdateContactPointConsents");

            Entity contactPointConsent = new Entity(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, existingConsentId);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value] = new OptionSetValue(consentStatus.Value);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Dataset] = new OptionSetValue(dataset);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf] = userName;

            if (consentSource == 0)
            {
                contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource] = new OptionSetValue(120000003);
            }
            else
            {
                contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource] = new OptionSetValue(consentSource);
            }

            _service.Update(contactPointConsent);

            _tracingService.Trace($"Updated Consent ID: {contactPointConsent.Id}");
        }

        private void AssociateContactToContactPointConsent(Guid contactPointConsentId, Guid contactId)
        {

            AssociateRequest associateRequestPrimary = new AssociateRequest
            {
                Target = new EntityReference(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, contactPointConsentId),
                RelatedEntities = new EntityReferenceCollection
                    {
                        new EntityReference(EntityNames.Contact.EntityLogicalName, contactId)
                    },
                Relationship = new Relationship("rhs_contact_msdynmkt_contactpointconsent4_MM")
            };

            // Execute the request
            _service.Execute(associateRequestPrimary);

            _tracingService.Trace($"Associating Contact to the Contact Point Consent is successful.");
        }

        private void ActivateContactPointConsent(Guid contactPointConsentId)
        {
            Entity contactPointConsent = new Entity(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, contactPointConsentId);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Statecode] = new OptionSetValue(0);
            contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Statuscode] = new OptionSetValue(1);

            _service.Update(contactPointConsent);

            _tracingService.Trace($"Activated Consent ID: {contactPointConsent.Id}");
        }
    }
}
