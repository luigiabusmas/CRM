﻿using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace Cultivate.BusinessLogic.Services
{
    public interface IContactPointConsentUpdateService
    {
        Guid CreateConsentAuditTrailHistory(Entity targetEntity, Entity preImageEntity);
    }

    public class ContactPointConsentUpdateService : IContactPointConsentUpdateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IPluginExecutionContext _context;

        public ContactPointConsentUpdateService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service)
        {
            _tracingService = tracingService;
            _service = service;
            _context = context;
        }

        public Guid CreateConsentAuditTrailHistory(Entity consent, Entity preImage)
        {
            _tracingService.Trace($"CreateConsentAuditTrailHistory Start");

            try
            {
                Guid userId = _context.UserId;

                // Retrieve the user's full name from the SystemUser entity
                Entity userEntity = _service.Retrieve(EntityNames.SystemUser.EntityLogicalName, userId, new ColumnSet(EntityNames.SystemUser.FullName));
                string userName = string.Empty;
                if (userEntity != null && userEntity.Contains(EntityNames.SystemUser.FullName))
                {
                    userName = userEntity[EntityNames.SystemUser.FullName].ToString();

                    _tracingService.Trace($"Process triggered by user: {userName}");
                }

                int? consentStatusNew = consent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value)
                                        ? (int)((OptionSetValue)consent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value]).Value
                                        : (int?)null;
                int? consentStatusOld = preImage.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value)
                                        ? (int)((OptionSetValue)preImage[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value]).Value
                                        : (int?)null;

                int? logicalReasonNew = consent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason)
                                        ? (int)((OptionSetValue)consent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason]).Value
                                        : (int?)null;
                int? logicalReasonOld = preImage.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason)
                                        ? (int)((OptionSetValue)preImage[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_logicalreason]).Value
                                        : (int?)null;

                var requestedByNew = userName;
                var requestedByOld = preImage.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf)
                                        ? (string)preImage[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_modifiedonbehalf]
                                        : string.Empty;

                int? sourceNew = consent.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source)
                                    ? (int)((OptionSetValue)consent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source]).Value
                                    : (int?)null;
                int? sourceOld = preImage.Contains(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source)
                                    ? (int)((OptionSetValue)preImage[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_source]).Value
                                    : (int?)null;

                int? consentSourceNew = consent.Contains(EntityNames.Msdynmkt_contactpointconsent4.ConsentSource)
                                        ? (int)((OptionSetValue)consent[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource]).Value
                                        : (int?)null;
                int? consentSourceOld = preImage.Contains(EntityNames.Msdynmkt_contactpointconsent4.ConsentSource)
                                        ? (int)((OptionSetValue)preImage[EntityNames.Msdynmkt_contactpointconsent4.ConsentSource]).Value
                                        : (int?)null;

                // Trace only if values are not null
                _tracingService.Trace($"Consent Status New: {(consentStatusNew.HasValue ? consentStatusNew.Value.ToString() : "null")}");
                _tracingService.Trace($"Consent Status Old: {(consentStatusOld.HasValue ? consentStatusOld.Value.ToString() : "null")}");
                _tracingService.Trace($"Logical Reason New: {(logicalReasonNew.HasValue ? logicalReasonNew.Value.ToString() : "null")}");
                _tracingService.Trace($"Logical Reason Old: {(logicalReasonOld.HasValue ? logicalReasonOld.Value.ToString() : "null")}");
                _tracingService.Trace($"Requested By New: {requestedByNew}");
                _tracingService.Trace($"Requested By Old: {requestedByOld}");
                _tracingService.Trace($"Source New: {(sourceNew.HasValue ? sourceNew.Value.ToString() : "null")}");
                _tracingService.Trace($"Source Old: {(sourceOld.HasValue ? sourceOld.Value.ToString() : "null")}");
                _tracingService.Trace($"Consent Source New: {(consentSourceNew.HasValue ? consentSourceNew.Value.ToString() : "null")}");
                _tracingService.Trace($"Consent Source Old: {(consentSourceOld.HasValue ? consentSourceOld.Value.ToString() : "null")}");

                Entity consentAuditTrail = new Entity(EntityNames.ConsentsAuditTrail.EntityLogicalName);
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ContactPointConsent] = new EntityReference(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, consent.Id);
                consentAuditTrail[EntityNames.ConsentsAuditTrail.FromValue] = consentStatusOld.HasValue ? new OptionSetValue(consentStatusOld.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ToValue] = consentStatusNew.HasValue ? new OptionSetValue(consentStatusNew.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.FromReason] = logicalReasonOld.HasValue ?  new OptionSetValue(logicalReasonOld.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ToReason] = logicalReasonNew.HasValue ? new OptionSetValue(logicalReasonNew.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ToRequestedBy] = userName;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.FromSource] = sourceOld.HasValue ? new OptionSetValue(sourceOld.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ToSource] = sourceNew.HasValue ? new OptionSetValue(sourceNew.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.FromConsentSource] = consentSourceOld.HasValue ? new OptionSetValue(consentSourceOld.Value) : null;
                consentAuditTrail[EntityNames.ConsentsAuditTrail.ToConsentSource] = consentSourceNew.HasValue ? new OptionSetValue(consentSourceNew.Value) : null;

                Guid consentAuditTrailId = _service.Create(consentAuditTrail);
                _tracingService.Trace($"Consent ID: {consentAuditTrailId}");

                _tracingService.Trace($"CreateConsentAuditTrailHistory End");

                return consentAuditTrailId;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Executing CreateDeactivateConsents has an error: {ex.Message} ");
            }
        }
    }
}