﻿using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipAssociateService
    {
        void MembershipAssociateValidation();
    }

    public class MembershipAssociateService : IMembershipAssociateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IPluginExecutionContext _context;
        private IPropertyRetrievalService _propertyRetrievalService;

        #region Constants
        const int newMemberDataSet = 120000000;
        const string membershipContactRelationship = "rhs_rhs_membership_contact_MM";
        const int noPrimaryMember = 120000000;
        const int yesPrimaryMember = 120000001;
        const int memberRelationship1 = 120000000;
        const int memberRelationship2 = 120000001;
        const string customAPI = "rhs_consentscreation";
        #endregion Constants

        public MembershipAssociateService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service, IPropertyRetrievalService propertyRetrievalService)
        {
            _tracingService = tracingService;
            _service = service;
            _context = context;
            _propertyRetrievalService = propertyRetrievalService;
        }

        public void MembershipAssociateValidation()
        {
            _tracingService.Trace("MembershipAssociateValidation Start");

            var targetEntity = (EntityReference)_context.InputParameters["Target"];
            _tracingService.Trace("targetEntity id: " + targetEntity.Id.ToString());

            if (_context.InputParameters.Contains("RelatedEntities") && _context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
            {
                var relatedEntities = _context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                _tracingService.Trace("relatedEntities count: " + relatedEntities.Count);

                // Retrieving membership
                Entity membership = null;
                try
                {
                    membership = _service.Retrieve(EntityNames.Membership.EntityLogicalName, targetEntity.Id, new ColumnSet(EntityNames.Membership.MembershipProductId));
                }
                catch
                {
                    _tracingService.Trace("Failed to retrieve target membership.");
                }

                // Validating
                if (membership != null) {
                    EntityReference membershipProductRef = membership.GetAttributeValue<EntityReference>(EntityNames.Membership.MembershipProductId);
                    EntityCollection existingPrimaryMembers = GetExistingPrimaryMembers(targetEntity.Id);

                    if (membershipProductRef == null)
                        throw new InvalidPluginExecutionException("Missing Membership Product");
                    _tracingService.Trace($"Membership Product: {membershipProductRef.Name}");

                    ValidateNumberOfMembersInMembership(targetEntity.Id, membershipProductRef.Id.ToString());

                    var relatedEntity = relatedEntities[0];

                    // Check if there is an existing Primary Member
                    if (existingPrimaryMembers.Entities.Count == 1)
                    {
                        ValidateAgeRequirementsInMembership(relatedEntities, membershipProductRef, existingPrimaryMembers);
                        _tracingService.Trace("ValidateAgeRequirementsInMembership Completed");
                        ValidateAddressInMembership(existingPrimaryMembers, relatedEntity, targetEntity);
                        _tracingService.Trace("ValidateAddressInMembership Completed");
                    }
                }
            }

            _tracingService.Trace("MembershipAssociateValidation End");
        }

        private EntityCollection GetExistingPrimaryMembers(Guid membershipId)
        {
            _tracingService.Trace($"GetExistingPrimaryMembers Start");
            QueryExpression query = new QueryExpression(EntityNames.Membership_contact_mm.EntityLogicalName);
            query.Distinct = true;
            query.ColumnSet.AddColumns(
                EntityNames.Membership_contact_mm.Contactid,
                EntityNames.Membership_contact_mm.Membershipid,
                EntityNames.Membership_contact_mm.PrimaryIdAttribute);

            // Add conditions to query.Criteria
            query.Criteria.AddCondition(EntityNames.Membership_contact_mm.Membershipid, ConditionOperator.Equal, membershipId);

            // Add link-entity ab
            var ab = query.AddLink(EntityNames.Contact.EntityLogicalName, EntityNames.Membership_contact_mm.Contactid, EntityNames.Contact.ContactId);
            ab.EntityAlias = "ab";

            // Add conditions to ab.LinkCriteria,
            ab.LinkCriteria.AddCondition(EntityNames.Contact.IsPrimaryMember, ConditionOperator.Equal, 120000001);

            EntityCollection existingPrimaryMembers = _service.RetrieveMultiple(query);
            _tracingService.Trace($"Existing Members Count: {existingPrimaryMembers.Entities.Count}");
            _tracingService.Trace($"GetExistingPrimaryMembers End");

            return existingPrimaryMembers;
        }

        private void ValidateNumberOfMembersInMembership(Guid membershipId, string productId)
        {
            _tracingService.Trace($"ValidateNumberOfMembersInMembership Start");

            var productPropertyName = "Number of Members Allowed";
            var numberOfMembersAllowedProperty = _propertyRetrievalService.GetProductProperty(productId, productPropertyName);
            var numberOfAllowedMembers = numberOfMembersAllowedProperty.DefaultValueInteger != null ? (int)numberOfMembersAllowedProperty.DefaultValueInteger : 0;

            var queryExistingMembers = new QueryExpression(EntityNames.Membership_contact_mm.EntityLogicalName);
            queryExistingMembers.Distinct = true;
            queryExistingMembers.ColumnSet.AddColumns(
                EntityNames.Membership_contact_mm.Contactid,
                EntityNames.Membership_contact_mm.Membershipid,
                EntityNames.Membership_contact_mm.PrimaryIdAttribute);
            queryExistingMembers.Criteria.AddCondition(EntityNames.Membership_contact_mm.Membershipid, ConditionOperator.Equal, membershipId);

            var existingMembers = _service.RetrieveMultiple(queryExistingMembers);
            _tracingService.Trace($"Existing Members Count: {existingMembers.Entities.Count}");

            if (numberOfAllowedMembers >= 1 && existingMembers.Entities.Count >= 1 && existingMembers.Entities.Count >= numberOfAllowedMembers)
            {
                _tracingService.Trace($"ValidateNumberOfMembersInMembership Failed. Over the allowed members.");
                throw new InvalidPluginExecutionException($"The Membership Product allows only {numberOfAllowedMembers} member/s. Please do not add extra member!");
            }

            _tracingService.Trace($"ValidateNumberOfMembersInMembership End");
        }

        private void ValidateAgeRequirementsInMembership(EntityReferenceCollection relatedEntities, EntityReference membershipProductRef, EntityCollection existingPrimaryMembers)
        {
            _tracingService.Trace($"ValidateAgeRequirementsInMembership Start");

            var isDOBRequired = _propertyRetrievalService.GetDefaultOptionSetValueOfProductProperty(membershipProductRef.Id.ToString(), "DOB Required") == 1 ? true : false;
            var minimumAgeProperty = _propertyRetrievalService.GetProductProperty(membershipProductRef.Id.ToString(), "Minimum Age");
            var minimumAge = minimumAgeProperty.DefaultValueInteger != null ? (int)minimumAgeProperty.DefaultValueInteger : 0;

            if (existingPrimaryMembers.Entities.Count == 1 && isDOBRequired)
            {
                // Check if there is an existing Primary Member
                var relatedEntity = relatedEntities[0];
                Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, relatedEntity.Id, new ColumnSet(EntityNames.Contact.BirthDate, EntityNames.Contact.Age, EntityNames.Contact.IsPrimaryMember, EntityNames.Contact.MembershipRelationship));

                // Check if DOB is required but not provided
                if (isDOBRequired && !contact.Contains(EntityNames.Contact.BirthDate))
                {
                    _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. DOB is required but not provided.");
                    throw new InvalidPluginExecutionException($"Contact selected as New Member requires Date of Birth for {membershipProductRef.Name}, Please update DOB for the contact first!");
                }

                // Check if the contact meets the minimum age requirement
                int minAgeRequirement = minimumAge;
                int contactAge = contact.Contains("rhs_age") ? contact.GetAttributeValue<int>("rhs_age") : 0;
                _tracingService.Trace($"Minimum Age Property Value: {minAgeRequirement}");
                _tracingService.Trace($"Contact Age Property Value: {contactAge}");

                if (contactAge < minAgeRequirement)
                {
                    _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. Contact does not meet the minimum age requirement.");
                    throw new InvalidPluginExecutionException($"New member cannot be added to the {membershipProductRef.Name}, the minimum age requirement is {minAgeRequirement} years and above for all members on a {membershipProductRef.Name}");
                }
            }
        }

        private void ValidateAddressInMembership(EntityCollection existingPrimaryMembers, EntityReference relatedEntity, EntityReference targetEntity)
        {
            _tracingService.Trace($"ValidateAddressInMembership Start");

            Entity membershipNtoN = existingPrimaryMembers.Entities[0];
            Guid primaryMemberId = (Guid)membershipNtoN[EntityNames.Membership_contact_mm.Contactid];
            _tracingService.Trace($"Primary Member Id: {primaryMemberId}");

            Entity primaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, primaryMemberId, new ColumnSet(true));

            //Retrieve concatenated address for Primary Member
            string primaryMemberAddress = GetContactAddress(primaryMemberId);

            Entity secondaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, relatedEntity.Id, new ColumnSet(true));

            //Retrieve concatenated address for Secondary Member
            string secondaryMemberAddress = GetContactAddress(secondaryMember.Id);

            if (string.IsNullOrEmpty(primaryMemberAddress))
            {
                throw new InvalidPluginExecutionException("Primary Member Address details is empty. Please provide!");
            }

            _tracingService.Trace($"Primary Member Address: {primaryMemberAddress}");

            if (string.IsNullOrEmpty(secondaryMemberAddress))
            {
                Entity updateSecondaryMember = new Entity(EntityNames.Contact.EntityLogicalName, secondaryMember.Id);
                //Update Secondary Member Address details
                updateSecondaryMember[EntityNames.Contact.AddressSearchTypePrimary] = primaryMember.Contains(EntityNames.Contact.AddressSearchTypePrimary) ? primaryMember[EntityNames.Contact.AddressSearchTypePrimary] : null;
                updateSecondaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] = primaryMember.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? primaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_Line1] = primaryMember.Contains(EntityNames.Contact.Address1_Line1) ? primaryMember[EntityNames.Contact.Address1_Line1] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_Line2] = primaryMember.Contains(EntityNames.Contact.Address1_Line2) ? primaryMember[EntityNames.Contact.Address1_Line2] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_Line3] = primaryMember.Contains(EntityNames.Contact.Address1_Line3) ? primaryMember[EntityNames.Contact.Address1_Line3] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_StateOrProvince] = primaryMember.Contains(EntityNames.Contact.Address1_StateOrProvince) ? primaryMember[EntityNames.Contact.Address1_StateOrProvince] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_City] = primaryMember.Contains(EntityNames.Contact.Address1_City) ? primaryMember[EntityNames.Contact.Address1_City] : null;
                updateSecondaryMember[EntityNames.Contact.LoqateAddress1County] = primaryMember.Contains(EntityNames.Contact.LoqateAddress1County) ? primaryMember[EntityNames.Contact.LoqateAddress1County] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_Country] = primaryMember.Contains(EntityNames.Contact.Address1_Country) ? primaryMember[EntityNames.Contact.Address1_Country] : null;
                updateSecondaryMember[EntityNames.Contact.Address1_PostalCode] = primaryMember.Contains(EntityNames.Contact.Address1_PostalCode) ? primaryMember[EntityNames.Contact.Address1_PostalCode] : null;
                updateSecondaryMember[EntityNames.Contact.Loqate_Latitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Latitude) ? primaryMember[EntityNames.Contact.Loqate_Latitude] : null;
                updateSecondaryMember[EntityNames.Contact.Loqate_Longitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Longitude) ? primaryMember[EntityNames.Contact.Loqate_Longitude] : null;
                updateSecondaryMember[EntityNames.Contact.Address1PAFValidated] = primaryMember.Contains(EntityNames.Contact.Address1PAFValidated) ? primaryMember[EntityNames.Contact.Address1PAFValidated] : null;
                updateSecondaryMember[EntityNames.Contact.BusinessValidatedPrimary] = primaryMember.Contains(EntityNames.Contact.BusinessValidatedPrimary) ? primaryMember[EntityNames.Contact.BusinessValidatedPrimary] : null;
                
                _service.Update(updateSecondaryMember);
                _tracingService.Trace("Updated contact: " + relatedEntity.Id.ToString());
            }

            else
            {
                _tracingService.Trace($"Secondary Member Address: {secondaryMemberAddress}");
                if (secondaryMemberAddress != primaryMemberAddress)
                {
                    _tracingService.Trace("TEST: Addresses do NOT match. Throwing an exception.");
                    throw new InvalidPluginExecutionException($"Addresses don't match, Please review the address for both the members!");
                }
                else
                {
                    Entity updateSecondaryMember = new Entity(EntityNames.Contact.EntityLogicalName, secondaryMember.Id);

                    // Update only the necessary fields
                    updateSecondaryMember[EntityNames.Contact.IsPrimaryMember] = new OptionSetValue(noPrimaryMember);
                    updateSecondaryMember[EntityNames.Contact.MembershipRelationship] = new OptionSetValue(memberRelationship2);

                    // Add tracing logs
                    _tracingService.Trace($"TEST: Set IsPrimaryMember to {noPrimaryMember}");
                    _tracingService.Trace($"TEST: Set MembershipRelationship to {memberRelationship2}");
                    _tracingService.Trace("TEST: About to update contact.......... ");

                    // Perform the update
                    _service.Update(updateSecondaryMember);
                    _tracingService.Trace("TEST: update contact successful ");
                }
            }

            _tracingService.Trace($"ValidateAddressInMembership End");
        }

        private string GetContactAddress(Guid contactid)
        {
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactid, new ColumnSet(true));

            string houseName = contact.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? (string)contact[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
            string houseLine = contact.Contains(EntityNames.Contact.Address1_Line1) ? (string)contact[EntityNames.Contact.Address1_Line1] : null;
            string city = contact.Contains(EntityNames.Contact.Address1_City) ? (string)contact[EntityNames.Contact.Address1_City] : null;
            string postalCode = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;

            string memberAddress = $"{houseName} {houseLine} {city} {postalCode}".Trim();

            return memberAddress.ToLower();
        }

        public void CreateOrUpdateConsentsForMembersAndPayer(EntityReference membershipRef, EntityReference contactRef)
        {
            _tracingService.Trace("CreateOrUpdateConsentsForMembersAndPayer Start");

            Entity membership = _service.Retrieve(EntityNames.Membership.EntityLogicalName, membershipRef.Id, new ColumnSet(true));

            try
            {
                // Retrieve the Primary and Secondary Members from the Membership record
                Guid? primaryMemberId = membership.Contains(EntityNames.Membership.Contact) ?
                                        ((EntityReference)membership[EntityNames.Membership.Contact]).Id : (Guid?)null;

                Guid? secondaryMemberId = membership.Contains(EntityNames.Membership.Member2) ?
                                          ((EntityReference)membership[EntityNames.Membership.Member2]).Id : (Guid?)null;

                Guid? payerId = membership.Contains(EntityNames.Membership.PayerV2) ?
                                ((EntityReference)membership[EntityNames.Membership.PayerV2]).Id : (Guid?)null;
                string? payerLogicalName = membership.Contains(EntityNames.Membership.PayerV2) ?
                                ((EntityReference)membership[EntityNames.Membership.PayerV2]).LogicalName : (string?)null;

                if (primaryMemberId.HasValue)
                {
                    _tracingService.Trace($"Primary Member Id: {primaryMemberId.Value}");

                    InvokeConsentCreationApi(primaryMemberId.Value.ToString(), newMemberDataSet);
                }

                if (secondaryMemberId.HasValue)
                {
                    _tracingService.Trace($"Secondary Member Id: {primaryMemberId.Value}");

                    InvokeConsentCreationApi(secondaryMemberId.Value.ToString(), newMemberDataSet);
                }

                bool isMembershipForSomeone = membership.Contains(EntityNames.Membership.IsMembershipForSomeone) ? (bool)membership[EntityNames.Membership.IsMembershipForSomeone] : false;

                if (payerId.HasValue && isMembershipForSomeone)
                {
                    if (payerLogicalName == EntityNames.Contact.EntityLogicalName && 
                        (payerId.Value != primaryMemberId.Value || payerId.Value != secondaryMemberId.Value))
                    {
                        _tracingService.Trace($"Payer Id: {payerId.Value}");
                        InvokeConsentCreationApi(payerId.Value.ToString(), newMemberDataSet);
                    }
                    else
                    {
                        _tracingService.Trace("Skipping consents creation of Payer.");
                    }
                }

                _tracingService.Trace("CreateOrUpdateConsentsForMembersAndPayer End");
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Error in MembershipConsentCreationPayer: {ex.Message}", ex);
            }
        }

        public void InvokeConsentCreationApi(string contactId, int newMemberDataSet)
        {
            OrganizationRequest apiRequest = new OrganizationRequest(customAPI)
            {
                Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", newMemberDataSet }
                    }
            };

            // Execute the Custom API call
            OrganizationResponse apiResponse = _service.Execute(apiRequest);

            // Check the response for success or failure
            if (apiResponse != null && apiResponse.Results.Contains("result") && (bool)apiResponse.Results["result"])
            {
                _tracingService.Trace("Consent creation via API was successful.");
            }
            else if (apiResponse != null && apiResponse.Results.Contains("error"))
            {
                string error = apiResponse.Results["error"].ToString();
                _tracingService.Trace($"Consent creation via API failed. Error: {error}");
                throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
            }

            _tracingService.Trace("Custom API executed successfully.");
        }
    }
}