﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipRenewalService
    {
        Membership UpdateRenewalFields(Membership membership, bool? isAdvancePayment);
        Membership CreateMembershipOnRenewal(Membership membership);
    }
    public class MembershipRenewalService : IMembershipRenewalService
    {
        private ILogger _logger;
        private IRepository<Membership> _membershipRepository;
        private IRepository<GiftPack> _giftPackRepository;
        private IProductService _productService;
        private IRecordDateCalculationService _recordDateCalculationService;
        private ICultivateConfigurationService _cultivateConfigurationService;

        public MembershipRenewalService(ILogger logger, IRepository<Membership> membershipRepository, IRepository<GiftPack> giftPackRepository,
            IProductService productService, IRecordDateCalculationService recordDateCalculationService, ICultivateConfigurationService cultivateConfigurationService)
        {
            _logger = logger;
            _membershipRepository = membershipRepository;
            _giftPackRepository = giftPackRepository;
            _productService = productService;
            _recordDateCalculationService = recordDateCalculationService;
            _cultivateConfigurationService = cultivateConfigurationService;
        }

        public Membership UpdateRenewalFields(Membership membership, bool? isAdvancePayment)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Preparing fields to update.");
            var membershipToUpdate = new Membership()
            {
                Id = membership.Id,
                //RenewalsCampaign = null,
                RenewalsMembershipProduct = new EntityReference("product", membership.MembershipProductId.Id),
                RenewalsPayer = membership.IsMembershipForSomeone == true && membership.IsthisMembershipaoneyeargift == true ?
                    membership.Contact : membership.PayerV2,
                RenewalsStatus = RenewalsStatus_GlobalOptionSet.PendingRenewal,
                RenewalsPriceList = membership.MembershipProductId.Name.ToLower().Contains("patron") ?
                    _productService.GetPatronProductRenewalPriceList(membership.MembershipProductId.Id) : _productService.GetProductRenewalPriceList(membership.MembershipProductId.Id),
                InRenewalsStage = true,
            };
            membershipToUpdate.RenewalsMembershipPrice = _productService.GetProductPrice(membershipToUpdate.RenewalsMembershipProduct.Id, membershipToUpdate.RenewalsPriceList.Id);
            membershipToUpdate.RenewalsTotalAmount = membershipToUpdate.RenewalsMembershipPrice;

            if (membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.GiftPack &&
                membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.InternalGiftPack)
            {
                membershipToUpdate.RenewalsPaymentMethod = membership.PaymentMethod;
            }

            if (membership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                if (isAdvancePayment == true)
                {
                    membershipToUpdate.RenewalsPaymentMethod = null;
                    //Also leave related Payment fields as blank
                }
                else
                {
                    membershipToUpdate.RenewalPaymentFrequency = membership.PaymentFrequency;
                    membershipToUpdate.RenewalPaymentSchedule = _recordDateCalculationService.CalculatePayoutDate(((DateTime)membership.Enddate).AddDays(1));
                    membership.Isrenewalcontinuouspayment = membership.IsContinuousPayment;
                    membership.IsRenewalDDDiscountAvailed = membership.IsDDDiscountAvailed;
                }
            }

            if (membership.IsMembershipForSomeone == true && membership.IsthisMembershipaoneyeargift == true)
                membershipToUpdate.RenewalsPaymentMethod = PaymentMethodType_GlobalOptionSet.CreditCard_Phone; //membershipToUpdate.RenewalsPaymentMethod = Msnfp_paymentmethodtype_GlobalOptionSet.Card;

            _logger.TraceInformation($"Updating fields.");
            _membershipRepository.Update(membershipToUpdate);
            var updatedMembership = _membershipRepository.GetById(membership.Id);

            _logger.TraceInformation($"Ending business logic.");
            return updatedMembership;
        }

        public Membership CreateMembershipOnRenewal(Membership membership)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Initilizing helper variables.");
            var isPatron = membership.RenewalsMembershipProduct != null && membership.RenewalsMembershipProduct.Name != null && membership.RenewalsMembershipProduct.Name.ToLower().Contains("patron");
            var originalMembershipEndDate = (DateTime)membership.Enddate;
            var utcNow = DateTime.UtcNow;

            var renewalPeriodDuration = int.Parse(_cultivateConfigurationService.GetCultivateConfigurationValue("RenewalPeriodDuration"));
            var dormancyPeriodDuration = int.Parse(_cultivateConfigurationService.GetCultivateConfigurationValue("DormancyPeriodDuration"));

            _logger.TraceInformation($"Preparing new membership dates.");
            var newMembershipStartDate = _recordDateCalculationService.CalculateStartDateOfRenewalMembership(membership.RenewalsMembershipProduct, (DateTime)membership.Enddate);
            var newMembershipEndDate = _recordDateCalculationService.CalculateEndDateOfRecord((DateTime)newMembershipStartDate, membership.RenewalsMembershipProduct.Id, membership.RenewalsCampaign?.Id);
            var newMembershipPayoutDate = membership.RenewalsPaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit && membership.RenewalPaymentSchedule == null ?
                _recordDateCalculationService.CalculatePayoutDate((DateTime)newMembershipStartDate) : membership.RenewalPaymentSchedule;
            var newMembershpiRenewalStartDate = newMembershipEndDate == null ? newMembershipEndDate : ((DateTime)newMembershipEndDate).AddMonths(-renewalPeriodDuration);
            var newMembershpiRenewalEndDate = newMembershipEndDate == null ? newMembershipEndDate : ((DateTime)newMembershipEndDate).AddMonths(dormancyPeriodDuration);
            bool newMembershipgiftAidOverride = membership.Giftaidoverride == true;

            _logger.TraceInformation($"Preparing new membership object.");
            var membershipToCreate = new Membership()
            {
                Channel = membership.Channel,
                Contact = membership.Contact,
                IsReferredByExistingMember = membership.IsReferredByExistingMember,
                LinkedMembership = membership.ToEntityReference(),
                IsRegistrationForGiftAid = membership.IsRegistrationForGiftAid,
                GDPRRead = membership.GDPRRead,
                CancellationRead = membership.CancellationRead,
                //DirectDebitRead = membership.DirectDebitRead, //Field is Deprecated

                GardenMagazine = membership.GardenMagazine,
                MagazineDeliveryContact = membership.MagazineDeliveryContact,
                JoiningDate = membership.JoiningDate,
                Startdate = newMembershipStartDate,
                Enddate = newMembershipEndDate,

                RenewalsStartDate = newMembershpiRenewalStartDate,
                RenewalsEndDate = newMembershpiRenewalEndDate,

                CampaignId = membership.RenewalsCampaign,
                MembershipProductId = membership.RenewalsMembershipProduct,
                PayerV2 = membership.RenewalsPayer,
                PriceList = membership.RenewalsPriceList,
                MembershipPrice = membership.RenewalsMembershipPrice,
                TotalAmount = membership.RenewalsTotalAmount,
                PaymentMethod = membership.RenewalsPaymentMethod,
                IsContinuousPayment = membership.Isrenewalcontinuouspayment,
                PaymentFrequency = membership.RenewalPaymentFrequency,
                PaymentSchedule = newMembershipPayoutDate,
                RedeemGiftPack = membership.RedeemRenewalGiftPack,
                ActivationCode = membership.RenewalGiftPackActivationCode,

                IsRenewal = true,
                PatronMembership = isPatron,

                Giftaidoverride = newMembershipgiftAidOverride,
                Giftaidoverrideuser = newMembershipgiftAidOverride ? membership.Giftaidoverrideuser : null,
                Giftaidoverridedate = newMembershipgiftAidOverride ? membership.Giftaidoverridedate : null,

                Statuscode = MembershipStatus.Active_Prospect
            };
            membershipToCreate.IsMembershipForSomeone = membershipToCreate.Contact?.Id != membershipToCreate.PayerV2?.Id;
            if (membershipToCreate.IsMembershipForSomeone == true && membershipToCreate.IsRenewal == true)
                membershipToCreate.IsthisMembershipaoneyeargift = false;
            if (membership.RenewalsMembershipProduct.Name.Contains("Joint"))
                membershipToCreate.Member2 = membership.RenewalMember2 != null ? membership.RenewalMember2 : membership.Member2;
            if (membershipToCreate.ActivationCode != null)
            {
                var giftPacksToRedeem = _giftPackRepository.GetAll().Where(gp => gp.GiftPackCode == membershipToCreate.ActivationCode).FirstOrDefault();
                membershipToCreate.GiftPack = giftPacksToRedeem != null ? giftPacksToRedeem.ToEntityReference() : null;
            }

            _logger.TraceInformation($"Creating new membership for renewal.");
            var createdMembership = _membershipRepository.Create(membershipToCreate);

            _logger.TraceInformation($"Ending business logic.");
            return createdMembership;
        }
    }
}