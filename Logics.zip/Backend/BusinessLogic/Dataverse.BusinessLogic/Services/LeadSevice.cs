﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk.Query;
using System.Globalization;
using System.Linq;
using System.Web.Security;


namespace Cultivate.BusinessLogic.Services
{
    public interface ILeadService
    {
        void ValidateLastName(Entity entity, ITracingService tracingService);
    }

    public class LeadService : ILeadService
    {
        private ILogger _logger;

        public LeadService(ILogger logger)
        {
            _logger = logger;
        }

        public void ValidateLastName(Entity entity, ITracingService tracingService)
        {
            if (entity.Contains("lastname"))
            {
                string lastName = entity["lastname"] as string;

                // Allow blank or null last names
                if (string.IsNullOrWhiteSpace(lastName))
                {
                    tracingService.Trace("Last name is blank or null. Skipping validation.");
                    return;
                }

                tracingService.Trace($"Validating last name: {lastName}");
                if (!IsValidLastName(lastName))
                {
                    tracingService.Trace($"Invalid last name detected: {lastName}");
                    throw new InvalidPluginExecutionException("The last name contains invalid characters. Only letters, accents, spaces, apostrophes, and dashes are allowed.");
                }
                tracingService.Trace("Last name validation passed.");
            }
        }

        private bool IsValidLastName(string lastName)
        {
            // Regex pattern to allow letters, accented characters, spaces, apostrophes, and dashes
            string pattern = @"^[a-zA-ZáéíóúÁÉÍÓÚàèìòùÀÈÌÒÙäëïöüÄËÏÖÜñÑ' -]+$";
            Regex regex = new Regex(pattern);
            return regex.IsMatch(lastName);
        }
    }
}
