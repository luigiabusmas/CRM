﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Extensions;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface ISubscriptionService
    {
        Entity SetSubscriptionOrderNumberOnSubscriptionEntity(Entity target);
        bool ValidateIfPaymentFieldsNeedToBeRepopulated(Entity preImage, Entity postImage);
        void ValidateCampaignInSubscriptionEntity(Entity entity);
        Entity SetPriceListOnSubscriptionEntity(Entity target, Entity entity);
        Entity SetCampaignAmountOnSubscriptionEntity(Entity target, Entity entity);
        Entity SetSubscriptionPriceOnSubscriptionEntity(Entity target, Entity entity);
        Entity SetPostChargeOnSubscriptionEntity(Entity target, Entity postImage);
        Entity SetTotalAmountOnSubscriptionEntity(Entity target, Entity entity);
        bool ValidateIfRenewalPaymentFieldsNeedToBeRepopulated(Entity preImage, Entity postImage);
        void ValidateRenewalCampaignInSubscriptionEntity(Entity entity);
        Entity SetRenewalPriceListOnSubscriptionEntity(Entity target, Entity entity);
        Entity SetRenewalSubscriptionPriceOnSubscriptionEntity(Entity target, Entity postImage);
        Entity SetRenewalTotalAmountOnSubscriptionEntity(Entity target, Entity postImage);
        Entity SetRenewalPostChargeOnSubscriptionEntity(Entity target, Entity postImage);
        bool ValidateIfDDSubscriptionWasCancelled(Entity entity);
        bool ValidateIfPaymentSubmissionWasTriggered(Entity preImage, Entity postImage);
        bool ValidateIfActivatedWithoutStartDate(Entity preImage, Entity postImage);
        Entity PopulateSubscriptionDates(Entity target, Entity postImage);
        Entity GetMembershipDetails(Guid membershipId);
        string GetConfigurationByName(string configurationName);
        Entity GetCampaignByName(string campaignName);
        Entity GetProductByName(string productName);
        Guid CreateInitialSubscription(Entity membershipEntity, bool isPatronFellow);
        void UpdateTransaction(Guid? transactionId, Guid? subscriptionId);
        void ActivateSubscription(Guid? subscriptionId, bool isPatronFellow);
        void ProcessFreePayment(Guid subscriptionId, EntityReference payer);
        void ValidateSubscriptionSetRenewalMHStatus(Entity subscription);
        bool ValidateIfRenewalsPayoutDateShouldBeRecalculated(Entity preImage, Entity postImage);
        Entity SetRenewalsPayoutDate(Entity target, Entity subscription);
    }

    public class SubscriptionService : ISubscriptionService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRepository<Contact> _contactRepository;
        private IRepository<Account> _organisationRepository;
        private IRepository<Country> _countryRepository;
        private IRepository<Campaign> _campaignRepository;
        private IRepository<Paymentdiscountconfiguration> _paymentDiscountConfigurationRepository;
        private IProductService _productService;
        private ICampaignService _campaignService;
        private ICustomAPIInvocationService _customApiInvocationService;
        private ICultivateConfigurationService _cultivateConfigurationService;
        private ISuppressionService _suppressionService;
        private IRecordDateCalculationService _recordDateCalculationService;

        private const string subscriptionNumberLogicalName = "rhs_number";
        private const string subscriptionCampaignLogicalName = "rhs_campaigncode";
        private const string subscriptionProductLogicalName = "rhs_subscriptionproduct";
        private const string subscriptionRecipientLogicalName = "rhs_recipient";
        private const string subscriptionPayerLogicalName = "rhs_subscriptionpayer";
        private const string subscriptionPriceListLogicalName = "rhs_pricelist";
        private const string subscriptionPriceLogicalName = "rhs_subscriptionprice";
        private const string subscriptionPostalChargeLogicalName = "rhs_postalcharges";
        private const string subscriptionCampaignAmountLogicalName = "rhs_campaignamount";
        private const string subscriptionTotalAmountLogicalName = "rhs_totalamount";
        private const string subscriptionPaymentMethodLogicalName = "rhs_paymentmethodcode";
        private const string subscriptionPaymentFrequencyLogicalName = "rhs_billingfrequency";
        private const string subscriptionPayoutDateLogicalName = "rhs_paymentschedule";
        private const string subscriptionStartDateLogicalName = "rhs_startdate";
        private const string subscriptionEndDateLogicalName = "rhs_enddate";
        private const string subscriptionSubmitPaymentLogicalName = "rhs_ispaymentsubmitted";
        private const string subscriptionRenewalsCampaignLogicalName = "rhs_renewalscampaign";
        private const string subscriptionRenewalsProductLogicalName = "rhs_renewalssubscriptionproduct";
        private const string subscriptionRenewalsPayerLogicalName = "rhs_renewalspayer";
        private const string subscriptionInRenewalStageLogicalName = "rhs_inrenewalsstage";
        private const string subscriptionRenewalStatusLogicalName = "rhs_renewalsstatus";
        private const string subscriptionRenewalPriceListLogicalName = "rhs_renewalssubscriptionprice";
        private const string subscriptionRenewalPriceLogicalName = "rhs_renewalssubscriptionpricevalue";
        private const string subscriptionRenewalPostalChargeLogicalName = "rhs_renewalpostalcharge";
        private const string subscriptionRenewalsTotalAmountLogicalName = "rhs_renewalstotalamount";
        private const string subscriptionRenewalsPaymentMethodLogicalName = "rhs_renewalspaymentmethodcode";
        private const string subscriptionRenewalsPaymentFrequencyLogicalName = "rhs_renewalbillingfrequency";
        private const string subscriptionRenewalPayoutDateLogicalName = "rhs_renewalpaymentschedule";
        private const string subscriptionRenewalsStartDateLogicalName = "rhs_renewalsstartdate";
        private const string subscriptionRenewalsEndDateLogicalName = "rhs_renewalsenddate";
        private const string subscriptionCancelSubscriptionLogicalName = "rhs_cancelsubscription";
        private const string subscriptionCancellationTypeLogicalName = "rhs_subscriptioncancellationtype";
        private const string subscriptionCancellationReasonLogicalName = "rhs_cancellationreason";
        private const string subscriptionStatusLogicalName = "statecode";
        private const string subscriptionStatusReasonLogicalName = "statuscode";
        private const string subscriptionRenewalNotifcationMHStatus = "rhs_renewalnotificationmhstatus";
        private const string freeSubscriptionLogicalName = "rhs_freesubscription";


        public SubscriptionService(ILogger logger, IOrganizationService service,
            IRepository<Contact> contactRepository, IRepository<Account> organisationRepository, IRepository<Country> countryRepository, IRepository<Campaign> campaignRepository, IRepository<Paymentdiscountconfiguration> paymentDiscountConfigurationRepository,
            IProductService productService, ICampaignService campaignService, ICustomAPIInvocationService customApiInvocationService, ICultivateConfigurationService cultivateConfigurationService, ISuppressionService suppressionService,
            IRecordDateCalculationService recordDateCalculationService)
        {
            _logger = logger;
            _service = service;
            _contactRepository = contactRepository;
            _organisationRepository = organisationRepository;
            _countryRepository = countryRepository;
            _campaignRepository = campaignRepository;
            _paymentDiscountConfigurationRepository = paymentDiscountConfigurationRepository;
            _productService = productService;
            _campaignService = campaignService;
            _customApiInvocationService = customApiInvocationService;
            _cultivateConfigurationService = cultivateConfigurationService;
            _suppressionService = suppressionService;
            _recordDateCalculationService = recordDateCalculationService;
        }

        public Entity SetSubscriptionOrderNumberOnSubscriptionEntity(Entity target)
        {
            _logger.TraceInformation($"Starting business logic.");

            var random = new Random();
            var subscriptionOrderNumber = "PR" + random.Next(9) + random.Next(9) + random.Next(9) + random.Next(9) + random.Next(9) + random.Next(9);
            _logger.TraceInformation($"Subscription Order Number = {subscriptionOrderNumber}.");

            target[subscriptionNumberLogicalName] = subscriptionOrderNumber;

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public bool ValidateIfPaymentSubmissionWasTriggered(Entity preImage, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var isTriggered = preImage.GetAttributeValue<bool?>(subscriptionSubmitPaymentLogicalName) != true && postImage.GetAttributeValue<bool?>(subscriptionSubmitPaymentLogicalName) == true;
            _logger.TraceInformation($"Is submit payment triggered? {isTriggered}.");


            _logger.TraceInformation($"Ending business logic.");
            return isTriggered;
        }

        public bool ValidateIfActivatedWithoutStartDate(Entity preImage, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var isActivatedWithoutStartDate = preImage.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName)?.Value != 1/*Active*/ && 
                postImage.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName)?.Value == 1/*Active*/ &&
                postImage.GetAttributeValue<DateTime?>(subscriptionStartDateLogicalName) == null;
            _logger.TraceInformation($"Is activated without start date? {isActivatedWithoutStartDate}");

            _logger.TraceInformation($"Ending business logic.");
            return isActivatedWithoutStartDate;
        }

        public Entity PopulateSubscriptionDates(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            int? paymentMethod = postImage.GetAttributeValue<OptionSetValue>(subscriptionPaymentMethodLogicalName)?.Value;
            _logger.TraceInformation($"Payment Method (Code) = {paymentMethod}.");

            bool isFreeSubscription = postImage.GetAttributeValue<bool>(freeSubscriptionLogicalName);
            _logger.TraceInformation($"is Free Subscription = {isFreeSubscription}.");

            DateTime today = DateTime.UtcNow.Date;
            DateTime startDate = new DateTime();
            DateTime rangeEndDate = new DateTime();
            string currentYear = DateTime.Now.Year.ToString();
            int yearEndDate = 0;
            int period = 0;

            var subscriptionConfigurationCollection = RetrieveSubscriptionConfiguration(today, currentYear);
            foreach (var subscriptionConfiguration in subscriptionConfigurationCollection)
            {
                period = ((OptionSetValue)subscriptionConfiguration["rhs_period"]).Value;
                rangeEndDate = (DateTime)subscriptionConfiguration["rhs_rangeenddate"];
                yearEndDate = rangeEndDate.Year;
            }
            switch (period)
            {
                //Period 1, set to 1st February in same year as the Range End Date
                case 120000000:
                    startDate = new DateTime(yearEndDate, 2, 1, 0, 0, 0);
                    break;
                //Period 2, set to 1st May in same year as the Range End Date    
                case 120000001:
                    startDate = new DateTime(yearEndDate, 5, 1, 0, 0, 0);
                    break;
                //Period 3, set to 1st August in same year as the Range End Date
                case 120000002:
                    startDate = new DateTime(yearEndDate, 8, 1, 0, 0, 0);
                    break;
                //Period 4, set to 1st November in same year as the Range End Date
                case 120000003:
                    startDate = new DateTime(yearEndDate, 11, 1, 0, 0, 0);
                    break;
            }

            if (isFreeSubscription)
            {
                DateTime endDate = GetNextMarchEndDate(startDate);
                postImage["rhs_enddate"] = endDate;
            }
            else
            {
                postImage["rhs_enddate"] = startDate.AddDays(364);
            }

            postImage["rhs_startdate"] = startDate;
            //postImage["rhs_enddate"] = startDate.AddDays(364);
            postImage["rhs_renewalsstartdate"] = (startDate.AddDays(364)).AddMonths(-2);
            postImage["rhs_renewalsenddate"] = startDate.AddDays(364);

            target["rhs_startdate"] = postImage["rhs_startdate"];
            target["rhs_enddate"] = postImage["rhs_enddate"];
            target["rhs_renewalsstartdate"] = postImage["rhs_renewalsstartdate"];
            target["rhs_renewalsenddate"] = postImage["rhs_renewalsenddate"];

            if (paymentMethod == (int?)PaymentMethodType_GlobalOptionSet.DirectDebit)
                target["rhs_paymentschedule"] = _recordDateCalculationService.CalculatePayoutDate(startDate);

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        private DateTime GetNextMarchEndDate(DateTime startDate)
        {
            int year = startDate.Month > 3 ? startDate.Year + 1 : startDate.Year;
            return new DateTime(year, 3, 31);
        }

        public List<Entity> RetrieveSubscriptionConfiguration(DateTime today, string currentYear)
        {
            _logger.TraceInformation("Retrieving Subscription Configuration records");
            var query = new QueryExpression("rhs_subscriptionconfiguration");
            query.ColumnSet.AddColumns("rhs_rangestartdate", "rhs_rangeenddate", "rhs_period", "rhs_year");
            var query_AND = new FilterExpression(LogicalOperator.And);
            query.Criteria.AddFilter(query_AND);
            query_AND.AddCondition("rhs_rangestartdate", ConditionOperator.LessEqual, today);
            query_AND.AddCondition("rhs_rangeenddate", ConditionOperator.GreaterEqual, today);
            //query_AND.AddCondition("rhs_year", ConditionOperator.Equal, currentYear); // condition not required on Task 63112
            var subscriptionConfigurationCollection = _service.RetrieveMultiple(query).Entities.ToList();

            if (subscriptionConfigurationCollection.Count == 0)
                throw new InvalidPluginExecutionException($"No Subscription Configuration records found");

            return subscriptionConfigurationCollection;
        }
        public bool ValidateIfPaymentFieldsNeedToBeRepopulated(Entity preImage, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            /*
            var isCampaignChanged = preImage.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName)?.Id != postImage.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName)?.Id;
            _logger.TraceInformation($"Campaign changed? {isCampaignChanged}");
            var isProductChanged = preImage.GetAttributeValue<EntityReference>(subscriptionProductLogicalName)?.Id != postImage.GetAttributeValue<EntityReference>(subscriptionProductLogicalName)?.Id;
            _logger.TraceInformation($"Product changed? {isProductChanged}");
            */

            var statusValue = postImage.GetAttributeValue<OptionSetValue>(subscriptionStatusLogicalName)?.Value;
            _logger.TraceInformation($"Status = {statusValue}.");

            var statusReasonValue = postImage.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName)?.Value;
            _logger.TraceInformation($"Status reason = {statusReasonValue}.");

            var isPaymentFieldsNeedToBeRepopulated = statusValue == 0 && (statusReasonValue == 120000001 || statusReasonValue == 120000003);
            _logger.TraceInformation($"Repopulate payment fields? {isPaymentFieldsNeedToBeRepopulated}");

            _logger.TraceInformation($"Ending business logic.");
            return isPaymentFieldsNeedToBeRepopulated;
        }

        public void ValidateCampaignInSubscriptionEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var subscriptionCampaignReference = entity.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName);
            if (subscriptionCampaignReference != null)
            {
                _logger.TraceInformation($"Campaign selected for subscription.");
                var subscriptionCampaign = _campaignRepository.GetById(subscriptionCampaignReference.Id);
                var subscriptionProductReference = entity.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);

                _logger.TraceInformation($"Validating if the campaign is active.");
                if (subscriptionCampaign.StateCode != CampaignState.Active)
                    throw new InvalidPluginExecutionException("Please enter a valid Campaign Code!");

                _logger.TraceInformation($"Validating if the campaign is valid for selected product.");
                var campaignProductIds = _campaignService.RetrieveCampaignProductIds(subscriptionCampaign.Id);
                if (subscriptionProductReference == null || !campaignProductIds.Any(id => id == subscriptionProductReference.Id))
                    throw new InvalidPluginExecutionException("Entered Campaign Code is not valid for selected Subscription Product. Please select correct Campaign Code!");
            }
            else
                _logger.TraceInformation($"No campaign selected for subscription.");

            _logger.TraceInformation($"Ending business logic.");
        }

        public Entity SetPriceListOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving subscription recipient and payer.");
            var subscriptionRecipient = postImage.GetAttributeValue<EntityReference>("rhs_recipient");
            var subscriptionPayer = postImage.GetAttributeValue<EntityReference>("rhs_subscriptionpayer");
            _logger.TraceInformation($"Subscription recipient id = {subscriptionRecipient}. Subscription payer id = {subscriptionPayer}.");

            _logger.TraceInformation($"Checking if recipient or payer is a member or payer of an existing active membership.");
            var query = new QueryExpression("rhs_membership");
            query.ColumnSet.AddColumns("rhs_contact", "rhs_member2", "rhs_payerv2", "statecode", "statuscode");
            query.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 1);
            var query_Or = new FilterExpression(LogicalOperator.Or);
            query.Criteria.AddFilter(query_Or);
            query_Or.AddCondition("rhs_contact", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_contact", ConditionOperator.Equal, subscriptionPayer.Id);
            query_Or.AddCondition("rhs_member2", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_member2", ConditionOperator.Equal, subscriptionPayer.Id);
            query_Or.AddCondition("rhs_payerv2", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_payerv2", ConditionOperator.Equal, subscriptionPayer.Id);

            var memberships = _service.RetrieveMultiple(query).Entities;
            var membershipCount = memberships.ToList().Count;

            postImage[subscriptionPriceListLogicalName] = _productService.GetPlantProductPriceList(membershipCount == 0);
            target[subscriptionPriceListLogicalName] = postImage[subscriptionPriceListLogicalName];

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetCampaignAmountOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var campaignReference = postImage.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName);
            if (campaignReference != null)
            {
                var campaign = _campaignRepository.GetById(campaignReference.Id);
                var productReference = postImage.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);

                if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _logger.TraceInformation($"Setting campaign amount because price based campaign exists on subscription.");
                    postImage[subscriptionCampaignAmountLogicalName] = _productService.GetCampaignProductPrice(productReference.Id, campaign.Id);
                    target[subscriptionCampaignAmountLogicalName] = postImage[subscriptionCampaignAmountLogicalName];
                }
                else
                {
                    postImage[subscriptionCampaignAmountLogicalName] = null;
                    target[subscriptionCampaignAmountLogicalName] = postImage[subscriptionCampaignAmountLogicalName];
                    _logger.TraceInformation($"Setting campaign amount to NULL because price-based campaign was not selected or unselected on subscription.");
                }
            }
            else
            {
                postImage[subscriptionCampaignAmountLogicalName] = null;
                target[subscriptionCampaignAmountLogicalName] = postImage[subscriptionCampaignAmountLogicalName];
                _logger.TraceInformation($"Setting campaign amount to NULL because price-based campaign was not selected or unselected on membership.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetSubscriptionPriceOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var productReference = postImage.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);
            var priceListReference = postImage.GetAttributeValue<EntityReference>(subscriptionPriceListLogicalName);

            postImage[subscriptionPriceLogicalName] = _productService.GetProductPrice(productReference.Id, priceListReference.Id);
            target[subscriptionPriceLogicalName] = postImage[subscriptionPriceLogicalName];

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetTotalAmountOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");
            Money totalAmount = null;

            var campaignReference = postImage.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName);
            if (campaignReference == null)
            {
                _logger.TraceInformation($"Setting total amount to the product price.");
                totalAmount = GetSubscriptionPrice(postImage);
            }
            else
            {
                var campaign = _campaignRepository.GetById(campaignReference.Id);

                if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _logger.TraceInformation($"Price based campaign exists. Setting total amount to the campaign product price.");
                    totalAmount = GetDiscountedPrice(postImage);
                }
            }

            var postalCharge = postImage.GetAttributeValue<Money>(subscriptionPostalChargeLogicalName);
            if (postalCharge != null)
            {
                _logger.TraceInformation($"Postal charge exists. Adding it to the total amount.");
                totalAmount = new Money(totalAmount.Value + postalCharge.Value);
            }


            //var paymentMethod = postImage.GetAttributeValue<OptionSetValue>("rhs_paymentmethod");
            //if (paymentMethod != null && paymentMethod.Value == (int)Msnfp_paymentmethodtype_GlobalOptionSet.PWAC)
            //{
            //    _logger.TraceInformation($"Payment method is PWAC. Setting total amount to 0.");
            //    totalAmount = new Money(0);
            //}

            _logger.TraceInformation($"Ending business logic.");
            postImage[subscriptionTotalAmountLogicalName] = totalAmount;
            target[subscriptionTotalAmountLogicalName] = postImage[subscriptionTotalAmountLogicalName];
            return target;
        }

        private Money GetSubscriptionPrice(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var product = entity.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);
            var priceList = entity.GetAttributeValue<EntityReference>(subscriptionPriceListLogicalName);
            var subscriptionPrice = entity.GetAttributeValue<Money>(subscriptionPriceLogicalName);

            var price = _productService.GetProductPrice(product.Id, priceList.Id);

            _logger.TraceInformation($"Ending business logic.");
            return subscriptionPrice;
        }

        private Money GetDiscountedPrice(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var productReference = entity.GetAttributeValue<EntityReference>(subscriptionProductLogicalName);
            var campaignReference = entity.GetAttributeValue<EntityReference>(subscriptionCampaignLogicalName);
            var campaignAmount = entity.GetAttributeValue<Money>(subscriptionCampaignAmountLogicalName);
            var paymentMethodOptionSetValue = entity.GetAttributeValue<OptionSetValue>(subscriptionPaymentMethodLogicalName);
            var paymentMethodEnum = paymentMethodOptionSetValue != null ? (PaymentMethodType_GlobalOptionSet?)paymentMethodOptionSetValue.Value : null;
            var paymentFrequencyOptionSetValue = entity.GetAttributeValue<OptionSetValue>(subscriptionPaymentFrequencyLogicalName);
            var paymentFrequencyEnum = paymentFrequencyOptionSetValue != null ? (PaymentFrequency_GlobalOptionSet?)paymentFrequencyOptionSetValue.Value : null;

            _logger.TraceInformation($"Setting discounted price to campaign price.");
            var campaign = _campaignRepository.GetById(campaignReference.Id);
            campaignAmount = campaignAmount != null ? new Money(campaignAmount.Value) : _productService.GetCampaignProductPrice(productReference.Id, campaign.Id);
            var discountedPrice = new Money(campaignAmount.Value);
            _logger.TraceInformation($"Set discounted price to {discountedPrice.Value}.");

            if (campaign.Paymentdiscountconfiguration != null)
            {
                var paymentDiscountConfiguration = _paymentDiscountConfigurationRepository.GetById(campaign.Paymentdiscountconfiguration.Id);
                if (paymentMethodEnum == paymentDiscountConfiguration.PaymentMethodCode &&
                    (paymentMethodEnum != PaymentMethodType_GlobalOptionSet.DirectDebit || paymentFrequencyEnum == PaymentFrequency_GlobalOptionSet.Annually))
                {
                    _logger.TraceInformation($"Payment discount configuration detected and it's payment method matches the membership payment method. Further discounts will be done to the discounted price.");

                    var subscriptionPrice = new Money(GetSubscriptionPrice(entity).Value);

                    if (paymentDiscountConfiguration.DiscountPercentage != null)
                    {
                        _logger.TraceInformation($"Discount percentage detected.");
                        _logger.TraceInformation($"New Discounted Price = {discountedPrice.Value} - ({paymentDiscountConfiguration.DiscountPercentage}% of {subscriptionPrice.Value}).");
                        discountedPrice.Value -= ((decimal)paymentDiscountConfiguration.DiscountPercentage / 100) * subscriptionPrice.Value;
                        _logger.TraceInformation($"New Discounted Price = {discountedPrice.Value}.");
                    }
                    if (paymentDiscountConfiguration.DiscountAmount != null)
                    {
                        _logger.TraceInformation($"Discount amount detected.");
                        _logger.TraceInformation($"New Discounted Price = {discountedPrice.Value} - {paymentDiscountConfiguration.DiscountAmount.Value}.");
                        discountedPrice.Value -= paymentDiscountConfiguration.DiscountAmount.Value;
                    }
                }
            }

            _logger.TraceInformation($"Ending business logic.");
            return discountedPrice;
        }

        private Money GetRenewalsSubscriptionPrice(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var renewalProduct = entity.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName);
            var renewalPriceList = entity.GetAttributeValue<EntityReference>(subscriptionRenewalPriceListLogicalName);
            var renewalSubscriptionPrice = entity.GetAttributeValue<Money>(subscriptionRenewalPriceLogicalName);

            var price = _productService.GetProductPrice(renewalProduct.Id, renewalPriceList.Id);

            _logger.TraceInformation($"Ending business logic.");
            return renewalSubscriptionPrice;
        }

        private Money GetRenewalsDiscountedPrice(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var renewalProductReference = entity.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName);
            var renewalCampaignReference = entity.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName);
            var renewalPaymentMethodOptionSetValue = entity.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName);
            var renewalPaymentMethodEnum = renewalPaymentMethodOptionSetValue != null ? (PaymentMethodType_GlobalOptionSet?)renewalPaymentMethodOptionSetValue.Value : null;
            var renewalPaymentFrequencyOptionSetValue = entity.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentFrequencyLogicalName);
            var renewalPaymentFrequencyEnum = renewalPaymentFrequencyOptionSetValue != null ? (PaymentFrequency_GlobalOptionSet?)renewalPaymentFrequencyOptionSetValue.Value : null;

            _logger.TraceInformation($"Setting discounted price to campaign price.");
            var renewalCampaign = _campaignRepository.GetById(renewalCampaignReference.Id);
            var renewalCampaignAmount = _productService.GetCampaignProductPrice(renewalProductReference.Id, renewalCampaign.Id);
            var renewalDiscountedPrice = new Money(renewalCampaignAmount.Value);
            _logger.TraceInformation($"Set discounted price to {renewalDiscountedPrice.Value}.");

            if (renewalCampaign.Paymentdiscountconfiguration != null)
            {
                var paymentDiscountConfiguration = _paymentDiscountConfigurationRepository.GetById(renewalCampaign.Paymentdiscountconfiguration.Id);
                if (renewalPaymentMethodEnum == paymentDiscountConfiguration.PaymentMethodCode &&
                    (renewalPaymentMethodEnum != PaymentMethodType_GlobalOptionSet.DirectDebit || renewalPaymentFrequencyEnum == PaymentFrequency_GlobalOptionSet.Annually))
                {
                    _logger.TraceInformation($"Payment discount configuration detected and it's payment method matches the membership payment method. Further discounts will be done to the discounted price.");

                    var subscriptionPrice = new Money(GetSubscriptionPrice(entity).Value);

                    if (paymentDiscountConfiguration.DiscountPercentage != null)
                    {
                        _logger.TraceInformation($"Discount percentage detected.");
                        _logger.TraceInformation($"New Discounted Price = {renewalDiscountedPrice.Value} - ({paymentDiscountConfiguration.DiscountPercentage}% of {subscriptionPrice.Value}).");
                        renewalDiscountedPrice.Value -= ((decimal)paymentDiscountConfiguration.DiscountPercentage / 100) * subscriptionPrice.Value;
                        _logger.TraceInformation($"New Discounted Price = {renewalDiscountedPrice.Value}.");
                    }
                    if (paymentDiscountConfiguration.DiscountAmount != null)
                    {
                        _logger.TraceInformation($"Discount amount detected.");
                        _logger.TraceInformation($"New Discounted Price = {renewalDiscountedPrice.Value} - {paymentDiscountConfiguration.DiscountAmount.Value}.");
                        renewalDiscountedPrice.Value -= paymentDiscountConfiguration.DiscountAmount.Value;
                    }
                }
            }

            _logger.TraceInformation($"Ending business logic.");
            return renewalDiscountedPrice;
        }

        public bool ValidateIfRenewalPaymentFieldsNeedToBeRepopulated(Entity preImage, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var isRenewalCampaignChanged = preImage.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName)?.Id != postImage.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName)?.Id;
            _logger.TraceInformation($"Renewal campaign changed? {isRenewalCampaignChanged}");

            var isRenewalProdcutChanged = preImage.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName)?.Id != postImage.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName)?.Id;
            _logger.TraceInformation($"Renewal product changed? {isRenewalProdcutChanged}");

            var isRenewalPaymentMethodChanged = preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName)?.Value != postImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName)?.Value;
            _logger.TraceInformation($"Renewal payment method changed? {isRenewalPaymentMethodChanged}");

            var isRenewalPaymentFrequencyChanged = preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentFrequencyLogicalName)?.Value != postImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentFrequencyLogicalName)?.Value;
            _logger.TraceInformation($"Renewal payment frequency changed? {isRenewalPaymentFrequencyChanged}");

            var inRenewalStage = postImage.GetAttributeValue<bool?>(subscriptionInRenewalStageLogicalName);
            _logger.TraceInformation($"In Renewal Stage? = {inRenewalStage}.");

            var renewalStatusValue = postImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalStatusLogicalName)?.Value;
            _logger.TraceInformation($"Renewal status = {renewalStatusValue}.");

            var statusValue = postImage.GetAttributeValue<OptionSetValue>(subscriptionStatusLogicalName)?.Value;
            _logger.TraceInformation($"Status = {statusValue}.");

            var isRenewalPriceFieldsNeedToBeRepopulated = (inRenewalStage == true && statusValue == 0 && renewalStatusValue == 120000000) &&
                (isRenewalCampaignChanged || isRenewalProdcutChanged || isRenewalPaymentMethodChanged || isRenewalPaymentFrequencyChanged);
            _logger.TraceInformation($"Repopulate renewal payment fields? {isRenewalPriceFieldsNeedToBeRepopulated}");

            _logger.TraceInformation($"Ending business logic.");
            return isRenewalPriceFieldsNeedToBeRepopulated;
        }

        public void ValidateRenewalCampaignInSubscriptionEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var subscriptionRenewalCampaignReference = entity.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName);
            if (subscriptionRenewalCampaignReference != null)
            {
                _logger.TraceInformation($"Campaign selected for subscription.");
                var subscriptionRenewalCampaign = _campaignRepository.GetById(subscriptionRenewalCampaignReference.Id);
                var subscriptionRenewalProductReference = entity.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName);

                _logger.TraceInformation($"Validating if the renewal campaign is active.");
                if (subscriptionRenewalCampaign.StateCode != CampaignState.Active)
                    throw new InvalidPluginExecutionException("Please enter a valid Campaign Code!");

                _logger.TraceInformation($"Validating if the renewal campaign is valid for selected renewal product.");
                var renewalCampaignProductIds = _campaignService.RetrieveCampaignProductIds(subscriptionRenewalCampaign.Id);
                if (subscriptionRenewalProductReference == null || !renewalCampaignProductIds.Any(id => id == subscriptionRenewalProductReference.Id))
                    throw new InvalidPluginExecutionException("Entered Campaign Code is not valid for selected Subscription Product. Please select correct Campaign Code!");
            }
            else
                _logger.TraceInformation($"No campaign selected for subscription.");

            _logger.TraceInformation($"Ending business logic.");
        }

        public Entity SetRenewalPriceListOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving subscription recipient and payer.");
            var subscriptionRecipient = postImage.GetAttributeValue<EntityReference>("rhs_recipient");
            var subscriptionRenewalsPayer = postImage.GetAttributeValue<EntityReference>("rhs_renewalspayer");
            _logger.TraceInformation($"Subscription recipient id = {subscriptionRecipient}. Subscription payer id = {subscriptionRenewalsPayer}.");

            _logger.TraceInformation($"Checking if recipient or payer is a member or payer of an existing active membership.");
            var query = new QueryExpression("rhs_membership");
            query.ColumnSet.AddColumns("rhs_contact", "rhs_member2", "rhs_renewalspayer", "statecode", "statuscode");
            query.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 1);
            var query_Or = new FilterExpression(LogicalOperator.Or);
            query.Criteria.AddFilter(query_Or);
            query_Or.AddCondition("rhs_contact", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_contact", ConditionOperator.Equal, subscriptionRenewalsPayer.Id);
            query_Or.AddCondition("rhs_member2", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_member2", ConditionOperator.Equal, subscriptionRenewalsPayer.Id);
            query_Or.AddCondition("rhs_renewalspayer", ConditionOperator.Equal, subscriptionRecipient.Id);
            query_Or.AddCondition("rhs_renewalspayer", ConditionOperator.Equal, subscriptionRenewalsPayer.Id);

            var memberships = _service.RetrieveMultiple(query).Entities;
            var membershipCount = memberships.ToList().Count;

            postImage[subscriptionRenewalPriceListLogicalName] = _productService.GetPlantProductPriceList(membershipCount == 0, true);
            target[subscriptionRenewalPriceListLogicalName] = postImage[subscriptionRenewalPriceListLogicalName];

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetRenewalSubscriptionPriceOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var renewalProductReference = postImage.GetAttributeValue<EntityReference>(subscriptionRenewalsProductLogicalName);
            var renewalPriceListReference = postImage.GetAttributeValue<EntityReference>(subscriptionRenewalPriceListLogicalName);

            postImage[subscriptionRenewalPriceLogicalName] = _productService.GetProductPrice(renewalProductReference.Id, renewalPriceListReference.Id);
            target[subscriptionRenewalPriceLogicalName] = postImage[subscriptionRenewalPriceLogicalName];

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetPostChargeOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var recipientReference = postImage.GetAttributeValue<EntityReference>(subscriptionRecipientLogicalName);
            var recipient = _service.Retrieve(recipientReference.LogicalName, recipientReference.Id, new ColumnSet("address1_country"));
            var recipientAddressCountry = recipient.GetAttributeValue<string>("address1_country");

            if (string.IsNullOrEmpty(recipientAddressCountry))
            {
                postImage[subscriptionPostalChargeLogicalName] = new Money(0);
                target[subscriptionPostalChargeLogicalName] = new Money(0);
            }
            else
            {
                var countries = _countryRepository.GetAll().Where(country => country.Name.Contains(recipientAddressCountry)).ToList();
                var recipientCountry = countries.Count > 0 ? countries.First() : null;
                postImage[subscriptionPostalChargeLogicalName] = recipientCountry != null ? recipientCountry.PostalCharges : new Money(0);
                target[subscriptionPostalChargeLogicalName] = postImage[subscriptionPostalChargeLogicalName];
            }

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public Entity SetRenewalTotalAmountOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");
            Money renewalTotalAmount = null;

            var renewalCampaignReference = postImage.GetAttributeValue<EntityReference>(subscriptionRenewalsCampaignLogicalName);
            if (renewalCampaignReference == null)
            {
                _logger.TraceInformation($"Setting total amount to the product price.");
                renewalTotalAmount = GetRenewalsSubscriptionPrice(postImage);
            }
            else
            {
                var renewalsCampaign = _campaignRepository.GetById(renewalCampaignReference.Id);

                if (renewalsCampaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _logger.TraceInformation($"Price based campaign exists. Setting total amount to the campaign product price.");
                    renewalTotalAmount = GetRenewalsDiscountedPrice(postImage);
                }
            }

            var renewalPostalCharge = postImage.GetAttributeValue<Money>(subscriptionRenewalPostalChargeLogicalName);
            if (renewalPostalCharge != null)
            {
                _logger.TraceInformation($"Renewal postal charge exists. Adding it to the renewal total amount.");
                renewalTotalAmount = new Money(renewalTotalAmount.Value + renewalPostalCharge.Value);
            }


            //var paymentMethod = postImage.GetAttributeValue<OptionSetValue>("rhs_paymentmethod");
            //if (paymentMethod != null && paymentMethod.Value == (int)Msnfp_paymentmethodtype_GlobalOptionSet.PWAC)
            //{
            //    _logger.TraceInformation($"Payment method is PWAC. Setting total amount to 0.");
            //    renewalTotalAmount = new Money(0);
            //}

            _logger.TraceInformation($"Ending business logic.");
            postImage[subscriptionRenewalsTotalAmountLogicalName] = renewalTotalAmount;
            target[subscriptionRenewalsTotalAmountLogicalName] = postImage[subscriptionRenewalsTotalAmountLogicalName];
            return target;
        }

        public Entity SetRenewalPostChargeOnSubscriptionEntity(Entity target, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic.");

            var recipientReference =
                postImage.GetAttributeValue<EntityReference>(subscriptionRecipientLogicalName);

            string recipientCountry = null;

            if (recipientReference.LogicalName == "contact")
            {
                var recipientContact = _contactRepository.GetById(recipientReference.Id);
                recipientCountry = recipientContact?.Address1_Country;
            }
            else if (recipientReference.LogicalName == "account")
            {
                var recipientAccount = _organisationRepository.GetById(recipientReference.Id);
                recipientCountry = recipientAccount?.Address1_Country;
            }

            if (string.IsNullOrEmpty(recipientCountry))
            {
                postImage[subscriptionRenewalPostalChargeLogicalName] = new Money(0);
                target[subscriptionRenewalPostalChargeLogicalName] = new Money(0);
            }
            else
            {
                var countries = _countryRepository.GetAll().Where(country => country.Name.Contains(recipientCountry)).ToList();
                var recipientCountryRecord = countries.Count > 0 ? countries.First() : null;
                postImage[subscriptionRenewalPostalChargeLogicalName] = recipientCountryRecord != null ? recipientCountryRecord.PostalCharges : new Money(0);
                target[subscriptionRenewalPostalChargeLogicalName] = postImage[subscriptionRenewalPostalChargeLogicalName];
            }

            _logger.TraceInformation($"Ending business logic.");
            return target;
        }

        public bool ValidateIfDDSubscriptionWasCancelled(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var paymentMethod = entity.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode");
            var status = entity.GetAttributeValue<OptionSetValue>("statecode");
            var statusReason = entity.GetAttributeValue<OptionSetValue>("statuscode");
            var cancellationType = entity.GetAttributeValue<OptionSetValue>("rhs_subscriptioncancellationtype");

            var isPaymentMethodDD = paymentMethod?.Value == 120000002/*Direct Debit*/;
            _logger.TraceInformation($"Is payment method DD? {isPaymentMethodDD}");

            var isMembershipCancelled = status?.Value == 1/*Inactive*/ && statusReason?.Value == 2/*Cancelled*//* && cancellationType?.Value == 120000000*//*Now*/;
            _logger.TraceInformation($"Is membership cancelled? {isMembershipCancelled}");

            _logger.TraceInformation($"Ending business logic.");
            return isMembershipCancelled && isPaymentMethodDD;
        }

        public Entity GetMembershipDetails(Guid membershipId)
        {
            _logger.TraceInformation("Start GetMembershipDetails");
            var result = new Entity();

            try
            {
                result = _service.Retrieve(Membership.EntityLogicalName, membershipId, new ColumnSet(EntityNames.Membership.Contact, EntityNames.Membership.PayerV2, EntityNames.Membership.PaymentMethod, EntityNames.Membership.MembershipProductId));
                _logger.TraceInformation($"Successfully retrieved membership");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error GetMembershipDetails: {0}", ex.Message));
            }

            return result;
        }

        public string GetConfigurationByName(string configurationName)
        {
            _logger.TraceInformation("Start GetConfigurationByName");
            var value = string.Empty;

            try
            {
                var query = new QueryExpression("rhs_cultivateconfigurations");
                query.ColumnSet.AddColumns("rhs_value");
                query.Criteria.AddCondition("rhs_name", ConditionOperator.Equal, configurationName);

                var result = (Cultivateconfigurations)_service.RetrieveMultiple(query).Entities.FirstOrDefault();
                value = result != null ? result.GetAttributeValue<string>("rhs_value") : string.Empty;
                _logger.TraceInformation($"Successfully retrieved configuration: {value}");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error GetConfigurationByName: {0}", ex.Message));
            }

            return value;
        }

        public Entity GetCampaignByName(string campaignName)
        {
            _logger.TraceInformation("Start GetConfigurationByName");
            var result = new Entity();

            try
            {
                var query = new QueryExpression("campaign");
                query.ColumnSet.AddColumns("campaignid");
                query.Criteria.AddCondition("name", ConditionOperator.Equal, campaignName);

                result = (Campaign)_service.RetrieveMultiple(query).Entities.FirstOrDefault();
                _logger.TraceInformation($"Successfully retrieved campaign: {result.Id}");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error GetConfigurationByName: {0}", ex.Message));
            }

            return result;
        }

        public Entity GetProductByName(string productName)
        {
            _logger.TraceInformation("Start GetProductByName");
            var result = new Entity();

            try
            {
                var query = new QueryExpression("product");
                query.ColumnSet.AddColumns("productid");
                query.Criteria.AddCondition("name", ConditionOperator.Equal, productName);

                result = (Product)_service.RetrieveMultiple(query).Entities.FirstOrDefault();
                _logger.TraceInformation($"Retrieved product: {result.Id}");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error GetProductByName: {0}", ex.Message));
            }

            return result;
        }

        public Guid CreateInitialSubscription(Entity membershipEntity, bool isPatronFellow)
        {
            _logger.TraceInformation("Start CreateActiveSubscription");

            var subscriptionId = Guid.Empty;

            try
            {
                //create initial subscription
                Subscription subscription = new Subscription();
                subscription["statuscode"] = new OptionSetValue(120000001); /*New*/
                subscription["rhs_recipient"] = membershipEntity.GetAttributeValue<EntityReference>(EntityNames.Membership.Contact);
                subscription["rhs_subscriptionpayer"] = membershipEntity.GetAttributeValue<EntityReference>(EntityNames.Membership.PayerV2);
                subscription["rhs_paymentmethodcode"] = new OptionSetValue((int)PaymentMethodType_GlobalOptionSet.PWAC);
                subscription["rhs_freesubscription"] = true;

                //retrieve plant review product
                Entity product = GetProductByName("Plant Review");
                subscription["rhs_subscriptionproduct"] = product != null ? product.ToEntityReference(Product.EntityLogicalName) : null;

                //retrieve campaign for patron fellow
                subscription["rhs_campaigncode"] = _cultivateConfigurationService.GetCultivateConfigurationCampaign("FellowPatronFreeSubscription");

                subscriptionId = _service.Create(subscription); //this will trigger SubscriptionCreatePreOpsPlugin to populate other fields
                _logger.TraceInformation($"Created subscription id: {subscriptionId}");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error CreateInitialSubscription: {0}", ex.Message));
            }
            return subscriptionId;
        }

        public void UpdateTransaction(Guid? transactionId, Guid? subscriptionId)
        {
            _logger.TraceInformation("Start UpdateTransaction");

            try
            {
                if (subscriptionId.HasValue && transactionId.HasValue)
                {
                    //populate subscription lookup in transaction
                    Transaction transaction = new Transaction()
                    {
                        TransactionId = transactionId,
                        SubscriptionId = new EntityReference(Subscription.EntityLogicalName, subscriptionId.Value)
                    };
                    _service.Update(transaction);
                    _logger.TraceInformation($"Updated transaction id: {transactionId}");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error UpdateTransaction: {0}", ex.Message));
            }
        }

        public void ActivateSubscription(Guid? subscriptionId, bool isPatronFellow)
        {
            _logger.TraceInformation("Start ActivateSubscription");

            try
            {
                if (subscriptionId.HasValue)
                {
                    Subscription subscription = new Subscription();
                    subscription["rhs_subscriptionid"] = subscriptionId.Value;
                    subscription["statuscode"] = new OptionSetValue(1); /*Active*/

                    //if (isPatronFellow)
                    //{
                    //    subscription["rhs_postalcharges"] = new Money(0);
                    //    subscription["rhs_totalamount"] = new Money(0);
                    //}

                    _service.Update(subscription); //this will trigger SubscriptionUpdatePreOpsPlugin to populate dates
                    _logger.TraceInformation($"Updated subscription id: {subscriptionId}");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error ActivateSubscription: {0}", ex.Message));
            }
        }

        public void ProcessFreePayment(Guid subscriptionId, EntityReference payer)
        {
            _logger.TraceInformation("Start ProcessFreePayment");

            try
            {
                _logger.TraceInformation("Call InvokeSubmitPaymentCustomAPI");
                if (subscriptionId != Guid.Empty && payer != null)
                {
                    var subscription = _service.Retrieve("rhs_subscription", subscriptionId, new ColumnSet("rhs_totalamount"));
                    Money totalAmountMoney = subscription.GetAttributeValue<Money>("rhs_totalamount");
                    var paymentReference = _cultivateConfigurationService.GetCultivateConfigurationValue("PatronFellowsSubscriptionInternalCostCentreCode");

                    var (transactionId, paymentId, paymentSchedulenId) = _customApiInvocationService.InvokeSubmitPaymentCustomAPI(
                        (int?)PaymentMethodType_GlobalOptionSet.PWAC,
                        (int?)NewTransactionType_GlobalOptionSet.Subscriptions,
                        (int?)Typetransaction_GlobalOptionSet.FullPayment,
                        subscriptionId,
                        payer.Id,
                        payer.LogicalName,
                        totalAmountMoney,
                        null,
                        null,
                        null,
                        null,
                        paymentReference
                    );

                    var paymentToUpdate = new Payment()
                    {
                        Id = (Guid)paymentId,
                        Statecode = PaymentState.Inactive,
                        Statuscode = PaymentStatus.Inactive_Paid
                    };
                    _service.Update(paymentToUpdate);
                    _logger.TraceInformation("Set payment to Paid");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error ProcessFreePayment: {0}", ex.Message));
            }

        }

        public void ValidateSubscriptionSetRenewalMHStatus(Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic. Validate Subscription to Set Renewal Status");

            var subscriptionRecipient = postImage.GetAttributeValue<EntityReference>("rhs_recipient");

            var statusReasonValue = postImage.GetAttributeValue<OptionSetValue>(subscriptionStatusReasonLogicalName)?.Value;
            _logger.TraceInformation($"Status reason = {statusReasonValue}.");

            var inRenewalStage = postImage.GetAttributeValue<bool?>(subscriptionInRenewalStageLogicalName) == true;
            _logger.TraceInformation($"Is Renewal? {inRenewalStage}.");

            var isActive = statusReasonValue == 1;
            _logger.TraceInformation($"Is Active? {isActive}.");

            var isDeceased = subscriptionRecipient.LogicalName == EntityNames.Contact.EntityLogicalName && _contactRepository.GetById(subscriptionRecipient.Id).Deceased == true;
            _logger.TraceInformation($"Is Deceased? {isDeceased}.");

            var isContactGoneAway = subscriptionRecipient.LogicalName == EntityNames.Contact.EntityLogicalName && _suppressionService.DoesContactHaveGoneAwaySuppression(subscriptionRecipient.Id);
            _logger.TraceInformation($"Is Suppressed? {isContactGoneAway}.");

            var isFreeSubscription = postImage.GetAttributeValue<bool?>(freeSubscriptionLogicalName) == true;
            _logger.TraceInformation($"Is Free Subscription? {isFreeSubscription}.");

            var isValidForRenewalMHStatus = isActive && !isDeceased && !isFreeSubscription && !isContactGoneAway && inRenewalStage;
            _logger.TraceInformation($"Is Valid for Renewal Status? {isValidForRenewalMHStatus}.");


            if (isValidForRenewalMHStatus)
            {

                Subscription subscription = new Subscription();
                subscription["rhs_subscriptionid"] = postImage.Id;
                subscription["rhs_renewalnotificationmhstatus"] = new OptionSetValue((int)MHStatus_GlobalOptionSet.Pending);

                _service.Update(subscription);
                _logger.TraceInformation($"Updated subscription id: {postImage.Id}");
            }

        }

        public bool ValidateIfRenewalsPayoutDateShouldBeRecalculated(Entity preImage, Entity postImage)
        {
            _logger.TraceInformation($"Starting business logic");

            var shouldRenewalsPayoutDateBeRecalculated =
                postImage[subscriptionEndDateLogicalName] != null &&
                preImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName)?.Value != (postImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName))?.Value &&
                postImage.GetAttributeValue<OptionSetValue>(subscriptionRenewalsPaymentMethodLogicalName)?.Value == (int?)PaymentMethodType_GlobalOptionSet.DirectDebit;
            _logger.TraceInformation($"Should renewals payout date be recalculated? {shouldRenewalsPayoutDateBeRecalculated}.");

            _logger.TraceInformation($"Ending business logic.");
            return shouldRenewalsPayoutDateBeRecalculated;

        }
        public Entity SetRenewalsPayoutDate(Entity target, Entity subscription)
        {
            _logger.TraceInformation($"Starting business logic");
            DateTime? renewalPayoutDate = _recordDateCalculationService.CalculatePayoutDate(((DateTime)subscription.GetAttributeValue<DateTime?>(subscriptionEndDateLogicalName)).AddDays(1));

            _logger.TraceInformation($"Ending business logic.");
            subscription[subscriptionRenewalPayoutDateLogicalName] = renewalPayoutDate;
            target[subscriptionRenewalPayoutDateLogicalName] = subscription[subscriptionRenewalPayoutDateLogicalName];
            return target;
        }
    }
}