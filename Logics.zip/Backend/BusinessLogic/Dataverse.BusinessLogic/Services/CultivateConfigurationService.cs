﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using System.Reflection;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICultivateConfigurationService
    {
        Cultivateconfigurations GetCultivateConfiguration(string configurationName);
        string GetCultivateConfigurationValue(string configurationName);
        EntityReference GetCultivateConfigurationPriceList(string configurationName);
        EntityReference GetCultivateConfigurationCampaign(string configurationName);
    }

    public class CultivateConfigurationService : ICultivateConfigurationService
    {
        private Avanade.BizApps.Core.Diagnostics.ILogger _logger;
        private IRepository<Cultivateconfigurations> _cultivateConfigurationRepository;

        public CultivateConfigurationService(ILogger logger, IRepository<Cultivateconfigurations> cultivateConfigurationRepository)
        {
            _logger = logger;
            _cultivateConfigurationRepository = cultivateConfigurationRepository;
        }

        public Cultivateconfigurations GetCultivateConfiguration(string configurationName)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving cultivate configuration w/ name = {configurationName}");
            var configurations = _cultivateConfigurationRepository.GetAll().Where(configuration => configuration.Name.Contains(configurationName)).ToList();
            if (configurations.Count == 0)
            {
                var errorMessage = $"Failed to retrieve cultivate configuration record with {configurationName} name.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage + " Please reach out to an administrator to fix this.");
            }

            var configuration = configurations.First();
            _logger.TraceInformation($"Retrieved cultivate configuration record w/ name = {configuration.Name} and value = {configuration.Value}.");

            _logger.TraceInformation($"ending business logic.");
            return configuration;
        }

        public string GetCultivateConfigurationValue(string configurationName)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving value of cultivate configuration w/ name = {configurationName}.");
            var configuration = GetCultivateConfiguration(configurationName);
            _logger.TraceInformation($"Retrieved value = {configuration.Value}.");

            _logger.TraceInformation($"ending business logic.");
            return configuration.Value;
        }

        public EntityReference GetCultivateConfigurationPriceList(string configurationName)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving price list from cultivate configuration w/ name = {configurationName}.");
            var configuration = GetCultivateConfiguration(configurationName);
            if (configuration.PriceList == null)
            {
                var errorMessage = $"{configurationName} cultivate configurtation has no price list selected.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage + " Please reach out to an administrator to fix this.");
            }
            _logger.TraceInformation($"Retrieved price list w/ Id = {configuration.PriceList?.Id}.");

            _logger.TraceInformation($"ending business logic.");
            return configuration.PriceList;
        }

        public EntityReference GetCultivateConfigurationCampaign(string configurationName)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving campaign from cultivate configuration w/ name = {configurationName}.");
            var configuration = GetCultivateConfiguration(configurationName);
            if (configuration.Campaign == null)
            {
                var errorMessage = $"{configurationName} cultivate configurtation has no campaign selected.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage + " Please reach out to an administrator to fix this.");
            }
            _logger.TraceInformation($"Retrieved campaign w/ Id = {configuration.Campaign?.Id}.");

            _logger.TraceInformation($"ending business logic.");
            return configuration.Campaign;
        }
    }
}