using Avanade.BizApps.Core.Contracts;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipCreateService
    {
        void SubmitPaymentForGiftPackRedeemedMembership(Membership membership);
        void RedeemGiftPack(Membership membership);
        void MembershipUpdatePrimaryAndSecondaryMember(Entity membership);
        void MembershipConsentCreationMembersAndPayer(Entity membership);
        void ValidateAddressInMembership(Entity membership);
        void ValidateAgeRequirementsInMembership(Entity membership);
        void ValidateDuplicateMembership(Entity membership);
        void ValidateCampaignInMembership(Entity entity);
        void ValidateCampaignEndDate(Entity entity);
        void PopulateJoiningDateField(Entity entity);
        Entity SetPriceListOnMembershipEntity(Entity entity, Membership membership);
        Entity SetCampaignAmountOnMembershipEntity(Entity entity, Membership membership);
        //Entity SetMembershipAmountOnMembershipEntity(Entity entity);
        Entity SetTotalAmountOnMembershipEntity(Entity entity, Membership membership);
        Entity SetMembershipPriceOnMembershipEntity(Entity entity, Membership membership);
        Entity SetIsDDDiscountAvailedOnMembership(Entity entity, Membership membership);
        Entity SetPaymentAvailabilityOnChangeMembership(Entity entity);
        Entity SetPatronMembershipOnMembership(Entity entity);
        Money GetMembershipPrice(Membership membership);
        Money GetDiscountedPrice(Membership membership);
        Money GetDiscountedPrice(Guid productId, Guid campaignId, Guid priceListId, Money campaignAmount, int? paymentMethod, int? paymentFrequency, Paymentdiscountconfiguration discountConfig = null, Money membershipPrice = null);
        bool ValidateIfLinkedWithMembershipOfDifferentProduct(Membership membership);
    }

    public class MembershipCreateService : IMembershipCreateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IRepository<Membership> _membershipRepository;
        private IRepository<GiftPack> _giftPackRepository;
        private IRepository<Campaign> _campaignRepository;
        private IRepository<Paymentdiscountconfiguration> _paymentDiscountConfigurationRepository;
        private IPropertyRetrievalService _propertyRetrievalService;
        private IProductService _productService;
        private ICampaignService _campaignService;
        private ICustomAPIInvocationService _customAPIInvocationService;
        private ICommonService _commonService;
        // private readonly MembershipUpdateService _membershipUpdateService;
        // private readonly ContactUpdateService _contactUpdateService;

        #region Constants

        const int newMemberDataSet = 120000000;
        const string relationshipName = "rhs_rhs_membership_contact_MM";
        const int noPrimaryMember = 120000000;
        const int yesPrimaryMember = 120000001;
        const int memberRelationship1 = 120000000;
        const int memberRelationship2 = 120000001;
        const string customAPI = "rhs_consentscreation";
        #endregion Constants

        public MembershipCreateService(
            ITracingService tracingService, IOrganizationService service,
            IRepository<Membership> membershipRepository, IRepository<GiftPack> giftPackRepository, IRepository<Campaign> campaignRepository, IRepository<Paymentdiscountconfiguration> paymentDiscountConfigurationRepository,
            IPropertyRetrievalService propertyRetrievalService, IProductService productService, ICampaignService campaignService, ICustomAPIInvocationService customAPIInvocationService, ICommonService commonService
        )
        {
            _tracingService = tracingService;
            _service = service;
            _membershipRepository = membershipRepository;
            _campaignRepository = campaignRepository;
            _giftPackRepository = giftPackRepository;
            _paymentDiscountConfigurationRepository = paymentDiscountConfigurationRepository;
            _propertyRetrievalService = propertyRetrievalService;
            _productService = productService;
            _campaignService = campaignService;
            _customAPIInvocationService = customAPIInvocationService;
            _commonService = commonService;
            //_membershipUpdateService = membershipUpdateService;
            //_contactUpdateService = contactUpdateService;
        }

        #region Post-Operation
        public void MembershipUpdatePrimaryAndSecondaryMember(Entity membership)
        {
            _tracingService.Trace("MembershipUpdatePrimaryAndSecondaryMember Start");

            try
            {
                Guid membershipId = membership.Id;
                _tracingService.Trace($"Membership Id: {membershipId}");

                // Safely retrieve the Primary Member from the Membership record
                Guid? primaryMemberId = GetLookupId(membership, EntityNames.Membership.Contact);

                // Safely retrieve the Secondary Member from the Membership record
                Guid? secondaryMemberId = GetLookupId(membership, EntityNames.Membership.Member2);

                if (primaryMemberId.HasValue)
                {
                    UpdateMember(primaryMemberId.Value, yesPrimaryMember, memberRelationship1);
                    AssociateContactWithMembership(membershipId, primaryMemberId.Value, relationshipName);
                }

                // Associate the Secondary Member if it exists
                if (secondaryMemberId.HasValue)
                {
                    UpdateMember(secondaryMemberId.Value, noPrimaryMember, memberRelationship2);
                    AssociateContactWithMembership(membershipId, secondaryMemberId.Value, relationshipName);
                }
                else
                {
                    _tracingService.Trace("Skipping association for Secondary Member.");
                }

                _tracingService.Trace("MembershipUpdatePrimaryAndSecondaryMember End");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public void MembershipConsentCreationMembersAndPayer(Entity membership)
        {
            _tracingService.Trace($"MembershipConsentCreationPayer Start");

            try
            {
                // Retrieve the Primary and Secondary Members from the Membership record
                Guid? primaryMemberId = membership.Contains(EntityNames.Membership.Contact) && ((EntityReference)membership[EntityNames.Membership.Contact]) != null ?
                                        ((EntityReference)membership[EntityNames.Membership.Contact]).Id : (Guid?)null;

                Guid? secondaryMemberId = membership.Contains(EntityNames.Membership.Member2) && ((EntityReference)membership[EntityNames.Membership.Member2]) != null ?
                                          ((EntityReference)membership[EntityNames.Membership.Member2]).Id : (Guid?)null;

                Guid? payerId = membership.Contains(EntityNames.Membership.PayerV2) && ((EntityReference)membership[EntityNames.Membership.PayerV2]) != null ?
                                ((EntityReference)membership[EntityNames.Membership.PayerV2]).Id : (Guid?)null;
                string? payerLogicalName = membership.Contains(EntityNames.Membership.PayerV2) && ((EntityReference)membership[EntityNames.Membership.PayerV2]) != null ?
                                ((EntityReference)membership[EntityNames.Membership.PayerV2]).LogicalName : (string?)null;

                if (primaryMemberId.HasValue)
                {
                    _tracingService.Trace($"Primary Member Id: {primaryMemberId.Value}");

                    InvokeConsentCreationApi(primaryMemberId.Value.ToString(), newMemberDataSet);
                }

                if (secondaryMemberId.HasValue)
                {
                    _tracingService.Trace($"Secondary Member Id: {primaryMemberId.Value}");

                    InvokeConsentCreationApi(secondaryMemberId.Value.ToString(), newMemberDataSet);
                }

                bool isMembershipForSomeone = membership.Contains(EntityNames.Membership.IsMembershipForSomeone) && ((bool)membership[EntityNames.Membership.IsMembershipForSomeone]) != null ?
                    (bool)membership[EntityNames.Membership.IsMembershipForSomeone] : false;

                if (payerId.HasValue && isMembershipForSomeone && !string.IsNullOrEmpty(payerLogicalName) && payerLogicalName == EntityNames.Contact.EntityLogicalName)
                {
                    if (payerLogicalName == EntityNames.Contact.EntityLogicalName &&
                        ((primaryMemberId.HasValue && payerId.Value != primaryMemberId.Value) || (secondaryMemberId.HasValue && payerId.Value != secondaryMemberId.Value)))
                    {
                        _tracingService.Trace($"Payer Id: {payerId.Value}");
                        InvokeConsentCreationApi(payerId.Value.ToString(), newMemberDataSet);
                    }
                    else
                    {
                        _tracingService.Trace("Skipping consents creation of Payer.");
                    }
                }
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Error in MembershipConsentCreationPayer: {ex.Message}", ex);
            }

            _tracingService.Trace($"MembershipConsentCreationPayer End");
        }

        public void SubmitPaymentForGiftPackRedeemedMembership(Membership membership)
        {
            _tracingService.Trace($"SubmitPaymentForGiftPackRedeemedMembership start.");

            if (membership.PaymentMethod == PaymentMethodType_GlobalOptionSet.GiftPack)
            {
                _tracingService.Trace($"SubmitPaymentForGiftPackRedeemedMembership detects that membership has gift pack payment method.");
                Money giftPackAmount = new Money(0);
                if (membership.ActivationCode != null)
                {
                    QueryExpression queryGiftPack = new QueryExpression(GiftPack.EntityLogicalName);
                    queryGiftPack.ColumnSet = new ColumnSet("rhs_price");
                    queryGiftPack.Criteria.AddCondition("rhs_giftpackcode", ConditionOperator.Equal, membership.ActivationCode);
                    var giftPack = _service.RetrieveMultiple(queryGiftPack).Entities.FirstOrDefault();
                    giftPackAmount = giftPack?.GetAttributeValue<Money>("rhs_price");
                }

                _tracingService.Trace($"SubmitPaymentForGiftPackRedeemedMembership generating transaction and payment.");

                var (transactionId, paymentId, paymentSchedulenId) = _customAPIInvocationService.InvokeSubmitPaymentCustomAPI(
                    (int?)membership.PaymentMethod.Value,
                    (int?)NewTransactionType_GlobalOptionSet.Membership,
                    (int?)Typetransaction_GlobalOptionSet.FullPayment,
                    membership.Id,
                    membership.PayerV2.Id,
                    membership.PayerV2.LogicalName,
                    giftPackAmount,
                    (int?)membership.PaymentFrequency,
                    membership.IsContinuousPayment,
                    membership.OutstandingAmount
                );

                var paymentToUpdate = new Payment()
                {
                    Id = (Guid)paymentId,
                    Statecode = PaymentState.Inactive,
                    Statuscode = PaymentStatus.Inactive_Paid
                };
                _service.Update(paymentToUpdate);
            }

            _tracingService.Trace($"SubmitPaymentForGiftPackRedeemedMembership end");
        }
        public void RedeemGiftPack(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //Check Payment Method and Payment Received values
            if (membership.PaymentMethod == PaymentMethodType_GlobalOptionSet.GiftPack &&
                membership.PaymentReceived == true)
            {
                //Retrieve Gift Pack based on membership activation code
                string giftPackCode = membership.ActivationCode;

                QueryExpression query = new QueryExpression(EntityNames.GiftPack.EntityLogicalName);
                query.Criteria.AddCondition(EntityNames.GiftPack.GiftPackCode, ConditionOperator.Equal, giftPackCode);

                EntityCollection giftPacks = _service.RetrieveMultiple(query);

                if (giftPacks.Entities.Count == 0)
                    return;

                Entity giftPack = giftPacks.Entities[0];

                _tracingService.Trace($"Updating Gift Pack");
                Entity updategiftPack = new Entity(EntityNames.GiftPack.EntityLogicalName, giftPack.Id);

                updategiftPack[EntityNames.GiftPack.RedeemedById] = membership.Contact;
                updategiftPack[EntityNames.GiftPack.RedeemOn] = DateTime.UtcNow;
                updategiftPack[EntityNames.GiftPack.Statecode] = new OptionSetValue((int)GiftPackState.Inactive);
                updategiftPack[EntityNames.GiftPack.Statuscode] = new OptionSetValue((int)GiftPackStatus.Inactive_Redeemed);

                _service.Update(updategiftPack);
                _tracingService.Trace($"Gift Pack updated.");

            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        #endregion Post-Operation

        #region Pre-Operation
        public void ValidateAgeRequirementsInMembership(Entity membership)
        {
            _tracingService.Trace($"ValidateAgeRequirementsInMembership Start");

            EntityReference membershipProductRef = (EntityReference)membership[EntityNames.Membership.MembershipProductId];
            var isDOBRequired = _propertyRetrievalService.GetDefaultOptionSetValueOfProductProperty(membershipProductRef.Id.ToString(), "DOB Required") == 1 ? true : false;
            var minimumAgeProperty = _propertyRetrievalService.GetProductProperty(membershipProductRef.Id.ToString(), "Minimum Age");
            var minimumAge = minimumAgeProperty.DefaultValueInteger != null ? (int)minimumAgeProperty.DefaultValueInteger : 0;

            EntityReference contactRef = (EntityReference)membership[EntityNames.Membership.Contact];
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactRef.Id, new ColumnSet(true));
            DateTime? primaryContactBirthdate = contact.GetAttributeValue<DateTime?>(EntityNames.Contact.BirthDate);

            // Now retrieve the Product record to get its name
            Entity product = _service.Retrieve(EntityNames.Product.EntityLogicalName, membershipProductRef.Id, new ColumnSet(EntityNames.Product.Name));
            string productName = (string)product[EntityNames.Product.Name];
            _tracingService.Trace($"Product Name: {productName}");

            string productId = membershipProductRef.Id.ToString();
            int numberOfAllowedMembers = GetNumberOfAllowedMembers(productId);
            _tracingService.Trace($"NUmber of Allowed Members: {numberOfAllowedMembers}");

            // Check if DOB is required but not provided
            if (isDOBRequired && !primaryContactBirthdate.HasValue)
            {
                _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. DOB is required but not provided.");
                throw new InvalidPluginExecutionException($"Contact selected as Primary Member requires Date of Birth for the {productName}, Please update DOB for the contact first!");
            }

            // Check if the contact meets the minimum age requirement
            int minAgeRequirement = minimumAge;
            int contactAge = contact.Contains(EntityNames.Contact.Age) ? contact.GetAttributeValue<int>(EntityNames.Contact.Age) : 0;
            _tracingService.Trace($"Minimum Age Property Value: {minAgeRequirement}");
            _tracingService.Trace($"Contact Age Property Value: {contactAge}");

            if (contactAge < minAgeRequirement)
            {
                _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. Contact does not meet the minimum age requirement.");
                throw new InvalidPluginExecutionException($"Primary Member cannot be added to the {productName}, the minimum age requirement is {minAgeRequirement} years and above for all members on a {productName}");
            }

            if (numberOfAllowedMembers == 2)
            {
                EntityReference secondaryContactRef = (EntityReference)membership[EntityNames.Membership.Member2];
                Entity secondaryContact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, secondaryContactRef.Id, new ColumnSet(true));
                DateTime? secondaryContactBirthdate = secondaryContact.GetAttributeValue<DateTime?>(EntityNames.Contact.BirthDate);

                int secondaryContactAge = secondaryContact.Contains(EntityNames.Contact.Age) ? secondaryContact.GetAttributeValue<int>(EntityNames.Contact.Age) : 0;

                // Check if DOB is required but not provided
                if (isDOBRequired && !secondaryContactBirthdate.HasValue)
                {
                    _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. DOB is required but not provided.");
                    throw new InvalidPluginExecutionException($"Contact selected as Secondary Member requires Date of Birth for the {productName}, Please update DOB for the contact first!");
                }

                if (secondaryContactAge < minAgeRequirement)
                {
                    _tracingService.Trace($"ValidateAgeRequirementsInMembership Failed. Contact does not meet the minimum age requirement.");
                    throw new InvalidPluginExecutionException($"Secondary Member cannot be added to the {productName}, the minimum age requirement is {minAgeRequirement} years and above for all members on a {productName}");
                }
            }
        }

        public void ValidateAddressInMembership(Entity membership)
        {
            _tracingService.Trace($"ValidateAddressInMembership Start");

            string productId = ((EntityReference)membership[EntityNames.Membership.MembershipProductId]).Id.ToString();
            int numberOfAllowedMembers = GetNumberOfAllowedMembers(productId);

            EntityReference primaryContactRef = (EntityReference)membership[EntityNames.Membership.Contact];
            Entity primaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, primaryContactRef.Id, new ColumnSet(true));

            //Retrieve concatenated address for Primary Member
            string primaryMemberAddress = GetContactAddress(primaryContactRef.Id);

            EntityReference secondaryMemberRef = null;
            Entity secondaryMember = null;
            string secondaryMemberAddress = string.Empty;

            if (string.IsNullOrEmpty(primaryMemberAddress))
            {
                throw new InvalidPluginExecutionException("Primary Member Address details is empty. Please provide!");
            }
            _tracingService.Trace($"Primary Member Address: {primaryMemberAddress}");

            if (numberOfAllowedMembers == 2)
            {
                secondaryMemberRef = (EntityReference)membership[EntityNames.Membership.Member2];
                secondaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, secondaryMemberRef.Id, new ColumnSet(true));

                //Retrieve concatenated address for Secondary Member
                secondaryMemberAddress = GetContactAddress(secondaryMemberRef.Id);
                _tracingService.Trace($"Get ContactAddress Completed");
                if (string.IsNullOrEmpty(secondaryMemberAddress))
                {
                    Entity updateSecondaryMember = new Entity(EntityNames.Contact.EntityLogicalName, secondaryMember.Id);
                    //Update Secondary Member Address details
                    updateSecondaryMember[EntityNames.Contact.AddressSearchTypePrimary] = primaryMember.Contains(EntityNames.Contact.AddressSearchTypePrimary) ? primaryMember[EntityNames.Contact.AddressSearchTypePrimary] : null;
                    updateSecondaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] = primaryMember.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? primaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line1] = primaryMember.Contains(EntityNames.Contact.Address1_Line1) ? primaryMember[EntityNames.Contact.Address1_Line1] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line2] = primaryMember.Contains(EntityNames.Contact.Address1_Line2) ? primaryMember[EntityNames.Contact.Address1_Line2] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line3] = primaryMember.Contains(EntityNames.Contact.Address1_Line3) ? primaryMember[EntityNames.Contact.Address1_Line3] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_StateOrProvince] = primaryMember.Contains(EntityNames.Contact.Address1_StateOrProvince) ? primaryMember[EntityNames.Contact.Address1_StateOrProvince] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_City] = primaryMember.Contains(EntityNames.Contact.Address1_City) ? primaryMember[EntityNames.Contact.Address1_City] : null;
                    updateSecondaryMember[EntityNames.Contact.LoqateAddress1County] = primaryMember.Contains(EntityNames.Contact.LoqateAddress1County) ? primaryMember[EntityNames.Contact.LoqateAddress1County] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Country] = primaryMember.Contains(EntityNames.Contact.Address1_Country) ? primaryMember[EntityNames.Contact.Address1_Country] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_PostalCode] = primaryMember.Contains(EntityNames.Contact.Address1_PostalCode) ? primaryMember[EntityNames.Contact.Address1_PostalCode] : null;
                    updateSecondaryMember[EntityNames.Contact.Loqate_Latitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Latitude) ? primaryMember[EntityNames.Contact.Loqate_Latitude] : null;
                    updateSecondaryMember[EntityNames.Contact.Loqate_Longitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Longitude) ? primaryMember[EntityNames.Contact.Loqate_Longitude] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1PAFValidated] = primaryMember.Contains(EntityNames.Contact.Address1PAFValidated) ? primaryMember[EntityNames.Contact.Address1PAFValidated] : null;
                    updateSecondaryMember[EntityNames.Contact.BusinessValidatedPrimary] = primaryMember.Contains(EntityNames.Contact.BusinessValidatedPrimary) ? primaryMember[EntityNames.Contact.BusinessValidatedPrimary] : null;

                    _service.Update(updateSecondaryMember);
                    _tracingService.Trace("Updated contact: " + secondaryMemberRef.Id.ToString());
                }

                else
                {
                    _tracingService.Trace($"Secondary Member Address: {secondaryMemberAddress}");
                    if (secondaryMemberAddress != primaryMemberAddress)
                    {
                        throw new InvalidPluginExecutionException($"Addresses don't match, Please review the address for both the members!");
                    }
                }
            }
            _tracingService.Trace($"ValidateAddressInMembership End");
        }

        private string GetContactAddress(Guid contactId)
        {
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactId, new ColumnSet(true));

            string houseName = contact.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? (string)contact[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
            string houseLine = contact.Contains(EntityNames.Contact.Address1_Line1) ? (string)contact[EntityNames.Contact.Address1_Line1] : null;
            string city = contact.Contains(EntityNames.Contact.Address1_City) ? (string)contact[EntityNames.Contact.Address1_City] : null;
            string postalCode = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;

            string memberAddress = $"{houseName} {houseLine} {city} {postalCode}".Trim();

            return memberAddress.ToLower();
        }
        public Entity SetPriceListOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //_tracingService.Trace($"Setting default price list of the product into the membership.");
            //membership.PriceList = _productService.GetPriceListUsedOnProduct(membership.MembershipProductId.Id);

            if (membership.MembershipProductId.Name.Contains("Patron"))
                membership.PriceList = _productService.GetPatronBackOfficePriceList(membership.MembershipProductId.Id);
            else
                membership.PriceList = _productService.GetProductBackOfficePriceList(membership.MembershipProductId.Id);

            entity[EntityNames.Membership.PriceList] = membership.PriceList;

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetCampaignAmountOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.CampaignId != null)
            {
                var campaign = _campaignRepository.GetById(membership.CampaignId.Id);

                if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _tracingService.Trace($"Setting campaign amount because price based campaign exists on membership.");
                    membership.CampaignAmount = _productService.GetCampaignProductPrice(membership.MembershipProductId.Id, membership.CampaignId.Id);
                }
                else
                {
                    membership.CampaignAmount = null;
                    _tracingService.Trace($"Setting campaign amount to NULL because price-based campaign was not selected or unselected on membership.");
                }
            }
            else
            {
                membership.CampaignAmount = null;
                _tracingService.Trace($"Setting campaign amount to NULL because price-based campaign was not selected or unselected on membership.");
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            entity[EntityNames.Membership.CampaignAmount] = membership.CampaignAmount;
            return entity;
        }

        //public Entity SetMembershipAmountOnMembershipEntity(Entity entity)
        //{
        //    _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

        //    var membership = entity.ToEntity<Membership>();
        //    entity[EntityNames.Membership.MembershipAmountV2] = _productService.GetProductPrice(membership.MembershipProductId.Id);

        //    _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        //    return entity;
        //}

        public Entity SetMembershipPriceOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //if (membership.MembershipPrice == null)
            membership.MembershipPrice = _productService.GetProductPrice(membership.MembershipProductId.Id, membership.PriceList.Id);
            entity[EntityNames.Membership.MembershipPrice] = membership.MembershipPrice;

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetTotalAmountOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //if (membership.TotalAmount == null)
            //{
            _tracingService.Trace($"Setting total amount to the product price.");
            membership.TotalAmount = GetMembershipPrice(membership);
            entity[EntityNames.Membership.TotalAmount] = membership.TotalAmount;
            //}

            if (membership.ActivationCode != null)
            {
                _tracingService.Trace($"Gift Pack Activation Code exists. Setting total amount to the zero.");
                membership.TotalAmount = new Money(0);
                entity[EntityNames.Membership.TotalAmount] = new Money(0);
            }

            if (membership.CampaignId != null)
            {
                var campaign = _campaignRepository.GetById(membership.CampaignId.Id);

                if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _tracingService.Trace($"Price based campaign exists. Setting total amount to the campaign product price.");

                    membership.TotalAmount = GetDiscountedPrice(membership);
                    entity[EntityNames.Membership.TotalAmount] = membership.TotalAmount;
                }
            }


            if (membership.LinkedMembership != null && membership.IsRenewal != true)
            {
                _tracingService.Trace($"Detected membership change. Recalculating total amount field.");

                var newMembership = membership;
                var newMembershipTotalAmountValue = newMembership.TotalAmount.Value;
                var newMembershipCarriedOverAmountValue = newMembership.CarriedOverAmount != null ? newMembership.CarriedOverAmount.Value : 0;

                var oldMembership = _membershipRepository.GetById(membership.LinkedMembership.Id);
                var oldMembershipPriceValue = oldMembership.MembershipPrice != null ? oldMembership.MembershipPrice.Value : 0;

                if (oldMembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.DirectDebit &&
                    oldMembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.Card &&
                    oldMembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.CreditCard_Phone)
                {
                    _tracingService.Trace($"Calculating and populating total amount value for non-DD/Card.");

                    newMembership.TotalAmount = new Money()
                    {
                        Value = newMembershipTotalAmountValue - oldMembershipPriceValue
                    };
                    entity[EntityNames.Membership.TotalAmount] = newMembership.TotalAmount;
                }
                else
                {
                    _tracingService.Trace($"Calculating and populating total amount value for DD/Card.");

                    newMembership.TotalAmount = new Money()
                    {
                        Value = newMembershipTotalAmountValue - oldMembershipPriceValue + newMembershipCarriedOverAmountValue
                    };
                    entity[EntityNames.Membership.TotalAmount] = newMembership.TotalAmount;
                }

                if (newMembership.TotalAmount.Value < 0)
                {
                    _tracingService.Trace($"Resetting negative total amount to 0.");
                    newMembership.TotalAmount = new Money() { Value = 0 };
                    entity[EntityNames.Membership.TotalAmount] = newMembership.TotalAmount;
                }

                //For renewal period
                if (oldMembership.InRenewalsStage == true)
                {
                    _tracingService.Trace($"Detected that it's currently the renewal period for this membership.");
                    _tracingService.Trace($"Recalculating and repopulating total amount value.");
                    newMembership.TotalAmount.Value += newMembership.MembershipPrice.Value;
                    entity[EntityNames.Membership.TotalAmount] = newMembership.TotalAmount;
                }
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Money GetMembershipPrice(Membership membership)
        {
            return GetMembershipPrice(membership.MembershipPrice, membership.MembershipProductId.Id, membership.PriceList.Id);
        }

        public Money GetMembershipPrice(Money membershipPrice, Guid producdId, Guid priceListId)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            membershipPrice = membershipPrice ?? _productService.GetProductPrice(producdId, priceListId);

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return membershipPrice;
        }

        public Money GetDiscountedPrice(Membership membership)
        {
            return GetDiscountedPrice(
                membership.MembershipProductId.Id,
                membership.CampaignId.Id,
                membership.PriceList.Id,
                membership.CampaignAmount,
                (int?)membership.PaymentMethod,
                (int?)membership.PaymentFrequency
            );
        }

        public Money GetDiscountedPrice(Guid productId, Guid campaignId, Guid priceListId, Money campaignAmount, int? paymentMethod, int? paymentFrequency, Paymentdiscountconfiguration discountConfig = null, Money membershipPrice = null)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (productId == Guid.Empty) throw new ArgumentException("ProductId is required.");
            if (campaignId == Guid.Empty) throw new ArgumentException("CampaignId is required.");

            var campaign = _campaignRepository.GetById(campaignId);
            var campaignPrice = campaignAmount ?? _productService.GetCampaignProductPrice(productId, campaignId);
            if (campaignPrice == null) throw new InvalidPluginExecutionException("Campaign price could not be determined.");

            var discountedPrice = new Money(campaignPrice.Value);
            _tracingService.Trace($"Initial discounted price: {discountedPrice.Value}.");

            // Use passed discountConfig if available
            if (discountConfig == null && campaign.Paymentdiscountconfiguration != null)
            {
                discountConfig = _paymentDiscountConfigurationRepository.GetById(campaign.Paymentdiscountconfiguration.Id);
            }

            if (discountConfig != null)
            {
                bool isEligibleForDiscount =
                    paymentMethod == (int?)discountConfig.PaymentMethodCode &&
                    (paymentMethod != (int)PaymentMethodType_GlobalOptionSet.DirectDebit ||
                     paymentFrequency == (int)PaymentFrequency_GlobalOptionSet.Annually);

                if (isEligibleForDiscount)
                {
                    _tracingService.Trace($"Eligible for payment discount configuration. {membershipPrice} - {priceListId}");

                    // Use passed membershipPrice if available
                    if (membershipPrice == null)
                    {
                        membershipPrice = priceListId != null && priceListId != Guid.Empty
                            ? _productService.GetProductPrice(productId, priceListId)
                            : _productService.GetProductPrice(productId);
                    }

                    if (membershipPrice == null)
                        throw new InvalidPluginExecutionException("Membership price could not be determined.");

                    // Apply percentage discount
                    if (discountConfig.DiscountPercentage.HasValue)
                    {
                        var percentDiscount = (discountConfig.DiscountPercentage.Value / 100) * membershipPrice.Value;
                        discountedPrice.Value -= percentDiscount;
                        _tracingService.Trace($"Applied percentage discount: {percentDiscount}, new price: {discountedPrice.Value}.");
                    }

                    // Apply fixed amount discount
                    if (discountConfig.DiscountAmount != null)
                    {
                        discountedPrice.Value -= discountConfig.DiscountAmount.Value;
                        _tracingService.Trace($"Applied fixed discount: {discountConfig.DiscountAmount.Value}, new price: {discountedPrice.Value}.");
                    }
                }
            }

            if (discountedPrice.Value < 0)
            {
                _tracingService.Trace("Discounted price is negative, resetting to 0.");
                discountedPrice.Value = 0;
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return discountedPrice;
        }

        private Money GetGiftPackPrice(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");
            var giftPackPrice = new Money();

            try
            {
                giftPackPrice = _giftPackRepository.GetAll().Where(giftPack => giftPack.GiftPackCode == membership.ActivationCode &&
                    giftPack.ExpireDate > DateTime.UtcNow && giftPack.IsPaymentReceived == true).First().Price;
            }
            catch
            {
                throw new InvalidPluginExecutionException("Invalid Activation Code, please enter the correct one.");
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return giftPackPrice;
        }

        public Entity SetIsDDDiscountAvailedOnMembership(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Annually &&
                membership.CampaignId != null && membership.IsDDDiscountAvailed != true)
            {
                _tracingService.Trace($"Setting of IsDDDiscountAvailed to true.");
                membership.IsDDDiscountAvailed = true;
            }
            else
            {
                _tracingService.Trace($"Setting of IsDDDiscountAvailed to false.");
                membership.IsDDDiscountAvailed = false;
            }

            _tracingService.Trace($"Membership.IsDDDiscountAvailed = {membership.IsDDDiscountAvailed}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            entity[EntityNames.Membership.IsDDDiscountAvailed] = membership.IsDDDiscountAvailed;
            return entity;
        }

        public void ValidateDuplicateMembership(Entity membership)
        {
            _tracingService.Trace("Starting validation for duplicate active or dormant membership.");
            // Check if membership is new
            if (membership.GetAttributeValue<bool?>(EntityNames.Membership.IsRenewal) != true)
            {
                // flag to check if new product is a patron product
                var isPatronProduct = false;

                // get environment variable default/current value
                var environmentVariableValue = _commonService.GetEnvironmentVariableValue("rhs_PatronMembershipProductParentID", _service);

                // get new membership product id
                Guid MembershipProductId = ((EntityReference)membership[EntityNames.Membership.MembershipProductId]).Id;

                // get all patron products 
                QueryExpression queryPatronProducts = new QueryExpression(Product.EntityLogicalName);
                queryPatronProducts.ColumnSet = new ColumnSet("productid");
                queryPatronProducts.Criteria.AddCondition("parentproductid", ConditionOperator.Equal, environmentVariableValue);
                var patronProducts = _service.RetrieveMultiple(queryPatronProducts);

                foreach (var entity in patronProducts.Entities)
                {
                    // condition if new membership product is a patron product.
                    if (entity.Id == MembershipProductId)
                    {
                        isPatronProduct = true;
                        break;
                    }
                }

                // Initialize query to check for active or dormant non-patron memberships
                QueryExpression query = new QueryExpression(EntityNames.Membership.EntityLogicalName);
                query.ColumnSet.AddColumns(
                    EntityNames.Membership.PrimaryIdAttribute,
                    EntityNames.Membership.Contact,
                    EntityNames.Membership.Member2,
                    EntityNames.Membership.Statuscode
                );

                // Initialize query to check for active or dormant patron memberships 
                QueryExpression queryPatron = new QueryExpression(EntityNames.Membership.EntityLogicalName);
                queryPatron.ColumnSet.AddColumns(
                    EntityNames.Membership.PrimaryIdAttribute,
                    EntityNames.Membership.Contact,
                    EntityNames.Membership.Member2,
                    EntityNames.Membership.Statuscode
                );

                // Filter for OR logic between Active and Dormant statuses
                FilterExpression statusFilter = new FilterExpression(LogicalOperator.Or);
                statusFilter.AddCondition(EntityNames.Membership.Statuscode, ConditionOperator.Equal, 1); // Active status
                statusFilter.AddCondition(EntityNames.Membership.Statuscode, ConditionOperator.Equal, 120000002); // Dormant status

                // Filter for not a patron membership
                FilterExpression statusFilterNonPatron = new FilterExpression(LogicalOperator.And);
                statusFilterNonPatron.AddCondition(EntityNames.Membership.PatronMembership, ConditionOperator.Equal, false); // Non Patron Membership

                // Filter for not a patron membership
                FilterExpression statusFilterPatron = new FilterExpression(LogicalOperator.And);
                statusFilterPatron.AddCondition(EntityNames.Membership.PatronMembership, ConditionOperator.Equal, true); // Patron Membership

                // Add the status filter to the main query criteria
                query.Criteria.AddFilter(statusFilter);
                query.Criteria.AddFilter(statusFilterNonPatron);

                // Add the status filter to the main query criteria
                queryPatron.Criteria.AddFilter(statusFilter);
                queryPatron.Criteria.AddFilter(statusFilterPatron);

                // Filter for OR logic for members
                FilterExpression filter = new FilterExpression(LogicalOperator.Or);

                // Check for primary member in both rhs_contact and rhs_member2 fields
                if (membership.Contains(EntityNames.Membership.Contact) &&
                    membership.GetAttributeValue<EntityReference?>(EntityNames.Membership.Contact) != null)
                {
                    Guid primaryMemberId = ((EntityReference)membership[EntityNames.Membership.Contact]).Id;

                    // Check if primary member exists in either Contact or Member2 fields
                    filter.AddCondition(EntityNames.Membership.Contact, ConditionOperator.Equal, primaryMemberId);
                    filter.AddCondition(EntityNames.Membership.Member2, ConditionOperator.Equal, primaryMemberId);
                }

                // Check for member2 in both rhs_contact and rhs_member2 fields
                if (membership.Contains(EntityNames.Membership.Member2) &&
                    membership.GetAttributeValue<EntityReference?>(EntityNames.Membership.Member2) != null)
                {
                    Guid member2Id = ((EntityReference)membership[EntityNames.Membership.Member2]).Id;

                    // Check if member2 exists in either Contact or Member2 fields
                    filter.AddCondition(EntityNames.Membership.Contact, ConditionOperator.Equal, member2Id);
                    filter.AddCondition(EntityNames.Membership.Member2, ConditionOperator.Equal, member2Id);
                }

                // Only add the filter if it contains conditions
                if (filter.Conditions.Count > 0)
                {
                    query.Criteria.AddFilter(filter);
                    queryPatron.Criteria.AddFilter(filter);
                }

                // Execute the query to check for any active or dormant non-patron memberships
                EntityCollection existingMemberships = _service.RetrieveMultiple(query);

                // Execute the query to check for any active or dormant patron memberships
                EntityCollection existingPatronMemberships = _service.RetrieveMultiple(queryPatron);

                // If any active or dormant memberships exist, throw an error
                if ((existingMemberships.Entities.Count > 0 && !isPatronProduct) || // do not allow Multiple active non-patron memberships 
                    (existingPatronMemberships.Entities.Count > 0 && isPatronProduct) || // do not Multiple active patron memberships
                    (existingMemberships.Entities.Count > 0 && existingPatronMemberships.Entities.Count > 0)) // Allow A single active patron membership + a single active non-patron membership
                {
                    _tracingService.Trace("Validation failed: member or member2 is associated with an active or dormant membership.");
                    throw new InvalidPluginExecutionException("The selected member is already associated with an active or dormant membership.");
                }

                _tracingService.Trace("Validation passed: no active or dormant memberships found.");
            }
            else
                _tracingService.Trace("Skipping validation for renewal membership.");
        }

        public void ValidateCampaignInMembership(Entity entity)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            var membership = entity.ToEntity<Membership>();
            if (membership.CampaignId != null)
            {
                _tracingService.Trace($"Campaign selected for membership.");
                var campaign = _campaignRepository.GetById(membership.CampaignId.Id);

                _tracingService.Trace($"Validating if the campaign is active.");
                if (campaign.StateCode != CampaignState.Active)
                    throw new InvalidPluginExecutionException("Please enter a valid Campaign Code!");

                _tracingService.Trace($"Validating if the campaign is valid for selected product.");
                var campaignProductIds = _campaignService.RetrieveCampaignProductIds(campaign.Id);
                if (membership.MembershipProductId == null || !campaignProductIds.Any(id => id == membership.MembershipProductId.Id))
                    throw new InvalidPluginExecutionException("Entered Campaign Code is not valid for selected Membership Product. Please select correct Campaign Code!");
            }
            else
                _tracingService.Trace($"No campaign selected for membership.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public void ValidateCampaignEndDate(Entity entity)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //Check for Campaign value
            var membership = entity.ToEntity<Membership>();
            if (membership.CampaignId != null)
            {
                Guid campaignId = _campaignRepository.GetById(membership.CampaignId.Id).Id;

                //Retrieve Campaign record to get the actual end date
                Entity campaign = _service.Retrieve(EntityNames.Campaign.EntityLogicalName, campaignId, new ColumnSet(EntityNames.Campaign.ActualEnd));

                if (campaign != null && campaign.Contains(EntityNames.Campaign.ActualEnd))
                {
                    _tracingService.Trace($"Validating if Campaign has expired.");
                    DateTime actualEnd = (DateTime)campaign[EntityNames.Campaign.ActualEnd];
                    DateTime now = DateTime.UtcNow;

                    if (actualEnd < now)
                    {
                        throw new InvalidPluginExecutionException("Invalid Campaign Code, please enter the correct one. The campaign has expired.");
                    }
                }
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public void PopulateJoiningDateField(Entity entity)
        {
            //Check for Linked Membership value
            var membership = entity.ToEntity<Membership>();
            if (membership.Contains(EntityNames.Membership.LinkedMembership) &&
                membership.GetAttributeValue<EntityReference>(EntityNames.Membership.LinkedMembership) != null)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                Guid linkedMembershipId = ((EntityReference)membership[EntityNames.Membership.LinkedMembership]).Id;

                //Retrieve Linked Membership record to get the joining date
                Entity linkedMembership = _service.Retrieve(EntityNames.Membership.EntityLogicalName, linkedMembershipId, new ColumnSet(EntityNames.Membership.JoiningDate));

                _tracingService.Trace($"Populating Joining Date field");
                if (linkedMembershipId != null && linkedMembership.Contains(EntityNames.Membership.JoiningDate))
                {
                    DateTime joiningDate = (DateTime)linkedMembership[EntityNames.Membership.JoiningDate];

                    //Populate Joining Date field
                    membership[EntityNames.Membership.JoiningDate] = joiningDate;
                    _tracingService.Trace($"Joining Date populated from Linked Membership: " + joiningDate);
                }
            }
            else
            {
                DateTime creationDate = DateTime.UtcNow;
                membership[EntityNames.Membership.JoiningDate] = creationDate;
                _tracingService.Trace($"Joining Date populated from Membership CreatedOn date: " + creationDate);
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public Entity SetPaymentAvailabilityOnChangeMembership(Entity entity)
        {
            var membership = entity.ToEntity<Membership>();
            if (membership.LinkedMembership != null)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                if (membership.TotalAmount.Value <= 0)
                {
                    _tracingService.Trace($"Membership should not be payable.");

                    entity[EntityNames.Membership.IsSubmitPayment] = true;
                    entity[EntityNames.Membership.PaymentReceived] = true;
                    entity[EntityNames.Membership.Statuscode] = new OptionSetValue((int)MembershipStatus.Active_Active);
                }
                else
                {
                    _tracingService.Trace($"Membership should be payable.");

                    entity[EntityNames.Membership.IsSubmitPayment] = false;
                    entity[EntityNames.Membership.PaymentReceived] = false;
                    entity[EntityNames.Membership.Statuscode] = new OptionSetValue((int)MembershipStatus.Active_PendingPayment);
                }

                _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            }
            return entity;
        }

        public Entity SetPatronMembershipOnMembership(Entity entity)
        {
            var membership = entity.ToEntity<Membership>();
            if (membership.Contact != null)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                // flag to check if new product is a patron product
                var isPatronProduct = false;

                // get environment variable default/current value
                var environmentVariableValue = _commonService.GetEnvironmentVariableValue("rhs_PatronMembershipProductParentID", _service);

                // get new membership product id
                Guid MembershipProductId = ((EntityReference)membership[EntityNames.Membership.MembershipProductId]).Id;

                // get all patron products 
                QueryExpression queryPatronProducts = new QueryExpression(Product.EntityLogicalName);
                queryPatronProducts.ColumnSet = new ColumnSet("productid");
                queryPatronProducts.Criteria.AddCondition("parentproductid", ConditionOperator.Equal, environmentVariableValue);
                var patronProducts = _service.RetrieveMultiple(queryPatronProducts);

                foreach (var entityPatronProducts in patronProducts.Entities)
                {
                    // condition if new membership product is a patron product.
                    if (entityPatronProducts.Id == MembershipProductId)
                    {
                        isPatronProduct = true;
                        break;
                    }
                }

                if (isPatronProduct == true)
                {
                    _tracingService.Trace($"Patron Membership is set to Yes.");

                    entity[EntityNames.Membership.PatronMembership] = true;
                }
                else
                {
                    _tracingService.Trace($"Patron Membership is set to No.");

                    entity[EntityNames.Membership.PatronMembership] = false;
                }

                _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            }
            return entity;
        }

        public bool ValidateIfLinkedWithMembershipOfDifferentProduct(Membership membership)
        {
            _tracingService.Trace("Starting ValidateIfWithLinkedMembershipWithDifferentProduct business logic.");

            var isLinkedWithMembershipOfDifferentProduct = false;
            if (membership.LinkedMembership != null)
            {
                var linkedMembership = _membershipRepository.GetById(membership.LinkedMembership.Id);

                if (membership.MembershipProductId != null && linkedMembership.MembershipProductId != null &&
                    membership.MembershipProductId.Id != linkedMembership.MembershipProductId.Id)
                {
                    isLinkedWithMembershipOfDifferentProduct = true;
                }
            }
            _tracingService.Trace($"Is linked with membership with different product? {isLinkedWithMembershipOfDifferentProduct}.");

            _tracingService.Trace("Ending ValidateIfWithLinkedMembershipWithDifferentProduct business logic.");
            return isLinkedWithMembershipOfDifferentProduct;
        }
        #endregion Pre-Operation

        #region Common Methods
        public int GetNumberOfAllowedMembers(string productId)
        {
            _tracingService.Trace($"GetNumberOfAllowedMembers Start");

            var productPropertyName = "Number of Members Allowed";
            var numberOfMembersAllowedProperty = _propertyRetrievalService.GetProductProperty(productId, productPropertyName);
            var numberOfAllowedMembers = numberOfMembersAllowedProperty.DefaultValueInteger != null ? (int)numberOfMembersAllowedProperty.DefaultValueInteger : 0;

            _tracingService.Trace($"GetNumberOfAllowedMembers End");

            return numberOfAllowedMembers;
        }

        private Guid? GetLookupId(Entity entity, string attributeName)
        {
            if (entity.Contains(attributeName) && entity[attributeName] is EntityReference lookup)
            {
                return lookup.Id;
            }
            return null;
        }

        private void UpdateMember(Guid memberId, int memberType, int memberRelationship)
        {
            Entity member = new Entity(EntityNames.Contact.EntityLogicalName, memberId);
            member[EntityNames.Contact.IsPrimaryMember] = new OptionSetValue(memberType);
            member[EntityNames.Contact.MembershipRelationship] = new OptionSetValue(memberRelationship);
            _service.Update(member);
        }

        private void AssociateContactWithMembership(Guid membershipId, Guid contactId, string relationshipName)
        {
            _tracingService.Trace($"MembershipId: {membershipId}");
            _tracingService.Trace($"ContactId: {contactId}");
            _tracingService.Trace($"RelationshipName: {relationshipName}");

            Relationship relationship = new Relationship(relationshipName);

            EntityReferenceCollection relatedEntities = new EntityReferenceCollection
            {
                new EntityReference(EntityNames.Contact.EntityLogicalName, contactId)
            };

            // Perform the associate operation
            _service.Associate(
                EntityNames.Membership.EntityLogicalName,
                membershipId,
                relationship,
                relatedEntities
            );

            _tracingService.Trace($"Successfully associated Contact ({contactId}) with Membership ({membershipId}).");
        }

        public void InvokeConsentCreationApi(string contactId, int newMemberDataSet)
        {
            try
            {
                OrganizationRequest apiRequest = new OrganizationRequest(customAPI)
                {
                    Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", newMemberDataSet }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse apiResponse = _service.Execute(apiRequest);

                // Check the response for success or failure
                if (apiResponse != null && apiResponse.Results.Contains("result") && (bool)apiResponse.Results["result"])
                {
                    _tracingService.Trace("Consent creation via API was successful.");
                }
                else if (apiResponse != null && apiResponse.Results.Contains("error"))
                {
                    string error = apiResponse.Results["error"].ToString();
                    _tracingService.Trace($"Consent creation via API failed. Error: {error}");
                    throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
                }

                _tracingService.Trace("Custom API executed successfully.");

            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception during Custom API invocation: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Error invoking Custom API: {ex.Message}", ex);
            }
        }

        #endregion Common Methods
        #region Create Membership from Deceased
        public void CreateJointOrIndividualMembershipFromDeceased(Membership oldmembership, Entity memberA, Entity memberB, Entity Payer, Product membershipProduct, Transaction? recentTransaction)
        {

            //_tracingService.Trace($"recentTransaction: {recentTransaction.OutstandingAmount.Value}");

            bool memberAisDeceased = memberA.Contains("rhs_deceased") && memberA["rhs_deceased"] != null && (bool)memberA["rhs_deceased"];
            bool memberBisDeceased = memberB.Contains("rhs_deceased") && memberB["rhs_deceased"] != null && (bool)memberB["rhs_deceased"];
            bool payerIsDeceased = Payer.Contains("rhs_deceased") && Payer["rhs_deceased"] != null && (bool)Payer["rhs_deceased"];

            bool ispayerDifferentPerson = false;
            if (memberA.Id != Payer.Id && memberB.Id != Payer.Id)
            {
                ispayerDifferentPerson = true;
            }
            var newRecord = new Entity(Membership.EntityLogicalName);
            newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", oldmembership.MembershipProductId.Id);
            newRecord[EntityNames.Membership.Startdate] = (DateTime)oldmembership.Startdate;
            newRecord[EntityNames.Membership.Enddate] = (DateTime)oldmembership.Enddate;
            newRecord["rhs_linkedmembership"] = new EntityReference(Membership.EntityLogicalName, oldmembership.Id);
            newRecord["rhs_replacementcard"] = true;


            if (!ispayerDifferentPerson)
            {
                if (memberAisDeceased)
                {
                    newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", memberB.Id);
                    newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", memberB.Id);

                    //for downgrade scenario
                    newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", membershipProduct.Id);


                }
                else if (memberBisDeceased)
                {
                    newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", memberA.Id);
                    newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", memberA.Id);

                    //for downgrade scenario
                    newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", membershipProduct.Id);

                }
            }
            else
            {

                if (memberAisDeceased)
                {

                    newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", memberB.Id);
                    newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", Payer.Id);

                    //for downgrade scenario
                    newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", membershipProduct.Id);
                    newRecord[EntityNames.Membership.IsMembershipForSomeone] = true;

                }
                else if (memberBisDeceased)
                {
                    newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", memberA.Id);
                    newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", Payer.Id);

                    //for downgrade scenario
                    newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", membershipProduct.Id);
                    newRecord[EntityNames.Membership.IsMembershipForSomeone] = true;



                }
                else if (payerIsDeceased)
                {
                    newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", memberA.Id);
                    newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", memberA.Id);
                    newRecord[EntityNames.Membership.Member2] = new EntityReference("contact", memberB.Id);
                }

                //update total amount from old recent transaction outstanding amount
                if (recentTransaction != null && recentTransaction.Contains(recentTransaction.OutstandingAmount.Value.ToString()))
                {
                    newRecord[EntityNames.Membership.CarriedOverAmount] = new Money()
                    {
                        Value = recentTransaction.OutstandingAmount.Value,
                        ExtensionData = recentTransaction.ExtensionData
                    };
                    newRecord[EntityNames.Membership.TotalAmount] = newRecord[EntityNames.Membership.CarriedOverAmount];
                }

            }

            if (oldmembership.Contains(EntityNames.Membership.PaymentMethod) &&
                (oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.DirectDebit ||
                 oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.Card ||
                 oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                 oldmembership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                 oldmembership.IsContinuousPayment.Value == false)
            {
                newRecord[EntityNames.Membership.PaymentMethod] = new OptionSetValue((int)oldmembership.PaymentMethod.Value);
                newRecord[EntityNames.Membership.PaymentReceived] = oldmembership.PaymentReceived.Value;
            }


            if (oldmembership.Contains(EntityNames.Membership.PaymentMethod) &&
                (oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                oldmembership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                oldmembership.IsContinuousPayment.Value == true)
            {
                newRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(120000003);
            }
            else
            {
                newRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(1);
            }


            try
            {
                _service.Create(newRecord);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Failed to create a new joint membership record: " + ex.Message);
                _tracingService.Trace($"Stack Trace: {ex.StackTrace}");
                throw new InvalidPluginExecutionException("Failed to create a new membership record.", ex);
            }
        }



        public void CreateIndividualMembershipFromDeceased(Membership oldmembership, Entity contact, bool payerIsDeceased, Transaction? recentTransaction)
        {

            _tracingService.Trace($"productid:{oldmembership.MembershipProductId.Id}");
            _tracingService.Trace($"contactid:{contact.Id}");

            var newRecord = new Entity(Membership.EntityLogicalName);

            newRecord[EntityNames.Membership.MembershipProductId] = new EntityReference("product", oldmembership.MembershipProductId.Id);
            newRecord[EntityNames.Membership.Contact] = new EntityReference("contact", contact.Id);
            newRecord[EntityNames.Membership.Startdate] = (DateTime)oldmembership.Startdate;
            newRecord[EntityNames.Membership.Enddate] = (DateTime)oldmembership.Enddate;
            newRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", contact.Id);
            newRecord["rhs_linkedmembership"] = new EntityReference(Membership.EntityLogicalName, oldmembership.Id);
            newRecord["rhs_replacementcard"] = true;




            if (oldmembership.Contains(EntityNames.Membership.PaymentMethod) &&
                (oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                oldmembership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                oldmembership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                oldmembership.IsContinuousPayment.Value == true)
            {
                newRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(120000003);
            }
            else
            {
                newRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(1);
            }


            //update total amount from old recent transaction outstanding amount
            if (recentTransaction != null && recentTransaction.Contains(recentTransaction.OutstandingAmount.Value.ToString()))
            {
                newRecord[EntityNames.Membership.CarriedOverAmount] = new Money()
                {
                    Value = recentTransaction.OutstandingAmount.Value,
                    ExtensionData = recentTransaction.ExtensionData
                };
                newRecord[EntityNames.Membership.TotalAmount] = newRecord[EntityNames.Membership.CarriedOverAmount];
            }

            if (oldmembership.Contains(EntityNames.Membership.PaymentMethod) &&
                  (oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.DirectDebit ||
                   oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.Card ||
                   oldmembership.PaymentMethod.Value != PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                   oldmembership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                   oldmembership.IsContinuousPayment.Value == false)
            {
                newRecord[EntityNames.Membership.PaymentMethod] = new OptionSetValue((int)oldmembership.PaymentMethod.Value);
                newRecord[EntityNames.Membership.PaymentReceived] = oldmembership.PaymentReceived.Value;
            }
            try
            {
                _service.Create(newRecord);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Failed to create a new individual membership record: " + ex.Message);
                _tracingService.Trace($"Stack Trace: {ex.StackTrace}");
                throw new InvalidPluginExecutionException("Failed to create a new membership record.", ex);
            }
        }
        #endregion


    }
}