﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMailingHouseItemService
    {
        void SetName(ref Entity target, ref Mailinghouseitem mailingHouseItem, Contact contact, Account account);
    }

    public class MailingHouseItemService : IMailingHouseItemService
    {
        private readonly ILogger _logger;
        private readonly IRepository<Contact> _contactRepository;
        private readonly IRepository<Account> _accountRepository;


        public MailingHouseItemService(ILogger logger, IRepository<Contact> contactRepository, IRepository<Account> accountRepository)
        {
            _logger = logger;
            _contactRepository = contactRepository;
            _accountRepository = accountRepository;
        }

        public void SetName(ref Entity target, ref Mailinghouseitem mailingHouseItem, Contact contact, Account account)
        {
            _logger.TraceInformation("Starting business logic.");

            var customerName = contact?.FullName != null ? contact?.FullName : account?.Name;
            var dateNow = DateTime.UtcNow.ToString("dd/MM/yyyy");

            mailingHouseItem.Name = $"Mailing House Item - {customerName} - {dateNow}";
            target[EntityNames.Mailinghouseitem.Name] = mailingHouseItem.Name;

            _logger.TraceInformation("Ending business logic.");
        }
    }
}