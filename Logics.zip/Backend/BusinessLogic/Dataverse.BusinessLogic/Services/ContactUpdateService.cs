﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IdentityModel.Protocols.WSTrust;
using System.Linq;
using System.Text.RegularExpressions;

using EntityNames = Cultivate.Entities.Generated.EntityNames;

namespace Cultivate.BusinessLogic.Services
{
    public interface IContactUpdateService
    {
        void CreateDeactivateConsents(Entity contact, Entity preImage);
        void OptOutConsentsDeceasedContact(Entity target);
        void CancelDDIsOfContact(Entity entity);
        void GetMembershipWhereMemberIsDeceased(Contact targetContact, IPropertyRetrievalService propertyRetrievalService, IProductService productService);
        void CancelSubscriptionContactIsDeceased(Contact targetContact);
        void CancelDonationsOfContactWhenDeceased(Contact targetContact);
        void validatedNameInputUpdate(Contact contact, (string value, string name, string fieldName)[] fields);
        void contactPopulateGDPRDeletionDate(Contact contact);
        void contactPopulateInitials(Contact contact);
        void contactPopulateAge(Contact contact);
        void contactPopulateSalutation(Contact contact);
        void contactCreateNameChange(Contact postcontact, Contact precontact);
        void contactPopulateLabelName(Contact contact);
        public void contactCreateAddress1Change(Contact postcontact, Contact precontact);
        public void contactCreateAddress2Change(Contact postcontact, Contact precontact);
        public void contactCreateLoqateAddressChange(Contact postcontact, Contact precontact);
        void populateAddressOnUpdate(Entity entity, Contact preUpdate, Contact postUpdate);
        void populateLoqateAddressOnUpdate(Entity entity, Contact preUpdate, Contact postUpdate);
    }

    public class ContactUpdateService : IContactUpdateService
    {
        private readonly ITracingService _tracingService;
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;
        private readonly IPluginExecutionContext _context;
        private readonly IRepository<Contact> _contactRepository;
        private readonly IRepository<Membership> _membershipRepository;
        private readonly IRepository<Donation> _donationRepository;
        private readonly IRepository<Product> _productRepository;
        private readonly IRepository<Transaction> _transactionRepository;
        private readonly IRepository<Payment> _paymentRepository;
        private readonly MembershipCreateService _membershipCreateService;
        private readonly MembershipUpdateService _membershipUpdateService;
        private readonly ICustomAPIInvocationService _customAPIInvocationService;
        private readonly ICommonService _commonService;

        public ContactUpdateService(
            ITracingService tracingService, ILogger logger,
            IPluginExecutionContext context,
            IRepository<Contact> contactRepository, IRepository<Membership> membershipRepository, IRepository<Donation> donationRepository,
            IRepository<Product> productRepository, IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository,
            IOrganizationService service,
            MembershipCreateService membershipCreateService,
            MembershipUpdateService membershipUpdateService,
            ICustomAPIInvocationService customAPIInvocationService,
            ICommonService commonService
        )
        {
            _tracingService = tracingService;
            _logger = logger;
            _context = context;
            _contactRepository = contactRepository;
            _membershipRepository = membershipRepository;
            _donationRepository = donationRepository;
            _productRepository = productRepository;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _service = service;
            _membershipCreateService = membershipCreateService;
            _membershipUpdateService = membershipUpdateService;
            _customAPIInvocationService = customAPIInvocationService;
            _commonService = commonService;
        }

        public void GetMembershipWhereMemberIsDeceased(Contact targetContact, IPropertyRetrievalService propertyRetrievalService , IProductService productService)
        {
            _logger.TraceInformation($"Starting business logic.");

            var contactMemberships = GetMembershipsWithContactAsPayerOrMember(targetContact.Id);

            if (contactMemberships.Count > 0)
            {
                _logger.TraceInformation($"contactMemberships Count: {contactMemberships.Count}");

                foreach (var membership in contactMemberships)
                {
                    List<Transaction> overDuetransactions = new List<Transaction>();
                    _logger.TraceInformation($"MembershipId: {membership.Id}");
                    bool memberAisDeceased = false, memberBisDeceased = false, payerIsDeceased = false;
                    Entity memberA = null, memberB = null, Payer = null;

                    if (membership.Contact?.Id != null)
                    {

                        memberA = _service.Retrieve(EntityNames.Contact.EntityLogicalName, membership.Contact.Id, new ColumnSet("rhs_deceased", "contactid", "fullname"));
                        memberAisDeceased = memberA.Contains("rhs_deceased") && memberA["rhs_deceased"] != null && (bool)memberA["rhs_deceased"];
                        string memberAfullName = memberA.Contains("fullname") && memberA["fullname"] != null ? memberA["fullname"].ToString() : string.Empty;
                        _logger.TraceInformation($"memberAisDeceased: {memberAisDeceased}");
                        _logger.TraceInformation($"memberAfullName: {memberAfullName}");

                    }
                    if (membership.Member2ContactRef?.Id != null)
                    {
                        memberB = _service.Retrieve(EntityNames.Contact.EntityLogicalName, membership.Member2ContactRef.Id, new ColumnSet("rhs_deceased", "contactid", "fullname"));

                        memberBisDeceased = memberB.Contains("rhs_deceased") && memberB["rhs_deceased"] != null && (bool)memberB["rhs_deceased"];
                        string memberBfullName = memberB.Contains("fullname") && memberB["fullname"] != null ? memberB["fullname"].ToString() : string.Empty;

                        _logger.TraceInformation($"memberBisDeceased: {memberBisDeceased}");
                        _logger.TraceInformation($"memberBfullName: {memberBfullName}");

                    }
                    _logger.TraceInformation($"PayerLogicalName: {membership.PayerV2.LogicalName}");
                    if (membership.PayerV2?.Id != null && membership.PayerV2.LogicalName == "contact")
                    {
                        Payer = _service.Retrieve(EntityNames.Contact.EntityLogicalName, membership.PayerV2.Id, new ColumnSet("rhs_deceased", "contactid", "fullname"));

                        payerIsDeceased = Payer.Contains("rhs_deceased") && Payer["rhs_deceased"] != null && (bool)Payer["rhs_deceased"];
                        string payerfullName = Payer.Contains("fullname") && Payer["fullname"] != null ? Payer["fullname"].ToString() : string.Empty;
                        _logger.TraceInformation($"payerisDeceased: {payerIsDeceased}");
                        _logger.TraceInformation($"payerfullName: {payerfullName}");

                    }

                    var membrshipProduct = _productRepository.GetById(membership.MembershipProductId.Id);

                    overDuetransactions = _transactionRepository.GetAll()
                      .Where(transaction =>
                          transaction.MembershipIdMembershipRef != null &&
                          transaction.MembershipIdMembershipRef.Id == membership.Id &&
                          transaction.Statuscode == TransactionStatus.Active_Overdue)
                      .ToList();

                    _logger.TraceInformation($"overdueMembershipTransactionCount : {overDuetransactions.Count}");


                    //get Product Properties
                    if (membrshipProduct != null)
                    {

                        var propertyService = new PropertyRetrievalService(_tracingService, _context, _service);


                        var allowedMember = propertyService.GetProductProperty(membrshipProduct.Id, "Number of Members Allowed");

                        _logger.TraceInformation($"allowedMember: {allowedMember.DefaultValueInteger.Value}");

                        if (allowedMember.DefaultValueInteger.Value > 1)
                        {
                            //Joint Membership Update
                            _membershipUpdateService.UpdateJointMembershipFromDeceased(membership, memberA, memberB, Payer);

                            # region Joint Transaction Cancellation
                            bool isJointpayerDifferentPerson = false;

                            if (memberA.Id != Payer.Id && memberB.Id != Payer.Id)
                            {
                                isJointpayerDifferentPerson = true;
                            }

                            if ((memberAisDeceased || memberBisDeceased) && !isJointpayerDifferentPerson)
                            {
                                if (membership.Contains(EntityNames.Membership.PaymentMethod) &&
                                 (membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                                 membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                                 membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                                 membership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                                 membership.IsContinuousPayment.Value == true && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly)
                                {
                                    CancelMembershipTransaction(membership);
                                }
                            }
                            else if (payerIsDeceased && isJointpayerDifferentPerson)
                            {
                                if (membership.Contains(EntityNames.Membership.PaymentMethod) &&
                                (membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                                membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                                membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                                membership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                                membership.IsContinuousPayment.Value == true && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly)
                                {
                                    CancelMembershipTransaction(membership);
                                }
                            }
                            #endregion
                        }
                        else if (allowedMember.DefaultValueInteger.Value == 1)
                        {
                            //Individual
                            _membershipUpdateService.UpdateIndividualMembershipFromDeceased(membership, memberA, Payer);

                            #region Individual Transaction Cancellation
                            bool isIndividualpayerDifferentPerson = false;

                            if (memberA.Id != Payer.Id)
                            {
                                isIndividualpayerDifferentPerson = true;
                            }

                            if (payerIsDeceased && isIndividualpayerDifferentPerson) {

                                if (membership.Contains(EntityNames.Membership.PaymentMethod) &&
                                (membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                                membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                                membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                                membership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                                membership.IsContinuousPayment.Value == true && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly)
                                {
                                    CancelMembershipTransaction(membership);
                                }

                            }
                            #endregion

                        }


                    }

                }
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void CancelMembershipTransaction(Membership membership)
        {

            List<Transaction> transactions = new List<Transaction>();
            transactions = _transactionRepository.GetAll()
                 .Where(transaction =>
                     transaction.MembershipIdMembershipRef != null &&
                     transaction.MembershipIdMembershipRef.Id == membership.Id
                  )
                 .ToList();
            _logger.TraceInformation($"transactionsCount: {transactions.Count}");

            if (transactions.Count != 0)
            {
                foreach (var item in transactions)
                {

                    _logger.TraceInformation($"transactionsCount: {item.TransacID}");
                    _logger.TraceInformation($"transactionsCount: {item.Id}");

                    GetRelatedPaymentFromTransactionAndCancel(_service, item.Id);
                    GetRelatedPaymentScheduleFromTransactionAndCancel(_service, (int?)item.TransactionType, membership.Id);

                    SetTransactionStatusToCancelled(_service, item.Id);
                }
            }
        }

        public bool IsCrmDateLessThanTwoMonthsFromNow(DateTime crmDate)
        {
            DateTime currentDatePlusTwoMonths = DateTime.Now.AddMonths(2);
            return crmDate < currentDatePlusTwoMonths;
        }

        private List<Membership> GetMembershipsWithContactAsPayerOrMember(Guid contactId)
        {
            _logger.TraceInformation($"GetMembershipsWithContactAsPayerOrMember.");

            var membershipsWithContactAsPayer = GetMembershipsWithContactAsPayer(contactId);
            var membershipsWithContactAsMember = GetMembershipsWithContactAsMember(contactId);

            var allMemberships = membershipsWithContactAsPayer.Concat(membershipsWithContactAsMember);

            // Group by Id and select the first membership in each group
            var distinctMemberships = allMemberships
                .GroupBy(m => m.Id) // Group by unique property
                .Select(g => g.First())
                .ToList();
            _logger.TraceInformation($"GetMembershipsWithContactAsPayerOrMember Count: {distinctMemberships.Count}");
            _logger.TraceInformation($"Ending GetMembershipsWithContactAsPayerOrMember");
            return distinctMemberships;
        }

        private List<Membership> GetMembershipsWithContactAsPayer(Guid contactId)
        {
            _logger.TraceInformation($"Starting GetMembershipsWithContactAsPayer business logic.");

            var memberships = _membershipRepository.GetAll().Where(
                membership => membership.PayerV2 != null && membership.PayerV2.Id == contactId && membership.Statecode == MembershipState.Active
            ).ToList();
            _logger.TraceInformation($"Count:{memberships.Count}");
            _logger.TraceInformation($"Ending business logic.");

            return memberships;
        }

        private List<Membership> GetMembershipsWithContactAsMember(Guid contactId)
        {
            _logger.TraceInformation($"Starting GetMembershipsWithContactAsMember business logic.");

            var query = new QueryExpression(EntityNames.Membership.EntityLogicalName);
            query.ColumnSet.AllColumns = true;


            var query_rhs_rhs_membership_contact_mm = query.AddLink(
                "rhs_rhs_membership_contact_mm",
                "rhs_membershipid",
                "rhs_membershipid");
            query_rhs_rhs_membership_contact_mm.LinkCriteria.AddCondition("contactid", ConditionOperator.Equal, contactId);

            var membershipEntities = _service.RetrieveMultiple(query).Entities;

            if (membershipEntities == null || !membershipEntities.Any())
            {
                _logger.TraceInformation("No memberships found for the given contact.");
                return new List<Membership>(); // Return empty list if no memberships found
            }

            var memberships = membershipEntities.Select(entity => entity.ToEntity<Membership>()).ToList();

            var activemembership = memberships.Where(mem => mem.Statecode == MembershipState.Active).ToList();
            _logger.TraceInformation($"Count:{activemembership.Count}");
            _logger.TraceInformation($"Ending business logic.");
            return activemembership;
        }

        private List<Contact> GetContactAsMember(Guid membershipd)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression(EntityNames.Contact.EntityLogicalName);
            query.ColumnSet.AllColumns = true;

            var query_rhs_rhs_membership_contact_mm = query.AddLink(
                "rhs_rhs_membership_contact_mm",
                "contactid",
                "contactid");
            query_rhs_rhs_membership_contact_mm.LinkCriteria.AddCondition("rhs_membershipid", ConditionOperator.Equal, membershipd);

            var membershipEntities = _service.RetrieveMultiple(query).Entities;
            var contacts = membershipEntities.Select(entity => entity.ToEntity<Contact>()).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return contacts;
        }

        public void CreateDeactivateConsents(Entity target, Entity preImage)
        {
            _tracingService.Trace("CreateDeactivateConsents Start");

            try
            {
                #region Initialization
                Guid contactId = target.Id;

                Entity contact = GetContactDetails(contactId);

                string fullName = contact.Contains(EntityNames.Contact.FullName) ? (string)contact[EntityNames.Contact.FullName] : null;
                _tracingService.Trace($"Contact Full Name: {fullName}");

                string newEmail = contact.Contains(EntityNames.Contact.EMailAddress1) ? (string)contact[EntityNames.Contact.EMailAddress1] : null;
                string newPhone = contact.Contains(EntityNames.Contact.Telephone1) ? (string)contact[EntityNames.Contact.Telephone1] : null;
                string newPost = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;

                _tracingService.Trace($"New Email: {newEmail}");
                _tracingService.Trace($"New Phone: {newPhone}");
                _tracingService.Trace($"New Post: {newPost}");

                string oldEmail = preImage.Contains(EntityNames.Contact.EMailAddress1) ? (string)preImage[EntityNames.Contact.EMailAddress1] : null;
                string oldPhone = preImage.Contains(EntityNames.Contact.Telephone1) ? (string)preImage[EntityNames.Contact.Telephone1] : null;
                string oldPost = preImage.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)preImage[EntityNames.Contact.Address1_PostalCode] : null;

                _tracingService.Trace($"Old Email: {oldEmail}");
                _tracingService.Trace($"Old Phone: {oldPhone}");
                _tracingService.Trace($"Old Post: {oldPost}");


                EntityReference countryCodePhoneRef = null;
                string countryCodePhone = string.Empty;
                string formattedNewPhone = string.Empty;
                string concatenatedNewPost = string.Empty;
                string countryCodeOldPhone = string.Empty;
                string formattedOldPhone = string.Empty;
                string concatenatedOldPost = string.Empty;

                EntityCollection associatedConsents = null;
                int existingDataSet = 0;
                bool hasAssociatedContacts = false;
                int contactDataSet = 120000007;

                if (!string.IsNullOrEmpty(newPhone) && !string.IsNullOrEmpty(oldPhone) && newPhone != oldPhone)
                {
                    _tracingService.Trace($"New Phone: {newPhone}");
                    _tracingService.Trace($"Old Phone: {oldPhone}");

                    countryCodePhoneRef = contact.Contains(EntityNames.Contact.CountryPhone1) ? (EntityReference)contact[EntityNames.Contact.CountryPhone1] : null;
                    if (countryCodePhoneRef != null)
                    {
                        _tracingService.Trace("Retrieving country code for telephone...");
                        Entity countryCodeEntity = _service.Retrieve(countryCodePhoneRef.LogicalName, countryCodePhoneRef.Id, new ColumnSet("rhs_countryid", "rhs_callingcode"));
                        countryCodePhone = countryCodeEntity.Contains("rhs_callingcode") ? (string)countryCodeEntity["rhs_callingcode"] : null;
                    }

                    _tracingService.Trace($"Phone Code: {countryCodePhone}");
                    formattedNewPhone = countryCodePhone + newPhone;
                    formattedOldPhone = countryCodePhone + oldPhone;

                    _tracingService.Trace($"New Telephone: {formattedNewPhone}");
                    _tracingService.Trace($"Old Telephone: {formattedOldPhone}");
                }
                else if (!string.IsNullOrEmpty(newPhone) && string.IsNullOrEmpty(oldPhone))
                {
                    countryCodePhoneRef = contact.Contains(EntityNames.Contact.CountryPhone1) ? (EntityReference)contact[EntityNames.Contact.CountryPhone1] : null;
                    if (countryCodePhoneRef != null)
                    {
                        _tracingService.Trace("Retrieving country code for telephone...");
                        Entity countryCodeEntity = _service.Retrieve(countryCodePhoneRef.LogicalName, countryCodePhoneRef.Id, new ColumnSet("rhs_countryid", "rhs_callingcode"));
                        countryCodePhone = countryCodeEntity.Contains("rhs_callingcode") ? (string)countryCodeEntity["rhs_callingcode"] : null;
                    }

                    formattedNewPhone = countryCodePhone + newPhone;
                }
                else if (string.IsNullOrEmpty(newPhone) && !string.IsNullOrEmpty(oldPhone))
                {
                    _tracingService.Trace($"Old Phone: {oldPhone}");

                    countryCodePhoneRef = contact.Contains(EntityNames.Contact.CountryPhone1) ? (EntityReference)contact[EntityNames.Contact.CountryPhone1] : null;
                    if (countryCodePhoneRef != null)
                    {
                        _tracingService.Trace("Retrieving country code for telephone...");
                        Entity countryCodeEntity = _service.Retrieve(countryCodePhoneRef.LogicalName, countryCodePhoneRef.Id, new ColumnSet("rhs_countryid", "rhs_callingcode"));
                        countryCodePhone = countryCodeEntity.Contains("rhs_callingcode") ? (string)countryCodeEntity["rhs_callingcode"] : null;
                    }

                    _tracingService.Trace($"Phone Code: {countryCodePhone}");
                    formattedOldPhone = countryCodePhone + oldPhone;

                    _tracingService.Trace($"Old Telephone: {formattedOldPhone}");
                }

                if (!string.IsNullOrEmpty(newPost) && !string.IsNullOrEmpty(oldPost) && newPost != oldPost)
                {
                    concatenatedNewPost = $"{fullName} - {newPost}";
                    concatenatedOldPost = $"{fullName} - {oldPost}";
                }
                else if (!string.IsNullOrEmpty(newPost) && string.IsNullOrEmpty(oldPost))
                {
                    concatenatedNewPost = $"{fullName} - {newPost}";
                }
                else if (string.IsNullOrEmpty(newPost) && !string.IsNullOrEmpty(oldPost))
                {
                    concatenatedOldPost = $"{fullName} - {oldPost}";
                }
                #endregion

                #region Logic
                //Email
                if (!string.IsNullOrEmpty(oldEmail) && !string.IsNullOrEmpty(newEmail) && oldEmail != newEmail)
                {
                    //Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), oldEmail);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), oldEmail);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with oldEmail
                                DeactivateContactPointConsent(associatedConsent.Id);

                                //Create Consents for newEmail
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with oldEmail
                                DisassociateContactToConsent(associatedConsent.Id, contactId);

                                //Create Consents for newEmail
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                        }
                    }
                    else
                    {
                        //Create Consents for newEmail
                        InvokeConsentCreationApi(contactId.ToString(), 120000007);
                    }
                }
                else if (string.IsNullOrEmpty(oldEmail) && !string.IsNullOrEmpty(newEmail))
                {
                    //Call Consents with Data Set = Contact
                    InvokeConsentCreationApi(contactId.ToString(), contactDataSet);
                }
                else if (!string.IsNullOrEmpty(oldEmail) && string.IsNullOrEmpty(newEmail))
                {
                    //Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), oldEmail);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), oldEmail);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with oldEmail
                                DeactivateContactPointConsent(associatedConsent.Id);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with oldEmail
                                DisassociateContactToConsent(associatedConsent.Id, contactId);
                            }
                        }
                    }
                }

                //Phone
                if (!string.IsNullOrEmpty(formattedOldPhone) && !string.IsNullOrEmpty(formattedNewPhone) && formattedOldPhone != formattedNewPhone)
                {
                    //Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), formattedOldPhone);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), formattedOldPhone);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with formattedOldPhone
                                DeactivateContactPointConsent(associatedConsent.Id);

                                //Create Consents for formattedNewPhone
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with formattedOldPhone
                                DisassociateContactToConsent(associatedConsent.Id, contactId);

                                //Create Consents for formattedNewPhone
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                        }
                    }
                    else
                    {
                        //Create Consents for formattedNewPhone
                        InvokeConsentCreationApi(contactId.ToString(), 120000007);
                    }
                }
                else if (string.IsNullOrEmpty(formattedOldPhone) && !string.IsNullOrEmpty(formattedNewPhone))
                {
                    //Call Consents with Data Set = Contact
                    InvokeConsentCreationApi(contactId.ToString(), contactDataSet);
                }
                else if (!string.IsNullOrEmpty(formattedOldPhone) && string.IsNullOrEmpty(formattedNewPhone))
                {
                    // Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), formattedOldPhone);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), formattedOldPhone);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with formattedOldPhone
                                DeactivateContactPointConsent(associatedConsent.Id);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with formattedOldPhone
                                DisassociateContactToConsent(associatedConsent.Id, contactId);
                            }
                        }
                    }
                }

                //Post
                if (!string.IsNullOrEmpty(concatenatedOldPost) && !string.IsNullOrEmpty(concatenatedNewPost) && concatenatedOldPost != concatenatedNewPost)
                {
                    //Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), concatenatedOldPost);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), concatenatedOldPost);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with concatenatedOldPost
                                DeactivateContactPointConsent(associatedConsent.Id);

                                //Create Consents for concatenatedNewPost
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with concatenatedOldPost
                                DisassociateContactToConsent(associatedConsent.Id, contactId);

                                //Create Consents for concatenatedNewPost
                                InvokeConsentCreationApi(contactId.ToString(), existingDataSet);
                            }
                        }
                    }
                    else
                    {
                        //Create Consents for concatenatedNewPost
                        InvokeConsentCreationApi(contactId.ToString(), 120000007);
                    }
                }
                else if (string.IsNullOrEmpty(concatenatedOldPost) && !string.IsNullOrEmpty(concatenatedNewPost))
                {
                    //Call Consents with Data Set = Contact
                    InvokeConsentCreationApi(contactId.ToString(), contactDataSet);
                }
                else if (!string.IsNullOrEmpty(concatenatedOldPost) && string.IsNullOrEmpty(concatenatedNewPost))
                {
                    //Check if any Consents is associated with the Contact with old email
                    associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), concatenatedOldPost);
                    _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                    if (associatedConsents.Entities.Count > 0)
                    {
                        foreach (var associatedConsent in associatedConsents.Entities)
                        {
                            existingDataSet = associatedConsent.Contains("rhs_dataset") ? ((OptionSetValue)associatedConsent["rhs_dataset"]).Value : 120000007;

                            //Check if any Contact is associated with the retrieved Consent with old email
                            hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), concatenatedOldPost);

                            if (!hasAssociatedContacts)
                            {
                                //Deactivate the Consents with concatenatedOldPost
                                DeactivateContactPointConsent(associatedConsent.Id);
                            }
                            else
                            {
                                //Disassociate the Contact to the Consents with concatenatedOldPost
                                DisassociateContactToConsent(associatedConsent.Id, contactId);
                            }
                        }
                    }
                }
                #endregion

                _tracingService.Trace("CreateDeactivateConsents End");
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException($"Executing CreateDeactivateConsents has an error: {ex.Message} ");
            }
        }

        private EntityCollection CheckConsentsAssociatedToContact(string contactId, string contactPointValue)
        {
            QueryExpression queryAssociatedConsentsToContact = new QueryExpression(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName);
            queryAssociatedConsentsToContact.ColumnSet.AddColumns(
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryNameAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value,
                EntityNames.Msdynmkt_contactpointconsent4.Statecode,
                EntityNames.Msdynmkt_contactpointconsent4.Dataset

            );

            // Add conditions to query.Criteria
            queryAssociatedConsentsToContact.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Statecode, ConditionOperator.Equal, 0);
            queryAssociatedConsentsToContact.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.PrimaryNameAttribute, ConditionOperator.Equal, contactPointValue);

            var ad = queryAssociatedConsentsToContact.AddLink(
                EntityNames.Contact_msdynmkt_contactpointconsent4.EntityLogicalName,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsent4id
            );
            ad.EntityAlias = "ad";

            var ae = ad.AddLink(
                EntityNames.Contact.EntityLogicalName,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Contactid,
                EntityNames.Contact.PrimaryIdAttribute
            );
            ae.EntityAlias = "ae";

            ae.Columns.AddColumn(EntityNames.Contact.PrimaryIdAttribute);
            ae.LinkCriteria.AddCondition(EntityNames.Contact.PrimaryIdAttribute, ConditionOperator.Equal, contactId);

            var result = _service.RetrieveMultiple(queryAssociatedConsentsToContact);

            return result;
        }

        private bool CheckContactsToConsents(string contactId, string contactPointValue)
        {
            QueryExpression queryAssociatedContactsToConsents = new QueryExpression(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName);
            queryAssociatedContactsToConsents.ColumnSet.AddColumns(
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryNameAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value,
                EntityNames.Msdynmkt_contactpointconsent4.Statecode,
                EntityNames.Msdynmkt_contactpointconsent4.Dataset

            );

            // Add conditions to query.Criteria
            queryAssociatedContactsToConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Statecode, ConditionOperator.Equal, 0);
            queryAssociatedContactsToConsents.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.PrimaryNameAttribute, ConditionOperator.Equal, contactPointValue);

            var ad = queryAssociatedContactsToConsents.AddLink(
                EntityNames.Contact_msdynmkt_contactpointconsent4.EntityLogicalName,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsent4id
            );
            ad.EntityAlias = "ad";

            var ae = ad.AddLink(
                EntityNames.Contact.EntityLogicalName,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Contactid,
                EntityNames.Contact.PrimaryIdAttribute
            );
            ae.EntityAlias = "ae";

            ae.Columns.AddColumn(EntityNames.Contact.PrimaryIdAttribute);
            ae.LinkCriteria.AddCondition(EntityNames.Contact.PrimaryIdAttribute, ConditionOperator.NotEqual, contactId);

            var result = _service.RetrieveMultiple(queryAssociatedContactsToConsents);

            // If any records are returned, consent has associated contact/s 
            bool hasAssociatedContacts = result.Entities.Any();

            _tracingService.Trace($"Is Contact associated with Consents: {hasAssociatedContacts}");

            return hasAssociatedContacts;
        }

        public Entity GetContactDetails(Guid contactId)
        {
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactId,
                    new ColumnSet(
                        EntityNames.Contact.EMailAddress1, EntityNames.Contact.Telephone1, EntityNames.Contact.Address1_PostalCode,
                        EntityNames.Contact.CountryPhone1, EntityNames.Contact.FullName
                    ));
            return contact;
        }

        private void DisassociateContactToConsent(Guid contactPointConsentId, Guid contactId)
        {
            if (contactPointConsentId == Guid.Empty || contactId == Guid.Empty)
            {
                _tracingService.Trace("Contact Point Consent ID or Contact ID is empty. Skipping association.");
                return;
            }

            _service.Disassociate(
                EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName,
                contactPointConsentId,
                new Relationship("rhs_contact_msdynmkt_contactpointconsent4_MM"),
                new EntityReferenceCollection
                {
                       new EntityReference(EntityNames.Contact.EntityLogicalName, contactId)
                }
            );

            _tracingService.Trace("Contact disassociated with Contact Point Consent successfully.");
        }

        private void DeactivateContactPointConsent(Guid contactPointConsentId)
        {
            Entity record = new Entity(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, new Guid(contactPointConsentId.ToString()));
            record[EntityNames.Msdynmkt_contactpointconsent4.Statecode] = new OptionSetValue(1); // State
            _service.Update(record);

            _tracingService.Trace($"Deactivating the old consent {record.Id} completed.");
        }

        public void InvokeConsentCreationApi(string contactId, int newMemberDataSet)
        {
            try
            {
                OrganizationRequest apiRequest = new OrganizationRequest("rhs_consentscreation")
                {
                    Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", newMemberDataSet }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse apiResponse = _service.Execute(apiRequest);

                // Check the response for success or failure
                if (apiResponse != null && apiResponse.Results.Contains("result") && (bool)apiResponse.Results["result"])
                {
                    _tracingService.Trace("Consent creation via API was successful.");
                }
                else if (apiResponse != null && apiResponse.Results.Contains("error"))
                {
                    string error = apiResponse.Results["error"].ToString();
                    _tracingService.Trace($"Consent creation via API failed. Error: {error}");
                    throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
                }

                _tracingService.Trace("Custom API executed successfully.");

            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception during Custom API invocation: {0}", ex.ToString());
                throw new InvalidPluginExecutionException($"Error invoking Custom API: {ex.Message}", ex);
            }
        }

        public void OptOutConsentsDeceasedContact(Entity target)
        {
            _tracingService.Trace("OptOutConsentsDeceasedContact Start");

            Guid userId = _context.UserId;

            // Retrieve the user's full name from the SystemUser entity
            Entity userEntity = _service.Retrieve(EntityNames.SystemUser.EntityLogicalName, userId, new ColumnSet(EntityNames.SystemUser.FullName));
            string userName = string.Empty;
            if (userEntity != null && userEntity.Contains(EntityNames.SystemUser.FullName))
            {
                userName = userEntity[EntityNames.SystemUser.FullName].ToString();

                _tracingService.Trace($"Process triggered by user: {userName}");
            }

            if (target.Contains(EntityNames.Contact.Deceased))
            {
                bool isDeceased = (bool)target[EntityNames.Contact.Deceased];

                if (isDeceased)
                {
                    Guid contactId = target.Id;

                    Entity contact = GetContactDetails(contactId);

                    string fullName = contact.Contains(EntityNames.Contact.FullName) ? (string)contact[EntityNames.Contact.FullName] : null;
                    _tracingService.Trace($"Contact Full Name: {fullName}");

                    string email = contact.Contains(EntityNames.Contact.EMailAddress1) ? (string)contact[EntityNames.Contact.EMailAddress1] : null;
                    string phone = contact.Contains(EntityNames.Contact.Telephone1) ? (string)contact[EntityNames.Contact.Telephone1] : null;
                    string post = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;

                    _tracingService.Trace($"Email: {email}");
                    _tracingService.Trace($"Phone: {phone}");
                    _tracingService.Trace($"Post: {post}");

                    EntityReference countryCodePhoneRef = null;
                    string countryCodePhone = string.Empty;
                    string formattedPhone = string.Empty;
                    string concatenatedPost = string.Empty;
                    EntityCollection associatedConsents = null;
                    bool hasAssociatedContacts = false;

                    if (!string.IsNullOrEmpty(phone))
                    {
                        countryCodePhoneRef = contact.Contains(EntityNames.Contact.CountryPhone1) ? (EntityReference)contact[EntityNames.Contact.CountryPhone1] : null;
                        if (countryCodePhoneRef != null)
                        {
                            Entity countryCodeEntity = _service.Retrieve(countryCodePhoneRef.LogicalName, countryCodePhoneRef.Id, new ColumnSet(EntityNames.Country.PrimaryIdAttribute, EntityNames.Country.CallingCode));
                            countryCodePhone = countryCodeEntity.Contains(EntityNames.Country.CallingCode) ? (string)countryCodeEntity[EntityNames.Country.CallingCode] : null;
                        }
                        formattedPhone = countryCodePhone + phone;
                    }

                    if (!string.IsNullOrEmpty(post))
                    {
                        concatenatedPost = $"{fullName} - {post}";
                    }


                    if (!string.IsNullOrEmpty(email))
                    {
                        associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), email);
                        _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                        if (associatedConsents.Entities.Count > 0)
                        {
                            foreach (var associatedConsent in associatedConsents.Entities)
                            {
                                hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), email);

                                if (!hasAssociatedContacts)
                                {
                                    //Opt-Out Consents of Contacts
                                    OptOutContactPointConsent(associatedConsent.Id, userName);
                                }
                                else
                                {
                                    //Disassociate the Contact to the Consents
                                    DisassociateContactToConsent(associatedConsent.Id, contactId);
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(phone))
                    {
                        //Check if any Consents is associated with the Contact with phone
                        associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), formattedPhone);
                        _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                        if (associatedConsents.Entities.Count > 0)
                        {
                            foreach (var associatedConsent in associatedConsents.Entities)
                            {
                                hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), formattedPhone);

                                if (!hasAssociatedContacts)
                                {
                                    //Opt-Out Consents of Contacts
                                    OptOutContactPointConsent(associatedConsent.Id, userName);
                                }
                                else
                                {
                                    //Disassociate the Contact to the Consents
                                    DisassociateContactToConsent(associatedConsent.Id, contactId);
                                }
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(concatenatedPost))
                    {
                        associatedConsents = CheckConsentsAssociatedToContact(contactId.ToString(), concatenatedPost);
                        _tracingService.Trace($"Associated Consents Count: {associatedConsents.Entities.Count}");

                        if (associatedConsents.Entities.Count > 0)
                        {
                            foreach (var associatedConsent in associatedConsents.Entities)
                            {
                                hasAssociatedContacts = CheckContactsToConsents(contactId.ToString(), concatenatedPost);

                                if (!hasAssociatedContacts)
                                {
                                    //Opt-Out Consents of Contacts
                                    OptOutContactPointConsent(associatedConsent.Id, userName);
                                }
                                else
                                {
                                    //Disassociate the Contact to the Consents
                                    DisassociateContactToConsent(associatedConsent.Id, contactId);
                                }
                            }
                        }
                    }
                }
            }

            _tracingService.Trace("OptOutConsentsDeceasedContact End");
        }

        private void OptOutContactPointConsent(Guid contactPointConsentId, string userName)
        {
            Entity record = new Entity(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName, contactPointConsentId);
            record[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value] = new OptionSetValue(534120002); // Opt Out: 534120002
            record[EntityNames.Msdynmkt_contactpointconsent4.ModifiedOnBehalfBy] = userName;
            _service.Update(record);

            _tracingService.Trace($"Opting Out the consent {record.Id} completed.");
        }

        public void HandleStudentCancellation(Entity target, ITracingService tracingService, IOrganizationService service)
        {

            tracingService.Trace("Start Student Cancellation");
            tracingService.Trace("Start Student Cancellation: Checking Memberbsip");

            var query = new QueryExpression(EntityNames.Membership.EntityLogicalName)
            {
                ColumnSet = new ColumnSet(EntityNames.Membership.Contact, EntityNames.Membership.Statuscode),
                Criteria = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                      new ConditionExpression(EntityNames.Membership.Contact, ConditionOperator.Equal, target.Id),
                      new ConditionExpression(EntityNames.Membership.Statecode , ConditionOperator.Equal, 0)
                    }
                }
            };

            var memberships = service.RetrieveMultiple(query);

            if (memberships.Entities.Count > 0)
            {
                tracingService.Trace($"Start Student Cancellation:Memberbsip Count:{memberships.Entities.Count}");
                tracingService.Trace($"Start Student Cancellation:Get Cancellation Reason");

                var cancellationReason = GetCancellationReason(service, "ID Not Valid");

                if (cancellationReason != null)
                {

                    tracingService.Trace($"Start Student Cancellation: Cancellation Reason ID: {cancellationReason.Id} ,  Cancellation Reason Name: {cancellationReason["rhs_name"]}");

                    var membership = memberships.Entities[0]; //

                    membership[EntityNames.Membership.CancelMembership] = true;
                    membership[EntityNames.Membership.CancellationType] = new OptionSetValue(120000000);
                    membership[EntityNames.Membership.MembershipCancellationReasonId] = new EntityReference("rhs_cancellationreason", cancellationReason.Id); ;
                    membership[EntityNames.Membership.CancellationDate] = DateTime.UtcNow;
                    membership[EntityNames.Membership.Enddate] = DateTime.UtcNow;
                    membership[EntityNames.Membership.Statecode] = new OptionSetValue(1);
                    membership[EntityNames.Membership.Statuscode] = new OptionSetValue(2);

                    service.Update(membership); // Save changes

                    //var setStateRequest = new SetStateRequest
                    //{
                    //    EntityMoniker = new EntityReference(EntityNames.Msnfp_membership.EntityLogicalName, membership.Id),
                    //    State = new OptionSetValue(1), // 1 for inactive
                    //    Status = new OptionSetValue(2) // 
                    //};

                    //service.Execute(setStateRequest);
                }

            }
            else
            {
                tracingService.Trace("Start Student Cancellation: Error, Membership is not active");
            }
        }

        public Entity GetCancellationReason(IOrganizationService service, string name)
        {
            var cancellationQuery = new QueryExpression("rhs_cancellationreason")
            {
                ColumnSet = new ColumnSet("rhs_cancellationreasonid", "rhs_name"),
                Criteria = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                        new ConditionExpression("rhs_name", ConditionOperator.Equal, name),
                    }
                }
            };

            var cancellationReasonCollection = service.RetrieveMultiple(cancellationQuery);
            return cancellationReasonCollection.Entities.Count > 0 ? cancellationReasonCollection.Entities[0] : null;
        }

        public void GetRelatedPaymentFromPaymentSchedulenAndCancel(IOrganizationService service, Guid paymentScheduleId)
        {
            // Create a query expression
            QueryExpression query = new QueryExpression("rhs_payment")
            {
                ColumnSet = new ColumnSet(
                    "rhs_paymentid",
                    "statuscode",
                    "statecode"
                )
            };
            // Create filters
            FilterExpression filter1 = new FilterExpression(LogicalOperator.Or);
            filter1.AddCondition("statuscode", ConditionOperator.Equal, 120000002);
            filter1.AddCondition("statuscode", ConditionOperator.Equal, 1);

            FilterExpression filter2 = new FilterExpression(LogicalOperator.And);
            filter2.AddCondition("statecode", ConditionOperator.Equal, 0);
            filter2.AddCondition("rhs_paymentschedule", ConditionOperator.Equal, paymentScheduleId);

            // Combine filters
            FilterExpression mainFilter = new FilterExpression(LogicalOperator.And);
            mainFilter.AddFilter(filter1);
            mainFilter.AddFilter(filter2);

            // Assign the combined filter to the query criteria
            query.Criteria = mainFilter;

            // Execute the query
            EntityCollection results = service.RetrieveMultiple(query);
            _logger.TraceInformation($"GetRelatedPaymentFromTransactionAndCancel: {results.Entities.Count}");
            foreach (var entity in results.Entities)
            {
                _logger.TraceInformation($"GetRelatedPaymentFromTransactionAndCancel: {entity.Id}");

                var setStateRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(entity.LogicalName, entity.Id),
                    State = new OptionSetValue(1), // 1 for inactive
                    Status = new OptionSetValue(120000004) // 
                };

                service.Execute(setStateRequest);

            }
        }
        public void GetRelatedPaymentFromTransactionAndCancel(IOrganizationService service, Guid transactionId)
        {
            // Create a query expression
            QueryExpression query = new QueryExpression("rhs_payment")
            {
                ColumnSet = new ColumnSet(
                    "rhs_paymentid",
                    "statuscode",
                    "statecode"
                )
            };
            // Create filters
            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("statecode", ConditionOperator.Equal, 0);
            filter.AddCondition("rhs_transaction", ConditionOperator.Equal, transactionId);

            // Combine filters
            FilterExpression mainFilter = new FilterExpression(LogicalOperator.And);
            mainFilter.AddFilter(filter);

            // Assign the combined filter to the query criteria
            query.Criteria = mainFilter;

            // Execute the query
            EntityCollection results = service.RetrieveMultiple(query);
            _logger.TraceInformation($"GetRelatedPaymentFromTransactionAndCancel: {results.Entities.Count}");
            foreach (var entity in results.Entities)
            {
                _logger.TraceInformation($"GetRelatedPaymentFromTransactionAndCancel: {entity.Id}");

                var setStateRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(entity.LogicalName, entity.Id),
                    State = new OptionSetValue(1), // 1 for inactive
                    Status = new OptionSetValue(120000004) // 
                };
                service.Execute(setStateRequest);

            }
        }

        public void GetRelatedPaymentScheduleFromTransactionAndCancel(IOrganizationService service, int? type, Guid recordId)
        {
            // Create a query expression
            QueryExpression query = new QueryExpression("rhs_paymentschedule")
            {
                ColumnSet = new ColumnSet(
                    "rhs_paymentscheduleid",
                    "statuscode",
                    "statecode"
                )
            };

            // Create filters
            FilterExpression filter = new FilterExpression(LogicalOperator.And);
            filter.AddCondition("statecode", ConditionOperator.Equal, 0);
            switch (type)
            {
                case 120000002/*Membership*/:
                    filter.AddCondition("rhs_membershipid", ConditionOperator.Equal, recordId);
                    break;
                case 120000003/*Subscription*/:
                    filter.AddCondition("rhs_subscriptionid", ConditionOperator.Equal, recordId);
                    break;
            }

            // Combine filters
            FilterExpression mainFilter = new FilterExpression(LogicalOperator.And);
            mainFilter.AddFilter(filter);

            // Assign the combined filter to the query criteria
            query.Criteria = mainFilter;
            // Execute the query
            EntityCollection results = service.RetrieveMultiple(query);

            _logger.TraceInformation($"GetRelatedPaymentScheduleFromTransactionAndCancel: {results.Entities.Count}");
            foreach (var entity in results.Entities)
            {
                GetRelatedPaymentFromPaymentSchedulenAndCancel(service, entity.Id);

                _logger.TraceInformation($"GetRelatedPaymentScheduleFromTransactionAndCancel: {entity.Id}");

                var setStateRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(entity.LogicalName, entity.Id),
                    State = new OptionSetValue(1), // 1 for inactive
                    Status = new OptionSetValue(120000003) // 
                };

                service.Execute(setStateRequest);
            }
        }

        public void SetTransactionStatusToCancelled(IOrganizationService service, Guid recordId)
        {
            // Create the entity object 
            var setStateRequest = new SetStateRequest
            {
                EntityMoniker = new EntityReference("rhs_transaction", recordId),
                State = new OptionSetValue(1), // 1 for inactive
                Status = new OptionSetValue(2) // 2 for cancelled
            };

            service.Execute(setStateRequest);
        }

        public string GetIndividualProduct(string jointProduct)
        {
            // Check if the product is "Joint" and determine the corresponding "Individual" product
            if (string.IsNullOrEmpty(jointProduct))
            {
                _logger.TraceInformation($"Meberhsip Product Null");
            }

            string individualProduct;

            switch (jointProduct)
            {
                case "Joint":
                    individualProduct = "Individual";
                    break;

                case "Joint Life":
                    individualProduct = "Individual Life";
                    break;

                case "Senior Joint Life":
                    individualProduct = "Senior Individual Life";
                    break;

                default:
                    // If we encounter an unknown product type, set default
                    individualProduct = "Individual";
                    break;
            }

            return individualProduct;
        }

        public void CancelSubscriptionContactIsDeceased(Contact targetContact)
        {
            _logger.TraceInformation($"CancelSubscriptionContactIsDeceased starts.");

            //Get All Subscriptions related to Payer or Recipient
            EntityCollection activeSubscriptions = GetActiveSubscriptions(targetContact.Id.ToString());
            if (activeSubscriptions.Entities.Any())
            {
                foreach (var subscription in activeSubscriptions.Entities)
                {
                    if (IsPayerOnly(subscription, targetContact.Id))
                    {
                        HandlePayerDeceasedScenario(subscription);

                        if (IsContinuousMonthlyCardOrDDPayment(subscription))
                        {
                            SetSubscriptionStatusToPendingPayment(subscription.Id); // Set status to Pending Payment
                        }
                    }
                    else
                    {
                        SetSubscriptionStatusToCancelled(subscription.Id); // Set status to Cancelled
                    }

                    CancelSubscriptionTransaction(subscription.Id); // Cancel transaction, payments, and payment schedule
                }
            }

            _logger.TraceInformation($"CancelSubscriptionContactIsDeceased ends.");
        }

        private void SetSubscriptionStatusToPendingPayment(Guid subscriptionId)
        {
            _logger.TraceInformation($"Setting subscription {subscriptionId} status to Pending Payment.");

            // Retrieve the subscription entity to update its fields
            Entity subscription = _service.Retrieve("rhs_subscription", subscriptionId, 
                new ColumnSet("rhs_ispaymentsubmitted", "rhs_ispaymentreceived", "statecode", "statuscode"));

            // Set status to Pending Payment (120,000,003)
            subscription["rhs_ispaymentsubmitted"] = false;
            subscription["rhs_ispaymentreceived"] = false;
            subscription["statecode"] = new OptionSetValue(0);
            subscription["statuscode"] = new OptionSetValue(120000003);

            _service.Update(subscription);

            _logger.TraceInformation($"Subscription {subscriptionId} status set to Pending Payment.");
        }

        private bool IsPayerOnly(Entity subscription, Guid contactId)
        {
            bool isPayer = subscription.Contains("rhs_subscriptionpayer") &&
                           subscription["rhs_subscriptionpayer"] is EntityReference payerRef &&
                           payerRef.Id == contactId;

            bool isNotRecipient = !(subscription.Contains("rhs_recipient") &&
                                    subscription["rhs_recipient"] is EntityReference recipientRef &&
                                    recipientRef.Id == contactId);

            return isPayer && isNotRecipient;
        }

        private bool IsContinuousMonthlyCardOrDDPayment(Entity subscription)
        {
            bool isCardOrDDPaymentMethod = subscription.Contains("rhs_paymentmethodcode") &&
                                           subscription["rhs_paymentmethodcode"] is OptionSetValue paymentMethod &&
                                           (paymentMethod.Value == 844060002/*Card*/ || paymentMethod.Value == 120000002/*Direct Debit*/ || paymentMethod.Value == 120000014/*Credit Card (Phone)*/);
            bool isContinuousPayment = subscription.Contains("rhs_iscontinuouspayment") &&
                                       subscription["rhs_iscontinuouspayment"] is bool continuousPayment &&
                                       continuousPayment == true;
            bool isMonthlyPaymentFrequency = subscription.Contains("rhs_billingfrequency") &&
                                             subscription["rhs_billingfrequency"] is OptionSetValue paymentFrequency &&
                                             paymentFrequency.Value == 120000002/*Monthly*/;

            return isCardOrDDPaymentMethod && isContinuousPayment && isMonthlyPaymentFrequency;
        }

        private void HandlePayerDeceasedScenario(Entity subscription)
        {
            _logger.TraceInformation($"Handling deceased payer scenario for subscription {subscription.Id}.");

            // Check if a recipient exists to assign as the new payer
            if (subscription.Contains("rhs_recipient") && subscription["rhs_recipient"] is EntityReference recipientRef)
            {
                subscription["rhs_subscriptionpayer"] = recipientRef;

                // Update the subscription to reflect the new payer
                _service.Update(subscription);
                _logger.TraceInformation($"Assigned recipient {recipientRef.Id} as the new payer for subscription {subscription.Id}.");
            }
        }

        public void CancelSubscriptionTransaction(Guid subscriptionId)
        {

            List<Transaction> transactions = new List<Transaction>();
            transactions = _transactionRepository.GetAll()
                 .Where(transaction =>
                     transaction.SubscriptionIdSubscriptionRef != null &&
                     transaction.SubscriptionIdSubscriptionRef.Id == subscriptionId &&
                     transaction.Statecode == TransactionState.Active
                  )
                 .ToList();
            _logger.TraceInformation($"transactionsCount: {transactions.Count}");


            if (transactions.Count != 0)
            {
                foreach (var item in transactions)
                {

                    _logger.TraceInformation($"transactionsCount: {item.TransacID}");
                    _logger.TraceInformation($"transactionsCount: {item.Id}");
                    #region can be replce with cancel DD. refered to membershipUpdatepreOpsPlugin

                    GetRelatedPaymentFromTransactionAndCancel(_service, item.Id);
                    GetRelatedPaymentScheduleFromTransactionAndCancel(_service, (int?)item.TransactionType, subscriptionId);
                    SetTransactionStatusToCancelled(_service, item.Id);
                    #endregion
                }

            }
        }

        public void SetSubscriptionStatusToCancelled(Guid subscriptionId) 
        {
            //Retrieve the subscription entity to update its fields
            Entity subscription = _service.Retrieve("rhs_subscription", subscriptionId, new ColumnSet("rhs_subscriptionid", "rhs_cancellationdate","rhs_cancellationreason",
                      "rhs_subscriptioncancellationtype", "rhs_cancelsubscription"));

            //cancellation date to the current UTC date and time
            subscription["rhs_cancellationdate"] = DateTime.UtcNow;

            // Retrieve and set the cancellation reason as 'Deceased'
            var cancellationReason = GetCancellationReason(_service, "Deceased");
            if (cancellationReason != null)
            {
                subscription["rhs_cancellationreason"] = new EntityReference("rhs_cancellationreason", cancellationReason.Id);

                _logger.TraceInformation($"Cancellation reason 'Deceased' set for subscription {subscriptionId}.");
            }
            else
            {
                _logger.TraceWarning($"Cancellation reason 'Deceased' not found for subscription {subscriptionId}.");
            }

            // Set the cancellation type to "Now" (Option Set)
            subscription["rhs_subscriptioncancellationtype"] = new OptionSetValue(120000000);

                _logger.TraceInformation($"Cancellation type set to 'Now' for subscription {subscriptionId}.");


            // Set Cancel Subscription to "Yes"
            if (subscription.Attributes.Contains("rhs_cancelsubscription"))
            {
                subscription["rhs_cancelsubscription"] = true; // Assuming "Yes" is represented as a boolean true
                _logger.TraceInformation($"Cancel subscription set to 'Yes' for subscription {subscriptionId}.");
            }
            else
            {
                _logger.TraceWarning($"Field 'rhs_cancelsubscription' not found in subscription {subscriptionId}.");
            }

            _service.Update(subscription);

            var setStateRequest = new SetStateRequest
            {
                EntityMoniker = new EntityReference("rhs_subscription", subscriptionId),
                State = new OptionSetValue(1), // 1 for 'Inactive'
                Status = new OptionSetValue(2) // 2 
            };

            _service.Execute(setStateRequest);

        }

        public EntityCollection GetActiveSubscriptions(string contactId)
        {
            QueryExpression activeSubscriptionsQuery = new QueryExpression("rhs_subscription");

            // Add columns to query.ColumnSet
            activeSubscriptionsQuery.ColumnSet.AddColumns("rhs_subscriptionid", "rhs_number", "statuscode", "rhs_recipient", "rhs_subscriptionpayer", "rhs_cancellationdate", "rhs_paymentmethodcode", "rhs_iscontinuouspayment", "rhs_billingfrequency");
            activeSubscriptionsQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

            var query_Or = new FilterExpression(LogicalOperator.Or);
            activeSubscriptionsQuery.Criteria.AddFilter(query_Or);

            query_Or.AddCondition("rhs_recipient", ConditionOperator.Equal, contactId);
            query_Or.AddCondition("rhs_subscriptionpayer", ConditionOperator.Equal, contactId);

            EntityCollection activeSubscriptions = _service.RetrieveMultiple(activeSubscriptionsQuery);

            return activeSubscriptions;
        }

        public void CancelDDIsOfContact(Entity contact)
        {
            _tracingService.Trace("CancelDDIsOfContact Start");

            // Cancel contact's membership DDIs
            _tracingService.Trace("Cancelling DDIs of contact's memberships");
            var membershipQuery = new QueryExpression("rhs_membership");
            membershipQuery.ColumnSet.AllColumns = true;
            membershipQuery.Criteria.AddCondition("rhs_paymentmethod", ConditionOperator.Equal, 120000002);
            membershipQuery.Criteria.AddCondition("rhs_payerv2", ConditionOperator.Equal, contact.Id);
            membershipQuery.Criteria.AddCondition("statuscode", ConditionOperator.NotEqual, 2);

            var memberships = _service.RetrieveMultiple(membershipQuery).Entities;
            foreach (var membership in memberships)
                _customAPIInvocationService.InvokeCancelDDICustomAPI(membership.Id, NewTransactionType_GlobalOptionSet.Membership);

            // Cancel contact's subscription DDIs
            _tracingService.Trace("Cancelling DDIs of contact's subscriptions");
            var subscriptionQuery = new QueryExpression("rhs_subscription");
            subscriptionQuery.ColumnSet.AllColumns = true;
            subscriptionQuery.Criteria.AddCondition("rhs_paymentmethodcode", ConditionOperator.Equal, 120000002);
            subscriptionQuery.Criteria.AddCondition("rhs_subscriptionpayer", ConditionOperator.Equal, contact.Id);
            subscriptionQuery.Criteria.AddCondition("statuscode", ConditionOperator.NotEqual, 2);

            var subscriptions = _service.RetrieveMultiple(subscriptionQuery).Entities;
            foreach (var subscription in subscriptions)
                _customAPIInvocationService.InvokeCancelDDICustomAPI(subscription.Id, NewTransactionType_GlobalOptionSet.Subscriptions);

            // Cancel contact's donation DDIs
            _tracingService.Trace("Cancelling DDIs of contact's donations");
            var donationQuery = new QueryExpression("rhs_donation");
            donationQuery.ColumnSet.AllColumns = true;
            donationQuery.Criteria.AddCondition("rhs_paymentmethodcode", ConditionOperator.Equal, 120000002);
            donationQuery.Criteria.AddCondition("rhs_donor", ConditionOperator.Equal, contact.Id);
            donationQuery.Criteria.AddCondition("statuscode", ConditionOperator.NotEqual, 120000002);

            var donations = _service.RetrieveMultiple(donationQuery).Entities;
            foreach (var donation in donations)
                _customAPIInvocationService.InvokeCancelDDICustomAPI(donation.Id, NewTransactionType_GlobalOptionSet.Donation);


            _tracingService.Trace("CancelDDIsOfContact End");
        }

        public void CancelDonationsOfContactWhenDeceased(Contact contact)
        {
            _logger.TraceInformation($"Starting business logic");

            // Retrieve donations of contact
            _logger.TraceInformation($"Retrieving active donations of contact w/ Id = {contact?.Id}.");
            var donations = _donationRepository.GetAll().Where(donation => 
                donation.Donor != null && donation.Donor.Id == contact.Id && 
                donation.Statecode == DonationState.Active 
            ).ToList();
            _logger.TraceInformation($"Retrieved {donations.Count} donations.");

            foreach (var donation in donations)
            {
                // Retrieve transactions of donation
                _logger.TraceInformation($"Retrieving active transactions of donation w/ Id = {donation?.Id}.");
                var transactions = _transactionRepository.GetAll().Where(transaction =>
                    transaction.Donation != null && transaction.Donation.Id == donation.Id &&
                    transaction.Statecode == TransactionState.Active
                ).ToList();
                _logger.TraceInformation($"Retrieved {transactions.Count} transactions.");

                foreach (var transaction in transactions)
                {
                    // Retrieve payments of transaction
                    _logger.TraceInformation($"Retrieving active payments of transaction w/ Id = {transaction?.Id}.");
                    var payments = _paymentRepository.GetAll().Where(payment =>
                        payment.Transaction != null && payment.Transaction.Id == transaction.Id &&
                        payment.Statecode == PaymentState.Active
                    ).ToList();
                    _logger.TraceInformation($"Retrieved {payments.Count} payments.");

                    foreach (var payment in payments)
                    {
                        // Cancel payment of transaction
                        _logger.TraceInformation($"Cancelling payment w/ Id = {payment?.Id}.");
                        var paymentToUpdate = new Payment()
                        {
                            Id = payment.Id,
                            Statecode = PaymentState.Inactive,
                            Statuscode = PaymentStatus.Inactive_Cancelled
                        };
                        _paymentRepository.Update(paymentToUpdate);
                        _logger.TraceInformation($"Cancelled payment.");
                    }

                    // Cancel transaction of donation
                    _logger.TraceInformation($"Cancelling transaction w/ Id = {transaction?.Id}.");
                    var transactionToUpdate = new Transaction()
                    {
                        Id = transaction.Id,
                        Statecode = TransactionState.Inactive,
                        Statuscode = TransactionStatus.Inactive_Cancelled
                    };
                    _transactionRepository.Update(transactionToUpdate);
                    _logger.TraceInformation($"Cancelled transaction.");
                }

                // Cancel donation of contact
                _logger.TraceInformation($"Cancelling donation w/ Id = {donation?.Id}.");
                var donationToUpdate = new Donation()
                {
                    Id = donation.Id,
                    Statecode = DonationState.Inactive,
                    Statuscode = DonationStatus.Inactive_Cancelled
                };
                _donationRepository.Update(donationToUpdate);
                _logger.TraceInformation($"Cancelled donation.");
            }

            _logger.TraceInformation($"Ending business logic");
        }

        public void validatedNameInputUpdate(Contact contact, (string value, string name, string fieldName)[] fields)
        {
            _logger.TraceInformation($"validatePreferredName Start");
            if (contact != null && fields != null && fields.Length > 0)
            {
                //Entity record = new Entity(EntityNames.Contact.EntityLogicalName, contact.Id);
                foreach (var field in fields)
                {
                    if (!string.IsNullOrWhiteSpace(field.value) && !string.IsNullOrWhiteSpace(field.name) && !string.IsNullOrWhiteSpace(field.fieldName))
                    {
                        _logger.TraceInformation(string.Format("validatePreferredName fields: {0} | {1} | {2}",field.value,field.name,field.fieldName));
                        bool isValid = _commonService.validateName(field.value);
                        if (isValid)
                        {
                            if (field.fieldName == EntityNames.Contact.FirstName || field.fieldName == EntityNames.Contact.LastName)
                            {
                                bool isLastName = false;
                                if (field.fieldName == EntityNames.Contact.LastName)
                                    isLastName = true;
                                else
                                    isLastName = false;
                                contact[field.fieldName] = _commonService.capitalizeNameInput(field.value, isLastName);
                            }
                        }
                        else
                        {
                            throw new InvalidPluginExecutionException(string.Format("The \"{0}\" field can only contain letters, spaces, dashes, and apostrophes. Please remove any invalid characters and try again.", field.name));
                        }
                    }
                }

            }
            _logger.TraceInformation($"validatePreferredName End");
        }

        public void contactPopulateGDPRDeletionDate(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateGDPRDeletionDate Start");
            if (contact != null)
            {
                //Get GDPR Configuration for Contact
                GDPRConfigurationSettings settings = _commonService.getGDPRConfiguration(new OptionSetValue((int)Entitynamegdprcode_GlobalOptionSet.Contacts));
                if (settings != null && settings.RetentionPeriod != null)
                {
                    contact.GDPRDeletionDate = DateTime.Now.AddDays(Convert.ToDouble(settings.RetentionPeriod));
                }
            }
            _logger.TraceInformation($"contactPopulateGDPRDeletionDate End");
        }
 
        public void contactPopulateInitials(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateInitials Start");
            if (contact != null)
            {

                //Populate Initials
                if (!string.IsNullOrWhiteSpace(contact.FirstName))
                {
                    string[] fNames = contact.FirstName.Split(' ');
                    string initials = string.Empty;
                    foreach (var fName in fNames)
                    {
                        if (!string.IsNullOrEmpty(fName))
                        {
                            initials += char.ToUpper(fName[0]) + " ";
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(initials))
                    {
                        contact.Initials = initials.Trim();
                    }
                }
                else
                {
                    contact.Initials = null;
                }
            }
            _logger.TraceInformation($"contactPopulateInitials End");
        }


        public void contactPopulateAge(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateAge Start");
            if (contact != null)
            {

                //Populate Age
                if (contact.BirthDate != null)
                {
                    DateTime dob = contact.BirthDate.Value.Date;
                    DateTime today = DateTime.Today;

                    if (dob > today)
                    {
                        throw new InvalidPluginExecutionException("Date of Birth cannot be in the future. Please enter a valid date and try again.");
                    }

                    int age = DateTime.Now.Year - contact.BirthDate.Value.Year;
                    if (contact.BirthDate.Value.Date > new DateTime(contact.BirthDate.Value.Year, DateTime.Now.Month, DateTime.Now.Day))
                    {
                        age--;
                    }
                    contact.Age = age;

                }
            }
            _logger.TraceInformation($"contactPopulateAge End");
        }

        public void contactPopulateSalutation(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateSalutation Start");
            if (contact != null)
            {
                var contacUpdate = new Entity(Contact.EntityLogicalName, contact.Id);
                if (contact.Title != null && contact.Title.Id != Guid.Empty)
                {
                    string titleString = _commonService.getSalutation(contact.Title.Id);
     
                    if (!string.IsNullOrWhiteSpace(titleString))
                    {

                        if (titleString.Contains("_firstname_ _lastname_"))
                        {
                            titleString = titleString.Replace("_firstname_ _lastname_", contact.FullName ?? "");
                            contacUpdate[EntityNames.Contact.Salutation] = titleString;
                        }
                        else if (titleString.Contains("_firstname_"))
                        {
                            titleString = titleString.Replace("_firstname_", contact.FirstName ?? "");
                            contacUpdate[EntityNames.Contact.Salutation] = titleString;
                        }
                        else if (titleString.Contains("_lastname_"))
                        {
                            titleString = titleString.Replace("_lastname_", contact.LastName ?? "");
                            contacUpdate[EntityNames.Contact.Salutation] = titleString;
                        }

                        else
                        {
                            contacUpdate[EntityNames.Contact.Salutation] = titleString;
                        }

                    }
                }
                else
                {

                    if (!string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName))
                    {
                        contacUpdate[EntityNames.Contact.Salutation] = $"{contact.FirstName} {contact.LastName}";
                    }
                    if (string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName) && !string.IsNullOrWhiteSpace(contact.Initials))
                    {
                        contacUpdate[EntityNames.Contact.Salutation] = $"{contact.Initials} {contact.LastName}";
                    }
                }

                if (contacUpdate.Attributes.Count > 0)
                {
                    _service.Update(contacUpdate);
                }
            }

            _logger.TraceInformation($"contactPopulateSalutation End");
        }

        public void contactCreateNameChange(Contact postcontact,Contact precontact)
        {
            _logger.TraceInformation($"contactCreateNameChange Start");
            if (postcontact != null && precontact != null)
            {
                var createNameChange = new Entity(EntityNames.NameChange.EntityLogicalName);
                if (!string.IsNullOrWhiteSpace(postcontact.FirstName))
                    createNameChange[EntityNames.NameChange.ToForenames] = postcontact.FirstName;
                if (!string.IsNullOrWhiteSpace(precontact.FirstName))
                    createNameChange[EntityNames.NameChange.FromForenames] = precontact.FirstName;

                if (!string.IsNullOrWhiteSpace(postcontact.LastName))
                    createNameChange[EntityNames.NameChange.ToLastName] = postcontact.LastName;
                if (!string.IsNullOrWhiteSpace(precontact.LastName))
                    createNameChange[EntityNames.NameChange.FromLastName] = precontact.LastName;

                if (!string.IsNullOrWhiteSpace(postcontact.Initials))
                    createNameChange[EntityNames.NameChange.ToInitials] = postcontact.Initials;
                if (!string.IsNullOrWhiteSpace(precontact.Initials))
                    createNameChange[EntityNames.NameChange.FromInitials] = precontact.Initials;

                if (postcontact.Title != null && postcontact.Title.Id != Guid.Empty)
                    createNameChange[EntityNames.NameChange.ToTitle] = postcontact.Title.Name;
                if (precontact.Title != null && precontact.Title.Id != Guid.Empty)
                    createNameChange[EntityNames.NameChange.FromTitle] = precontact.Title.Name;
                createNameChange[EntityNames.NameChange.Regarding] = new EntityReference(Contact.EntityLogicalName, postcontact.Id);
                _service.Create(createNameChange);

            }
            _logger.TraceInformation($"contactCreateNameChange End");
        }
        public void contactPopulateLabelName(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateLabelName Start");
            if (contact != null)
            {
                string title = string.Empty;
                var contactLabelNameUpdate = new Entity(EntityNames.Contact.EntityLogicalName, contact.Id);

                if (contact.Title != null && contact.Title.Id != Guid.Empty)
                {
                    Entity Salutation = _service.Retrieve(TitleandSalutation.EntityLogicalName, contact.Title.Id, new ColumnSet(EntityNames.TitleandSalutation.Name));
                    if (Salutation != null)
                    {
                        title = Salutation[EntityNames.TitleandSalutation.Name] as string;
                    }
                    contactLabelNameUpdate[EntityNames.Contact.LabelName2] = string.Join(" ",
                    new[] {
                    title,
                    contact.Initials,
                    _commonService.capitalizeNameInput(contact.LastName, true),
                    contact.Suffix
                        }.Where(s => !string.IsNullOrWhiteSpace(s))
                    );
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName))
                    {
                        contactLabelNameUpdate[EntityNames.Contact.LabelName2] = $"{contact.Initials} {contact.LastName} {contact.Suffix}";
                    }
                    if (string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName) && !string.IsNullOrWhiteSpace(contact.Initials))
                    {
                        contactLabelNameUpdate[EntityNames.Contact.LabelName2] = $"{contact.Initials} {contact.LastName} {contact.Suffix}";
                    }

                }

                if (contactLabelNameUpdate.Attributes.Count > 0)
                {
                    _service.Update(contactLabelNameUpdate);
                }
                
                _logger.TraceInformation($"contactPopulateLabelName Updated Label Name");
            }

            _logger.TraceInformation($"contactPopulateLabelName End");
        }

        public void contactCreateAddress1Change(Contact postcontact, Contact precontact)
        {
            _logger.TraceInformation("contactCreateAddress1Change Start");

            if (postcontact != null && precontact != null)
            {
                var createAddressChange = new Entity(EntityNames.AddressChange.EntityLogicalName);
                #region addressFields
                var addressMappings = new List<(string PostValue, string PreValue, string ToField, string FromField)>
                {
                (postcontact.Address1_City, precontact.Address1_City,
                    EntityNames.AddressChange.ToCity, EntityNames.AddressChange.FromCity),
                (postcontact.Address1_Country, precontact.Address1_Country,
                    EntityNames.AddressChange.ToCountry, EntityNames.AddressChange.FromCountry),

                (postcontact.Address1_PostalCode, precontact.Address1_PostalCode,
                    EntityNames.AddressChange.ToPostalCode, EntityNames.AddressChange.FromPostalCode),

                (postcontact.Address1_Line1, precontact.Address1_Line1,
                    EntityNames.AddressChange.ToLine1, EntityNames.AddressChange.FromLine1),

                (postcontact.Address1_Line2, precontact.Address1_Line2,
                    EntityNames.AddressChange.ToLine2, EntityNames.AddressChange.FromLine2),

                (postcontact.Address1_Line3, precontact.Address1_Line3,
                    EntityNames.AddressChange.ToLine3, EntityNames.AddressChange.FromLine3),

                (postcontact.Address1_StateOrProvince, precontact.Address1_StateOrProvince,
                    EntityNames.AddressChange.ToStateOrProvince, EntityNames.AddressChange.FromStateOrProvince),

                (postcontact.LoqateAddress1County, precontact.LoqateAddress1County,
                    EntityNames.AddressChange.ToCounty, EntityNames.AddressChange.FromCounty),

                (postcontact.LoqateHomeAddressHouseName, precontact.LoqateHomeAddressHouseName,
                    EntityNames.AddressChange.ToHouseName, EntityNames.AddressChange.FromHouseName),


                };
                #endregion

                foreach (var (postValue, preValue, toField, fromField) in addressMappings)
                {
                    if (!string.IsNullOrWhiteSpace(postValue))
                        createAddressChange[toField] = postValue;
                    if (!string.IsNullOrWhiteSpace(preValue))
                        createAddressChange[fromField] = preValue;
                }

                createAddressChange[EntityNames.AddressChange.RegardingObjectId] =
                    new EntityReference(Contact.EntityLogicalName, postcontact.Id);
                createAddressChange[EntityNames.AddressChange.Subject] = $"Primary Address change for {postcontact.FullName} on {DateTime.Today.ToString("d/M/yyyy")}";


                _service.Create(createAddressChange);
            }

            _logger.TraceInformation("contactCreateAddress1Change End");
        }

        public void contactCreateAddress2Change(Contact postcontact, Contact precontact)
        {
            _logger.TraceInformation($"contactCreateAddress2Change Start");
            if (postcontact != null && precontact != null)
            {
                var createAddressChange = new Entity(EntityNames.AddressChange.EntityLogicalName);
                #region addressFields
                var addressMappings = new List<(string PostValue, string PreValue, string ToField, string FromField)>
                {
                (postcontact.Address2_City, precontact.Address2_City,
                    EntityNames.AddressChange.ToCity, EntityNames.AddressChange.FromCity),
                (postcontact.Address2_Country, precontact.Address2_Country,
                    EntityNames.AddressChange.ToCountry, EntityNames.AddressChange.FromCountry),

                (postcontact.Address2_PostalCode, precontact.Address2_PostalCode,
                    EntityNames.AddressChange.ToPostalCode, EntityNames.AddressChange.FromPostalCode),

                (postcontact.Address2_Line1, precontact.Address2_Line1,
                    EntityNames.AddressChange.ToLine1, EntityNames.AddressChange.FromLine1),

                (postcontact.Address2_Line2, precontact.Address2_Line2,
                    EntityNames.AddressChange.ToLine2, EntityNames.AddressChange.FromLine2),

                (postcontact.Address2_Line3, precontact.Address2_Line3,
                    EntityNames.AddressChange.ToLine3, EntityNames.AddressChange.FromLine3),

                (postcontact.Address2_StateOrProvince, precontact.Address2_StateOrProvince,
                    EntityNames.AddressChange.ToStateOrProvince, EntityNames.AddressChange.FromStateOrProvince),

                (postcontact.LoqateAddress2County, precontact.LoqateAddress2County,
                    EntityNames.AddressChange.ToCounty, EntityNames.AddressChange.FromCounty),

                (postcontact.LoqateAddress2HouseName, precontact.LoqateAddress2HouseName,
                    EntityNames.AddressChange.ToHouseName, EntityNames.AddressChange.FromHouseName)
                };
                #endregion

                foreach (var (postValue, preValue, toField, fromField) in addressMappings)
                {
                    if (!string.IsNullOrWhiteSpace(postValue))
                        createAddressChange[toField] = postValue;
                    if (!string.IsNullOrWhiteSpace(preValue))
                        createAddressChange[fromField] = preValue;
                }

                createAddressChange[EntityNames.AddressChange.ToAddressTypeCode] =
                    postcontact.SecondaryAddressTypeCode != null
                        ? new OptionSetValue((int)postcontact.SecondaryAddressTypeCode.Value)
                        : null;

                createAddressChange[EntityNames.AddressChange.FromAddressTypeCode] =
                    precontact.SecondaryAddressTypeCode != null
                        ? new OptionSetValue((int)precontact.SecondaryAddressTypeCode.Value)
                        : null;

                createAddressChange[EntityNames.AddressChange.RegardingObjectId] =
                    new EntityReference(Contact.EntityLogicalName, postcontact.Id);
                createAddressChange[EntityNames.AddressChange.Subject] = $"Secondary Address change for {postcontact.FullName} on {DateTime.Today.ToString("d/M/yyyy")}";


                _service.Create(createAddressChange);

            }
            _logger.TraceInformation($"contactCreateAddress2Change End");
        }

        public void contactCreateLoqateAddressChange(Contact postcontact, Contact precontact)
        {
            _logger.TraceInformation($"contactCreateLoqateAddressChange Start");
            if (postcontact != null && precontact != null)
            {
                var createAddressChange = new Entity(EntityNames.AddressChange.EntityLogicalName);
                #region addressFields
                var addressMappings = new List<(string PostValue, string PreValue, string ToField, string FromField)>
                {
                (postcontact.LoqateAddress3City, precontact.LoqateAddress3City,
                    EntityNames.AddressChange.ToCity, EntityNames.AddressChange.FromCity),
                (postcontact.LoqateAddress3Country, precontact.LoqateAddress3Country,
                    EntityNames.AddressChange.ToCountry, EntityNames.AddressChange.FromCountry),

                (postcontact.LoqateAddress3Postcode, precontact.LoqateAddress3Postcode,
                    EntityNames.AddressChange.ToPostalCode, EntityNames.AddressChange.FromPostalCode),

                (postcontact.LoqateAddress3Line1, precontact.LoqateAddress3Line1,
                    EntityNames.AddressChange.ToLine1, EntityNames.AddressChange.FromLine1),

                (postcontact.LoqateAddress3Line2, precontact.LoqateAddress3Line2,
                    EntityNames.AddressChange.ToLine2, EntityNames.AddressChange.FromLine2),

                (postcontact.LoqateAddress3Line3, precontact.LoqateAddress3Line3,
                    EntityNames.AddressChange.ToLine3, EntityNames.AddressChange.FromLine3),

                (postcontact.LoqateAddress3Line4, precontact.LoqateAddress3Line4,
                    EntityNames.AddressChange.ToStateOrProvince, EntityNames.AddressChange.FromStateOrProvince),

                (postcontact.LoqateAddress3County, precontact.LoqateAddress3County,
                    EntityNames.AddressChange.ToCounty, EntityNames.AddressChange.FromCounty),

                (postcontact.LoqateAddress3HouseName, precontact.LoqateAddress3HouseName,
                    EntityNames.AddressChange.ToHouseName, EntityNames.AddressChange.FromHouseName)
                };
                #endregion

                foreach (var (postValue, preValue, toField, fromField) in addressMappings)
                {
                    if (!string.IsNullOrWhiteSpace(postValue))
                        createAddressChange[toField] = postValue;
                    if (!string.IsNullOrWhiteSpace(preValue))
                        createAddressChange[fromField] = preValue;
                }

                createAddressChange[EntityNames.AddressChange.ToAddressTypeCode] =
                    postcontact.AlternateAddressTypeCode != null
                        ? new OptionSetValue((int)postcontact.AlternateAddressTypeCode.Value)
                        : null;

                createAddressChange[EntityNames.AddressChange.FromAddressTypeCode] =
                    precontact.AlternateAddressTypeCode != null
                        ? new OptionSetValue((int)precontact.AlternateAddressTypeCode.Value)
                        : null;

                createAddressChange[EntityNames.AddressChange.RegardingObjectId] =
                    new EntityReference(Contact.EntityLogicalName, postcontact.Id);
                createAddressChange[EntityNames.AddressChange.Subject] = $"Alternate Address change for {postcontact.FullName} on {DateTime.Today.ToString("d/M/yyyy")}";


                _service.Create(createAddressChange);

            }
            _logger.TraceInformation($"contactCreateLoqateAddressChange End");
        }

        public void populateAddressOnUpdate(Entity entity, Contact preUpdate, Contact postUpdate)
        {
            _logger.TraceInformation($"populateAddressOnUpdate Start");
            if (entity != null && preUpdate != null || postUpdate != null) 
            {
                var targetContact = entity.ToEntity<Contact>();

                //Address 1
                if (entity.Contains(EntityNames.Contact.Loqate_Latitude) && preUpdate.Loqate_Latitude != postUpdate.Loqate_Latitude && targetContact.Loqate_Latitude != "")
                    postUpdate.Address1_Latitude = Convert.ToDouble(targetContact.Loqate_Latitude);

                if (entity.Contains(EntityNames.Contact.Loqate_Longitude) && preUpdate.Loqate_Longitude != postUpdate.Loqate_Longitude && targetContact.Loqate_Longitude != "")
                    postUpdate.Address1_Longitude = Convert.ToDouble(targetContact.Loqate_Longitude);

                if (entity.Contains(EntityNames.Contact.LoqateAddress1County) && preUpdate.LoqateAddress1County != postUpdate.LoqateAddress1County)
                    postUpdate.Address1_County = targetContact.LoqateAddress1County;

                if (entity.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) && preUpdate.LoqateHomeAddressHouseName != postUpdate.LoqateHomeAddressHouseName)
                    postUpdate.Address1_Name = targetContact.LoqateHomeAddressHouseName;

                //Postal Code
                if (entity.Contains(EntityNames.Contact.Address1_PostalCode) && preUpdate.Address1_PostalCode != postUpdate.Address1_PostalCode)
                    postUpdate.PostcodeHomeAddress = targetContact.Address1_PostalCode;

                //Address 2 
                if (entity.Contains(EntityNames.Contact.LoqateAddress2Latitude) && preUpdate.LoqateAddress2Latitude != postUpdate.LoqateAddress2Latitude && targetContact.LoqateAddress2Latitude != "")
                    postUpdate.Address2_Latitude = Convert.ToDouble(targetContact.LoqateAddress2Latitude);

                if (entity.Contains(EntityNames.Contact.LoqateAddress2Longitude) && preUpdate.LoqateAddress2Longitude != postUpdate.LoqateAddress2Longitude && targetContact.LoqateAddress2Longitude != "")
                    postUpdate.Address2_Longitude = Convert.ToDouble(targetContact.LoqateAddress2Longitude);

                if (entity.Contains(EntityNames.Contact.LoqateAddress2County) && preUpdate.LoqateAddress2County != postUpdate.LoqateAddress2County)
                    postUpdate.Address2_County = targetContact.LoqateAddress2County;

                if (entity.Contains(EntityNames.Contact.LoqateAddress2HouseName) && preUpdate.LoqateAddress2HouseName != postUpdate.LoqateAddress2HouseName)
                    postUpdate.Address2_Name = targetContact.LoqateAddress2HouseName;
            }
            _logger.TraceInformation($"populateAddressOnUpdate End");
        }

        public void populateLoqateAddressOnUpdate(Entity entity, Contact preUpdate, Contact postUpdate)
        {
            _logger.TraceInformation($"populateLoqateAddressOnUpdate Start");
            if (entity != null && preUpdate != null || postUpdate != null)
            {
                var targetContact = entity.ToEntity<Contact>();

                if (entity.Contains(EntityNames.Contact.LoqateAddress3HouseName) && preUpdate.LoqateAddress3HouseName != postUpdate.LoqateAddress3HouseName)
                    postUpdate.Address3_Name = targetContact.LoqateAddress3HouseName;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Line1) && preUpdate.LoqateAddress3Line1 != postUpdate.LoqateAddress3Line1)
                    postUpdate.Address3_Line1 = targetContact.LoqateAddress3Line1;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Line2) && preUpdate.LoqateAddress3Line2 != postUpdate.LoqateAddress3Line2)
                    postUpdate.Address3_Line2 = targetContact.LoqateAddress3Line2;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Line3) && preUpdate.LoqateAddress3Line3 != postUpdate.LoqateAddress3Line3)
                    postUpdate.Address3_Line2 = targetContact.LoqateAddress3Line3;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Line4) && preUpdate.LoqateAddress3Line4 != postUpdate.LoqateAddress3Line4)
                    postUpdate.Address3_StateOrProvince = targetContact.LoqateAddress3Line4;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3City) && preUpdate.LoqateAddress3City != postUpdate.LoqateAddress3City)
                    postUpdate.Address3_City = targetContact.LoqateAddress3City;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3County) && preUpdate.LoqateAddress3County != postUpdate.LoqateAddress3County)
                    postUpdate.Address3_County = targetContact.LoqateAddress3County;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Country) && preUpdate.LoqateAddress3Country != postUpdate.LoqateAddress3Country)
                    postUpdate.Address3_Country = targetContact.LoqateAddress3Country;

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Latitude) && preUpdate.LoqateAddress3Latitude != postUpdate.LoqateAddress3Latitude && targetContact.LoqateAddress3Latitude != "")
                    postUpdate.Address3_Latitude = Convert.ToDouble(targetContact.LoqateAddress3Latitude);

                if (entity.Contains(EntityNames.Contact.LoqateAddress3Longitude) && preUpdate.LoqateAddress3Longitude != postUpdate.LoqateAddress3Longitude && targetContact.LoqateAddress3Longitude != "")
                    postUpdate.Address3_Longitude = Convert.ToDouble(targetContact.LoqateAddress3Longitude);
            }
            _logger.TraceInformation($"populateLoqateAddressOnUpdate End");
        }

    }
}

