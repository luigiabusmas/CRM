﻿using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;


namespace Cultivate.BusinessLogic.Services
{
    public interface ICustomAPIInvocationService
    {
        void InvokeConsentCreationCustomAPI(string contactId, int newMemberDataSet);
        (Guid?, Guid?, Guid?) InvokeSubmitPaymentCustomAPI(int? paymentMethod, int? transactionType, int? type, Guid? recordId, Guid? payerId, string? payerEntity, Money? totalAmount, int? paymentFrequency, bool? isContiniousPayment, Money? outstandingAmount, Money? writtenOffAmount = null, string paymentReference = null, int? payingInSlipNumber = null);
        (Guid?, Guid?) InvokeCancelDDCustomAPI(Guid membershipId);
        (List<Guid>, List<Guid>, List<Guid>) InvokeCancelDDICustomAPI(Guid recordId, NewTransactionType_GlobalOptionSet transactionType);
        string InvokeStripeCreateCustomerCustomAPI(string contactName);
        string InvokeStripeCheckoutSessionCustomAPI(string stripeCustomerId, string stripeCurrency, string stripeUnitAmount, string stripeQuantity, string stripeMode, string stripeProduct);
        (string, string) InvokeStripeGetCheckoutSessionCustomAPI(string stripeSessionId);
        string InvokeStripeRefundCustomAPI(string paymentIntentId);
        string InvokeMembershipRenewalCustomAPI(Guid membershipId, bool? advancePayment);
        Guid? InvokeCreateMembershipOnRenewalsCustomAPI(Guid membershipId);
        Guid? InvokeCreatePaidDonationCustomAPI(bool isStandaloneDonation, decimal donationAmount, Guid batchOrderLineId, Guid membershipId, Guid transactionId);
    }
    public class CustomAPIInvocationService : ICustomAPIInvocationService
    {
        private ILogger _logger;
        private IPluginExecutionContext _context;
        private IOrganizationService _service;

        public CustomAPIInvocationService(ILogger logger, IPluginExecutionContext context, IOrganizationService service)
        {
            _logger = logger;
            _context = context;
            _service = service;
        }

        public void InvokeConsentCreationCustomAPI(string contactId, int newMemberDataSet)
        {
            try
            {
                OrganizationRequest request = new OrganizationRequest("rhs_consentscreation")
                {
                    Parameters =
                    {
                        { "contactid", contactId },
                        { "dataset", newMemberDataSet }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse response = _service.Execute(request);

                // Check the response for success or failure
                if (response != null && response.Results.Contains("result") && (bool)response.Results["result"])
                {
                    _logger.TraceInformation("Consent creation via API was successful.");
                }
                else if (response != null && response.Results.Contains("error"))
                {
                    string error = response.Results["error"].ToString();
                    _logger.TraceInformation($"Consent creation via API failed. Error: {error}");
                    throw new InvalidPluginExecutionException($"Consent creation failed: {error}");
                }

                _logger.TraceInformation("Custom API executed successfully.");

            }
            catch (Exception ex)
            {
                _logger.TraceInformation($"Exception during Custom API invocation: {ex.Message}");
                throw new InvalidPluginExecutionException($"Error invoking Custom API: {ex.Message}", ex);
            }
        }

        public (Guid?, Guid?, Guid?) InvokeSubmitPaymentCustomAPI(int? paymentMethod, int? transactionType, int? type, Guid? recordId, Guid? payerId, string? payerEntity, Money? totalAmount, int? paymentFrequency, bool? isContiniousPayment, Money? outstandingAmount, Money? writtenOffAmount = null, string paymentReference = null, int? payingInSlipNumber = null)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Executing custom API request.");
            var request = new OrganizationRequest("rhs_submitpayment_new")
            {
                Parameters =
                    {
                        { "PaymentMethod", paymentMethod },
                        { "TransactionType", transactionType },
                        { "Type", type },
                        { "RecordId", recordId },
                        { "PayerId", payerId },
                        { "PayerEntity", payerEntity },
                        { "TotalAmount", totalAmount },
                        { "PaymentFrequency", paymentFrequency },
                        { "IsContiniousPayment", isContiniousPayment },
                        { "OutstandingAmount", outstandingAmount },
                        { "WrittenOffAmount", writtenOffAmount },
                        { "PaymentReference", paymentReference },
                        { "PayingInSlipNumber", payingInSlipNumber },
                    }
            };
            var response = _service.Execute(request);

            _logger.TraceInformation($"Retrieving response data.");
            Guid? transactionId = null;
            Guid? paymentId = null;
            Guid? paymentSchedulenId = null;

            if (response != null && response.Results.Contains("TransactionId") && (Guid?)response.Results["TransactionId"] != null)
                transactionId = (Guid?)response.Results["TransactionId"];
            if (response != null && response.Results.Contains("PaymentId") && (Guid?)response.Results["PaymentId"] != null)
                paymentId = (Guid?)response.Results["PaymentId"];
            if (response != null && response.Results.Contains("PayementScheduleId") && (Guid?)response.Results["PayementScheduleId"] != null)
                paymentSchedulenId = (Guid?)response.Results["PayementScheduleId"];

            _logger.TraceInformation($"Ending business logic.");
            return (transactionId, paymentId, paymentSchedulenId);
        }

        public (Guid?, Guid?) InvokeCancelDDCustomAPI(Guid membershipId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Executing custom API request.");
            var request = new OrganizationRequest("rhs_cancelDD_new")
            {
                Parameters =
                    {
                        { "MembershipId", membershipId },
                    }
            };
            var response = _service.Execute(request);

            _logger.TraceInformation($"Retrieving response data.");
            Guid? transactionId = null;
            Guid? paymentSchedulenId = null;

            if (response != null && response.Results.Contains("TransactionId") && (Guid?)response.Results["TransactionId"] != null)
                transactionId = (Guid?)response.Results["TransactionId"];
            if (response != null && response.Results.Contains("PayementScheduleId") && (Guid?)response.Results["PayementScheduleId"] != null)
                paymentSchedulenId = (Guid?)response.Results["PayementScheduleId"];

            _logger.TraceInformation($"Ending business logic.");
            return (transactionId, paymentSchedulenId);
        }

        public (List<Guid>, List<Guid>, List<Guid>) InvokeCancelDDICustomAPI(Guid recordId, NewTransactionType_GlobalOptionSet transactionType)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"RecordId = {recordId}.");
            _logger.TraceInformation($"Transaction Type = {transactionType}.");

            _logger.TraceInformation($"Executing custom API request.");
            var request = new OrganizationRequest("rhs_cancelDDI_new")
            {
                Parameters =
                    {
                        { "RecordId", recordId },
                        { "TransactionType", (int)transactionType }
                    }
            };
            var response = _service.Execute(request);

            _logger.TraceInformation($"Retrieving response data.");
            var transactionIds = new List<Guid>();
            var paymentScheduleIds = new List<Guid>();
            var paymentIds = new List<Guid>();

            if (response != null && response.Results.Contains("TransactionIds") && (string[])response.Results["TransactionIds"] != null)
                transactionIds = ((string[])response.Results["TransactionIds"]).Select(id => Guid.Parse(id)).ToList();
            if (response != null && response.Results.Contains("PayementScheduleIds") && (string[])response.Results["PayementScheduleIds"] != null)
                paymentScheduleIds = ((string[])response.Results["PayementScheduleIds"]).Select(id => Guid.Parse(id)).ToList();
            if (response != null && response.Results.Contains("PayementIds") && (string[])response.Results["PayementIds"] != null)
                paymentIds = ((string[])response.Results["PayementIds"]).Select(id => Guid.Parse(id)).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return (transactionIds, paymentScheduleIds, paymentIds);
        }

        public string InvokeStripeCreateCustomerCustomAPI(string contactName)
        {
            try
            {
                string stripeCustomerId = string.Empty;

                OrganizationRequest request = new OrganizationRequest("rhs_stripeCreateCustomer")
                {
                    Parameters =
                    {
                        { "rhs_stripeName", contactName }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse response = _service.Execute(request);

                // Check the response for success or failure
                if (response != null && response.Results.Contains("rhs_stripeCustomerResponse"))
                {
                    string jsonResponse = (string)response.Results["rhs_stripeCustomerResponse"];

                    var json = JObject.Parse(jsonResponse);
                    stripeCustomerId = json["customerId"].ToString();

                    _logger.TraceInformation("Stripe Create Customer is successful.");
                }
                return stripeCustomerId;
            }
            catch (Exception ex)
            {
                var errorMessage = "Failed to generate stripe customer id";
                _logger.TraceInformation(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }
        }

        public string InvokeStripeCheckoutSessionCustomAPI(string stripeCustomerId, string stripeCurrency, string stripeUnitAmount, string stripeQuantity, string stripeMode, string stripeProduct)
        {
            try
            {
                string stripeCheckoutUrl = string.Empty;

                OrganizationRequest request = new OrganizationRequest("rhs_checkoutSessionStripe")
                {
                    Parameters =
                    {
                        { "rhs_stripeCustomerId", stripeCustomerId },
                        { "rhs_stripeCurrency", stripeCurrency },
                        { "rhs_stipeUnitAmount", stripeUnitAmount },
                        { "rhs_stripeQuantity", stripeQuantity },
                        { "rhs_stripeMode", stripeMode },
                        { "rhs_stripeProduct", stripeProduct }

                    }
                };

                // Execute the Custom API call
                OrganizationResponse response = _service.Execute(request);

                // Check the response for success or failure
                if (response != null && response.Results.Contains("rhs_stripeCheckoutSessionResponse"))
                {

                    string jsonResponse = (string)response.Results["rhs_stripeCheckoutSessionResponse"];

                    var json = JObject.Parse(jsonResponse);
                    stripeCheckoutUrl = json["checkoutUrl"].ToString();

                    _logger.TraceInformation("Stripe Checkout Session is successful.");
                }
                return stripeCheckoutUrl;
            }
            catch (Exception ex)
            {
                var errorMessage = "Failed to generate stripe checkout session";
                _logger.TraceInformation(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }
        }

        public (string, string) InvokeStripeGetCheckoutSessionCustomAPI(string stripeSessionId)
        {
            try
            {
                string stripePaymentStatus = string.Empty;
                string paymentIntentId = string.Empty;

                OrganizationRequest request = new OrganizationRequest("rhs_getCheckoutSessionStripe")
                {
                    Parameters =
                    {
                        { "rhs_stripeCheckoutSessionId", stripeSessionId }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse response = _service.Execute(request);

                // Check the response for success or failure
                if (response != null && response.Results.Contains("rhs_stripeCheckoutSessionResponse"))
                {

                    string jsonResponse = (string)response.Results["rhs_stripeCheckoutSessionResponse"];

                    var json = JObject.Parse(jsonResponse);
                    stripePaymentStatus = json["payment_status"].ToString();
                    paymentIntentId = json["paymentIntentId"].ToString();

                    _logger.TraceInformation("Stripe Get Checkout Session Details is successful.");
                }
                return (stripePaymentStatus, paymentIntentId);
            }
            catch (Exception ex)
            {
                var errorMessage = "Failed to retrieve stripe checkout session status";
                _logger.TraceInformation(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }
        }

        public string InvokeStripeRefundCustomAPI(string paymentIntentId)
        {
            try
            {
                string refundId = string.Empty;

                OrganizationRequest request = new OrganizationRequest("rhs_stripeRefund")
                {
                    Parameters =
                    {
                        { "rhs_stripePaymentIntentId", paymentIntentId }
                    }
                };

                // Execute the Custom API call
                OrganizationResponse response = _service.Execute(request);

                // Check the response for success or failure
                if (response != null && response.Results.Contains("rhs_stripeRefundResponse"))
                {

                    string jsonResponse = (string)response.Results["rhs_stripeRefundResponse"];

                    var json = JObject.Parse(jsonResponse);
                    refundId = json["refundId"].ToString();

                    _logger.TraceInformation("Stripe Refund is successful.");
                }
                return refundId;
            }
            catch (Exception ex)
            {
                var errorMessage = "Failed to refund stripe payment.";
                _logger.TraceInformation(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }
        }

        public string InvokeMembershipRenewalCustomAPI(Guid membershipId, bool? advancePayment)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Executing custom API request.");
            var request = new OrganizationRequest("rhs_membership_renewals_new")
            {
                Parameters =
                    {
                        { "MembershipId", membershipId },
                        { "AdvancePayment", advancePayment }
                    }
            };
            var response = _service.Execute(request);

            _logger.TraceInformation($"Retrieving response data.");
            string? result = null;

            if (response != null)
            {
                if (response.Results.Contains("Result") && (Guid?)response.Results["Result"] != null)
                    result = (string?)response.Results["TrResultansactionId"];
            }

            _logger.TraceInformation($"Ending business logic.");
            return result;
        }

        public Guid? InvokeCreateMembershipOnRenewalsCustomAPI(Guid membershipId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Executing custom API request.");
            var request = new OrganizationRequest("rhs_Create_membership_onrenewals_new")
            {
                Parameters =
                    {
                        { "MembershipId", membershipId },
                    }
            };
            var response = _service.Execute(request);

            _logger.TraceInformation($"Retrieving response data.");
            Guid? newMembershipId = null;

            if (response != null)
            {
                if (response.Results.Contains("MembershipId") && (Guid?)response.Results["MembershipId"] != null)
                    newMembershipId = (Guid?)response.Results["MembershipId"];
            }

            _logger.TraceInformation($"Ending business logic.");
            return newMembershipId;
        }

        public Guid? InvokeCreatePaidDonationCustomAPI(bool isStandaloneDonation, decimal donationAmount, Guid batchOrderLineId, Guid membershipId, Guid transactionId)
        {
            _logger.TraceInformation($"Starting business logic.");

            try
            {
                _logger.TraceInformation($"Executing custom API request.");
                var request = new OrganizationRequest("rhs_createpaiddonation_new")
                {
                    Parameters =
                {
                    { "IsStandaloneDonation", isStandaloneDonation },
                    { "DonationAmount", donationAmount },
                    { "BatchOrderLineId", batchOrderLineId },
                    { "MembershipId", membershipId },
                    { "TransactionId", transactionId },
                }
                };

                // Execute the request
                var response = _service.Execute(request);

                _logger.TraceInformation($"Retrieving response data.");
                Guid? newDonationId = null;

                if (response != null)
                {
                    if (response.Results.Contains("DonationId") && (Guid?)response.Results["DonationId"] != null)
                        newDonationId = (Guid?)response.Results["DonationId"];
                }

                _logger.TraceInformation($"Ending business logic.");
                return newDonationId;
            }
            //catch error for selected campaign
            catch (FaultException<OrganizationServiceFault> orgEx)
            {

                if (orgEx.InnerException != null)
                {
                    _logger.TraceError($"Service error occurred: {orgEx.InnerException.Message}");
                }
                else
                {
                    _logger.TraceError($"Service error occurred: {orgEx.Message}");
                }


                throw new InvalidPluginExecutionException("The selected Campaign is missing either a Donation Type or a Restricted Fund. Please update the selected Campaign to proceed.");
            }
            //catch unexpected error
            catch (Exception ex)
            {

                if (ex.InnerException != null)
                {
                    _logger.TraceError($"Unexpected error occurred: {ex.InnerException.Message}");
                }
                else
                {
                    _logger.TraceError($"Unexpected error occurred: {ex.Message}");
                }


                throw new InvalidPluginExecutionException($"An unexpected error occurred. {ex.Message}");
            }

        }


    }
}