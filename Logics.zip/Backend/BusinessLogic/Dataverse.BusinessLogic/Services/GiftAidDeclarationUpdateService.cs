﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;

namespace Cultivate.BusinessLogic.Services
{

    public interface IGiftAidDeclarationUpdateService
    {
        void ValidateDateOverlap(Entity GiftAidDeclaration);
        void SetDateRangeLastUpdated(GiftAidDeclaration giftAid);
    }
    public class GiftAidDeclarationUpdateService : IGiftAidDeclarationUpdateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private ILogger _logger;

        public GiftAidDeclarationUpdateService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service, ILogger logger)
        {
            _tracingService = tracingService;
            _service = service;
            _logger = logger;
        }

        public void ValidateDateOverlap(Entity GiftAidDeclaration)
        {
            _tracingService.Trace("Starting ValidateDateOverlap...");

            // Extract fields from Gift Aid Declaration
            DateTime? newStartDate = GiftAidDeclaration.Contains(EntityNames.GiftAidDeclaration.StartDate) ? GiftAidDeclaration.GetAttributeValue<DateTime?>(EntityNames.GiftAidDeclaration.StartDate) : null;
            DateTime? newEndDate = GiftAidDeclaration.Contains(EntityNames.GiftAidDeclaration.EndDate) ? GiftAidDeclaration.GetAttributeValue<DateTime?>(EntityNames.GiftAidDeclaration.EndDate) : null;

            Entity customerReference = _service.Retrieve(EntityNames.GiftAidDeclaration.EntityLogicalName, GiftAidDeclaration.Id, new ColumnSet(true));
            EntityReference customerRef = customerReference.Contains(EntityNames.GiftAidDeclaration.CustomerId) ? customerReference.GetAttributeValue<EntityReference>(EntityNames.GiftAidDeclaration.CustomerId) : null;

            if (GiftAidDeclaration.Id == Guid.Empty)
            {
                _tracingService.Trace("Gift Aid Declaration is empty. Returning");
                return; // If fields are missing, exit the validation
            }

            if (customerRef == null || newStartDate == null)
            {
                _tracingService.Trace("Missing required fields: Customer or Start Date. Exiting validation.");
                return; // If fields are missing, exit the validation
            }

            _tracingService.Trace($"Validating for Customer: {customerRef.Id}, Start Date: {newStartDate}, End Date: {newEndDate}");

            // Query to find overlapping Gift Aid Declarations
            var query = new QueryExpression(EntityNames.GiftAidDeclaration.EntityLogicalName)
            {
                ColumnSet = new ColumnSet(EntityNames.GiftAidDeclaration.StartDate, EntityNames.GiftAidDeclaration.EndDate, EntityNames.GiftAidDeclaration.CustomerId)
            };

            query.Criteria.AddCondition(EntityNames.GiftAidDeclaration.CustomerId, ConditionOperator.Equal, customerRef.Id);


            query.Criteria.AddCondition(EntityNames.GiftAidDeclaration.GiftAidDeclarationId, ConditionOperator.NotEqual, GiftAidDeclaration.Id);


            var existingRecords = _service.RetrieveMultiple(query);

            foreach (var record in existingRecords.Entities)
            {
                DateTime existingStartDate = record.GetAttributeValue<DateTime>(EntityNames.GiftAidDeclaration.StartDate);
                DateTime existingEndDate = record.GetAttributeValue<DateTime>(EntityNames.GiftAidDeclaration.EndDate);
                //inside the existing range

                existingStartDate = existingStartDate.AddDays(1);
                existingEndDate = existingEndDate.AddDays(1);

                if ((newStartDate >= existingStartDate && newStartDate <= existingEndDate) ||
                    //greater than existing range
                    (newEndDate >= existingStartDate && newEndDate <= existingEndDate) ||
                    //overlap end date
                    (newEndDate >= existingEndDate)
                    )
                {
                    throw new InvalidPluginExecutionException($"The proposed date range overlaps with an existing Gift Aid Declaration record starting on {existingStartDate.Date.ToString("dd/MM/yyyy")} and ending on {existingEndDate.Date.ToString("dd/MM/yyyy")}.");
                }
            }

            _tracingService.Trace("Validation complete. No overlaps found.");
        }

        public void SetDateRangeLastUpdated(GiftAidDeclaration giftAid)
        {
            _logger.TraceInformation($"SetDateRangeLastUpdated Start");
            if (giftAid != null)
            {
                giftAid.DateRangeLastUpdated = DateTime.Now;
            }
            _logger.TraceInformation($"SetDateRangeLastUpdated End");
        }

    }
}
