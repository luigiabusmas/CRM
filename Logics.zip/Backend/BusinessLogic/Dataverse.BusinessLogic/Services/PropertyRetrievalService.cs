﻿using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Services;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface IPropertyRetrievalService
    {
        DynamicProperty GetProductProperty(string productId, string propertyName);
        string GetDefaultStringOfProductProperty(string productId, string containsPropertyName);
        int? GetDefaultIntegerOfProductProperty(string productId, string containsPropertyName);
        int? GetDefaultOptionSetValueOfProductProperty(string productId, string containsPropertyName);
        string GetDefaultOptionSetValueNameOfProductProperty(string productId, string containsPropertyName);

        DynamicProperty GetProductProperty(Guid productId, string propertyName);
        string GetDefaultStringOfProductProperty(Guid productId, string containsPropertyName);
        int? GetDefaultIntegerOfProductProperty(Guid productId, string containsPropertyName);
        int? GetDefaultOptionSetValueOfProductProperty(Guid productId, string containsPropertyName);
        string GetDefaultOptionSetValueNameOfProductProperty(Guid productId, string containsPropertyName);
    }

    public class PropertyRetrievalService : IPropertyRetrievalService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IPluginExecutionContext _context;

        public PropertyRetrievalService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service)
        {
            _tracingService = tracingService;
            _service = service;
            _context = context;
        }

        public DynamicProperty GetProductProperty(string productId, string containsPropertyName)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            #region Query Initialization
            var query = new QueryExpression(EntityNames.DynamicProperty.EntityLogicalName);
            query.ColumnSet.AddColumns(
                EntityNames.DynamicProperty.Name,
                EntityNames.DynamicProperty.DataType,
                EntityNames.DynamicProperty.DefaultAttributeValue,
                EntityNames.DynamicProperty.DefaultValueDecimal,
                EntityNames.DynamicProperty.DefaultValueDouble,
                EntityNames.DynamicProperty.DefaultValueInteger,
                EntityNames.DynamicProperty.DefaultValueOptionSet,
                EntityNames.DynamicProperty.DefaultValueString
            );
            query.Criteria.AddCondition(EntityNames.DynamicProperty.Name, ConditionOperator.Like, $"%{containsPropertyName}%");

            var query_dynamicpropertyassociation = query.AddLink(
                EntityNames.DynamicPropertyAssociation.EntityLogicalName,
                EntityNames.DynamicPropertyAssociation.DynamicPropertyId,
                EntityNames.DynamicProperty.DynamicPropertyId);
            query_dynamicpropertyassociation.LinkCriteria.AddCondition(
                EntityNames.DynamicPropertyAssociation.AssociationStatus, 
                ConditionOperator.Equal,
                (int) DynamicPropertyAssociation_AssociationStatus_OptionSet.Active);

            var query_dynamicpropertyassociation_product = query_dynamicpropertyassociation.AddLink(
                EntityNames.Product.EntityLogicalName,
                EntityNames.DynamicPropertyAssociation.RegardingObjectid,
                EntityNames.Product.ProductId);
            query_dynamicpropertyassociation_product.LinkCriteria.AddCondition(EntityNames.Product.ProductId, ConditionOperator.Equal, productId);
            #endregion

            #region Record Retrieval
            _tracingService.Trace($"{MethodBase.GetCurrentMethod().Name} method attempting to retrieve \"{containsPropertyName}\" product property");
            var productProperties = _service.RetrieveMultiple(query);

            if (productProperties.Entities.Count == 0)
                throw new InvalidPluginExecutionException($"Failed to retrieve default value of \"{containsPropertyName}\" product property");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return productProperties.Entities.FirstOrDefault() as DynamicProperty;
            #endregion
        }


        public string GetDefaultStringOfProductProperty(string productId, string containsPropertyName)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");
            var dynamicProperty = GetProductProperty(productId, containsPropertyName);

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return dynamicProperty.DefaultValueString;
        }

        public int? GetDefaultIntegerOfProductProperty(string productId, string containsPropertyName)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");
            var dynamicProperty = GetProductProperty(productId, containsPropertyName);

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return dynamicProperty.DefaultValueInteger;
        }

        public int? GetDefaultOptionSetValueOfProductProperty(string productId, string containsPropertyName)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");
            var dynamicProperty = GetProductProperty(productId, containsPropertyName);

            int? dynamicPropertyOptionValue = null;
            if (dynamicProperty.DefaultValueOptionSet != null)
            {
                _tracingService.Trace($"{MethodBase.GetCurrentMethod().Name} method attempts to retrieve \"{containsPropertyName}\" property option set value.");
                dynamicPropertyOptionValue = (_service.Retrieve(
                    EntityNames.DynamicPropertyOptionSetItem.EntityLogicalName,
                    dynamicProperty.DefaultValueOptionSet.Id,
                    new ColumnSet(
                        EntityNames.DynamicPropertyOptionSetItem.DynamicPropertyOptionName,
                        EntityNames.DynamicPropertyOptionSetItem.DynamicPropertyOptionValue
                    )
                ) as DynamicPropertyOptionSetItem).DynamicPropertyOptionValue;
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return dynamicPropertyOptionValue;
        }

        public string GetDefaultOptionSetValueNameOfProductProperty(string productId, string containsPropertyName)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");
            var dynamicProperty = GetProductProperty(productId, containsPropertyName);

            string dynamicPropertyOptionName = null;
            if (dynamicProperty.DefaultValueOptionSet != null)
            {
                _tracingService.Trace($"{MethodBase.GetCurrentMethod().Name} method attempts to retrieve \"{containsPropertyName}\" property option set value.");
                dynamicPropertyOptionName = (_service.Retrieve(
                    EntityNames.DynamicPropertyOptionSetItem.EntityLogicalName,
                    dynamicProperty.DefaultValueOptionSet.Id,
                    new ColumnSet(
                        EntityNames.DynamicPropertyOptionSetItem.DynamicPropertyOptionName,
                        EntityNames.DynamicPropertyOptionSetItem.DynamicPropertyOptionValue
                    )
                ) as DynamicPropertyOptionSetItem).DynamicPropertyOptionName;
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return dynamicPropertyOptionName;
        }

        public DynamicProperty GetProductProperty(Guid productId, string containsPropertyName)
        {
            return GetProductProperty(productId.ToString(), containsPropertyName);
        }

        public string GetDefaultStringOfProductProperty(Guid productId, string containsPropertyName)
        {
            return GetDefaultStringOfProductProperty(productId.ToString(), containsPropertyName);
        }

        public int? GetDefaultIntegerOfProductProperty(Guid productId, string containsPropertyName)
        {
            return GetDefaultIntegerOfProductProperty(productId.ToString(), containsPropertyName);
        }

        public int? GetDefaultOptionSetValueOfProductProperty(Guid productId, string containsPropertyName)
        {
            return GetDefaultOptionSetValueOfProductProperty(productId.ToString(), containsPropertyName);
        }

        public string GetDefaultOptionSetValueNameOfProductProperty(Guid productId, string containsPropertyName)
        {
            return GetDefaultOptionSetValueNameOfProductProperty(productId.ToString(), containsPropertyName);
        }
    }
}