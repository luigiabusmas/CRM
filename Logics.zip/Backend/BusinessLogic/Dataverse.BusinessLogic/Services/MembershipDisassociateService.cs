﻿using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipDisassociateService
    {
        void MembershipDisassociateValidation();
    }

    public class MembershipDisassociateService : IMembershipDisassociateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IPluginExecutionContext _context;
        private IAccountContactSyncService _syncService;

        public MembershipDisassociateService(ITracingService tracingService, IPluginExecutionContext context, IOrganizationService service, IAccountContactSyncService syncService)
        {
            _tracingService = tracingService;
            _service = service;
            _context = context;
            _syncService = syncService;
        }

        public void MembershipDisassociateValidation()
        {
            _tracingService.Trace("MembershipDisassociateValidation Start");

            EntityReferenceCollection relatedEntities = null;
            EntityReference targetEntity = null;
            EntityReference relatedEntity = null;

            targetEntity = (EntityReference)_context.InputParameters["Target"];
            _tracingService.Trace("targetEntity: " + targetEntity.Id.ToString());

            if (_context.InputParameters.Contains("RelatedEntities") && _context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
            {
                relatedEntities = _context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                relatedEntity = relatedEntities[0];

                if (relatedEntity != null)
                {
                    _tracingService.Trace("relatedEntity: " + relatedEntity.Id.ToString());

                    // Retrieving contact
                    Entity contact = null;
                    try
                    {
                        contact = _service.Retrieve(Contact.EntityLogicalName, relatedEntity.Id, new ColumnSet(EntityNames.Contact.IsPrimaryMember));
                    }
                    catch
                    {
                        _tracingService.Trace("Failed to retrieve related contact.");
                    }

                    // Validating + other logics
                    if (contact != null)
                    {
                        var isPrimaryMember = contact.GetAttributeValue<OptionSetValue>(EntityNames.Contact.IsPrimaryMember);

                        if (isPrimaryMember == null || isPrimaryMember.Value == 120000000)
                        {
                            _syncService.UpdateMemberDetails(relatedEntity.Id);
                        }
                        else if (isPrimaryMember.Value == 120000001)
                        {
                            throw new InvalidPluginExecutionException("Primary Member should not be removed. Please do not remove the Primary Member!");
                        }
                    }
                }
            }

            _tracingService.Trace("MembershipDisassociateValidation End");
        }
    }
}
