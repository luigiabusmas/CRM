using System;
using System.Collections.Generic;
using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;

namespace Cultivate.BusinessLogic.Services
{
    /// <summary>
    /// Represents a split payment between voucher and card amounts.
    /// </summary>
    public class PaymentSplit
    {
        /// <summary>
        /// The amount to be paid via voucher.
        /// </summary>
        public decimal VoucherAmount { get; set; }

        /// <summary>
        /// The amount to be paid via card.
        /// </summary>
        public decimal CardAmount { get; set; }

        /// <summary>
        /// Indicates whether this is a split payment (both voucher and card).
        /// </summary>
        public bool IsSplitPayment { get; set; }
    }

    public class PaymentResult
    {
        public Guid? TransactionId { get; set; }
        public string TransactionNumber { get; set; }
    }

    /// <summary>
    /// Service for handling payment processing including standard payments and Tesco vouchers.
    /// </summary>
    public interface IPaymentProcessingService
    {
        /// <summary>
        /// Handles payment processing and mandate creation for a membership.
        /// </summary>
        void HandleMembershipPayment(
            Portalsession portalSession,
            Membership membership,
            Contact payer,
            PortalSessionDiscount portalSessionDiscount
        );

        /// <summary>
        /// Processes a split payment (voucher + card) for gift packs.
        /// </summary>
        PaymentResult ProcessSplitPayment(
            Portalsession portalSession,
            Guid recordId,
            Guid payerId,
            PaymentSplit paymentSplit,
            PortalSessionDiscount discount,
            List<GiftPack> giftPacks = null
        );

        /// <summary>
        /// Processes a standard gift pack payment.
        /// </summary>
        PaymentResult ProcessStandardGiftPackPayment(
            Portalsession portalSession,
            Guid giftPackOrderId,
            Guid payerId,
            decimal totalAmount,
            List<GiftPack> giftPackEntities
        );

        /// <summary>
        /// Calculates the payment split between voucher and card.
        /// </summary>
        PaymentSplit CalculatePaymentSplit(decimal totalAmount, PortalSessionDiscount discount);

        /// <summary>
        /// Marks a portal session as processed.
        /// </summary>
        void MarkPortalSessionAsProcessed(Portalsession portalSession, Guid transactionId);

        /// <summary>
        /// Marks a portal session as processed with transaction number.
        /// </summary>
        void MarkPortalSessionAsProcessed(Portalsession portalSession, Guid transactionId, string transactionNumber);
    }

    /// <summary>
    /// Service for handling payment processing including standard payments and Tesco vouchers.
    /// </summary>
    public class PaymentProcessingService : IPaymentProcessingService
    {
        #region Fields

        private readonly ITracingService _tracingService;
        private readonly ISubmitPaymentService _submitPaymentService;
        private readonly IDirectDebitMandateService _directDebitMandateService;
        private readonly IRepository<Portalsession> _portalSessionRepository;
        private readonly IRepository<Transaction> _transactionRepository;
        private readonly IPortalSessionContactAccountDetailsRepository _portalSessionContactAccountDetailsRepository;
        private readonly ICommonService _commonService;

        #endregion Fields

        #region Constructor

        public PaymentProcessingService(
            ITracingService tracingService,
            ISubmitPaymentService submitPaymentService,
            IDirectDebitMandateService directDebitMandateService,
            IRepository<Portalsession> portalSessionRepository,
            IRepository<Transaction> transactionRepository,
            IPortalSessionContactAccountDetailsRepository portalSessionContactAccountDetailsRepository,
            ICommonService commonService
        )
        {
            _tracingService =
                tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _submitPaymentService =
                submitPaymentService
                ?? throw new ArgumentNullException(nameof(submitPaymentService));
            _directDebitMandateService =
                directDebitMandateService
                ?? throw new ArgumentNullException(nameof(directDebitMandateService));
            _portalSessionRepository =
                portalSessionRepository
                ?? throw new ArgumentNullException(nameof(portalSessionRepository));
            _transactionRepository =
                transactionRepository
                ?? throw new ArgumentNullException(nameof(transactionRepository));
            _portalSessionContactAccountDetailsRepository =
                portalSessionContactAccountDetailsRepository
                ?? throw new ArgumentNullException(
                    nameof(portalSessionContactAccountDetailsRepository)
                );
            _commonService = commonService ?? throw new ArgumentNullException(nameof(commonService));
        }

        #endregion Constructor

        #region Public Methods

        public void HandleMembershipPayment(Portalsession portalSession, Membership membership, Contact payer, PortalSessionDiscount portalSessionDiscount)
        {
            if (_commonService.IsTescoVoucherPayment(portalSession))
            {
                var result = ProcessSplitPayment(
                    portalSession,
                    membership.Id,
                    payer.Id,
                    CalculatePaymentSplit(membership.TotalAmount?.Value ?? 0, portalSessionDiscount),
                    portalSessionDiscount
                );

                if (result?.TransactionId.HasValue == true)
                {
                    MarkPortalSessionAsProcessed(portalSession, result.TransactionId.Value, result.TransactionNumber);
                }

                return;
            }

            // Standard payment
            var submitCommand = CreateSubmitPaymentCommand(portalSession, membership.Id, payer.Id);

            // For Direct Debit, set outstanding amount to the total amount since payment hasn't been claimed yet
            if (portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                submitCommand.TotalAmount = membership.TotalAmount;
                submitCommand.OutstandingAmount = membership.TotalAmount;
            }

            var submitResult = _submitPaymentService.SubmitPayment(submitCommand);

            if (portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                var transaction = CreateDirectDebitMandate(portalSession, submitResult.TransactionId.Value);
                if (transaction != null)
                {
                    MarkPortalSessionAsProcessed(portalSession, transaction.Id, transaction.TransacID);
                    return;
                }
            }

            if (submitResult.TransactionId.HasValue)
            {
                MarkPortalSessionAsProcessed(portalSession, submitResult.TransactionId.Value, submitResult.TransactionNumber);
            }
        }

        public PaymentResult ProcessSplitPayment(
            Portalsession portalSession,
            Guid recordId,
            Guid payerId,
            PaymentSplit paymentSplit,
            PortalSessionDiscount discount,
            List<GiftPack> giftPacks = null
        )
        {
            PaymentResult paymentResult = new PaymentResult();

            if (paymentSplit.VoucherAmount > 0)
            {
                var voucherCommand = CreateTescoVoucherPaymentCommand(
                    portalSession,
                    recordId,
                    payerId,
                    paymentSplit.VoucherAmount,
                    paymentSplit.IsSplitPayment,
                    discount
                );

                var voucherResult = _submitPaymentService.SubmitPayment(voucherCommand, giftPacks);
                if (voucherResult?.TransactionId is Guid vId && vId != Guid.Empty)
                {
                    paymentResult.TransactionId = vId;
                    paymentResult.TransactionNumber = voucherResult.TransactionNumber;
                }
            }

            if (paymentSplit.CardAmount > 0)
            {
                var cardCommand = CreateCardPaymentCommand(
                    portalSession,
                    recordId,
                    payerId,
                    paymentSplit.CardAmount,
                    discount
                );

                var cardResult = _submitPaymentService.SubmitPayment(cardCommand, giftPacks);
                if (cardResult?.TransactionId is Guid cId && cId != Guid.Empty)
                {
                    paymentResult.TransactionId = cId;
                    paymentResult.TransactionNumber = cardResult.TransactionNumber;
                }
            }

            return paymentResult;
        }

        public PaymentResult ProcessStandardGiftPackPayment(
            Portalsession portalSession,
            Guid giftPackOrderId,
            Guid payerId,
            decimal totalAmount,
            List<GiftPack> giftPackEntities
        )
        {
            var submitPaymentCommand = CreateSubmitPaymentCommand(
                portalSession,
                giftPackOrderId,
                payerId
            );
            submitPaymentCommand.TotalAmount = new Money(totalAmount);

            // For Direct Debit, set outstanding amount to total since payment hasn't been claimed yet
            submitPaymentCommand.OutstandingAmount =
                portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit
                ? new Money(totalAmount)
                : new Money(0);

            submitPaymentCommand.Type = (int)Typetransaction_GlobalOptionSet.FullPayment;

            var result = _submitPaymentService.SubmitPayment(
                submitPaymentCommand,
                giftPackEntities
            );

            if (result?.TransactionId is Guid transactionId && transactionId != Guid.Empty)
            {
                return new PaymentResult { TransactionId = transactionId, TransactionNumber = result.TransactionNumber };
            }

            return null;
        }

        public PaymentSplit CalculatePaymentSplit(
            decimal totalAmount,
            PortalSessionDiscount discount
        )
        {
            var voucherAmount = _commonService.GetVoucherDiscount(discount);
            var cardAmount = totalAmount - voucherAmount;
            var isSplitPayment = voucherAmount > 0 && cardAmount > 0;

            return new PaymentSplit
            {
                VoucherAmount = voucherAmount,
                CardAmount = cardAmount,
                IsSplitPayment = isSplitPayment,
            };
        }

        public void MarkPortalSessionAsProcessed(Portalsession portalSession, Guid transactionId)
        {
            MarkPortalSessionAsProcessed(portalSession, transactionId, null);
        }

        public void MarkPortalSessionAsProcessed(Portalsession portalSession, Guid transactionId, string transactionNumber)
        {
            _tracingService.Trace(
                "Updating portal session with payment details and setting status to inactive."
            );

            var updatePortalSession = new Portalsession
            {
                Id = portalSession.Id,
                TransactionID = transactionId.ToString(),
                TransactionNumber = transactionNumber,
                Statecode = PortalsessionState.Inactive,
                Statuscode = PortalsessionStatus.Inactive_Processed,
            };

            _portalSessionRepository.Update(updatePortalSession);
        }

        #endregion Public Methods

        #region Private Payment Processing

        private Transaction CreateDirectDebitMandate(Portalsession portalSession, Guid transactionId)
        {
            var portalSessionContactAccountDetails =
                GetAccountDetails(portalSession.Payerid.Id)
                ?? throw new InvalidOperationException(
                    "No Portal Session Contact details found for the payer. Direct Debit Mandate cannot be created."
                );

            var transaction = _transactionRepository.GetById(transactionId);
            var directDebitMandate = _directDebitMandateService.CreateDirectDebitMandate(
                portalSessionContactAccountDetails,
                transaction
            );

            _transactionRepository.Update(
                new Transaction
                {
                    Id = transaction.Id,
                    Directdebitmandate = directDebitMandate.ToEntityReference(),
                }
            );

            return transaction;
        }

        #endregion Private Payment Processing

        #region Command Creation

        private SubmitPaymentCommand CreateTescoVoucherPaymentCommand(
            Portalsession portalSession,
            Guid recordId,
            Guid payerId,
            decimal amount,
            bool isPartialPayment,
            PortalSessionDiscount discount
        )
        {
            var command = CreateSubmitPaymentCommand(portalSession, recordId, payerId);
            command.PaymentReference = discount?.PromoCode;
            command.PaymentMethod = (int)Msnfp_paymentmethodtype_GlobalOptionSet.TescoVoucher;
            command.IsTescoVoucher = true;
            command.TotalAmount = new Money(amount);
            command.Type = isPartialPayment
                ? (int)Typetransaction_GlobalOptionSet.PartialPayment
                : (int)Typetransaction_GlobalOptionSet.FullPayment;
            command.OutstandingAmount = new Money(0);
            return command;
        }

        private SubmitPaymentCommand CreateCardPaymentCommand(
            Portalsession portalSession,
            Guid recordId,
            Guid payerId,
            decimal amount,
            PortalSessionDiscount discount
        )
        {
            var command = CreateSubmitPaymentCommand(portalSession, recordId, payerId);
            command.PaymentReference = discount?.PromoCode;
            command.PaymentMethod = (int)Msnfp_paymentmethodtype_GlobalOptionSet.Card;
            command.IsTescoVoucher = true;
            command.TotalAmount = new Money(amount);
            command.Type = (int)Typetransaction_GlobalOptionSet.PartialPayment;
            command.OutstandingAmount = new Money(0);
            return command;
        }

        private SubmitPaymentCommand CreateSubmitPaymentCommand(
            Portalsession portalSession,
            Guid recordId,
            Guid payerId
        )
        {
            return new SubmitPaymentCommand
            {
                PaymentMethod = (int)portalSession.PaymentMethodCode,
                TransactionType = (int)portalSession.ProductType,
                Type = (int)portalSession.PaymentType,
                RecordId = recordId,
                PayerId = payerId,
                PayerEntity = EntityNames.Contact.EntityLogicalName,
                PaymentFrequency = (int?)portalSession.PaymentFrequency,
                IsContiniousPayment = _commonService.IsContinuousPayment(portalSession),
                TransactionId = _commonService.GetTransactionIdFromSession(portalSession),
                OutstandingAmount = new Money(0),
                Channel = ChannelOptionChoice_GlobalOptionSet.Online,
            };
        }

        #endregion Command Creation

        #region Direct Debit

        private PortalSessionContactAccountDetails GetAccountDetails(Guid payerId) =>
            _portalSessionContactAccountDetailsRepository.GetByPayerId(payerId);

        #endregion Direct Debit
    }
}