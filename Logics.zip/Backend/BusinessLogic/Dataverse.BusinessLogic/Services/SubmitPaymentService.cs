﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface ISubmitPaymentService
    {
        bool ValidateIfInstantaneousPayment(PaymentMethodType_GlobalOptionSet? paymentMethod, bool? isContinuousPayment, PaymentFrequency_GlobalOptionSet? paymentFrequency);

        Payment CreatePaymentForInstantenousPayment(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money totalAmount, Money writtenOffAmmount, DateTime? paymentSchedule);

        public bool ValidateIfScheduledPayment(PaymentMethodType_GlobalOptionSet? paymentMethod, bool? isContinuousPayment, PaymentFrequency_GlobalOptionSet? paymentFrequency);

        bool ValidateRequiredFieldsForScheduledPayment(DateTime? startDate, DateTime? endDate, DateTime? paymentSchedule);

        (DateTime, Money, Money, Money, Money, int, int) PrepareDataForScheduledPayment(EntityReference recordReference, Money totalAmount, Money writtenOffAmount, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime payOutDate, DateTime startDate, DateTime endDate);

        PaymentSchedule CreatePaymentScheduleForScheduledPayment(EntityReference transactionEntityReference, EntityReference recordReference, Money expectedPaymentAmount, Money actualPaymentAmount, int numberOfPayments, PaymentMethodType_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime? payoutDate, DateTime? startDate, DateTime? endDate);

        List<Payment> CreateRecurringPaymentsForScheduledPayment(EntityReference recordReference, EntityReference transactionEntityReference, EntityReference paymentScheduleEntityReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, string paymentReferenceText, Money expectedPaymentAmount, Money expectedRemainderAmount, Money actualPaymentAmount, Money actualRemainderAmount, int numberOfPayments, int startingPaymentNumber, DateTime payoutDate, DateTime startDate);

        void LinkPaymentScheduleToMembershipForScheduledPayment(Guid transactionId, EntityReference paymentScheduleReference);

        Payment CreatePaymentForWrittenAmount(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money writtenOffAmmount);

        PaymentSchedule RetrievePreviousPaymentSchedule(EntityReference recordReference);

        List<Payment> RetrievePaidPayments(PaymentSchedule paymentSchedule);

        List<Payment> RetrieveUnpaidPayments(PaymentSchedule paymentSchedule);

        int GetNumberOfPayments(DateTime startDate, DateTime endDate, PaymentFrequency_GlobalOptionSet? paymentFrequency);

        int GetMonthDifference(DateTime startDate, DateTime endDate);

        int GetQuarterDifference(DateTime startDate, DateTime endDate);

        SubmitPaymentResult SubmitPayment(SubmitPaymentCommand command, List<GiftPack> giftPacks = null);
    }

    public class SubmitPaymentService : ISubmitPaymentService
    {
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;

        //private IPluginExecutionContext _context;
        private readonly IRepository<Transaction> _transactionRepository;

        private readonly IRepository<Payment> _paymentRepository;
        private readonly IRepository<PaymentSchedule> _paymentScheduleRepository;
        private readonly IRepository<Membership> _membershipRepository;
        private readonly IRepository<GiftPack> _giftPackRepository;
        private readonly IRepository<Giftpackorder> _giftPackOrderRepository;

        public SubmitPaymentService(ILogger logger, /*IPluginExecutionContext context, */IOrganizationService service, IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository, IRepository<PaymentSchedule> paymentScheduleRepository, IRepository<Membership> membershipRepository, IRepository<GiftPack> giftPackRepository, IRepository<Giftpackorder> giftPackOrderRepository)
        {
            _logger = logger;
            _service = service;
            //_context = context;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _paymentScheduleRepository = paymentScheduleRepository;
            _membershipRepository = membershipRepository;
            _giftPackRepository = giftPackRepository;
            _giftPackOrderRepository = giftPackOrderRepository;
        }

        #region Instantenous Payment

        public bool ValidateIfInstantaneousPayment(PaymentMethodType_GlobalOptionSet? paymentMethod, bool? isContinuousPayment, PaymentFrequency_GlobalOptionSet? paymentFrequency)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Payment method = {paymentMethod}.");
            _logger.TraceInformation($"Is continuous payment = {isContinuousPayment}.");
            _logger.TraceInformation($"Payment frequency = {paymentFrequency}.");

            var isInstantaneousPayment =
                paymentFrequency != PaymentFrequency_GlobalOptionSet.Monthly;
            _logger.TraceInformation($"Is instantaneous payment? {isInstantaneousPayment}.");

            _logger.TraceInformation($"Ending business logic.");
            return isInstantaneousPayment;
        }

        public Payment CreatePaymentForInstantenousPayment(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money totalAmount, Money writtenOffAmmount, DateTime? paymentSchedule)
        {
            // Delegate to overload with FullPayment as default type
            return CreatePaymentForInstantenousPayment(recordReference, transactionReference, payerReference, productReference, thirdPartyPaymentTypeReference,
                locationReference, channel, paymentMethod, payingInSlipNumber, paymentReferenceText, totalAmount, writtenOffAmmount, paymentSchedule, Typetransaction_GlobalOptionSet.FullPayment);
        }

        // New overload to allow dynamic payment type (Full/Partial) for instantaneous payments
        public Payment CreatePaymentForInstantenousPayment(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money totalAmount, Money writtenOffAmmount, DateTime? paymentSchedule, Typetransaction_GlobalOptionSet paymentType)
        {
            _logger.TraceInformation($"Starting business logic.");
            _logger.TraceInformation($"Preparing payment data.");

            var amount = totalAmount != null && writtenOffAmmount != null
        ? new Money(totalAmount.Value - writtenOffAmmount.Value)
          : totalAmount;

            var dueDate = paymentSchedule ?? DateTime.UtcNow;

            var paymentToCreate = BuildPayment(recordReference, transactionReference, payerReference, productReference, thirdPartyPaymentTypeReference, locationReference, channel, paymentMethod, payingInSlipNumber, paymentReferenceText, amount, writtenOffAmmount, dueDate, paymentType, false);

            _logger.TraceInformation($"Creating payment.");
            var payment = _paymentRepository.Create(paymentToCreate);
            _logger.TraceInformation($"Created payment w/ Id = {payment.Id}.");
            _logger.TraceInformation($"Ending business logic.");
            return payment;
        }

        public Payment CreateGiftPacksPaymentForInstantenousPayment(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money totalAmount, Money writtenOffAmmount, DateTime? paymentSchedule, Guid giftPackId, Typetransaction_GlobalOptionSet type)
        {
            _logger.TraceInformation($"Starting business logic.");

            var amount = totalAmount != null && writtenOffAmmount != null
                ? new Money(totalAmount.Value - writtenOffAmmount.Value)
                : totalAmount;

            var dueDate = paymentSchedule ?? DateTime.UtcNow;

            var paymentToCreate = BuildPayment(
                recordReference, transactionReference, payerReference, productReference, thirdPartyPaymentTypeReference,
                locationReference, channel, paymentMethod, payingInSlipNumber, paymentReferenceText, amount, writtenOffAmmount,
                dueDate, type, false
            );
            paymentToCreate.Giftpack = new EntityReference(GiftPack.EntityLogicalName, giftPackId);
            _logger.TraceInformation($"Creating payment.");
            var payment = _paymentRepository.Create(paymentToCreate);
            _logger.TraceInformation($"Created payment w/ Id = {payment.Id}.");
            _logger.TraceInformation($"Ending business logic.");
            return payment;
        }

        #endregion Instantenous Payment

        #region Scheduled Payment

        public bool ValidateIfScheduledPayment(PaymentMethodType_GlobalOptionSet? paymentMethod, bool? isContinuousPayment, PaymentFrequency_GlobalOptionSet? paymentFrequency)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Payment method = {paymentMethod}.");
            _logger.TraceInformation($"Is continuous payment = {isContinuousPayment}.");
            _logger.TraceInformation($"Payment frequency = {paymentFrequency}.");

            var isNonAnnualScheduledPayment =
                (paymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit || paymentMethod == PaymentMethodType_GlobalOptionSet.Card) &&
                isContinuousPayment == true &&
                paymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly;
            _logger.TraceInformation($"Is scheduled payment? {isNonAnnualScheduledPayment}.");

            _logger.TraceInformation($"Ending business logic.");
            return isNonAnnualScheduledPayment;
        }

        public bool ValidateRequiredFieldsForScheduledPayment(DateTime? startDate, DateTime? endDate, DateTime? paymentSchedule)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (startDate == null || endDate == null)
            {
                var errorMessage = $"Missing start date or end date for continuous payment.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }

            if (paymentSchedule == null)
            {
                var errorMessage = $"Missing payment schedule (date) for continuous payment.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }

            _logger.TraceInformation($"Ending business logic.");
            return true;
        }

        public PaymentSchedule RetrievePreviousPaymentSchedule(EntityReference recordReference)
        {
            _logger.TraceInformation($"Starting business logic.");

            PaymentSchedule latestCancelledPaymentSchedule = null;
            switch(recordReference.LogicalName)
            {
                case EntityNames.Membership.EntityLogicalName:
                    latestCancelledPaymentSchedule = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                        paymentSchedule.Membership != null && paymentSchedule.Membership.Id == recordReference.Id
                    ).OrderByDescending(paymentSchedule => paymentSchedule.CreatedOn).FirstOrDefault();
                    break;
                case EntityNames.Donation.EntityLogicalName:
                    latestCancelledPaymentSchedule = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                        paymentSchedule.Donationid != null && paymentSchedule.Donationid.Id == recordReference.Id
                    ).OrderByDescending(paymentSchedule => paymentSchedule.CreatedOn).FirstOrDefault();
                    break;
                case EntityNames.GiftPack.EntityLogicalName:
                    latestCancelledPaymentSchedule = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                        paymentSchedule.GiftPackId != null && paymentSchedule.GiftPackId.Id == recordReference.Id
                    ).OrderByDescending(paymentSchedule => paymentSchedule.CreatedOn).FirstOrDefault();
                    break;
                case EntityNames.GiftPackBulkPurchase.EntityLogicalName:
                    latestCancelledPaymentSchedule = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                        paymentSchedule.GiftPackBulkPurchaseId != null && paymentSchedule.GiftPackBulkPurchaseId.Id == recordReference.Id
                    ).OrderByDescending(paymentSchedule => paymentSchedule.CreatedOn).FirstOrDefault();
                    break;
                case "rhs_subscription":
                    latestCancelledPaymentSchedule = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                        paymentSchedule.SubscriptionId != null && paymentSchedule.SubscriptionId.Id == recordReference.Id
                    ).OrderByDescending(paymentSchedule => paymentSchedule.CreatedOn).FirstOrDefault();
                    break;
            } 

            _logger.TraceInformation(latestCancelledPaymentSchedule != null ? $"A payment schedule w/ Id = {latestCancelledPaymentSchedule.Id} has been cancelled previously." : "No payment schedule for this record was cancelled before.");

            _logger.TraceInformation($"Ending business logic.");
            return latestCancelledPaymentSchedule;
        }

        public List<Payment> RetrievePaidPayments(PaymentSchedule paymentSchedule)
        {
            _logger.TraceInformation($"Starting business logic.");

            var paidPayments = _paymentRepository.GetAll().Where(payment =>
                payment.PaymentSchedule == paymentSchedule.ToEntityReference() &&
                payment.Statuscode == PaymentStatus.Inactive_Paid
            ).OrderBy(payment => payment.CreatedOn).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return paidPayments;
        }

        public List<Payment> RetrieveUnpaidPayments(PaymentSchedule paymentSchedule)
        {
            _logger.TraceInformation($"Starting business logic.");

            var paidPayments = _paymentRepository.GetAll().Where(payment =>
                payment.PaymentSchedule == paymentSchedule.ToEntityReference() &&
                payment.Statuscode != PaymentStatus.Inactive_Paid
            ).OrderBy(payment => payment.CreatedOn).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return paidPayments;
        }

        public EntityReference RetrieveDonationType(Guid donationId)
        {
            _logger.TraceInformation("Start RetrieveDonationType");
            var donation = _service.Retrieve(Donation.EntityLogicalName, donationId, new ColumnSet("rhs_donationtype"));
            var donationType = donation != null ? donation.GetAttributeValue<EntityReference>("rhs_donationtype") : null;
            _logger.TraceInformation($"Successfully retrieved donation: {donationId}");

            _logger.TraceInformation("End RetrieveDonationType");

            return donationType;
        }

        public (DateTime, Money, Money, Money, Money, int, int) PrepareDataForScheduledPayment(EntityReference recordReference, Money totalAmount, Money writtenOffAmount, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime payoutDate, DateTime startDate, DateTime endDate)
        {
            _logger.TraceInformation($"Starting business logic.");

            int numberOfPayments = 0, startingPaymentNumber = 0;
            Money subtractedTotalAmount = null, expectedPaymentAmount = null, expectedRemainderAmount = null, actualPaymentAmount = null, actualRemainderAmount = null;
            DateTime earliestPaymentDueDate = payoutDate;

            var previousPaymentSchedule = RetrievePreviousPaymentSchedule(recordReference);
            if (previousPaymentSchedule != null)
            {
                var unpaidPayments = RetrieveUnpaidPayments(previousPaymentSchedule);
                if (unpaidPayments != null)
                {
                    _logger.TraceInformation($"Preparing data for regeneration of payment scedule and payments.");
                    _logger.TraceInformation($"Count of unpaid payments = {unpaidPayments.Count}.");

                    var earliestUnpaidPayment = unpaidPayments.First();
                    _logger.TraceInformation($"Preparing data for regeneration of payment scedule and payments.");

                    earliestPaymentDueDate = (DateTime)earliestUnpaidPayment.DueDate;
                    numberOfPayments = unpaidPayments.Count();
                    startingPaymentNumber = earliestUnpaidPayment.PaymentNumber != null ? (int)earliestUnpaidPayment.PaymentNumber : 1;
                }
            }
            else
            {
                _logger.TraceInformation($"Preparing data for 1st time generation of payment scedule and payments.");

                numberOfPayments = GetNumberOfPayments(startDate, endDate, paymentFrequency);
                startingPaymentNumber = 1;
            }

            _logger.TraceInformation($"Preparing payment amount and remainder.");
            // Get expected payment amount and remainder
            expectedPaymentAmount = new Money((decimal)(int)(totalAmount.Value * 100 / numberOfPayments) / 100);
            expectedRemainderAmount = new Money((decimal)(int)(totalAmount.Value * 100 % numberOfPayments) / 100);
            // Get actual payment amount and remainder
            subtractedTotalAmount = totalAmount != null && writtenOffAmount != null ? new Money(totalAmount.Value - writtenOffAmount.Value) : totalAmount;
            actualPaymentAmount = new Money((decimal)(int)(subtractedTotalAmount.Value * 100 / numberOfPayments) / 100);
            actualRemainderAmount = new Money((decimal)(int)(subtractedTotalAmount.Value * 100 % numberOfPayments) / 100);

            _logger.TraceInformation($"Ending business logic.");
            return (earliestPaymentDueDate, expectedPaymentAmount, expectedRemainderAmount, actualPaymentAmount, actualRemainderAmount, numberOfPayments, startingPaymentNumber);
        }

        public PaymentSchedule CreatePaymentScheduleForScheduledPayment(EntityReference transactionEntityReference, EntityReference recordReference, Money expectedPaymentAmount, Money actualPaymentAmount, int numberOfPayments, PaymentMethodType_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime? payoutDate, DateTime? startDate, DateTime? endDate)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Preparing payment schedule data.");
            var paymentScheduleToCreate = new PaymentSchedule()
            {
                PaymentFrequencys = paymentFrequency,
                PaymentTypesCode = paymentMethod,
                StartDate = startDate,
                EndDate = endDate,
                Date = payoutDate,
                PaymentDue = payoutDate,
                NumberofPayments = numberOfPayments,
                PaymentAmount = actualPaymentAmount,
                WrittenOffAmount = expectedPaymentAmount.Value != actualPaymentAmount.Value ? new Money(expectedPaymentAmount.Value - actualPaymentAmount.Value) : null,
                Statecode = PaymentScheduleState.Active,
                Statuscode = PaymentScheduleStatus.Active_Pending
            };

            switch (recordReference.LogicalName)
            {
                case EntityNames.Membership.EntityLogicalName:
                    paymentScheduleToCreate.Membership = recordReference;
                    break;

                case EntityNames.GiftPack.EntityLogicalName:
                    paymentScheduleToCreate.GiftPackId = recordReference;
                    break;

                case EntityNames.GiftPackBulkPurchase.EntityLogicalName:
                    paymentScheduleToCreate.GiftPackBulkPurchaseId = recordReference;
                    break;

                case "rhs_subscription":
                    paymentScheduleToCreate.SubscriptionId = recordReference;
                    break;

                case EntityNames.Donation.EntityLogicalName:
                    paymentScheduleToCreate.Donationid = recordReference;
                    break;
            }

            _logger.TraceInformation($"Creating payment schedule.");
            var paymentSchedule = _paymentScheduleRepository.Create(paymentScheduleToCreate);
            _logger.TraceInformation($"Created payment schedule w/ Id = {paymentSchedule.Id}.");

            _logger.TraceInformation($"Ending business logic.");
            return paymentSchedule;
        }

        public List<Payment> CreateRecurringPaymentsForScheduledPayment(EntityReference recordReference, EntityReference transactionEntityReference, EntityReference paymentScheduleEntityReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, string paymentReferenceText, Money expectedPaymentAmount, Money expectedRemainderAmount, Money actualPaymentAmount, Money actualRemainderAmount, int numberOfPayments, int startingPaymentNumber, DateTime payoutDate, DateTime startDate)
        {
            _logger.TraceInformation($"Start Creating recurring payments. Initial payout date: {payoutDate:yyyy-MM-dd}");

            var paymentsToCreate = new List<Payment>();

            for (int count = 0; count < numberOfPayments; count++)
            {
                // Payment Due Date calculation
                DateTime paymentDueDate;
                DateTime paymentDueDateWithoutTime;

                if (count == 0 || startDate.AddMonths(count) < payoutDate)
                {
                    paymentDueDate = payoutDate;
                }
                else
                {
                    paymentDueDate = startDate.AddMonths(count);
                }

                paymentDueDateWithoutTime = paymentDueDate.Date;

                // Payment data preparation
                var paymentToCreate = BuildPayment(recordReference, transactionEntityReference, payerReference, productReference, thirdPartyPaymentTypeReference, locationReference, channel, paymentMethod, null, paymentReferenceText, count == 0 ? new Money(actualPaymentAmount.Value + actualRemainderAmount.Value) : actualPaymentAmount, count == 0 ? new Money((expectedPaymentAmount.Value + expectedRemainderAmount.Value) - (actualPaymentAmount.Value + actualRemainderAmount.Value)) : new Money(expectedPaymentAmount.Value - actualPaymentAmount.Value), paymentDueDateWithoutTime, Typetransaction_GlobalOptionSet.PartialPayment);

                paymentToCreate.PaymentNumber = count + startingPaymentNumber;
                paymentToCreate.PaymentSchedule = paymentScheduleEntityReference;

                paymentsToCreate.Add(paymentToCreate);
            }

            var payments = new List<Payment>();
            foreach (var paymentToCreate in paymentsToCreate)
            {
                var payment = _paymentRepository.Create(paymentToCreate);
                payments.Add(payment);
            }
            return payments;
        }

        public void LinkPaymentScheduleToMembershipForScheduledPayment(Guid transactionId, EntityReference paymentScheduleReference)
        {
            _logger.TraceInformation($"Starting business logic.");

            var transactionToUpdate = new Transaction()
            {
                Id = transactionId,
                PaymentScheduleTransaction = paymentScheduleReference,
            };

            _logger.TraceInformation($"Linking payment schedule to membership.");
            _transactionRepository.Update(transactionToUpdate);

            _logger.TraceInformation($"Ending business logic.");
        }

        #endregion Scheduled Payment

        public Payment CreatePaymentForWrittenAmount(EntityReference recordReference, EntityReference transactionReference, EntityReference payerReference, EntityReference productReference, EntityReference thirdPartyPaymentTypeReference, EntityReference locationReference, ChannelOptionChoice_GlobalOptionSet? channel, PaymentMethodType_GlobalOptionSet? paymentMethod, int? payingInSlipNumber, string paymentReferenceText, Money writtenOffAmmount)
        {
            _logger.TraceInformation($"Starting business logic.");
            _logger.TraceInformation($"Preparing payment data.");

            var paymentToCreate = BuildPayment(
                recordReference,
                transactionReference,
                payerReference,
                productReference,
                thirdPartyPaymentTypeReference,
                locationReference,
                channel,
                paymentMethod,
                payingInSlipNumber,
                paymentReferenceText,
                writtenOffAmmount,
                writtenOffAmmount,
                DateTime.UtcNow,
                Typetransaction_GlobalOptionSet.FullPayment,
                false);

            _logger.TraceInformation($"Creating payment.");
            var payment = _paymentRepository.Create(paymentToCreate);
            _logger.TraceInformation($"Created payment w/ Id = {payment.Id}.");

            _logger.TraceInformation($"Updating payment as paid.");
            var paymentUpdate = new Payment()
            {
                Id = payment.Id,
                Statecode = PaymentState.Inactive,
                Statuscode = PaymentStatus.Inactive_Paid
            };
            _paymentRepository.Update(paymentUpdate);
            _logger.TraceInformation($"Updated payment as paid.");

            _logger.TraceInformation($"Ending business logic.");
            return payment;
        }

        //public void UpdateMembershipPaymentReceivedToYes(Membership membership)
        //{
        //    _logger.TraceInformation($"Starting business logic.");

        //    var membershipToUpdate = new Membership()
        //    {
        //        Id = membership.Id,
        //        PaymentReceived = true
        //    };

        //    _logger.TraceInformation($"Updating membership payment received to 'Yes'.");
        //    _service.Update(membershipToUpdate);

        //    _logger.TraceInformation($"Ending business logic.");
        //}

        #region Helper methods

        private static Typetransaction_GlobalOptionSet ResolvePaymentType(SubmitPaymentCommand command)
        {
            return (command.IsTescoVoucher && command.Type.HasValue) ? (Typetransaction_GlobalOptionSet)command.Type.Value : Typetransaction_GlobalOptionSet.FullPayment;
        }

        private void ProcessMembershipInstantaneousPayment(TransactionPreparationResult result, SubmitPaymentResult response, SubmitPaymentCommand command, Transaction transaction)
        {
            var paymentType = ResolvePaymentType(command);
            var payment = CreatePaymentForInstantenousPayment(result.RecordReference, transaction.ToEntityReference(), result.PayerReference, result.ProductReference,
                result.ThirdPartyPaymentTypeReference, result.LocationReference, result.Channel, result.PaymentMethod, result.PayingInSlipNumber, result.PaymentReferenceText,
                result.TotalAmount, result.WrittenOffAmount, result.PayoutDate, paymentType);

            response.PaymentId = payment.Id;

            if (result.Channel == ChannelOptionChoice_GlobalOptionSet.Online && result.PaymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                MarkPaymentAsPaid(payment.Id);
            }
        }

        private void ProcessGiftPackInstantaneousPayment(TransactionPreparationResult result, SubmitPaymentResult response, SubmitPaymentCommand command, Transaction transaction, List<GiftPack> giftPacks)
        {
            var packs = giftPacks ?? RetrieveGiftPacksfromGiftPackOrder(result.RecordReference.Id);

            if (command.IsTescoVoucher)
            {
                if (packs.Count == 0)
                    throw new ArgumentException("No GiftPack found for Tesco Voucher order.");
                ProcessGiftPackPayment(result, response, command, transaction, packs.FirstOrDefault());
            }
            else
            {
                foreach (var giftPack in packs)
                {
                    ProcessGiftPackPayment(result, response, command, transaction, giftPack);
                }
            }
        }

        public int GetNumberOfPayments(DateTime startDate, DateTime endDate, PaymentFrequency_GlobalOptionSet? paymentFrequency)
        {
            _logger.TraceInformation($"Starting business logic.");

            var numberOfPayments = 1;
            switch (paymentFrequency)
            {
                //case PaymentFrequency_GlobalOptionSet.Annually:
                //    break;
                //case PaymentFrequency_GlobalOptionSet.Quarterly:
                //    numberOfPayments = GetQuarterDifference((DateTime)membership.Msnfp_startdate, (DateTime)membership.Msnfp_enddate);
                //    break;
                case PaymentFrequency_GlobalOptionSet.Monthly:
                    numberOfPayments = GetMonthDifference(startDate, endDate);
                    break;
            }

            _logger.TraceInformation($"Ending business logic.");
            return numberOfPayments;
        }

        public int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            _logger.TraceInformation($"Starting business logic.");

            var unsubtractedEndDate = endDate.AddDays(1);
            var monthsApart = 12 * (startDate.Year - unsubtractedEndDate.Year) + startDate.Month - unsubtractedEndDate.Month;
            _logger.TraceInformation($"Month difference between {startDate} and {endDate} = {monthsApart}.");

            _logger.TraceInformation($"Ending business logic.");
            return Math.Abs(monthsApart);
        }

        public int GetQuarterDifference(DateTime startDate, DateTime endDate)
        {
            _logger.TraceInformation($"Starting business logic.");

            var quartersApart = GetMonthDifference(startDate, endDate) / 3;
            _logger.TraceInformation($"Quarter difference between {startDate} and {endDate} = {quartersApart}.");

            _logger.TraceInformation($"Ending business logic.");
            return Math.Abs(quartersApart);
        }

        #endregion Helper methods

        private Transaction BuildTransaction(
            EntityReference recordReference,
            EntityReference payerReference,
            EntityReference productReference,
            PaymentMethodType_GlobalOptionSet? paymentMethod,
            Money totalAmount,
            Money outstandingAmount,
            Money writtenOffAmmount)
        {
            var transactionToCreate = new Transaction()
            {
                Customer = payerReference,
                PaymentMethod_Code = paymentMethod,
                Product = productReference,
                Amount = totalAmount != null && writtenOffAmmount != null ? new Money(totalAmount.Value - writtenOffAmmount.Value) : totalAmount,
                OutstandingAmount = outstandingAmount != null && writtenOffAmmount != null ? new Money(outstandingAmount.Value - writtenOffAmmount.Value) : outstandingAmount,
                WrittenOffAmount = writtenOffAmmount,
                Type = Typetransaction_GlobalOptionSet.FullPayment,
                Statuscode = TransactionStatus.Active_PendingPayment,
            };

            switch (recordReference.LogicalName)
            {
                case EntityNames.Membership.EntityLogicalName:
                    transactionToCreate.MembershipId = recordReference;
                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.Membership;
                    break;

                /*case EntityNames.GiftPack.EntityLogicalName:
                    transactionToCreate.GiftPackId = recordReference;

                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;*/

                case EntityNames.Giftpackorder.EntityLogicalName:
                    transactionToCreate.Giftpackorder = recordReference;
                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;

                case EntityNames.GiftPackBulkPurchase.EntityLogicalName:
                    transactionToCreate.GiftPackBulkPurchaseId = recordReference;
                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;

                case "rhs_subscription":
                    transactionToCreate.SubscriptionId = recordReference;
                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.Subscriptions;
                    break;

                case EntityNames.Donation.EntityLogicalName:
                    transactionToCreate.Donation = recordReference;
                    transactionToCreate.TransactionType = NewTransactionType_GlobalOptionSet.Donation;
                    break;
            }

            return transactionToCreate;
        }

        private Payment BuildPayment(
            EntityReference recordReference,
            EntityReference transactionReference,
            EntityReference payerReference,
            EntityReference productReference,
            EntityReference thirdPartyPaymentTypeReference,
            EntityReference locationReference,
            ChannelOptionChoice_GlobalOptionSet? channel,
            PaymentMethodType_GlobalOptionSet? paymentMethod,
            int? payingInSlipNumber,
            string paymentReferenceText,
            Money amount,
            Money writtenOffAmmount,
            DateTime dueDate,
            Typetransaction_GlobalOptionSet type,
            bool exportToFinance = false)
        {
            var paymentToCreate = new Payment()
            {
                Transaction = transactionReference,
                Payer = payerReference,
                PaymentMethodType = paymentMethod,
                Amount = amount,
                WrittenOffAmount = writtenOffAmmount,
                DueDate = dueDate,
                Type = type,
                ExporttoFinance = exportToFinance,
                Product = productReference,
                ThirdPartyPaymentType = thirdPartyPaymentTypeReference,
                PaymentReference = paymentReferenceText,
                PayingInSlipNumber = payingInSlipNumber,
                ChannelSource = channel,
                Location = locationReference
            };

            switch (recordReference.LogicalName)
            {
                case EntityNames.Membership.EntityLogicalName:
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.Membership;
                    break;

                case EntityNames.GiftPack.EntityLogicalName:
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;

                case EntityNames.Giftpackorder.EntityLogicalName:
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;

                case EntityNames.GiftPackBulkPurchase.EntityLogicalName:
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.GiftPack;
                    break;

                case "rhs_subscription":
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.Subscriptions;
                    break;

                case EntityNames.Donation.EntityLogicalName:
                    paymentToCreate.PaymentType = NewTransactionType_GlobalOptionSet.Donation;
                    paymentToCreate.DonationProduct = RetrieveDonationType(recordReference.Id);
                    break;
            }

            return paymentToCreate;
        }

        public TransactionPreparationResult PrepareDataBasedOnTransactionType(SubmitPaymentCommand command)
        {
            switch (command.TransactionType)
            {
                case (int?)NewTransactionType_GlobalOptionSet.Membership:
                    return PrepareMembershipData(command);

                case (int?)NewTransactionType_GlobalOptionSet.GiftPack:
                    //return PrepareGiftPackData(command);
                    return PrepareGiftPackOrderData(command);

                case (int?)NewTransactionType_GlobalOptionSet.Subscriptions:
                    return PrepareSubscriptionData(command);

                case (int?)NewTransactionType_GlobalOptionSet.Donation:
                    return PrepareDonationData(command);

                default:
                    throw new ArgumentOutOfRangeException(nameof(command), "Unsupported transaction type.");
            }
        }

        private TransactionPreparationResult PrepareMembershipData(SubmitPaymentCommand command)
        {
            var membership = _membershipRepository.GetById((Guid)command.RecordId);

            return new TransactionPreparationResult
            {
                RecordReference = new EntityReference(EntityNames.Membership.EntityLogicalName, membership.Id),
                ProductReference = membership.MembershipProductId,
                Channel = membership.Channel,
                LocationReference = membership.Location,
                PaymentMethod = command.PaymentMethod != null ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : (PaymentMethodType_GlobalOptionSet?)membership.PaymentMethod,
                ThirdPartyPaymentTypeReference = membership.ThirdPartyPaymentType,
                PaymentReferenceText = command.PaymentReference,
                PayerReference = command.PayerId != null && command.PayerEntity != null ? new EntityReference(command.PayerEntity, (Guid)command.PayerId) : membership.PayerV2ContactRef,
                TotalAmount = command.TotalAmount ?? membership.TotalAmount,
                PaymentFrequency = command.PaymentFrequency != null ? (PaymentFrequency_GlobalOptionSet)command.PaymentFrequency : membership.PaymentFrequency,
                PayoutDate = membership.PaymentSchedule,
                IsContinuousPayment = command.IsContiniousPayment ?? membership.IsContinuousPayment,
                OutstandingAmount = command.OutstandingAmount ?? membership.OutstandingAmount,
                WrittenOffAmount = command.WrittenOffAmount,
                StartDate = membership.Startdate,
                EndDate = membership.Enddate,
                PayingInSlipNumber = command.PayingInSlipNumber
            };
        }

        private TransactionPreparationResult PrepareGiftPackData(SubmitPaymentCommand command)
        {
            var giftPack = _giftPackRepository.GetById((Guid)command.RecordId);
            return new TransactionPreparationResult
            {
                RecordReference = giftPack.ToEntityReference(),
                ProductReference = giftPack.Product,
                Channel = giftPack.Channel,
                LocationReference = null,
                PaymentMethod = command.PaymentMethod != null ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : giftPack.PaymentMethod,
                ThirdPartyPaymentTypeReference = giftPack.ThirdPartyPaymentType,
                PaymentReferenceText = command.PaymentReference,
                PayerReference = command.PayerId != null && command.PayerEntity != null ? new EntityReference(command.PayerEntity, (Guid)command.PayerId) : giftPack.PurchasedBy,
                TotalAmount = command.TotalAmount ?? giftPack.TotalPrice,
                PaymentFrequency = null,
                PayoutDate = null,
                IsContinuousPayment = false,
                OutstandingAmount = null,
                WrittenOffAmount = command.WrittenOffAmount,
                StartDate = null,
                EndDate = null,
                PayingInSlipNumber = command.PayingInSlipNumber
            };
        }

        private TransactionPreparationResult PrepareGiftPackOrderData(SubmitPaymentCommand command)
        {
            var giftPackOrder = _giftPackOrderRepository.GetById((Guid)command.RecordId);
            return new TransactionPreparationResult
            {
                RecordReference = giftPackOrder.ToEntityReference(),
                ProductReference = giftPackOrder.Product,
                Channel = giftPackOrder.Channel,
                LocationReference = null,
                PaymentMethod = command.PaymentMethod != null ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : giftPackOrder.PaymentMethodCode,
                ThirdPartyPaymentTypeReference = null,
                PaymentReferenceText = command.PaymentReference,
                PayerReference = command.PayerId != null && command.PayerEntity != null ? new EntityReference(command.PayerEntity, (Guid)command.PayerId) : giftPackOrder.Purchasedby,
                TotalAmount = command.TotalAmount ?? giftPackOrder.Totalprice_v2,
                PaymentFrequency = null,
                PayoutDate = null,
                IsContinuousPayment = false,
                OutstandingAmount = new Money(0),
                WrittenOffAmount = command.WrittenOffAmount,
                StartDate = null,
                EndDate = null,
                PayingInSlipNumber = command.PayingInSlipNumber
            };
        }

        private TransactionPreparationResult PrepareSubscriptionData(SubmitPaymentCommand command)
        {
            var subscription = _service.Retrieve("rhs_subscription", (Guid)command.RecordId, new ColumnSet(true));
            return new TransactionPreparationResult
            {
                RecordReference = new EntityReference("rhs_subscription", subscription.Id),
                ProductReference = subscription.GetAttributeValue<EntityReference>("rhs_subscriptionproduct"),
                Channel = (ChannelOptionChoice_GlobalOptionSet?)subscription.GetAttributeValue<OptionSetValue>("rhs_channel")?.Value,
                LocationReference = null,
                PaymentMethod = command.PaymentMethod != null ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : (PaymentMethodType_GlobalOptionSet?)subscription.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode")?.Value,
                ThirdPartyPaymentTypeReference = null,
                PaymentReferenceText = command.PaymentReference,
                PayerReference = command.PayerId != null && command.PayerEntity != null ? new EntityReference(command.PayerEntity, (Guid)command.PayerId) : subscription.GetAttributeValue<EntityReference>("rhs_subscriptionpayer"),
                TotalAmount = command.TotalAmount ?? subscription.GetAttributeValue<Money>("rhs_totalamount"),
                PaymentFrequency = command.PaymentFrequency != null ? (PaymentFrequency_GlobalOptionSet)command.PaymentFrequency : (PaymentFrequency_GlobalOptionSet?)subscription.GetAttributeValue<OptionSetValue>("rhs_billingfrequency")?.Value,
                PayoutDate = subscription.GetAttributeValue<DateTime?>("rhs_paymentschedule"),
                IsContinuousPayment = command.IsContiniousPayment ?? subscription.GetAttributeValue<bool?>("rhs_iscontinuouspayment"),
                OutstandingAmount = command.OutstandingAmount ?? subscription.GetAttributeValue<Money>("rhs_outstandingamount"),
                WrittenOffAmount = command.WrittenOffAmount,
                StartDate = subscription.GetAttributeValue<DateTime?>("rhs_startdate"),
                EndDate = subscription.GetAttributeValue<DateTime?>("rhs_enddate"),
                StatusReasonCode = subscription.GetAttributeValue<OptionSetValue>("statuscode")?.Value,
                PayingInSlipNumber = command.PayingInSlipNumber
            };
        }

        private TransactionPreparationResult PrepareDonationData(SubmitPaymentCommand command)
        {
            var donation = _service.Retrieve(EntityNames.Donation.EntityLogicalName, (Guid)command.RecordId, new ColumnSet(true));
            return new TransactionPreparationResult
            {
                RecordReference = new EntityReference(EntityNames.Donation.EntityLogicalName, donation.Id),
                ProductReference = null,
                Channel = (ChannelOptionChoice_GlobalOptionSet?)donation.GetAttributeValue<OptionSetValue>("rhs_channel")?.Value,
                LocationReference = null,
                PaymentMethod = command.PaymentMethod != null ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : (PaymentMethodType_GlobalOptionSet?)donation.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode")?.Value,
                ThirdPartyPaymentTypeReference = null,
                PaymentReferenceText = command.PaymentReference,
                PayerReference = command.PayerId != null && command.PayerEntity != null ? new EntityReference(command.PayerEntity, (Guid)command.PayerId) : donation.GetAttributeValue<EntityReference>("rhs_donor"),
                TotalAmount = command.TotalAmount ?? donation.GetAttributeValue<Money>("rhs_ongoingddamount"),
                PaymentFrequency = command.PaymentFrequency != null ? (PaymentFrequency_GlobalOptionSet)command.PaymentFrequency : (PaymentFrequency_GlobalOptionSet?)donation.GetAttributeValue<OptionSetValue>("rhs_paymentfrequency")?.Value,
                PayoutDate = donation.GetAttributeValue<DateTime?>("rhs_payoutdate"),
                IsContinuousPayment = command.IsContiniousPayment ?? donation.GetAttributeValue<bool?>("rhs_iscontinuouspayment"),
                OutstandingAmount = command.OutstandingAmount ?? donation.GetAttributeValue<Money>("rhs_amount"),
                WrittenOffAmount = command.WrittenOffAmount,
                StartDate = donation.GetAttributeValue<DateTime?>("rhs_startdate"),
                EndDate = donation.GetAttributeValue<DateTime?>("rhs_enddate"),
                StatusReasonCode = donation.GetAttributeValue<OptionSetValue>("statuscode")?.Value,
                PayingInSlipNumber = command.PayingInSlipNumber
            };
        }

        public SubmitPaymentResult SubmitPayment(SubmitPaymentCommand command, List<GiftPack> giftPacks = null)
        {
            var result = PrepareDataBasedOnTransactionType(command);
            var response = new SubmitPaymentResult();

            if (result.PaymentMethod == null)
            {
                _logger.TraceInformation("Payment method is null. No payment will be processed.");
                return response;
            }

            if (ValidateIfInstantaneousPayment(result.PaymentMethod, result.IsContinuousPayment, result.PaymentFrequency))
            {
                HandleInstantaneousPayment(result, response, command, giftPacks);
                return response;
            }

            if (ValidateIfScheduledPayment(result.PaymentMethod, result.IsContinuousPayment, result.PaymentFrequency) &&
                ValidateRequiredFieldsForScheduledPayment(result.StartDate, result.EndDate, result.PayoutDate))
            {
                HandleScheduledPayment(result, response, command);
                return response;
            }

            _logger.TraceWarning("No valid payment flow matched for the provided command.");
            return response;
        }

        private void HandleInstantaneousPayment(TransactionPreparationResult result, SubmitPaymentResult response, SubmitPaymentCommand command, List<GiftPack> giftPacks = null)
        {
            _logger.TraceInformation("Starting business logic.");
            var transaction = SaveTransaction(
                command.TransactionId, 
                result.RecordReference, 
                result.PayerReference, 
                result.ProductReference,
                result.PaymentMethod,
                result.TotalAmount,
                result.OutstandingAmount,
                result.WrittenOffAmount,
                command.TransactionType.Value);

            response.TransactionId = transaction.Id;
            response.TransactionNumber = transaction.TransacID;
            _logger.TraceInformation($"Created transaction w/ Id = {transaction.Id}.");

            if (command.TransactionType == (int?)NewTransactionType_GlobalOptionSet.GiftPack)
            {
                ProcessGiftPackInstantaneousPayment(result, response, command, transaction, giftPacks);
            }
            else
            {
                ProcessMembershipInstantaneousPayment(result, response, command, transaction);
            }

            _logger.TraceInformation("Ending business logic.");
        }

        private void ProcessGiftPackPayment(
            TransactionPreparationResult result,
            SubmitPaymentResult response,
            SubmitPaymentCommand command,
            Transaction transaction,
            GiftPack giftPack)
        {
            Money paymentAmount = command.IsTescoVoucher ? command.TotalAmount : giftPack.TotalPrice;
            var paymentMethod = command.IsTescoVoucher ? (PaymentMethodType_GlobalOptionSet)command.PaymentMethod : giftPack.PaymentMethod;
            var transactionType = command.IsTescoVoucher ? (Typetransaction_GlobalOptionSet)command.Type : Typetransaction_GlobalOptionSet.FullPayment;

            var payment = CreateGiftPacksPaymentForInstantenousPayment(
                result.RecordReference, transaction.ToEntityReference(), result.PayerReference, giftPack.Product,
                result.ThirdPartyPaymentTypeReference, result.LocationReference, giftPack.Channel, paymentMethod,
                result.PayingInSlipNumber, result.PaymentReferenceText, paymentAmount, result.WrittenOffAmount, result.PayoutDate,
                giftPack.Id,
                transactionType
            );
            response.PaymentId = payment.Id;

            if (result.Channel == ChannelOptionChoice_GlobalOptionSet.Online)
            {
                MarkPaymentAsPaid(payment.Id);
            }
        }

        private void MarkPaymentAsPaid(Guid paymentId)
        {
            _paymentRepository.Update(new Payment
            {
                Id = paymentId,
                Statecode = PaymentState.Inactive,
                Statuscode = PaymentStatus.Inactive_Paid
            });
        }

        private void HandleScheduledPayment(TransactionPreparationResult result, SubmitPaymentResult response, SubmitPaymentCommand command)
        {
            _logger.TraceInformation($"Starting business logic.");
            var transaction = SaveTransaction(
               command.TransactionId,
         result.RecordReference,
       result.PayerReference,
     result.ProductReference,
     result.PaymentMethod,
   result.TotalAmount,
       result.OutstandingAmount,
     result.WrittenOffAmount,
              command.TransactionType.Value);

            response.TransactionId = transaction.Id;
            response.TransactionNumber = transaction.TransacID;
            _logger.TraceInformation($"Created transaction w/ Id = {transaction.Id}.");

            var (startingDueDate, expectedPaymentAmount, expectedRemainderAmount, actualPaymentAmount, actualRemainderAmount, numberOfPayments, startingPaymentNumber) =
                   PrepareDataForScheduledPayment(result.RecordReference, result.TotalAmount, result.WrittenOffAmount,
              result.PaymentFrequency, (DateTime)result.PayoutDate, (DateTime)result.StartDate, (DateTime)result.EndDate);

            var paymentSchedule = CreatePaymentScheduleForScheduledPayment(
        transaction.ToEntityReference(), result.RecordReference, expectedPaymentAmount, actualPaymentAmount,
         numberOfPayments, result.PaymentMethod, result.PaymentFrequency, startingDueDate, result.StartDate, result.EndDate);
            LinkPaymentScheduleToMembershipForScheduledPayment(transaction.Id, paymentSchedule.ToEntityReference());
            response.PaymentScheduleId = paymentSchedule.Id;

            CreateRecurringPaymentsForScheduledPayment(
result.RecordReference, transaction.ToEntityReference(), paymentSchedule.ToEntityReference(),
          result.PayerReference, result.ProductReference, result.ThirdPartyPaymentTypeReference, result.LocationReference,
   result.Channel, result.PaymentMethod, result.PaymentReferenceText, expectedPaymentAmount, expectedRemainderAmount,
          actualPaymentAmount, actualRemainderAmount, numberOfPayments, startingPaymentNumber, startingDueDate, (DateTime)result.StartDate);
            _logger.TraceInformation($"Ending business logic.");
        }

        private Transaction SaveTransaction(Guid? transactionId, EntityReference recordReference, EntityReference payerReference, EntityReference productReference,
            PaymentMethodType_GlobalOptionSet? paymentMethod, Money totalAmount, Money outstandingAmount, Money writtenOffAmmount, int TransactionType)
        {
            var transaction = BuildTransaction(
                recordReference,
                payerReference,
                productReference,
                paymentMethod,
                totalAmount,
                outstandingAmount,
                writtenOffAmmount);
            if (TransactionType == (int?)NewTransactionType_GlobalOptionSet.GiftPack)
            {
                transaction.PaidOn = DateTime.UtcNow;
            }
            if (transactionId.HasValue && transactionId != Guid.Empty)
            {
                transaction.Id = transactionId.Value;
                _transactionRepository.Update(transaction);
                return _transactionRepository.GetById(transactionId.Value);
            }
            return _transactionRepository.Create(transaction);
        }

        public List<GiftPack> RetrieveGiftPacksfromGiftPackOrder(Guid giftPackOrderId)
        {
            _logger.TraceInformation($"Starting RetrieveGiftPacksfromGiftPackOrder business logic.");

            var giftPacksFromGiftPackOrder = _giftPackRepository.GetAll().Where(giftpack =>
                giftpack.Giftpackorder.Id == giftPackOrderId
            ).ToList();

            _logger.TraceInformation($"Ending RetrieveGiftPacksfromGiftPackOrder business logic.");
            return giftPacksFromGiftPackOrder;
        }
    }

    public class SubmitPaymentResult
    {
        public Guid? TransactionId { get; set; }
        public string TransactionNumber { get; set; }
        public Guid? PaymentId { get; set; }
        public Guid? PaymentScheduleId { get; set; }
    }

    public class SubmitPaymentCommand
    {
        public int? PaymentMethod { get; set; }
        public int? TransactionType { get; set; }
        public int? Type { get; set; }
        public Guid? RecordId { get; set; }
        public Guid? PayerId { get; set; }
        public string PayerEntity { get; set; }
        public Money TotalAmount { get; set; }
        public int? PaymentFrequency { get; set; }
        public bool? IsContiniousPayment { get; set; }
        public Money OutstandingAmount { get; set; }
        public Money WrittenOffAmount { get; set; }
        public string PaymentReference { get; set; }
        public int? PayingInSlipNumber { get; set; }
        public Guid? TransactionId { get; set; }
        public ChannelOptionChoice_GlobalOptionSet? Channel { get; set; }
        public bool IsTescoVoucher { get; set; }
    }

    public class TransactionPreparationResult
    {
        public EntityReference RecordReference { get; set; }
        public EntityReference ProductReference { get; set; }
        public EntityReference PayerReference { get; set; }
        public EntityReference ThirdPartyPaymentTypeReference { get; set; }
        public EntityReference LocationReference { get; set; }
        public ChannelOptionChoice_GlobalOptionSet? Channel { get; set; }
        public PaymentMethodType_GlobalOptionSet? PaymentMethod { get; set; }
        public string PaymentReferenceText { get; set; }
        public bool? IsContinuousPayment { get; set; }
        public PaymentFrequency_GlobalOptionSet? PaymentFrequency { get; set; }
        public DateTime? PayoutDate { get; set; }
        public Money TotalAmount { get; set; }
        public Money OutstandingAmount { get; set; }
        public Money WrittenOffAmount { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? StatusReasonCode { get; set; }
        public int? PayingInSlipNumber { get; set; }
    }
}