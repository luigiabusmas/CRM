using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipContactCreateService
    {
        Contact Create(Portalsessioncontact portalsessioncontact);
    }

    public class MembershipContactCreateService : IMembershipContactCreateService
    {
        private readonly ITracingService _tracingService;
        private readonly IContactRepository _contactRepository;

        public MembershipContactCreateService(ITracingService tracingService, IContactRepository contactRepository)
        {
            _tracingService = tracingService;
            _contactRepository = contactRepository;
        }

        public Contact Create(Portalsessioncontact portalsessioncontact)
        {
            if (portalsessioncontact == null || portalsessioncontact.Id == Guid.Empty)
                return null;

            // Create new Contact
            var newContact = new Contact
            {
                Id = portalsessioncontact.Id,
                FirstName = portalsessioncontact.Firstname,
                LastName = portalsessioncontact.Lastname,
                BirthDate = portalsessioncontact.Birthdate,
                EMailAddress1 = portalsessioncontact.Emailaddress1,
                //CountryPhone1 = portalsessioncontact.Countryid,
                Title = portalsessioncontact.Title,
                Telephone1 = portalsessioncontact.Telephone1,
                //LoqateHomeAddressHouseName = portalsessioncontact.,
                LoqateHomeAddressHouseName = portalsessioncontact.Address1_name,
                Address1_Line1 = portalsessioncontact.Address1_line1,
                Address1_Line2 = portalsessioncontact.Address1_line2,
                Address1_Line3 = portalsessioncontact.Address1_line3,
                Address1_StateOrProvince = portalsessioncontact.Address1_line4,
                Address1_City = portalsessioncontact.Address1_city,
                Address1_Country = portalsessioncontact.Address1_country,
                Address1_PostalCode = portalsessioncontact.Address1_postalcode,
                ActiveGiftAidDeclaration = (portalsessioncontact.ActiveGiftAidDeclaration.HasValue && portalsessioncontact.ActiveGiftAidDeclaration.Value),
                //Source = portalsessioncontact.Source
                CourseName = portalsessioncontact.CourseName,
                StudyMode = portalsessioncontact.StudyMode,
                StudentID = portalsessioncontact.StudentID,
                StudentsCollegeorApprenticeshipName = portalsessioncontact.StudentsCollegeorApprenticeshipName,
                StudentsRemainingCourseApprenticeshipDuration = portalsessioncontact.StudentsRemainingCourseApprenticeshipDuration,
                StudentType = portalsessioncontact.StudentType,
                Source = Incident_caseorigincode_GlobalOptionSet.OnlineWebPortal
            };
            return _contactRepository.Create(newContact);
        }
    }
}