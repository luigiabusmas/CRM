using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;

namespace Cultivate.BusinessLogic.Services
{
    public interface IAccountPrefillService
    {
        void PrefillAccount(Account account);
    }

    public class AccountPrefillService : IAccountPrefillService
    {
        private readonly ILogger _logger;
        private readonly IRepository<Account> _accountRepository;

        public AccountPrefillService(ILogger logger, IRepository<Account> accountRepository)
        {
            _logger = logger;
            _accountRepository = accountRepository;
        }

        public void PrefillAccount(Account account)
        {
            _logger.TraceWarning("Test warning");
            _logger.TraceInformation("Test info");
            
            account.Name += " (Prefilled)";
            account.Description = "(Prefilled)";

            _accountRepository.Update(account);
        }
    }
}