﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IGiftPackOrderService
    {
        Entity SetGiftPackPriceAndPriceListOnEntity(Entity targetEntity);
        void CreateGiftPackRecordOfGiftPackOrderBasedOnQuantity(Giftpackorder giftpackorder);
        void UpdateProductOfGiftPacks(Entity targetEntity);
        void UpdateCampaignOfGiftPacks(Entity targetEntity);
        void UpdatePaymentMethodOfGiftPacks(Giftpackorder giftpackorder);
        (Giftpackorder Order, List<GiftPack> GiftPacks) CreateFromPortalSession(Portalsession portalSession, IQueryable<Portalsessioncontact> sessionContacts, Contact payer);
    }

    public class GiftPackOrderService : IGiftPackOrderService
    {
        private readonly ILogger _logger;
        private readonly IOrganizationService _organizationService;
        private readonly IRepository<Giftpackorder> _giftPackOrderRepository;
        private readonly IProductService _productService;
        private readonly IGiftPackRepository _giftPackRepository;
        private readonly IGiftPackService _giftpackService;

        public GiftPackOrderService(
            ILogger logger, IOrganizationService service,
            IRepository<Giftpackorder> giftPackOrderRepository,
            IProductService productService,
            IGiftPackRepository giftPackRepository,
            IGiftPackService giftpackService
            )

        {
            _logger = logger;
            _organizationService = service;

            _productService = productService;
            _giftPackOrderRepository = giftPackOrderRepository;
            _giftPackRepository = giftPackRepository;
            _giftpackService = giftpackService;
        }

        public Entity SetGiftPackPriceAndPriceListOnEntity(Entity targetEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var targetGiftPackOrder = targetEntity.ToEntity<Giftpackorder>();

            if (targetGiftPackOrder.Product == null)
                throw new InvalidPluginExecutionException("Please select a Product to set up this record's Price and Price List Used.");

            if (targetGiftPackOrder.Pricelistuse == null)
                targetEntity[EntityNames.Giftpackorder.Pricelistuse] = _productService.GetPriceListUsedOnProduct(targetGiftPackOrder.Product.Id);
            if (targetGiftPackOrder.Unitprice == null)
                targetEntity[EntityNames.Giftpackorder.Unitprice] = _productService.GetProductPrice(targetGiftPackOrder.Product.Id);

            _logger.TraceInformation($"Ending business logic.");
            return targetEntity;
        }

        public void CreateGiftPackRecordOfGiftPackOrderBasedOnQuantity(Giftpackorder giftpackorder)
        {
            _logger.TraceInformation("Starting business logic.");
            GiftPack giftPackOrder;
            int noOfRecordsToCreate = giftpackorder.Quantity.Value;
            for (int counter = 1; counter <= noOfRecordsToCreate; counter++)
            {
                if (giftpackorder.Copydown == true)
                {
                    giftPackOrder = new GiftPack
                    {
                        Product = giftpackorder.Product,
                        Channel = giftpackorder.Channel,
                        PurchasedBy = giftpackorder.Purchasedby,
                        PaymentMethod = giftpackorder.PaymentMethodCode,
                        DeliveryContactId = giftpackorder.Deliverycontact,
                        DeliveryAddress = giftpackorder.Deliveryaddresscode,
                        GDPRConsentsScriptRead = giftpackorder.Gdprconsent,
                        CancellationRightsScriptRead = giftpackorder.Cancellationconsent,
                        CampaignId = giftpackorder.Campaign,
                        GiftMessage = giftpackorder.Giftpackmessage,
                        Giftpackorder = giftpackorder.ToEntityReference()
                    };
                }
                else
                {
                    giftPackOrder = new GiftPack
                    {
                        Product = giftpackorder.Product,
                        Channel = giftpackorder.Channel,
                        PurchasedBy = giftpackorder.Purchasedby,
                        PaymentMethod = giftpackorder.PaymentMethodCode,
                        DeliveryContactId = giftpackorder.Deliverycontact,
                        DeliveryAddress = giftpackorder.Deliveryaddresscode,
                        GDPRConsentsScriptRead = giftpackorder.Gdprconsent,
                        CancellationRightsScriptRead = giftpackorder.Cancellationconsent,
                        CampaignId = giftpackorder.Campaign,
                        GiftMessage = null,
                        Giftpackorder = giftpackorder.ToEntityReference()
                    };
                }

                var giftPackOrderEntity = giftPackOrder.ToEntity<Entity>();
                _organizationService.Create(giftPackOrderEntity);
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void UpdateProductOfGiftPacks(Entity targetEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var newProduct = targetEntity.GetAttributeValue<EntityReference>(EntityNames.Giftpackorder.Product);
            var orderId = targetEntity.Id;

            var queryGiftPacks = new QueryExpression(EntityNames.GiftPack.EntityLogicalName);
            queryGiftPacks.ColumnSet.AddColumns(EntityNames.GiftPack.GiftPackId, EntityNames.GiftPack.Product);
            queryGiftPacks.Criteria.AddCondition(EntityNames.GiftPack.Giftpackorder, ConditionOperator.Equal, orderId);
            List<Entity> giftPackRecords = _organizationService.RetrieveMultiple(queryGiftPacks).Entities.ToList();

            foreach (var giftPack in giftPackRecords)
            {
                var updateGiftPack = new Entity(EntityNames.GiftPack.EntityLogicalName);
                updateGiftPack.Id = giftPack.Id;
                updateGiftPack[EntityNames.GiftPack.Product] = newProduct;
                _giftpackService.SetGiftPackPriceAndPriceListOnEntity(updateGiftPack);
                _organizationService.Update(updateGiftPack);
                _logger.TraceInformation($"Updated Gift Pack {giftPack.Id} Product to {newProduct.Id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void UpdateCampaignOfGiftPacks(Entity targetEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var newCampaign = targetEntity.GetAttributeValue<EntityReference>(EntityNames.Giftpackorder.Campaign);
            var orderId = targetEntity.Id;

            var queryGiftPacks = new QueryExpression(EntityNames.GiftPack.EntityLogicalName);
            queryGiftPacks.ColumnSet.AddColumns(EntityNames.GiftPack.GiftPackId, EntityNames.GiftPack.CampaignId);
            queryGiftPacks.Criteria.AddCondition(EntityNames.GiftPack.Giftpackorder, ConditionOperator.Equal, orderId);
            List<Entity> giftPackRecords = _organizationService.RetrieveMultiple(queryGiftPacks).Entities.ToList();

            foreach (var giftPack in giftPackRecords)
            {
                var updateGiftPack = new Entity(EntityNames.GiftPack.EntityLogicalName);
                updateGiftPack.Id = giftPack.Id;
                updateGiftPack[EntityNames.GiftPack.CampaignId] = newCampaign;
                _organizationService.Update(updateGiftPack);

                if (newCampaign != null)
                    _logger.TraceInformation($"Updated Gift Pack {giftPack.Id} Campaign to {newCampaign.Id}.");
                else
                    _logger.TraceInformation($"Cleared Campaign for Gift Pack {giftPack.Id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void UpdatePaymentMethodOfGiftPacks(Giftpackorder giftPackOrder)
        {
            _logger.TraceInformation($"Starting business logic.");

            var giftPacks = _giftPackRepository.GetAll().Where(gp => gp.Giftpackorder != null && gp.Giftpackorder.Id == giftPackOrder.Id).ToList();
            foreach (var giftPack in giftPacks)
            {
                var giftPackUpdate = new GiftPack()
                {
                    Id = giftPack.Id,
                    PaymentMethod = giftPackOrder.PaymentMethodCode
                };
                _giftPackRepository.Update(giftPackUpdate);
                _logger.TraceInformation($"Updated Gift Pack {giftPack.Id} Payment Method to {giftPackOrder.PaymentMethodCode}.");
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public (Giftpackorder Order, List<GiftPack> GiftPacks) CreateFromPortalSession(Portalsession portalSession, IQueryable<Portalsessioncontact> sessionContacts, Contact payer)
        {
            var giftPackOrder = _giftPackOrderRepository.Create(new Giftpackorder
            {
                Product = portalSession.Productid,
                Quantity = sessionContacts.ToList().Count,
                Purchasedby = payer.ToEntityReference(),
                PaymentMethodCode = portalSession.PaymentMethodCode,
                Channel = ChannelOptionChoice_GlobalOptionSet.Online,
                Gdprconsent = true,
                Cancellationconsent = true,
                Copydown = false
            });

            List<GiftPack> createdGiftPacks = new List<GiftPack>();

            foreach (var contact in sessionContacts)
            {
                var giftPack = new GiftPack
                {
                    CareGiftPackID = Guid.NewGuid().ToString(),
                    PaymentIntentId = portalSession.PaymentIntentId,
                    CheckoutSessionId = portalSession.CheckoutSessionId,
                    CheckoutURL = portalSession.CheckoutURL,
                    Product = portalSession.Productid,
                    PaymentMethod = portalSession.PaymentMethodCode,
                    PurchasedBy = payer.ToEntityReference(),
                    GDPRConsentsScriptRead = true,
                    CancellationRightsScriptRead = true,
                    IsPaymentSubmitted = true,
                    IsPaymentReceived = true,
                    Channel = ChannelOptionChoice_GlobalOptionSet.Online,
                    PriceListUsed = portalSession.Contains(EntityNames.Portalsession.PriceListID) && !string.IsNullOrEmpty(portalSession.PriceListID)
                    ? new EntityReference(EntityNames.PriceLevel.EntityLogicalName, new Guid(portalSession.PriceListID))
                    : null,
                    GiftMessage = contact.GiftMessage,
                    Giftpackorder = giftPackOrder.ToEntityReference(),
                    DeliveryAddressLine1 = contact.Address1_line1,
                    DeliveryAddressLine2 = contact.Address1_line2,
                    DeliveryAddressLine3 = contact.Address1_line3,
                    DeliveryAddressLine4 = contact.Address1_line4,
                    DeliveryAddressCityTown = contact.Address1_city,
                    DeliveryAddressCounty = contact.Address1_county,
                    DeliveryAddressCountry = contact.Address1_country,
                    DeliveryAddressPostcode = contact.Address1_postalcode,
                    Statecode = GiftPackState.Active,
                    Statuscode = GiftPackStatus.Active_Purchased
                };

                var createdGiftPack = _giftPackRepository.Create(giftPack);
                createdGiftPacks.Add(createdGiftPack);
            }
            return (giftPackOrder, createdGiftPacks);
        }
    }
}