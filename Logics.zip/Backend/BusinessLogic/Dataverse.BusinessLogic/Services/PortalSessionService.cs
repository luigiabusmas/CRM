using System;
using System.Collections.Generic;
using System.Linq;
using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;

namespace Cultivate.BusinessLogic.Services
{
    /// <summary>
    /// Service for processing portal session orders, including memberships and gift packs.
    /// </summary>
    public interface IPortalSessionService
    {
        void ProcessOrder(Portalsession portalSession);
    }

    public class PortalSessionService : IPortalSessionService
    {
        #region Fields

        private readonly ITracingService _tracingService;
        private readonly IMembershipOrderService _membershipOrderService;
        private readonly IPaymentProcessingService _paymentProcessingService;
        private readonly IGiftPackOrderService _giftPackOrderService;
        private readonly ITescoVoucherService _tescoVoucherService;
        private readonly IMembershipContactCreateService _membershipContactCreateService;

        private readonly IPortalSessionContactRepository _portalSessionContactRepository;
        private readonly IPortalSessionDiscountRepository _portalSessionDiscountRepository;
        private readonly IRepository<GiftPack> _giftPackRepository;
        private readonly IContactRepository _contactRepository;
        private readonly ICommonService _commonService;
        private readonly IGiftPackRedemptionService _giftPackRedemptionService;

        #endregion Fields

        #region Constructor

        public PortalSessionService(
            ITracingService tracingService,
            IMembershipOrderService membershipOrderService,
            IPaymentProcessingService paymentProcessingService,
            IGiftPackOrderService giftPackOrderService,
            ITescoVoucherService tescoVoucherService,
            IMembershipContactCreateService membershipContactCreateService,
            IPortalSessionContactRepository portalSessionContactRepository,
            IPortalSessionDiscountRepository portalSessionDiscountRepository,
            IRepository<GiftPack> giftPackRepository,
            IContactRepository contactRepository,
            ICommonService commonService,
            IGiftPackRedemptionService giftPackRedemptionService
        )
        {
            _tracingService = tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _membershipOrderService = membershipOrderService ?? throw new ArgumentNullException(nameof(membershipOrderService));
            _paymentProcessingService = paymentProcessingService ?? throw new ArgumentNullException(nameof(paymentProcessingService));
            _giftPackOrderService = giftPackOrderService ?? throw new ArgumentNullException(nameof(giftPackOrderService));
            _tescoVoucherService = tescoVoucherService ?? throw new ArgumentNullException(nameof(tescoVoucherService));
            _membershipContactCreateService = membershipContactCreateService ?? throw new ArgumentNullException(nameof(membershipContactCreateService));
            _portalSessionContactRepository = portalSessionContactRepository ?? throw new ArgumentNullException(nameof(portalSessionContactRepository));
            _portalSessionDiscountRepository = portalSessionDiscountRepository ?? throw new ArgumentNullException(nameof(portalSessionDiscountRepository));
            _giftPackRepository = giftPackRepository ?? throw new ArgumentNullException(nameof(giftPackRepository));
            _contactRepository = contactRepository ?? throw new ArgumentNullException(nameof(contactRepository));
            _commonService = commonService ?? throw new ArgumentNullException(nameof(commonService));
            _giftPackRedemptionService = giftPackRedemptionService ?? throw new ArgumentNullException(nameof(giftPackRedemptionService));
        }

        #endregion Constructor

        #region Public Methods

        public void ProcessOrder(Portalsession portalSession)
        {
            ValidatePortalSession(portalSession);

            // Cache Tesco flag to avoid repeated service calls
            var isTescoVoucher = _commonService.IsTescoVoucherPayment(portalSession);

            if (isTescoVoucher)
            {
                ProcessTescoVoucherOrder(portalSession);
                return;
            }

            if (portalSession.ProductType == NewTransactionType_GlobalOptionSet.Membership
                && portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.GiftPack)
            {
                _giftPackRedemptionService.ProcessGiftPackRedemption(portalSession);
                return;
            }

            switch (portalSession.ProductType)
            {
                case NewTransactionType_GlobalOptionSet.Membership:
                    _membershipOrderService.ProcessMembershipOrder(portalSession);
                    break;

                case NewTransactionType_GlobalOptionSet.GiftPack:
                    ProcessGiftPackOrder(portalSession, isTescoVoucher: isTescoVoucher);
                    break;

                default:
                    throw new ArgumentException("Unsupported ProductType.");
            }
        }

        #endregion Public Methods

        #region Gift Pack Order Processing

        protected internal void ProcessGiftPackOrder(
            Portalsession portalSession,
            PortalSessionDiscount discount = null,
            bool isTescoVoucher = false
        )
        {
            _tracingService.Trace("Processing GiftPack order.");

            var sessionContacts = GetSessionContactsOrThrow(portalSession);
            var payer = GetPayerForGiftPackOrder(portalSession);
            var (giftPackOrder, giftPacks) = _giftPackOrderService.CreateFromPortalSession(
                portalSession,
                sessionContacts,
                payer
            );

            if (isTescoVoucher)
            {
                ProcessTescoVoucherGiftPackOrder(
                    portalSession,
                    discount,
                    giftPackOrder,
                    giftPacks,
                    payer
                );
            }
            else
            {
                ProcessStandardGiftPackOrder(portalSession, giftPackOrder, giftPacks);
            }
        }

        private void ProcessTescoVoucherGiftPackOrder(
            Portalsession portalSession,
            PortalSessionDiscount discount,
            Giftpackorder giftPackOrder,
            List<GiftPack> giftPacks,
            Contact payer
        )
        {
            var giftPack =
                giftPacks.FirstOrDefault()
                ?? throw new ArgumentException("GiftPack could not be created for Tesco Gift.");

            var loadedGiftPack = _giftPackRepository.GetById(giftPack.Id);
            var portalSessionDiscount =
                discount
                ?? _portalSessionDiscountRepository.GetByPortalSesssionId(portalSession.Id);

            var paymentSplit = _paymentProcessingService.CalculatePaymentSplit(
                loadedGiftPack.TotalPrice?.Value ??0,
                portalSessionDiscount
            );

            var paymentResult = _paymentProcessingService.ProcessSplitPayment(
                portalSession,
                giftPackOrder.Id,
                payer.Id,
                paymentSplit,
                portalSessionDiscount,
                new List<GiftPack> { loadedGiftPack }
            );

            if (paymentResult?.TransactionId.HasValue == true)
            {
                _paymentProcessingService.MarkPortalSessionAsProcessed(
                    portalSession,
                    paymentResult.TransactionId.Value,
                    paymentResult.TransactionNumber
                );
            }
        }

        private void ProcessStandardGiftPackOrder(
            Portalsession portalSession,
            Giftpackorder giftPackOrder,
            List<GiftPack> giftPacks
        )
        {
            var payer = GetPayerOrThrow(portalSession);
            var giftPackEntities = giftPacks
                .Select(gp => _giftPackRepository.GetById(gp.Id))
                .ToList();
            var totalAmount = giftPackEntities.Sum(gp => gp.TotalPrice?.Value ??0);

            var paymentResult = _paymentProcessingService.ProcessStandardGiftPackPayment(
                portalSession,
                giftPackOrder.Id,
                payer.Id,
                totalAmount,
                giftPackEntities
            );

            if (paymentResult?.TransactionId.HasValue == true)
            {
                _paymentProcessingService.MarkPortalSessionAsProcessed(
                    portalSession,
                    paymentResult.TransactionId.Value,
                    paymentResult.TransactionNumber
                );
            }
        }

        #endregion Gift Pack Order Processing

        #region Tesco Voucher Processing

        private void ProcessTescoVoucherOrder(Portalsession portalSession)
        {
            var discount = GetDiscountOrThrow(portalSession);
            var tescoResult = _tescoVoucherService.ValidateTescoVoucher(discount);

            _tescoVoucherService.ValidateTescoVoucherAmount(discount, tescoResult);

            switch (portalSession.ProductType)
            {
                case NewTransactionType_GlobalOptionSet.Membership:
                    _membershipOrderService.ProcessMembershipOrder(portalSession, discount);
                    break;

                case NewTransactionType_GlobalOptionSet.GiftPack:
                    ProcessGiftPackOrder(portalSession, discount, true);
                    break;

                default:
                    throw new ArgumentException("Unsupported ProductType.");
            }

            // Redeem the voucher after successful processing
            _tescoVoucherService.RedeemTescoVoucher(discount.PromoCode);
        }

        #endregion Tesco Voucher Processing

        #region Contact Management

        private Contact GetPayerFromSession(Portalsession portalSession)
        {
            _tracingService.Trace("Checking for payer in portal session.");

            if (portalSession.Payerid == null || portalSession.Payerid.Id == Guid.Empty)
                return null;

            var portalSessionContactPayer = _portalSessionContactRepository.GetById(
                portalSession.Payerid.Id
            );

            if (portalSessionContactPayer == null || portalSessionContactPayer.Id == Guid.Empty)
                return null;

            return CreateOrResolveContact(portalSessionContactPayer, portalSession.PaymentMethodCode);
        }

        private Contact CreateOrResolveContact(
            Portalsessioncontact contact,
            PaymentMethodType_GlobalOptionSet? paymentMethod
        )
        {
            if (paymentMethod != PaymentMethodType_GlobalOptionSet.TescoVoucher)
            {
                return _membershipContactCreateService.Create(contact);
            }

            var existingContact = _contactRepository
                .GetByNameEmailPostCode(
                    contact.Firstname,
                    contact.Lastname,
                    contact.Emailaddress1,
                    contact.Address1_postalcode
                )
                .FirstOrDefault();

            return existingContact != null
                ? _contactRepository.GetById(existingContact.Id)
                : _membershipContactCreateService.Create(contact);
        }

        #endregion Contact Management

        #region Validation

        private static void ValidatePortalSession(Portalsession portalSession)
        {
            if (portalSession == null)
                throw new ArgumentNullException(nameof(portalSession));

            if (portalSession.PaymentMethodCode != PaymentMethodType_GlobalOptionSet.GiftPack 
                && portalSession.ProductType != NewTransactionType_GlobalOptionSet.Membership 
                && !portalSession.Contains(EntityNames.Portalsession.Payerid))
                throw new ArgumentException("Payer ID cannot be empty.");

            if (portalSession.ProductType == NewTransactionType_GlobalOptionSet.Membership)
            {
                if (!portalSession.Contains(EntityNames.Portalsession.Memberid))
                    throw new ArgumentException(
                        "Member ID cannot be empty for Membership product type."
                    );

                if (portalSession.PaymentMethodCode == null)
                    throw new ArgumentException("Payment Method cannot be null");
            }

            if (
                portalSession.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly
                && portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.Card
            )
            {
                throw new ArgumentException("Invalid Payment Method and Payment Frequency");
            }

            ValidatePortalSessionStatus(portalSession);
        }

        private static void ValidatePortalSessionStatus(Portalsession portalSession)
        {
            var isPaymentCompleted =
                portalSession.Statuscode == PortalsessionStatus.Active_PaymentCompleted;
            var isDirectDebitCompleted =
                portalSession.Statuscode == PortalsessionStatus.Active_DirectDebitMandateCompleted;
            var isValidPaymentMethod =
                portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.Card
                || portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.TescoVoucher
                || portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.GiftPack;
            var isDirectDebit =
                portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit;
            var isMembership =
                portalSession.ProductType == NewTransactionType_GlobalOptionSet.Membership;

            if (
                (isPaymentCompleted && !isValidPaymentMethod)
                || (isDirectDebitCompleted && (!isDirectDebit || !isMembership))
            )
            {
                throw new ArgumentException(
                    "Invalid Portal Session Status Reason and Payment Method"
                );
            }
        }

        #endregion Validation

        #region Repository Access Helpers

        private PortalSessionDiscount GetDiscountOrThrow(Portalsession portalSession)
        {
            var discount = _portalSessionDiscountRepository.GetByPortalSesssionId(portalSession.Id);
            if (discount == null || string.IsNullOrEmpty(discount.PromoCode))
                throw new InvalidOperationException("Tesco voucher code not found.");
            return discount;
        }

        private IQueryable<Portalsessioncontact> GetSessionContactsOrThrow(
            Portalsession portalSession
        )
        {
            var sessionContacts = _portalSessionContactRepository.GetByPortalSessionId(
                portalSession.Id
            );
            if (sessionContacts.FirstOrDefault() == null)
                throw new ArgumentException(
                    "No PortalSessionContacts found for this PortalSession."
                );
            return sessionContacts;
        }

        private Contact GetPayerForGiftPackOrder(Portalsession portalSession)
        {
            var payerSessionContact = _portalSessionContactRepository.GetById(
                portalSession.Payerid.Id
            );

            return CreateOrResolveContact(payerSessionContact, portalSession.PaymentMethodCode)
                ?? throw new ArgumentException("Payer could not be determined for GiftPack order.");
        }

        private Contact GetPayerOrThrow(Portalsession portalSession)
        {
            var payer = GetPayerFromSession(portalSession);
            return payer
                ?? throw new ArgumentException("Payer could not be determined for GiftPack order.");
        }

        #endregion Repository Access Helpers
    }
}
