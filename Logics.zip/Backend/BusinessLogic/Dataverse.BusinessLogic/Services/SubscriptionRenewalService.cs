﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface ISubscriptionRenewalService
    {
        void UpdateRenewalFields(Entity subscriptionEntity, bool? isAdvancePayment);
        Guid CreateSubscriptionOnRenewal(Entity subscriptionEntity);
    }
    public class SubscriptionRenewalService : ISubscriptionRenewalService
    {
        private ILogger _logger;
        private IOrganizationService _organizationService;
        private IProductService _productService;
        private IRecordDateCalculationService _recordDateCalculationService;
        private ICultivateConfigurationService _cultivateConfigurationService;

        public SubscriptionRenewalService(ILogger logger, IOrganizationService organizationService, 
            IProductService productService, IRecordDateCalculationService recordDateCalculationService, ICultivateConfigurationService cultivateConfigurationService)
        {
            _logger = logger;
            _organizationService = organizationService;
            _productService = productService;
            _recordDateCalculationService = recordDateCalculationService;
            _cultivateConfigurationService = cultivateConfigurationService;
        }

        public void UpdateRenewalFields(Entity subscriptionEntity, bool? isAdvancePayment)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Preparing fields to update.");
            var subscriptionEntityToUpdate = new Entity("rhs_subscription", subscriptionEntity.Id);
            //subscriptionEntityToUpdate["rhs_renewalscampaign"] = null;
            subscriptionEntityToUpdate["rhs_renewalssubscriptionproduct"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_subscriptionproduct");
            subscriptionEntityToUpdate["rhs_renewalspayer"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_subscriptionpayer");
            subscriptionEntityToUpdate["rhs_renewalsstatus"] = new OptionSetValue((int)RenewalsStatus_GlobalOptionSet.PendingRenewal);
            //subscriptionEntityToUpdate["rhs_renewalssubscriptionprice"] = _productService.GetProductRenewalPriceList(subscriptionEntity.GetAttributeValue<EntityReference>("rhs_subscriptionproduct").Id);
            //subscriptionEntityToUpdate["rhs_renewalssubscriptionpricevalue"] = _productService.GetProductRenewalPrice(subscriptionEntity.GetAttributeValue<EntityReference>("rhs_subscriptionproduct").Id);
            //subscriptionEntityToUpdate["rhs_renewalstotalamount"] = _productService.GetProductRenewalPrice(subscriptionEntity.GetAttributeValue<EntityReference>("rhs_subscriptionproduct").Id);
            subscriptionEntityToUpdate["rhs_inrenewalsstage"] = true;

            if (subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode")?.Value == (int)PaymentMethodType_GlobalOptionSet.CreditCard_Phone ||
                (subscriptionEntity.GetAttributeValue<DateTime?>("rhs_renewalsstartdate") != null && DateTime.UtcNow >= subscriptionEntity.GetAttributeValue<DateTime?>("rhs_renewalsstartdate")))
            {
                subscriptionEntityToUpdate["rhs_renewalspaymentmethodcode"] = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode");
            }
            if (subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode")?.Value == (int)PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                if (isAdvancePayment == true)
                {
                    subscriptionEntityToUpdate["rhs_renewalspaymentmethodcode"] = null;
                    //Also leave related Payment fields as blank
                }
                else
                {
                    subscriptionEntityToUpdate["rhs_renewalbillingfrequency"] = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_billingfrequency");
                    subscriptionEntityToUpdate["rhs_renewalpaymentschedule"] = _recordDateCalculationService.CalculatePayoutDate(((DateTime)subscriptionEntity.GetAttributeValue<DateTime?>("rhs_startdate")).AddDays(1));
                    subscriptionEntityToUpdate["rhs_isrenewalcontinuouspayment"] = subscriptionEntity.GetAttributeValue<bool?>("rhs_iscontinuouspayment");
                }
            }

            _logger.TraceInformation($"Updating fields.");
            _organizationService.Update(subscriptionEntityToUpdate);

            _logger.TraceInformation($"Ending business logic.");
        }

        public Guid CreateSubscriptionOnRenewal(Entity subscriptionEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Preparing date data for new membership for renewal.");
            var renewalPeriodDuration = int.Parse(_cultivateConfigurationService.GetCultivateConfigurationValue("SubscriptionRenewalPeriodDuration"));
            var dormancyPeriodDuration = 0; //no dormancy applicable for Subscription
            var newSubscriptionStartDate = subscriptionEntity.GetAttributeValue<DateTime>("rhs_enddate").AddDays(1);
            var newSubscriptionEndDate = _recordDateCalculationService.CalculateEndDateOfRecord(newSubscriptionStartDate, subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalssubscriptionproduct").Id, subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalscampaign")?.Id);
            var newSubscriptionPayoutDate = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_renewalspaymentmethodcode")?.Value == (int?)PaymentMethodType_GlobalOptionSet.DirectDebit && subscriptionEntity.GetAttributeValue<DateTime?>("rhs_renewalpaymentschedule") == null ?
                _recordDateCalculationService.CalculatePayoutDate(newSubscriptionStartDate) : subscriptionEntity.GetAttributeValue<DateTime?>("rhs_renewalpaymentschedule");
            var newSubscriptionRenewalStartDate = newSubscriptionEndDate == null ? newSubscriptionEndDate : ((DateTime)newSubscriptionEndDate).AddMonths(-renewalPeriodDuration);
            var newSubscriptioniRenewalEndDate = newSubscriptionEndDate == null ? newSubscriptionEndDate : ((DateTime)newSubscriptionEndDate).AddMonths(dormancyPeriodDuration);

            var subscriptionEntityToCreate = new Entity("rhs_subscription");
            subscriptionEntityToCreate["rhs_channel"] = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_channel");
            subscriptionEntityToCreate["rhs_recipient"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_recipient");
            subscriptionEntityToCreate["rhs_linkedsubscription"] = new EntityReference("rhs_subscription", subscriptionEntity.Id);
            subscriptionEntityToCreate["rhs_startdate"] = newSubscriptionStartDate;
            subscriptionEntityToCreate["rhs_enddate"] = newSubscriptionEndDate;
            subscriptionEntityToCreate["rhs_renewalsstartdate"] = newSubscriptionRenewalStartDate;
            subscriptionEntityToCreate["rhs_renewalsenddate"] = newSubscriptioniRenewalEndDate;
            subscriptionEntityToCreate["rhs_campaigncode"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalscampaign");
            subscriptionEntityToCreate["rhs_subscriptionproduct"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalssubscriptionproduct");
            subscriptionEntityToCreate["rhs_subscriptionpayer"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalspayer");
            subscriptionEntityToCreate["rhs_pricelist"] = subscriptionEntity.GetAttributeValue<EntityReference>("rhs_renewalssubscriptionprice");
            subscriptionEntityToCreate["rhs_subscriptionprice"] = subscriptionEntity.GetAttributeValue<Money>("rhs_renewalssubscriptionpricevalue");
            subscriptionEntityToCreate["rhs_postalcharges"] = subscriptionEntity.GetAttributeValue<Money>("rhs_renewalpostalcharge");
            //subscriptionEntityToCreate["rhs_totalamount"] = subscriptionEntity.GetAttributeValue<Money>("rhs_renewalstotalamount");
            subscriptionEntityToCreate["rhs_paymentmethodcode"] = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_renewalspaymentmethodcode");
            subscriptionEntityToCreate["rhs_iscontinuouspayment"] = subscriptionEntity.GetAttributeValue<bool?>("rhs_isrenewalcontinuouspayment");
            subscriptionEntityToCreate["rhs_billingfrequency"] = subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_renewalbillingfrequency");
            subscriptionEntityToCreate["rhs_paymentschedule"] = newSubscriptionPayoutDate;
            subscriptionEntityToCreate["rhs_isrenewal"] = true;
            subscriptionEntityToCreate["statuscode"] = new OptionSetValue(120000001)/*New*/;
         
            if (subscriptionEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethodcode")?.Value == (int)PaymentMethodType_GlobalOptionSet.PWAC)
            {
                subscriptionEntityToCreate["rhs_totalamount"] = new Money(0);
            }
            else
            {
                subscriptionEntityToCreate["rhs_totalamount"] = subscriptionEntity.GetAttributeValue<Money>("rhs_renewalstotalamount");
            }

            var createdSubscriptionId = _organizationService.Create(subscriptionEntityToCreate);

            _logger.TraceInformation($"Ending business logic.");
            return createdSubscriptionId;
        }
    }
}
