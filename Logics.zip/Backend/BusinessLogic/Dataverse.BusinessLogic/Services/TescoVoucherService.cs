using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using System.Linq;
using System.Runtime.Serialization;

namespace Cultivate.BusinessLogic.Services
{
    public interface ITescoVoucherService
    {
        TescoVoucherResponse InvokeTescoVoucherRequestApi(string requestType, string tokenCode);
        TescoVoucherResponse ValidateTescoVoucher(PortalSessionDiscount discount);
        void RedeemTescoVoucher(string promoCode);
        void ValidateTescoVoucherAmount(PortalSessionDiscount discount, TescoVoucherResponse tescoResult);
    }

    public class TescoVoucherService : ITescoVoucherService
    {
        private readonly ITracingService _tracingService;
        private readonly IOrganizationService _service;

        private const string TescoApiActionName = "rhs_tescovoucherrequest";
        private const string TescoApiRequestTypeValidate = "Validate";
        private const string TescoApiRequestTypeRedeem = "Redeem";
        private const string ContactServicesMessage = "Please contact Membership Services by phone02031765810 or email membership@rhs.org.uk.";

        public TescoVoucherService(ITracingService tracingService, IOrganizationService service)
        {
            _tracingService = tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _service = service ?? throw new ArgumentNullException(nameof(service));
        }

        public TescoVoucherResponse ValidateTescoVoucher(PortalSessionDiscount discount)
        {
            return InvokeTescoVoucherRequestApi(TescoApiRequestTypeValidate, discount.PromoCode);
        }

        public void RedeemTescoVoucher(string promoCode)
        {
            InvokeTescoVoucherRequestApi(TescoApiRequestTypeRedeem, promoCode);
        }

        public void ValidateTescoVoucherAmount(PortalSessionDiscount discount, TescoVoucherResponse tescoResult)
        {
            if (discount.DiscountAmount == null || tescoResult.TokenValue != discount.DiscountAmount.Value)
            {
                throw new InvalidOperationException(
                    "The Tesco Voucher value has been changed. Please check the Tesco voucher and try again.");
            }
        }

        public TescoVoucherResponse InvokeTescoVoucherRequestApi(string requestType, string tokenCode)
        {
            try
            {
                var apiRequest = new OrganizationRequest(TescoApiActionName)
                {
                    Parameters = new ParameterCollection
                    {
                        { "RequestType", requestType },
                        { "TokenCode", tokenCode },
                    },
                };

                var apiResponse = _service.Execute(apiRequest);

                if (apiResponse?.Results.Values.Count > 0)
                {
                    var json = apiResponse.Results.Values.FirstOrDefault()?.ToString();
                    var response = Newtonsoft.Json.JsonConvert.DeserializeObject<TescoVoucherResponse>(json);
                    var errorMessage = GetTescoVoucherErrorMessage(requestType, response.TokenStatus);

                    if (errorMessage != null)
                        throw new InvalidPluginExecutionException(errorMessage);

                    return response;
                }

                throw new InvalidPluginExecutionException("Tesco voucher response was not valid.");
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Exception during Tesco API invocation: {0}", ex.ToString());
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private static string GetTescoVoucherErrorMessage(string requestType, string tokenStatus)
        {
            if (requestType == "Validate")
            {
                return tokenStatus switch
                {
                    "Active" => null,
                    "Redeemed" => $"This code has Redeemed. {ContactServicesMessage}",
                    "Expired" => $"This code has expired. {ContactServicesMessage}",
                    "Cancelled" => $"This code has already been cancelled. {ContactServicesMessage}",
                    "NotFound" => $"This code was not found. {ContactServicesMessage}",
                    _ => $"Invalid voucher code status. {ContactServicesMessage}",
                };
            }

            if (requestType == "Redeem")
            {
                return tokenStatus switch
                {
                    "Redeemed" => null,
                    "TokenAlreadyRedeemed" => $"This code has already been redeemed. {ContactServicesMessage}",
                    "Expired" => $"This code has expired. {ContactServicesMessage}",
                    "Cancelled" => $"This code has already been cancelled. {ContactServicesMessage}",
                    "NotFound" => $"This code was not found. {ContactServicesMessage}",
                    "NoTokenCodeInRequest" => $"No code was provided. {ContactServicesMessage}",
                    "TokenAlreadyInvoiced" => $"This code has already been invoiced. {ContactServicesMessage}",
                    _ => $"Invalid voucher code status. {ContactServicesMessage}",
                };
            }

            return null;
        }
    }

    [DataContract]
    public class TescoVoucherResponse
    {
        [DataMember(Name = "tokenCode")]
        public string TokenCode { get; set; }

        [DataMember(Name = "tokenStatus")]
        public string TokenStatus { get; set; }

        [DataMember(Name = "tokenExpiryDate")]
        public string TokenExpiryDate { get; set; }

        [DataMember(Name = "tokenValue")]
        public decimal TokenValue { get; set; }

        [DataMember(Name = "lastname")]
        public string Lastname { get; set; }

        [DataMember(Name = "postcode")]
        public string Postcode { get; set; }
    }
}