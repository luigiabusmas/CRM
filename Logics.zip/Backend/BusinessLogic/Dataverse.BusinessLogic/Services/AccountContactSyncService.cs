using System;
using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;

namespace Cultivate.BusinessLogic.Services
{
    public interface IAccountContactSyncService
    {
        void SyncAccountDetailsToPrimaryContact(Account account);
        void SyncAccountDetailsToPrimaryContact(Guid accountId);
        void CreateContactFromAccount(Account account);
        void UpdateMemberDetails(Guid contactId);
    }

    public class AccountContactSyncService : IAccountContactSyncService
    {
        private readonly IContactRepository _contactRepository;
        private readonly IRepository<Account> _accountRepository;

        public AccountContactSyncService(IContactRepository contactRepository, IRepository<Account> accountRepository)
        {
            _contactRepository = contactRepository;
            _accountRepository = accountRepository;
        }

        public void SyncAccountDetailsToPrimaryContact(Guid accountId)
        {
            var account = _accountRepository.GetById(accountId);
            SyncAccountDetailsToPrimaryContact(account);
        }

        public void CreateContactFromAccount(Account account)
        {
            var maxLength = 50 - " (Default Contact)".Length;
            var lastName = (account.Name.Length > maxLength
                               ? account.Name.Substring(0, maxLength)
                               : account.Name) + " (Default Contact)";

            var contact = new Contact
            {
                LastName = lastName,
                Description = account.Description,
                ParentCustomerId = account.ToEntityReference(),
                Address1_City = account.Address1_City,
                Address1_Country = account.Address1_Country,
                Address1_County = account.Address1_County,
                Address1_StateOrProvince = account.Address1_StateOrProvince,
                Address1_PostalCode = account.Address1_PostalCode,
                Address1_Line1 = account.Address1_Line1,
                Address1_Line2 = account.Address1_Line2,
                Address1_Line3 = account.Address1_Line3,
                Address1_Name = account.Address1_Name
            };

            contact = _contactRepository.Create(contact);

            account.PrimaryContactId = contact.ToEntityReference();
            _accountRepository.Update(account);
        }

        public void SyncAccountDetailsToPrimaryContact(Account account)
        {
            if (account == null)
                throw new ArgumentNullException(nameof(account));

            if (account.PrimaryContactId == null)
                return;

            var contact = _contactRepository.GetById(account.PrimaryContactId.Id);

            contact.Address1_City = account.Address1_City;
            contact.Address1_Country = account.Address1_Country;
            contact.Address1_County = account.Address1_County;
            contact.Address1_StateOrProvince = account.Address1_StateOrProvince;
            contact.Address1_PostalCode = account.Address1_PostalCode;
            contact.Address1_Line1 = account.Address1_Line1;
            contact.Address1_Line2 = account.Address1_Line2;
            contact.Address1_Line3 = account.Address1_Line3;
            contact.Address1_Name = account.Address1_Name;

            _contactRepository.Update(contact);
        }

        public void UpdateMemberDetails(Guid contactId)
        {
            var contact = _contactRepository.GetById(contactId);
            contact["rhs_isprimarymember"] = null;
            contact["rhs_membershiprelationship"] = null;
            _contactRepository.Update(contact);
        }
    }
}