﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface IBatchOrderService
    {
        void ValidateMembershipCampaign(Batchorder batchOrder);
    }

    public class BatchOrderService : IBatchOrderService
    {
        private ILogger _logger;
        private IRepository<Batchorder> _batchOrderRepository;
        private IRepository<Campaign> _campaignRepository;
        private ICampaignService _campaignService;

        public BatchOrderService(ILogger logger, IRepository<Batchorder> batchOrderRepository, IRepository<Campaign> campaignRepository, ICampaignService campaignService)
        {
            _logger = logger;
            _batchOrderRepository = batchOrderRepository;
            _campaignRepository = campaignRepository;
            _campaignService = campaignService;
        }

        #region Business Logics
        public void ValidateMembershipCampaign(Batchorder batchOrder)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (batchOrder.MembershipProduct != null && batchOrder.CampaignCode != null)
            {
                _logger.TraceInformation($"Membership product and campaign selected.");

                _logger.TraceInformation($"Retreiving membership campaign.");
                var campaign = _campaignRepository.GetById(batchOrder.CampaignCode.Id);

                _logger.TraceInformation($"Validating if the campaign is active.");
                if (campaign.StateCode != CampaignState.Active)
                    throw new InvalidPluginExecutionException("Please enter a valid Campaign Code!");

                _logger.TraceInformation($"Validating if the campaign is valid for selected product.");
                var campaignProductIds = _campaignService.RetrieveCampaignProductIds(campaign.Id);
                if (batchOrder.MembershipProduct == null || !campaignProductIds.Any(id => id == batchOrder.MembershipProduct.Id))
                    throw new InvalidPluginExecutionException("Entered Campaign Code is not valid for selected Membership Product. Please select correct Campaign Code!");

                _logger.TraceInformation($"Validation passed.");
            }
            else
                _logger.TraceInformation($"Either no membership product or campaign selected.");

            _logger.TraceInformation($"Ending business logic.");
        }
        #endregion

        #region Helpers

        #endregion
    }
}