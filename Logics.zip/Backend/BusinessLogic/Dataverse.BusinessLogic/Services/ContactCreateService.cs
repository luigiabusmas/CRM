﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ComponentModel;
using System.Linq;
using System.Text.RegularExpressions;

namespace Cultivate.BusinessLogic.Services
{
    public interface IContactCreateService
    {
        void validatedNameInputOnCreate(Contact contact);
        void contactPopulateFieldOnCreate(Contact contact);
        void contactPopulateInitials(Contact contact);
        void contactPopulateAge(Contact contact);
        void contactPopulateSalutation(Contact contact);
        void contactLastNameAdvancedAutoCapitalization(Contact contact);
        void contactPopulateLabelName(Contact contact);
        void contactSetAddressFieldsOnCreate(Contact contact);
        void contactSetAddress3FieldsOnCreate(Contact contact);
    }

    public class ContactCreateService : IContactCreateService
    {
        private readonly ITracingService _tracingService;
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;
        private readonly IPluginExecutionContext _context;
        private readonly IRepository<Contact> _contactRepository;
        private ICommonService _commonService;
        private IContactUpdateService _contactUpdateService;

        public ContactCreateService(
           ITracingService tracingService, ILogger logger,
           IOrganizationService service,
           IPluginExecutionContext context,
           IRepository<Contact> contactRepository,
           ICommonService commonService,
           IContactUpdateService contactUpdateService

        )
        {
            _tracingService = tracingService;
            _logger = logger;
            _service = service;
            _context = context;
            _contactRepository = contactRepository;
            _commonService = commonService;
            _contactUpdateService = contactUpdateService;
        }
        public void validatedNameInputOnCreate (Contact contact)
        {
            _logger.TraceInformation($"validatePreferredName Start");
            //Validate Preferred Name
            if (contact != null)
            {

                //Validate First Name, Last Name, Preferred Name, and Initial
                var fields = new (string value, string name, string fieldName)[]
                        {
                            (contact.FirstName, "First Name", EntityNames.Contact.FirstName),
                            (contact.LastName, "Last Name", EntityNames.Contact.LastName),
                            (contact.NickName, "Preferred Name", EntityNames.Contact.NickName),
                            (contact.Initials, "Initials", EntityNames.Contact.Initials)
                        };

                Entity record = new Entity(EntityNames.Contact.EntityLogicalName, contact.Id);
                foreach (var field in fields)
                {
                    if (!string.IsNullOrWhiteSpace(field.value) && !string.IsNullOrWhiteSpace(field.name) && !string.IsNullOrWhiteSpace(field.fieldName))
                    {
                        _logger.TraceInformation(string.Format("validatePreferredName fields: {0} | {1} | {2}", field.value, field.name, field.fieldName));
                        bool isValid = _commonService.validateName(field.value);
                        if (isValid)
                        {
                            if (field.fieldName == EntityNames.Contact.FirstName || field.fieldName == EntityNames.Contact.LastName)
                            {
                                bool isLastName = false;
                                if (field.fieldName == EntityNames.Contact.LastName)
                                    isLastName = true;
                                else
                                    isLastName = false;
                                contact[field.fieldName] = _commonService.capitalizeNameInput(field.value, isLastName);
                            }
                        }
                        else
                        {
                            throw new InvalidPluginExecutionException(string.Format("The \"{0}\" field can only contain letters, spaces, dashes, and apostrophes. Please remove any invalid characters and try again.", field.name));
                        }
                    }
                }
                /*if (record.Attributes.Count > 0)
                {
                    _service.Update(record);
                }*/

            }
            //Validate First Name and Last Name and Perform Auto Capitalization
            //Validate Initials
            _logger.TraceInformation($"validatePreferredName End");
        }

        public void contactPopulateFieldOnCreate(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateFieldOnCreate Start");
            if (contact != null)
            {
                //Get GDPR Configuration for Contact
                _contactUpdateService.contactPopulateGDPRDeletionDate(contact);

                //Populate Constituent Number
                //contact.Msnfp_constituentnumber = new Random().Next(10000000, 100000000).ToString(); //converted to autonumber
              
            }
            _logger.TraceInformation($"contactPopulateFieldOnCreate End");
        }
        public void contactPopulateInitials(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateInitials Start");
            if (contact != null)
            {

                //Populate Initials
                if (!string.IsNullOrWhiteSpace(contact.FirstName))
                {
                    string[] fNames = contact.FirstName.Split(' ');
                    string initials = string.Empty;
                    foreach (var fName in fNames)
                    {
                        if (!string.IsNullOrEmpty(fName))
                        {
                            initials += char.ToUpper(fName[0]) + " ";
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(initials))
                    {
                        var updateContact = new Entity(Contact.EntityLogicalName, contact.Id);
                        updateContact[EntityNames.Contact.Initials] = initials.Trim();
                        _service.Update(updateContact);
                    }
                }
            }
            _logger.TraceInformation($"contactPopulateInitials End");
        }


        public void contactPopulateAge(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateAge Start");
            if (contact != null)
            {

                //Populate Age
                if (contact.BirthDate != null)
                {

                    DateTime dob = contact.BirthDate.Value.Date;
                    DateTime today = DateTime.Today;

                    if (dob > today)
                    {
                        throw new InvalidPluginExecutionException("Date of Birth cannot be in the future. Please enter a valid date and try again.");
                    }

                    int age = DateTime.Now.Year - contact.BirthDate.Value.Year;
                    if (contact.BirthDate.Value.Date > new DateTime(contact.BirthDate.Value.Year, DateTime.Now.Month, DateTime.Now.Day))
                    {
                        age--;
                    }
                    var updateContact = new Entity(Contact.EntityLogicalName, contact.Id);
                    updateContact[EntityNames.Contact.Age] = age;
                    _service.Update(updateContact);

                }
            }
            _logger.TraceInformation($"contactPopulateAge End");
        }

        public void contactPopulateSalutation(Contact contact)
        {
            _logger.TraceInformation("contactPopulateSalutation Start");

            if (contact == null)
            {
                _logger.TraceInformation("Contact is null. Exiting method.");
                return;
            }

            string titleString = null;

            if (contact.Title != null && contact.Title.Id != Guid.Empty)
            {
                titleString = _commonService.getSalutation(contact.Title.Id);
                if (!string.IsNullOrWhiteSpace(titleString))
                {
                    if (titleString.Contains("_firstname_ _lastname_"))
                    {
                        titleString = titleString.Replace("_firstname_ _lastname_", contact.FullName ?? "");
                    }
                    else if (titleString.Contains("_firstname_"))
                    {
                        titleString = titleString.Replace("_firstname_", contact.FirstName ?? "");
                    }
                    else if (titleString.Contains("_lastname_"))
                    {
                        titleString = titleString.Replace("_lastname_", contact.LastName ?? "");
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(titleString))
            {
                if (!string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName))
                {
                    titleString = $"{contact.FirstName} {contact.LastName}";
                }
                else if (string.IsNullOrWhiteSpace(contact.FirstName) && !string.IsNullOrWhiteSpace(contact.LastName) && !string.IsNullOrWhiteSpace(contact.Initials))
                {
                    titleString = $"{contact.Initials} {contact.LastName}";
                }
            }

            if (!string.IsNullOrWhiteSpace(titleString))
            {
                contact.Salutation = titleString;
            }
            _logger.TraceInformation("contactPopulateSalutation End");
        }

        public void contactLastNameAdvancedAutoCapitalization(Contact contact)
        {
            _logger.TraceInformation($"contactLastNameAdvancedAutoCapitalization Start");
            if (contact != null)
            {
                if (!string.IsNullOrWhiteSpace(contact.LastName))
                {
                    var UpdateLastName = new Contact()
                    {
                        Id = contact.Id,
                        LastName = _commonService.capitalizeNameInput(contact.LastName, true)
                    };
                    _service.Update(UpdateLastName);
                    _logger.TraceInformation($"contactLastNameAdvancedAutoCapitalization contact updated");
                }

            }
            _logger.TraceInformation($"contactLastNameAdvancedAutoCapitalization End");
        }

        public void contactPopulateLabelName(Contact contact)
        {
            _logger.TraceInformation($"contactPopulateLabelName Start");
            if (contact != null)
            {
                string title = string.Empty;
                if (contact.Title != null && contact.Title.Id != Guid.Empty)
                {
                    Entity Salutation = _service.Retrieve(TitleandSalutation.EntityLogicalName, contact.Title.Id, new ColumnSet(EntityNames.TitleandSalutation.Name));
                    if (Salutation != null)
                    {
                        title = Salutation[EntityNames.TitleandSalutation.Name] as string;
                    }
                }
                contact.LabelName2 = string.Join(" ",
                    new[] {
                title,
                contact.Initials,
                _commonService.capitalizeNameInput(contact.LastName, true),
                contact.Suffix
                    }.Where(s => !string.IsNullOrWhiteSpace(s))
                );
                _logger.TraceInformation($"contactPopulateLabelName Updated Label Name");
            }
            _logger.TraceInformation($"contactPopulateLabelName End");
        }
        public void contactSetAddressFieldsOnCreate(Contact contact)
        {
            _logger.TraceInformation($"contactSetAddressFieldsOnCreate Start");
            if (contact != null)
            {
                //Address 1
                if (!string.IsNullOrWhiteSpace(contact.Loqate_Longitude))
                    contact.Address1_Longitude = Convert.ToDouble(contact.Loqate_Longitude);
                if (!string.IsNullOrWhiteSpace(contact.Loqate_Latitude))
                    contact.Address1_Latitude = Convert.ToDouble(contact.Loqate_Latitude);
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress1County))
                    contact.Address1_County = contact.LoqateAddress1County;
                if (!string.IsNullOrWhiteSpace(contact.LoqateHomeAddressHouseName))
                    contact.Address1_Name = contact.LoqateHomeAddressHouseName;

                //Postcode home address
                if (!string.IsNullOrWhiteSpace(contact.Address1_PostalCode))
                    contact.PostcodeHomeAddress = contact.Address1_PostalCode;

                //Address 2
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress2Longitude))
                    contact.Address2_Longitude = Convert.ToDouble(contact.LoqateAddress2Longitude);
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress2Latitude))
                    contact.Address2_Latitude = Convert.ToDouble(contact.LoqateAddress2Latitude);
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress2County))
                    contact.Address2_County = contact.LoqateAddress2County;
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress2HouseName))
                    contact.Address2_Name = contact.LoqateAddress2HouseName;
            }
            _logger.TraceInformation($"contactSetAddressFieldsOnCreate End");
        }

        public void contactSetAddress3FieldsOnCreate(Contact contact)
        {
            _logger.TraceInformation($"contactSetAddress3FieldsOnCreate Start");
            if (contact != null)
            {
                var contacUpdate = new Entity(Contact.EntityLogicalName, contact.Id);
                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3HouseName))
                    contacUpdate[EntityNames.Contact.Address3_Name] = contact.LoqateAddress3HouseName;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Line1))
                    contacUpdate[EntityNames.Contact.Address3_Line1] = contact.LoqateAddress3Line1;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Line2))
                    contacUpdate[EntityNames.Contact.Address3_Line2] = contact.LoqateAddress3Line2;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Line3))
                    contacUpdate[EntityNames.Contact.Address3_Line3] = contact.LoqateAddress3Line3;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Line4))
                    contacUpdate[EntityNames.Contact.Address3_StateOrProvince] = contact.LoqateAddress3Line4;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3City))
                    contacUpdate[EntityNames.Contact.Address3_City] = contact.LoqateAddress3City;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Country))
                    contacUpdate[EntityNames.Contact.Address3_Country] = contact.LoqateAddress3Country;

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Longitude))
                    contacUpdate[EntityNames.Contact.Address3_Longitude] = Convert.ToDouble(contact.LoqateAddress3Longitude);

                if (!string.IsNullOrWhiteSpace(contact.LoqateAddress3Latitude))
                    contacUpdate[EntityNames.Contact.Address3_Latitude] = Convert.ToDouble(contact.LoqateAddress3Latitude);

                if (contacUpdate.Attributes.Count > 0)
                {
                    _service.Update(contacUpdate);
                    _logger.TraceInformation($"contactSetAddress3FieldsOnCreate contact address updated");
                }


            }
            _logger.TraceInformation($"contactSetAddress3FieldsOnCreate End");
        }


    }
}