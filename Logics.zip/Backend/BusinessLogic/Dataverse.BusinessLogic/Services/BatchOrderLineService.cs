﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IBatchOrderLineService
    {
        Batchorder GetBatchOrderOfBatchOrderLine(Batchorderline batchOrderLine);
        Membership CreateLinkedMembership(Batchorderline batchOrderLine);
        void PayAndActivateMembershipWhenApplicable(Membership membership, Guid? paymentId); //method can be moved to membership (update) service
        void LinkDonationIdWithBatchOrderLine(Batchorderline batchOrderLine, Guid donationId);
        void ValidateDonationCampaignOnUpdate(Batchorderline batchOrderLine);
    }

    public class BatchOrderLineService : IBatchOrderLineService
    {
        private ILogger _logger;
        private readonly IOrganizationService _service;
        private IRepository<Batchorderline> _batchOrderLineRepository;
        private IRepository<Batchorder> _batchOrderRepository;
        private IRepository<Membership> _membershipRepository;
        private IRepository<Payment> _paymentRepositroy;
        private IProductService _productService;
        private IRecordDateCalculationService _recordDateCalculationService;

        public BatchOrderLineService(ILogger logger,
            IOrganizationService service,
            IRepository<Batchorderline> batchOrderLineRepository, IRepository<Batchorder> batchOrderRepository, 
            IRepository<Membership> membershipRepository, IRepository<Payment> paymentRepositroy,
            IProductService productService, IRecordDateCalculationService recordDateCalculationService)
        {
            _logger = logger;
            _service = service;
            _batchOrderLineRepository = batchOrderLineRepository;
            _batchOrderRepository = batchOrderRepository;
            _membershipRepository = membershipRepository;
            _paymentRepositroy = paymentRepositroy;
            _productService = productService;
            _recordDateCalculationService = recordDateCalculationService;
        }

        #region Business Logics
        public Batchorder GetBatchOrderOfBatchOrderLine(Batchorderline batchOrderLine)
        {
            _logger.TraceInformation($"Starting business logic.");

            var batchOrder = batchOrderLine.Batchorder != null ? _batchOrderRepository.GetById(batchOrderLine.Batchorder.Id) : null;

            _logger.TraceInformation($"Ending business logic.");
            return batchOrder;
        }

        public Membership CreateLinkedMembership(Batchorderline batchOrderLine)
        {
            _logger.TraceInformation($"Starting business logic.");
            Membership newMembership = null;

            _logger.TraceInformation($"Creating membership from batch order line and batch order.");
            var membershipToCreate = new Membership()
            {
                CampaignId = batchOrderLine.Campaign,
                CampaignDonation = batchOrderLine.DonationCampaign,
                MembershipProductId = batchOrderLine.MembershipProduct,
                
                IsMembershipForSomeone = batchOrderLine.IsthisMembershipforsomeoneelse,
                IsthisMembershipaoneyeargift = batchOrderLine.IsthisMe,
                Contact = batchOrderLine.PrimaryMember,
                Member2 = batchOrderLine.SecondaryMember,
                PayerV2 = batchOrderLine.Payer,
                IsNewMembershipPacktoMember = batchOrderLine.NewMembershippacktomember,
                IsReferredByExistingMember = batchOrderLine.IsReferredByExistingMember,
                ReferralMemberId = batchOrderLine.ReferralMember,
                Channel = batchOrderLine.ChannelSource,
                Location = batchOrderLine.Location,

                PriceList = batchOrderLine.PriceList,
                TotalAmount = batchOrderLine.MembershipPrice/*with discount*/,
                PaymentMethod = (PaymentMethodType_GlobalOptionSet?)batchOrderLine.PaymentMethodCode,
                IsContinuousPayment = false,
                PaymentFrequency = PaymentFrequency_GlobalOptionSet.Annually,
                ThirdPartyPaymentType = batchOrderLine.ThirdPartyPaymentType,

                GDPRRead = true,
                CancellationRead = true,

                Statecode = MembershipState.Active,
                Statuscode = MembershipStatus.Active_Prospect,
            };
            membershipToCreate.Startdate = _recordDateCalculationService.CalculateStartDateOfRecord(membershipToCreate.MembershipProductId);
            membershipToCreate.Enddate = _recordDateCalculationService.CalculateEndDateOfRecord(membershipToCreate.Startdate, membershipToCreate.MembershipProductId.Id, membershipToCreate.CampaignId?.Id);
            membershipToCreate.RenewalsStartDate = _recordDateCalculationService.CalculateRenewalStartDateOfRecord(membershipToCreate.Enddate);
            membershipToCreate.RenewalsEndDate = _recordDateCalculationService.CalculateRenewalEndDateOfRecord(membershipToCreate.Enddate);
            membershipToCreate.PaymentSchedule = membershipToCreate.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit ?
                _recordDateCalculationService.CalculatePayoutDate((DateTime)membershipToCreate.Startdate) : null;
            try
            {
                newMembership = _membershipRepository.Create(membershipToCreate);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.InnerException.Message);
            }

            _logger.TraceInformation($"Linking membership to batch order line.");
            var batchOrderLineUpdate = new Batchorderline()
            {
                Id = batchOrderLine.Id,
                MembershipId = newMembership.ToEntityReference(),
            };
            _batchOrderLineRepository.Update(batchOrderLineUpdate);

            _logger.TraceInformation($"Ending business logic.");
            return newMembership;
        }

        public void PayAndActivateMembershipWhenApplicable(Membership membership, Guid? paymentId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Payment Method = {membership.PaymentMethod}.");
            if (paymentId != null && membership.PaymentMethod != null &&
                membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.Card &&
                membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.CreditCard_Phone &&
                membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit &&
                membership.PaymentMethod != PaymentMethodType_GlobalOptionSet.InternalGiftPack)
            {
                _logger.TraceInformation($"Paying membership");
                var paymentUpdate = new Payment() 
                { 
                    Id = (Guid)paymentId, 
                    Statecode = PaymentState.Inactive, 
                    Statuscode = PaymentStatus.Inactive_Paid 
                };
                _paymentRepositroy.Update(paymentUpdate);

                _logger.TraceInformation($"Activating membership");
                var membershipUpdate = new Membership()
                {
                    Id = membership.Id,
                    IsSubmitPayment = true,
                    PaymentReceived = true,
                    Statecode = MembershipState.Active,
                    Statuscode = MembershipStatus.Active_Active
                };
                _membershipRepository.Update(membershipUpdate);
            }

            _logger.TraceInformation($"Ending business logic.");
        }
        
        public void LinkDonationIdWithBatchOrderLine(Batchorderline batchOrderLine, Guid donationId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var batchOrderLineUpdate = new Batchorderline()
            {
                Id = batchOrderLine.Id,
                Donation = new EntityReference(EntityNames.Donation.EntityLogicalName, donationId),
            };
            _batchOrderLineRepository.Update(batchOrderLineUpdate);

            _logger.TraceInformation($"Ending business logic.");
        }

        public void ValidateDonationCampaignOnUpdate(Batchorderline batchOrderLine)
        {
            _logger.TraceInformation($"ValidateDonationCampaignOnUpdate Start");
            if (batchOrderLine != null && batchOrderLine.DonationCampaign != null)
            {
                if (batchOrderLine.DonationCampaign.Id != Guid.Empty)
                {
                    Entity campaign = _service.Retrieve(EntityNames.Campaign.EntityLogicalName, batchOrderLine.DonationCampaign.Id, new ColumnSet(EntityNames.Campaign.DonationType, EntityNames.Campaign.RestrictedFund));
                    if (campaign != null)
                    {
                        var donationType = campaign.GetAttributeValue<EntityReference>(EntityNames.Campaign.DonationType);
                        var restrictedFund = campaign.GetAttributeValue<EntityReference>(EntityNames.Campaign.RestrictedFund);

                        if (donationType == null || donationType.Id == Guid.Empty ||
                            restrictedFund == null || restrictedFund.Id == Guid.Empty)
                        {
                            throw new InvalidPluginExecutionException(
                                "The selected Campaign is missing either a Donation Type or a Restricted Fund. Please update the Campaign record to proceed."
                            );
                        }
                    }
                }

            }
            _logger.TraceInformation($"ValidateDonationCampaignOnUpdate End");
        }
        #endregion

        #region Helpers
        #endregion
    }
}