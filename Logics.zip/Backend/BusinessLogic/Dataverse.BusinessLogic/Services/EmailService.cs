using Avanade.BizApps.Core.Diagnostics;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface IEmailService
    {
        void SetGdprDeletionDate(Entity emailEntity);
    }

    public class EmailService : IEmailService
    {
        private readonly ITracingService _tracingService;
        private readonly IOrganizationService _organizationService;

        public EmailService(ITracingService tracingService, IOrganizationService service)
        {
            _tracingService = tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _organizationService = service ?? throw new ArgumentNullException(nameof(service));
        }

        public void SetGdprDeletionDate(Entity emailEntity)
        {
            _tracingService.Trace("SetGdprDeletionDate Start");

            QueryExpression query = new QueryExpression("rhs_gdprconfigurationsettings")
            {
                ColumnSet = new ColumnSet("rhs_retentionperiod"),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression("rhs_entitynamecode", ConditionOperator.Equal, 120000003)
                    }
                }
            };

            EntityCollection configResults = _organizationService.RetrieveMultiple(query);

            if (configResults.Entities.Any())
            {
                Entity config = configResults.Entities.First();
                if (config.Contains("rhs_retentionperiod") && config["rhs_retentionperiod"] is int retentionPeriod)
                {
                    DateTime deletionDateUtc = DateTime.UtcNow.AddDays(retentionPeriod);
                    emailEntity["rhs_gdprdeletiondate"] = deletionDateUtc;
                    _tracingService.Trace($"GDPR Deletion Date set to {deletionDateUtc:dd/MM/yyyy HH:mm} UTC for Email.");
                }
                else
                {
                    _tracingService.Trace("GDPR configuration found but 'rhs_retentionperiod' is missing or invalid.");
                }
            }
            else
            {
                _tracingService.Trace("No GDPR configuration found for Email entity.");
            }

            _tracingService.Trace("SetGdprDeletionDate End");
        }
    }
}