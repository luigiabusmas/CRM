﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface ISuppressionService
    {
        List<Suppression> RetrieveContactSuppression(Guid contactId);
        bool DoesContactHaveGoneAwaySuppression(Guid contactId);
    }

    public class SuppressionService : ISuppressionService
    {
        private readonly ILogger _logger;
        private IOrganizationService _service;
        private readonly IRepository<Suppression> _suppressionRepository;

        public SuppressionService(ILogger logger, IOrganizationService organizationService, IRepository<Suppression> suppressionRepository)
        {
            _logger = logger;
            _service = organizationService;
            _suppressionRepository = suppressionRepository;
        }

        public List<Suppression> RetrieveContactSuppression(Guid contactId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression("rhs_suppression");
            query.ColumnSet.AddColumn("rhs_newcolumn");
            //query.ColumnSet.AddColumn("rhs_description");
            var query_rhs_contact_rhs_suppression = query.AddLink("rhs_contact_rhs_suppression", "rhs_suppressionid", "rhs_suppressionid");
            query_rhs_contact_rhs_suppression.LinkCriteria.AddCondition("contactid", ConditionOperator.Equal, contactId);

            var suppressions = _service.RetrieveMultiple(query).Entities.Select(suppression => suppression.ToEntity<Suppression>()).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return suppressions;
        }

        public bool DoesContactHaveGoneAwaySuppression(Guid contactId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var suppressions = RetrieveContactSuppression(contactId);
            var containsGoneAway = suppressions.Where(suppression => suppression.Newcolumn == "Gone Away").ToList().Count > 0;

            _logger.TraceInformation($"Ending business logic.");
            return containsGoneAway;
        }
    }
}