﻿using Avanade.BizApps.Core.Contracts;
using Cultivate.Entities.Generated;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;

namespace Cultivate.BusinessLogic.Services
{
    public interface IMembershipUpdateService
    {
        bool ValidateIfMemberValidationShouldBeDone(Membership preImageMembership, Membership postImageMembership);
        void MembershipMembersValidation(Entity targetMembership);
        void MembershipMembersValidationV2(Membership membership);
        void MembershipCancellation(Entity membership);
        bool ValidateIfCampaignAmountShouldBeRepopulated(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfTotalAmountShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfDDMembershipWasCancelled(Membership membership);
        bool ValidateIfPayerWasChangedForDDMembership(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfPaymentMethodWasChangedFromDD(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfPaymentSubmissionWasTriggered(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfActivatedWithoutStartDate(Membership preImageMembership, Membership postImageMembership);
        bool ValidateIfMembershipWasActivated(Membership preImageMembership, Membership postImageMembership);
        Entity SetStartDateOnMembershipEntity(Entity entity, Membership membership);
        Entity SetEndDateOnMembershipEntity(Entity entity, Membership membership);
        Entity SetRenewalsStartDateOnMembershipEntity(Entity entity, Membership membership);
        Entity SetRenewalsEndDateOnMembershipEntity(Entity entity, Membership membership);
        Entity SetOutstandingAmounteOnMembershipEntity(Entity entity, Membership membership);
        Entity MakeMembershipPayableWhenOutstandingAmountGreaterThanZero(Entity entity, Membership membership);
        //Entity MembershipMakePaymentForStripe(Entity entity, Membership membership);
        bool ValidateIfRenewalsTotalAmountShouldBeRecalculated(Entity entity);
        Entity SetRenewalMembershipPriceOnMembershipEntity(Entity entity, Membership membership);
        Entity SetRenewalTotalAmountOnMembershipEntity(Entity entity, Membership membership);
        bool ValidateIfRenewalsPayoutDateShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership);
        Entity SetPayoutDate(Entity entity, Membership membership);
        Entity SetRenewalsPayoutDate(Entity entity, Membership membership);
        void ValidateRenewalCampaignInMembership(Membership membership);
        bool ValidateIfMembershipPackMHStatusShouldBeSetToPending(Membership membership);
        Entity SetNewMembershipPackMHStatusOnMembershipEntity(Entity entity, Membership membership);
        Entity SetMembershipCardDetails(Entity entity, Membership membership);
        Entity SetPaymentMethodToCard(Entity entity, Membership membership);
        bool ValidateIfDonationAmountShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership);
        void ValidatePatronTotalAmount(Membership membership);
        Entity RevertTotalAmountIfMembershipContainsDonation(Entity entity, Membership postImageMembership, Money originalTotalAmount);
        void PopulatePrimaryMembershipOfMembers(Membership membership);
        Entity SetDonationAmountOnMembershipEntity(Entity entity, Membership membership);
        void ValidateIfMembershipRenewalPackMHStatusShouldBeSetToPending(Entity membership);
        void SetCardIssueNumber(Membership membership);
        void RedeemGiftPack(Membership membership);
        void SetStatusOnMembershipEntity(Entity entity, Membership preImageMembership, Membership membership);
        void ValidateAddressInMembership(Entity entity, Membership preImageMembership);
        Entity SetPatronMembershipOnMembership(Entity entity, Membership membership);
    }

    public class MembershipUpdateService : IMembershipUpdateService
    {
        private ITracingService _tracingService;
        private IOrganizationService _service;
        private IRepository<Contact> _contactRepository;
        private IRepository<Campaign> _campaignRepository;
        private IRepository<Paymentdiscountconfiguration> _paymentDiscountConfigurationRepository;
        private IRepository<Transaction> _transactionRepository;
        private IPropertyRetrievalService _propertyRetrievalService;
        private IProductService _productService;
        private ICampaignService _campaignService;
        private ISuppressionService _suppressionService;
        private IRecordDateCalculationService _recordDateCalculationService;
        private IMembershipCreateService _membershipCreateService;
        private ICommonService _commonService;

        public MembershipUpdateService(ITracingService tracingService, IOrganizationService service,
            IRepository<Contact> contactRepository, IRepository<Campaign> campaignRepository, IRepository<Paymentdiscountconfiguration> paymentDiscountConfigurationRepository, IRepository<Transaction> transactionRepository,
            IPropertyRetrievalService propertyRetrievalService, IProductService productService, ICampaignService campaignService, ISuppressionService suppressionService, IRecordDateCalculationService recordDateCalculationService, IMembershipCreateService membershipCreateService, ICommonService commonService
        )
        {
            _tracingService = tracingService;
            _service = service;
            _contactRepository = contactRepository;
            _campaignRepository = campaignRepository;
            _paymentDiscountConfigurationRepository = paymentDiscountConfigurationRepository;
            _transactionRepository = transactionRepository;
            _propertyRetrievalService = propertyRetrievalService;
            _productService = productService;
            _campaignService = campaignService;
            _suppressionService = suppressionService;
            _recordDateCalculationService = recordDateCalculationService;
            _membershipCreateService = membershipCreateService;
            _commonService = commonService;
        }

        public bool ValidateIfMemberValidationShouldBeDone(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace("ValidateIfMemberValidationShouldBeDone Start");

            var isPreActivation = 
                postImageMembership.Statuscode == null || 
                postImageMembership.Statuscode == MembershipStatus.Active_Prospect || 
                postImageMembership.Statuscode == MembershipStatus.Active_PendingPayment;
            _tracingService.Trace($"Is pre-activation? {isPreActivation}");

            var hasProductChanged = preImageMembership.MembershipProductId?.Id != postImageMembership.MembershipProductId?.Id;
            _tracingService.Trace($"Has product changed? {hasProductChanged}");

            var hasPrimaryMemberChanged = preImageMembership.Contact?.Id != postImageMembership.Contact?.Id;
            _tracingService.Trace($"Has primary member changed? {hasPrimaryMemberChanged}");

            var hasSecondaryMemberChanged = preImageMembership.Member2?.Id != postImageMembership.Member2?.Id;
            _tracingService.Trace($"Has secondary member changed? {hasSecondaryMemberChanged}");

            var shouldMemberValidationBeDone = isPreActivation && (hasProductChanged || hasPrimaryMemberChanged || hasSecondaryMemberChanged);
            _tracingService.Trace($"Should member validation be done? {shouldMemberValidationBeDone}");

            _tracingService.Trace("ValidateIfMemberValidationShouldBeDone End");
            return shouldMemberValidationBeDone;
        }
        public void MembershipMembersValidation(Entity targetMembership)
        {
            _tracingService.Trace("MembershipMembersValidation Start");
            _tracingService.Trace($"Membership Id: {targetMembership.Id}");

            #region Record Retrieval
            // Membership Product Retrieval
            Entity membership;
            if (targetMembership.ToEntity<Membership>().MembershipProductId != null)
                membership = targetMembership;
            else
                membership = _service.Retrieve(EntityNames.Membership.EntityLogicalName, targetMembership.Id, new ColumnSet(EntityNames.Membership.MembershipProductId));
            EntityReference membershipProductRef = membership.GetAttributeValue<EntityReference>(EntityNames.Membership.MembershipProductId);

            if (membershipProductRef == null)
                throw new InvalidPluginExecutionException("Missing Membership Product");

            _tracingService.Trace($"Membership Product: {membershipProductRef.Name}");

            // "Number of Members Allowed" Product Property Retrieval
            var productPropertyName = "Number of Members Allowed";
            var numberOfAllowedMembers = _propertyRetrievalService.GetProductProperty(membershipProductRef.Id.ToString(), productPropertyName).DefaultValueInteger;
            _tracingService.Trace($"numberOfAllowedMembers: {numberOfAllowedMembers}");

            // Membership Members Retrieval
            QueryExpression query = new QueryExpression(EntityNames.Membership_contact_mm.EntityLogicalName);
            query.Distinct = true;
            query.ColumnSet.AddColumns(
                EntityNames.Membership_contact_mm.Contactid,
                EntityNames.Membership_contact_mm.Membershipid,
                EntityNames.Membership_contact_mm.PrimaryIdAttribute
            );
            query.Criteria.AddCondition(EntityNames.Membership_contact_mm.Membershipid, ConditionOperator.Equal, targetMembership.Id);

            EntityCollection existingMembers = _service.RetrieveMultiple(query);
            _tracingService.Trace($"Existing Members Count: {existingMembers.Entities.Count}");
            #endregion

            #region Validation
            if (numberOfAllowedMembers >= 1 && existingMembers.Entities.Count >= 1 && existingMembers.Entities.Count > numberOfAllowedMembers)
            {
                throw new InvalidPluginExecutionException($"The Membership Product allows only {numberOfAllowedMembers} members, but there are currently {existingMembers.Entities.Count} members. Please remove extra member!");
            }
            else if (numberOfAllowedMembers >= 1 && existingMembers.Entities.Count >= 1 && existingMembers.Entities.Count < numberOfAllowedMembers)
            {
                throw new InvalidPluginExecutionException($"The Membership Product allows {numberOfAllowedMembers} members, but there are currently {existingMembers.Entities.Count} members. Please add another member!");
            }
            #endregion

            _tracingService.Trace("MembershipMembersValidation End");
        }

        public void MembershipMembersValidationV2(Membership membership)
        {
            _tracingService.Trace("MembershipMembersValidation Start");
            _tracingService.Trace($"Membership Id: {membership.Id}");

            #region Record Retrieval
            // Membership Product Retrieval
            EntityReference membershipProductRef = membership.MembershipProductId;
            if (membershipProductRef == null)
                throw new InvalidPluginExecutionException("Missing Membership Product");
            _tracingService.Trace($"Membership Product: {membershipProductRef.Name}");

            // "Number of Members Allowed" Product Property Retrieval
            var productPropertyName = "Number of Members Allowed";
            var numberOfAllowedMembers = _propertyRetrievalService.GetProductProperty(membershipProductRef.Id.ToString(), productPropertyName).DefaultValueInteger;
            _tracingService.Trace($"numberOfAllowedMembers: {numberOfAllowedMembers}");

            // Membership Members Count Retrieval
            var existingMembersCount = -1;
            if (membership.Contact != null && membership.Member2 != null)
                existingMembersCount = 2;
            else if (membership.Contact != null)
                existingMembersCount = 1;
            else
                existingMembersCount = 0;
            _tracingService.Trace($"Existing Members Count: {existingMembersCount}");
            #endregion

            #region Validation
            if (numberOfAllowedMembers >= 1 && existingMembersCount >= 1 && existingMembersCount > numberOfAllowedMembers)
            {
                throw new InvalidPluginExecutionException($"The Membership Product allows only {numberOfAllowedMembers} members, but there are currently {existingMembersCount} members. Please remove extra member!");
            }
            else if (numberOfAllowedMembers >= 1 && existingMembersCount >= 1 && existingMembersCount < numberOfAllowedMembers)
            {
                throw new InvalidPluginExecutionException($"The Membership Product allows {numberOfAllowedMembers} members, but there are currently {existingMembersCount} members. Please add another member!");
            }
            #endregion

            _tracingService.Trace("MembershipMembersValidation End");
        }

        public void MembershipCancellation(Entity membership)
        {
            _tracingService.Trace("MembershipCancellationDeceased Start");

            try
            {
                EntityReference cancellationReasonRef = membership.Contains(EntityNames.Membership.MembershipCancellationReasonId) ? (EntityReference)membership[EntityNames.Membership.MembershipCancellationReasonId] : null;

                string[] cancellationReasonsType1 = new string[] { "Deceased", "Lost contact" };
                string[] cancellationReasonsType2 = new string[] { "Garden Visit", "Shows Visit", "Protest" };
                string cancellationReasonName = string.Empty;
                if (cancellationReasonRef != null)
                {
                    cancellationReasonName = (string)_service.Retrieve(cancellationReasonRef.LogicalName, cancellationReasonRef.Id, new ColumnSet(true))["rhs_name"];
                }
                _tracingService.Trace($"Cancellation Reason: {cancellationReasonName}");

                Guid transactionalPurposeId = GetPurposeIdByName("Transactional");
                Guid commercialPurposeId = GetPurposeIdByName("Commercial");

                //Check for Members in the Contact
                EntityCollection members = null;
                EntityCollection associatedConsentsOfTransactional = null;
                EntityCollection associatedConsentsOfCommercial = null;

                if (cancellationReasonsType1.Contains(cancellationReasonName))
                {
                    members = GetDeceasedMembersByMembershipId(membership.Id.ToString());

                    if (members.Entities.Any())
                    {
                        foreach (Entity member in members.Entities)
                        {
                            associatedConsentsOfTransactional = CheckConsentsAssociatedByMemberId(member.Id.ToString(), transactionalPurposeId.ToString());
                            associatedConsentsOfCommercial = CheckConsentsAssociatedByMemberId(member.Id.ToString(), commercialPurposeId.ToString());

                            if (associatedConsentsOfTransactional.Entities.Any())
                            {
                                UpdateContactPointConsentsByPurpose(associatedConsentsOfTransactional, member.Id);
                            }
                            else if (associatedConsentsOfCommercial.Entities.Any())
                            {
                                UpdateContactPointConsentsByPurpose(associatedConsentsOfCommercial, member.Id);
                            }
                            else
                            {
                                _tracingService.Trace("Skipping UpdateContactPointConsentsByPurpose since no records found.");
                            }
                        }
                        _tracingService.Trace("MembershipCancellationDeceased End");
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException("No deceased members found for the membership.");
                    }
                }
                else if (cancellationReasonsType2.Contains(cancellationReasonName))
                {
                    members = GetMembersByMembershipId(membership.Id.ToString());

                    foreach (Entity member in members.Entities)
                    {
                        associatedConsentsOfCommercial = CheckConsentsAssociatedByMemberId(member.Id.ToString(), commercialPurposeId.ToString());

                        if (associatedConsentsOfCommercial.Entities.Any())
                        {
                            foreach (Entity contactPointConsent in associatedConsentsOfCommercial.Entities)
                            {
                                OptionSetValue existingConsentStatus = (OptionSetValue)contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value];
                                _tracingService.Trace($"Consent Status: {existingConsentStatus.Value}");

                                //Update Consent Status to Opt-Out = 534120002
                                if (existingConsentStatus.Value != 534120002)
                                {
                                    Entity consentToBeAmended = new Entity(contactPointConsent.LogicalName, contactPointConsent.Id);
                                    consentToBeAmended[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value] = new OptionSetValue(534120002);
                                    _service.Update(consentToBeAmended);

                                    _tracingService.Trace($"Updated Consent ID: {consentToBeAmended.Id}");
                                }
                                else
                                {
                                    _tracingService.Trace($"Existing Consent Value is Opt-Out");
                                }
                            }
                        }
                        else
                        {
                            _tracingService.Trace("Skipping UpdateContactPointConsentsByPurpose since no records found.");
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private Guid GetPurposeIdByName(string purposeName)
        {
            Guid purposeId = Guid.Empty;
            QueryExpression queryPurpose = new QueryExpression(EntityNames.Msdynmkt_purpose.EntityLogicalName);
            queryPurpose.ColumnSet.AddColumns(
                EntityNames.Msdynmkt_purpose.PrimaryIdAttribute,
                EntityNames.Msdynmkt_purpose.PrimaryNameAttribute
            );

            queryPurpose.Criteria.AddCondition(EntityNames.Msdynmkt_purpose.PrimaryNameAttribute, ConditionOperator.Equal, purposeName);

            EntityCollection purposes = _service.RetrieveMultiple(queryPurpose);

            if (purposes != null && purposes.Entities.Any())
            {
                Entity purpose = purposes.Entities.First();
                purposeId = purpose.Id;
            }

            return purposeId;
        }

        private EntityCollection GetDeceasedMembersByMembershipId(string membershipId)
        {
            QueryExpression queryDeceasedMembers = new QueryExpression(EntityNames.Contact.EntityLogicalName);
            queryDeceasedMembers.ColumnSet.AddColumns(
                EntityNames.Contact.PrimaryIdAttribute,
                EntityNames.Contact.PrimaryNameAttribute,
                EntityNames.Contact.Deceased
            );

            // Add conditions to query.Criteria
            queryDeceasedMembers.Criteria.AddCondition(EntityNames.Contact.Deceased, ConditionOperator.Equal, true);

            var aa = queryDeceasedMembers.AddLink(
                EntityNames.Membership_contact_mm.EntityLogicalName,
                EntityNames.Contact.PrimaryIdAttribute,
                EntityNames.Membership_contact_mm.Contactid
            );
            aa.EntityAlias = "aa";

            var ab = aa.AddLink(
                EntityNames.Membership.EntityLogicalName,
                EntityNames.Membership_contact_mm.Membershipid,
                EntityNames.Membership.PrimaryIdAttribute
            );
            ab.EntityAlias = "ab";
            ab.Columns.AddColumn(EntityNames.Membership.PrimaryIdAttribute);
            ab.LinkCriteria.AddCondition(EntityNames.Membership.PrimaryIdAttribute, ConditionOperator.Equal, membershipId);

            EntityCollection records = _service.RetrieveMultiple(queryDeceasedMembers);

            return records;
        }

        private EntityCollection GetMembersByMembershipId(string membershipId)
        {
            QueryExpression queryMembers = new QueryExpression(EntityNames.Contact.EntityLogicalName);
            queryMembers.ColumnSet.AddColumns(
                EntityNames.Contact.PrimaryIdAttribute,
                EntityNames.Contact.PrimaryNameAttribute,
                EntityNames.Contact.Deceased
            );

            // Add conditions to query.Criteria
            //queryMembers.Criteria.AddCondition(EntityNames.Contact.Deceased, ConditionOperator.Equal, true);

            var aa = queryMembers.AddLink(
                EntityNames.Membership_contact_mm.EntityLogicalName,
                EntityNames.Contact.PrimaryIdAttribute,
                EntityNames.Membership_contact_mm.Contactid
            );
            aa.EntityAlias = "aa";

            var ab = aa.AddLink(
                EntityNames.Membership.EntityLogicalName,
                EntityNames.Membership_contact_mm.Membershipid,
                EntityNames.Membership.PrimaryIdAttribute
            );
            ab.EntityAlias = "ab";
            ab.Columns.AddColumn(EntityNames.Membership.PrimaryIdAttribute);
            ab.LinkCriteria.AddCondition(EntityNames.Membership.PrimaryIdAttribute, ConditionOperator.Equal, membershipId);

            EntityCollection records = _service.RetrieveMultiple(queryMembers);

            return records;
        }

        private EntityCollection CheckConsentsAssociatedByMemberId(string memberId, string purposeId)
        {
            QueryExpression queryAssociatedConsentsToMember = new QueryExpression(EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName);
            queryAssociatedConsentsToMember.ColumnSet.AddColumns(
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryNameAttribute,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_topicId,
                EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value,
                EntityNames.Msdynmkt_contactpointconsent4.Statecode,
                EntityNames.Msdynmkt_contactpointconsent4.Dataset

            );

            queryAssociatedConsentsToMember.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Statecode, ConditionOperator.Equal, 0);
            queryAssociatedConsentsToMember.Criteria.AddCondition(EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_purposeId, ConditionOperator.Equal, purposeId);

            var ad = queryAssociatedConsentsToMember.AddLink(
                EntityNames.Contact_msdynmkt_contactpointconsent4.EntityLogicalName,
                EntityNames.Msdynmkt_contactpointconsent4.PrimaryIdAttribute,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsent4id
            );
            ad.EntityAlias = "ad";

            var ae = ad.AddLink(
                EntityNames.Contact.EntityLogicalName,
                EntityNames.Contact_msdynmkt_contactpointconsent4.Contactid,
                EntityNames.Contact.PrimaryIdAttribute
            );
            ae.EntityAlias = "ae";

            ae.Columns.AddColumn(EntityNames.Contact.PrimaryIdAttribute);
            ae.LinkCriteria.AddCondition(EntityNames.Contact.PrimaryIdAttribute, ConditionOperator.Equal, memberId);

            var result = _service.RetrieveMultiple(queryAssociatedConsentsToMember);

            return result;
        }

        private bool CheckConsentHasRelatedContacts(string contactId, string consentId)
        {
            QueryExpression queryAssociatedContactsToConsents = new QueryExpression(EntityNames.Contact.EntityLogicalName);
            queryAssociatedContactsToConsents.ColumnSet.AddColumns(
                EntityNames.Contact.PrimaryIdAttribute,
                EntityNames.Contact.PrimaryNameAttribute
            );

            queryAssociatedContactsToConsents.Criteria.AddCondition(EntityNames.Contact.PrimaryIdAttribute, ConditionOperator.NotEqual, contactId);

            var ag = queryAssociatedContactsToConsents.AddLink(
                EntityNames.Contact_msdynmkt_contactpointconsent4.EntityLogicalName,
                EntityNames.Contact.PrimaryIdAttribute, EntityNames.Contact_msdynmkt_contactpointconsent4.Contactid
            );
            ag.EntityAlias = "ag";

            ag.LinkCriteria.AddCondition(EntityNames.Contact_msdynmkt_contactpointconsent4.Msdynmkt_contactpointconsent4id, ConditionOperator.Equal, consentId);

            var result = _service.RetrieveMultiple(queryAssociatedContactsToConsents);

            // If any records are returned, consent has associated contact/s 
            bool hasAssociatedContacts = result.Entities.Any();

            _tracingService.Trace($"Is Contact associated with Consents: {hasAssociatedContacts}");

            return hasAssociatedContacts;
        }

        private void UpdateContactPointConsentsByPurpose(EntityCollection associatedConsents, Guid memberId)
        {
            bool hasAssociatedContacts = false;

            foreach (Entity contactPointConsent in associatedConsents.Entities)
            {
                OptionSetValue existingConsentStatus = (OptionSetValue)contactPointConsent[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value];
                _tracingService.Trace($"Consent Status: {existingConsentStatus.Value}");

                hasAssociatedContacts = CheckConsentHasRelatedContacts(memberId.ToString(), contactPointConsent.Id.ToString());

                if (hasAssociatedContacts)
                {
                    //Remove relationship to consents
                    DisassociateContactToConsent(contactPointConsent.Id, memberId);
                }
                else
                {
                    //Update Consent Status to Opt-Out = 534120002
                    if (existingConsentStatus.Value != 534120002)
                    {
                        Entity consentToBeAmended = new Entity(contactPointConsent.LogicalName, contactPointConsent.Id);
                        consentToBeAmended[EntityNames.Msdynmkt_contactpointconsent4.Msdynmkt_value] = new OptionSetValue(534120002);
                        _service.Update(consentToBeAmended);

                        _tracingService.Trace($"Updated Consent ID: {consentToBeAmended.Id}");
                    }
                    else
                    {
                        _tracingService.Trace($"Existing Consent Value is Opt-Out");
                    }
                }
            }
        }

        private void DisassociateContactToConsent(Guid contactPointConsentId, Guid contactId)
        {
            if (contactPointConsentId == Guid.Empty || contactId == Guid.Empty)
            {
                _tracingService.Trace("Contact Point Consent ID or Contact ID is empty. Skipping association.");
                return;
            }

            _service.Disassociate(
                EntityNames.Msdynmkt_contactpointconsent4.EntityLogicalName,
                contactPointConsentId,
                new Relationship("rhs_contact_msdynmkt_contactpointconsent4_MM"),
                new EntityReferenceCollection
                {
                       new EntityReference(EntityNames.Contact.EntityLogicalName, contactId)
                }
            );

            _tracingService.Trace("Contact disassociated with Contact Point Consent successfully.");
        }

        public void CancelDeceasedMembership(Membership target, ITracingService tracingService, IOrganizationService service)
        {

            var cancellationReason = GetCancellationReason(service, "Deceased");

            if (cancellationReason != null)
            {

                tracingService.Trace($"Start Student Cancellation: Cancellation Reason ID: {cancellationReason.Id} ,  Cancellation Reason Name: {cancellationReason["rhs_name"]}");

                var membership = target; //

                membership[EntityNames.Membership.CancelMembership] = true;
                membership[EntityNames.Membership.CancellationType] = new OptionSetValue(120000000);
                membership[EntityNames.Membership.MembershipCancellationReasonId] = new EntityReference("rhs_cancellationreason", cancellationReason.Id); ;
                membership[EntityNames.Membership.CancellationDate] = DateTime.UtcNow;
                membership[EntityNames.Membership.Enddate] = DateTime.UtcNow;

                service.Update(membership); // Save changes

                var setStateRequest = new SetStateRequest
                {
                    EntityMoniker = new EntityReference(EntityNames.Membership.EntityLogicalName, membership.Id),
                    State = new OptionSetValue(1), // 1 for inactive
                    Status = new OptionSetValue(2) // 
                };

                service.Execute(setStateRequest);
            }
        }

        public Entity GetCancellationReason(IOrganizationService service, string name)
        {
            var cancellationQuery = new QueryExpression("rhs_cancellationreason")
            {
                ColumnSet = new ColumnSet("rhs_cancellationreasonid", "rhs_name"),
                Criteria = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                        new ConditionExpression("rhs_name", ConditionOperator.Equal, name),
                    }
                }
            };

            var cancellationReasonCollection = service.RetrieveMultiple(cancellationQuery);
            return cancellationReasonCollection.Entities.Count > 0 ? cancellationReasonCollection.Entities[0] : null;
        }

        public bool ValidateIfDDMembershipWasCancelled(Membership membership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isPaymentMethodDD = membership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit;
            _tracingService.Trace($"Is payment method DD? {isPaymentMethodDD}");

            var isMembershipCancelled = membership.Statecode == MembershipState.Inactive && membership.Statuscode == MembershipStatus.Inactive_Cancelled/* && membership.CancellationType == Membershipcancellationtypecode_GlobalOptionSet.Now*/;
            _tracingService.Trace($"Is membership cancelled? {isMembershipCancelled}");

            _tracingService.Trace($"Ending business logic.");
            return isMembershipCancelled && isPaymentMethodDD;
        }

        public bool ValidateIfPayerWasChangedForDDMembership(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isPaymentMethodDD = postImageMembership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit;
            _tracingService.Trace($"Is payment method DD? {isPaymentMethodDD}");

            var isMembershipPayerChanged = preImageMembership.PayerV2 != null && postImageMembership.PayerV2 != null && preImageMembership.PayerV2.Id != postImageMembership.PayerV2.Id;
            _tracingService.Trace($"Is membership payer changed? {isMembershipPayerChanged}");

            _tracingService.Trace($"Ending business logic.");
            return isMembershipPayerChanged && isPaymentMethodDD;
        }

        public bool ValidateIfPaymentMethodWasChangedFromDD(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isOldPaymentMethodDD = preImageMembership.PaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit;
            _tracingService.Trace($"Is old payment method DD? {isOldPaymentMethodDD}");

            var isNewPaymentMethodNotDD = postImageMembership.PaymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit;
            _tracingService.Trace($"Is new payment method not DD? {isNewPaymentMethodNotDD}");

            var isNotInRenewalStage = postImageMembership.InRenewalsStage != true;
            _tracingService.Trace($"Is not in renewal stage? {isNotInRenewalStage}");

            var isActive = postImageMembership.Statuscode == MembershipStatus.Active_Active;
            _tracingService.Trace($"Is status active? {isActive}");

            _tracingService.Trace($"Ending business logic.");
            return isOldPaymentMethodDD && isNewPaymentMethodNotDD && isNotInRenewalStage && isActive;
        }

        public Entity MakeMembershipPayableWhenOutstandingAmountGreaterThanZero(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            _tracingService.Trace($"Validating if outstanding amount > 0.");
            if (membership.OutstandingAmount != null && membership.OutstandingAmount.Value > 0)
            {
                _tracingService.Trace($"Outstanding amount of {membership.OutstandingAmount.Value} > 0.");

                _tracingService.Trace($"Making membership payable.");
                if (membership.IsSubmitPayment != false)
                {
                    membership.IsSubmitPayment = false;
                    entity[EntityNames.Membership.IsSubmitPayment] = membership.IsSubmitPayment;
                }
                if (membership.PaymentReceived != false)
                {
                    membership.PaymentReceived = false;
                    entity[EntityNames.Membership.PaymentReceived] = membership.PaymentReceived;
                }
                if (membership.Statecode != MembershipState.Active)
                {
                    membership.Statecode = MembershipState.Active;
                    entity[EntityNames.Membership.Statecode] = new OptionSetValue((int)membership.Statecode);
                }
                if (membership.Statuscode != MembershipStatus.Active_PendingPayment)
                {
                    membership.Statuscode = MembershipStatus.Active_PendingPayment;
                    entity[EntityNames.Membership.Statuscode] = new OptionSetValue((int)membership.Statuscode);
                }
            }
            else
            {
                _tracingService.Trace($"Outstanding amount <= 0.");
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public bool ValidateIfPaymentSubmissionWasTriggered(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isSubmitPayment = preImageMembership.IsSubmitPayment != true && postImageMembership.IsSubmitPayment == true;
            _tracingService.Trace($"Is submit payment changed to true? {isSubmitPayment}");

            _tracingService.Trace($"Ending business logic.");
            return isSubmitPayment;
        }

        public bool ValidateIfActivatedWithoutStartDate(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isChangedToActiveWithoutStartDate = preImageMembership.Statuscode != MembershipStatus.Active_Active && postImageMembership.Statuscode == MembershipStatus.Active_Active
                && postImageMembership.Startdate == null;
            _tracingService.Trace($"Is status reason changed to active without start date? {isChangedToActiveWithoutStartDate}");

            _tracingService.Trace($"Ending business logic.");
            return isChangedToActiveWithoutStartDate;
        }

        public bool ValidateIfMembershipWasActivated(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting business logic.");

            var isMembershipActivated = preImageMembership.Statuscode != MembershipStatus.Active_Active && postImageMembership.Statuscode == MembershipStatus.Active_Active;
            _tracingService.Trace($"Is membership status reason changed to active? {isMembershipActivated}");

            _tracingService.Trace($"Ending business logic.");
            return isMembershipActivated;
        }

        public bool ValidateIfCampaignAmountShouldBeRepopulated(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            var isCampaignChanged = preImageMembership.CampaignId != postImageMembership.CampaignId;
            _tracingService.Trace($"Campaign changed? {isCampaignChanged}.");
            var isProductChanged = preImageMembership.MembershipProductId != postImageMembership.MembershipProductId;
            _tracingService.Trace($"Product changed? {isProductChanged}.");

            var shouldCampaignAmountGetRepopulated = isCampaignChanged || isProductChanged;
            _tracingService.Trace($"Should campaign amount get repopulated? {shouldCampaignAmountGetRepopulated}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return shouldCampaignAmountGetRepopulated;
        }

        public bool ValidateIfTotalAmountShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            var isPaymentMethodNotGiftPack = postImageMembership.PaymentMethod != PaymentMethodType_GlobalOptionSet.GiftPack;
            _tracingService.Trace($"Payment method not gift pack? {isPaymentMethodNotGiftPack}.");

            //var doesOutstandingAmountNotExist = postImageMembership.OutstandingAmount == null;
            //_tracingService.Trace($"Does outstanding amount not exist yet? {doesOutstandingAmountNotExist}.");

            var isCampaignChanged = preImageMembership.CampaignId?.Id != postImageMembership.CampaignId?.Id;
            _tracingService.Trace($"Campaign changed? {isCampaignChanged}.");

            var isProductChanged = preImageMembership.MembershipProductId?.Id != postImageMembership.MembershipProductId?.Id;
            _tracingService.Trace($"Product changed? {isProductChanged}.");

            var isPaymentMethodChanged = preImageMembership.PaymentMethod != postImageMembership.PaymentMethod;
            _tracingService.Trace($"Payment method changed? {isPaymentMethodChanged}.");

            var isPaymentFrequenctChanged = preImageMembership.PaymentFrequency != postImageMembership.PaymentFrequency;
            _tracingService.Trace($"Payment frequency changed? {isPaymentFrequenctChanged}.");

            var shouldTotalAmountBeRecalculated = isPaymentMethodNotGiftPack && /*doesOutstandingAmountNotExist &&*/ (isCampaignChanged || isProductChanged || isPaymentMethodChanged || isPaymentFrequenctChanged);
            _tracingService.Trace($"Should total amount be recalculated? {shouldTotalAmountBeRecalculated}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return shouldTotalAmountBeRecalculated;
        }

        public bool ValidateIfEndDateRequiresRecalculation(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //var paymentMethodNotGiftPack = postImageMembership.PaymentMethod != PaymentMethodType_GlobalOptionSet.GiftPack;
            //_tracingService.Trace($"Payment method not gift pack? {paymentMethodNotGiftPack}");

            var startDateExists = postImageMembership.Startdate != null;
            _tracingService.Trace($"Start date exists? {startDateExists}");

            var productChanged = preImageMembership.MembershipProductId != postImageMembership.MembershipProductId;
            _tracingService.Trace($"Product changed? {productChanged}");

            var campaignChanged = preImageMembership.CampaignId != postImageMembership.CampaignId;
            _tracingService.Trace($"Campaign changed? {campaignChanged}");

            var submitPaymentChanged = preImageMembership.IsSubmitPayment != postImageMembership.IsSubmitPayment && postImageMembership.IsSubmitPayment == true;
            _tracingService.Trace($"Submit payment changed? {submitPaymentChanged}");

            var isendDateRecalculationNeeded = /*paymentMethodNotGiftPack &&*/ startDateExists && (productChanged || campaignChanged || submitPaymentChanged);
            _tracingService.Trace($"Is end date recalculation needed? {submitPaymentChanged}");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return isendDateRecalculationNeeded;
        }
        public Entity SetStartDateOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.Startdate == null)
            {
                _tracingService.Trace($"Start date does not exist yet.");

                membership.Startdate = _recordDateCalculationService.CalculateStartDateOfRecord(membership.MembershipProductId);
                entity[EntityNames.Membership.Startdate] = membership.Startdate;

                _tracingService.Trace($"Set membership start date to {membership.Startdate}.");
            }
            else
            {
                _tracingService.Trace($"Start date already exists.");
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetEndDateOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.Enddate != null && membership.PatronMembership == true)
            {
                _tracingService.Trace($"End date is not blank and Patron Membership.");

            }
            else
            {
                membership.Enddate = _recordDateCalculationService.CalculateEndDateOfRecord(membership.Startdate, membership.MembershipProductId.Id, membership.CampaignId?.Id);

                entity[EntityNames.Membership.Enddate] = membership.Enddate;
                _tracingService.Trace($"Membership end date = {membership.Enddate}.");
            }
            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetRenewalsStartDateOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            string productName = membership.MembershipProductId?.Name;

            if (membership.MembershipProductId != null && string.IsNullOrEmpty(productName))
            {
                _tracingService.Trace("Product name missing from lookup. Fetching from database...");
                var prod = _service.Retrieve("product", membership.MembershipProductId.Id, new ColumnSet("name"));
                productName = prod.GetAttributeValue<string>("name");
            }

            if (!string.IsNullOrEmpty(productName) && productName.IndexOf("Life", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                string originalValue = membership.RenewalsStartDate.HasValue
                    ? membership.RenewalsStartDate.Value.ToShortDateString()
                    : "already null";

                _tracingService.Trace($"Life product detected ('{productName}'). Original Renewals Start Date: {originalValue}. Clearing value.");

                entity[EntityNames.Membership.RenewalsStartDate] = null;
            }
            else if (membership.RenewalsStartDate != null)
            {
                _tracingService.Trace($"Renewals Start date is not blank.");
            }
            else
            {
                if (membership.Enddate != null)
                {
                    membership.RenewalsStartDate = _recordDateCalculationService.CalculateRenewalStartDateOfRecord(membership.Enddate);
                    entity[EntityNames.Membership.RenewalsStartDate] = membership.RenewalsStartDate;

                    _tracingService.Trace($"Set membership renewals start date to {membership.RenewalsStartDate}.");
                }
                else
                {
                    _tracingService.Trace($"Cannot calculate renewals start date because end date does not exist.");
                }
            }


            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetRenewalsEndDateOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            string productName = membership.MembershipProductId?.Name;

            if (membership.MembershipProductId != null && string.IsNullOrEmpty(productName))
            {
                _tracingService.Trace("Product name missing from lookup. Fetching from database...");
                var prod = _service.Retrieve("product", membership.MembershipProductId.Id, new ColumnSet("name"));
                productName = prod.GetAttributeValue<string>("name");
            }

            if (!string.IsNullOrEmpty(productName) && productName.IndexOf("Life", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                string originalValue = membership.RenewalsEndDate.HasValue
                    ? membership.RenewalsEndDate.Value.ToShortDateString()
                    : "already null";

                _tracingService.Trace($"Life product detected ('{productName}'). Original Renewals End Date: {originalValue}. Clearing value.");

                entity[EntityNames.Membership.RenewalsEndDate] = null;
            }
            else if (membership.RenewalsEndDate != null)
            {
                _tracingService.Trace($"Renewals End date is not blank.");
            }
            else
            {
                if (membership.Enddate != null)
                {
                    membership.RenewalsEndDate = _recordDateCalculationService.CalculateRenewalEndDateOfRecord(membership.Enddate);

                    entity[EntityNames.Membership.RenewalsEndDate] = membership.RenewalsEndDate;
                    _tracingService.Trace($"Membership renewals end date = {membership.RenewalsEndDate}.");
                }
                else
                {
                    _tracingService.Trace($"Cannot calculate renewals end date because end date does not exist.");
                }
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public Entity SetOutstandingAmounteOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            _tracingService.Trace($"Calculating outstanding amount.");
            if (membership.IsMigrated != true)
            {
                var query = new QueryExpression(EntityNames.Payment.EntityLogicalName);
                query.ColumnSet.AddColumn(EntityNames.Payment.Amount);
                query.Criteria.AddCondition(EntityNames.Payment.Statuscode, ConditionOperator.Equal, (2));
                query.Criteria.AddCondition(EntityNames.Payment.Refund, ConditionOperator.Equal, false);
                query.Criteria.AddCondition(EntityNames.Payment.Amount, ConditionOperator.NotNull);
                var query_rhs_transaction = query.AddLink(EntityNames.Transaction.EntityLogicalName, EntityNames.Payment.Transaction, EntityNames.Transaction.TransactionId);
                var query_rhs_transaction_rhs_membership = query_rhs_transaction.AddLink(EntityNames.Membership.EntityLogicalName, EntityNames.Transaction.MembershipId, EntityNames.Membership.MembershipId);
                query_rhs_transaction_rhs_membership.LinkCriteria.AddCondition(EntityNames.Membership.MembershipId, ConditionOperator.Equal, membership.Id);

                var paidPayments = _service.RetrieveMultiple(query).Entities;
                var totalAmount = new Money(membership.TotalAmount.Value);
                var outstandingAmount = new Money(totalAmount.Value - paidPayments.ToList().Select(payment => payment.ToEntity<Payment>().Amount.Value).ToList().Sum());

                _tracingService.Trace($"Setting outstanding amount on membership.");
                membership.OutstandingAmount = outstandingAmount;
            }
            else
            {
                membership.OutstandingAmount = new Money(0);
            }
            entity[EntityNames.Membership.OutstandingAmount] = membership.OutstandingAmount;

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        public void UpdateJointMembershipFromDeceased(Membership membership, Entity memberA, Entity memberB, Entity Payer)
        {
            bool memberAisDeceased = memberA.Contains("rhs_deceased") && memberA["rhs_deceased"] != null && (bool)memberA["rhs_deceased"];
            bool memberBisDeceased = memberB.Contains("rhs_deceased") && memberB["rhs_deceased"] != null && (bool)memberB["rhs_deceased"];
            bool payerIsDeceased = Payer.Contains("rhs_deceased") && Payer["rhs_deceased"] != null && (bool)Payer["rhs_deceased"];

            bool ispayerDifferentPerson = false;

            if (memberA.Id != Payer.Id && memberB.Id != Payer.Id)
            {
                ispayerDifferentPerson = true;
            }

            var updateRecord = membership;

            if (!ispayerDifferentPerson)
            {
                CancelDeceasedMembership(membership, _tracingService, _service);
            }
            else
            {
                if (payerIsDeceased)
                {

                    membership[EntityNames.Membership.PayerV2] = new EntityReference("contact", memberA.Id);
                    updateRecord[EntityNames.Membership.IsMembershipForSomeone] = false;
                    if (membership.Contains(EntityNames.Membership.PaymentMethod) &&
                        (membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                        membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                        membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                        membership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                        membership.IsContinuousPayment.Value == true && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly)
                    {

                        updateRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(120000003);
                    }


                }
                else
                {
                    CancelDeceasedMembership(membership, _tracingService, _service);
                }

            }

            try
            {
                _service.Update(updateRecord);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Failed to update a new  membership record: " + ex.Message);
                _tracingService.Trace($"Stack Trace: {ex.StackTrace}");
                throw new InvalidPluginExecutionException("Failed to update membership record.", ex);
            }
        }

        public void UpdateIndividualMembershipFromDeceased(Membership membership, Entity memberA, Entity Payer)
        {
            bool memberAisDeceased = memberA.Contains("rhs_deceased") && memberA["rhs_deceased"] != null && (bool)memberA["rhs_deceased"];
            bool payerIsDeceased = Payer.Contains("rhs_deceased") && Payer["rhs_deceased"] != null && (bool)Payer["rhs_deceased"];

            _tracingService.Trace($"productid:{membership.MembershipProductId.Id}");
            _tracingService.Trace($"memberA:{memberA.Id}");
            _tracingService.Trace($"memberA:{Payer.Id}");

            var updateRecord = membership;
            bool isindividualpayerDifferentPerson = false;

            if (memberA.Id != Payer.Id)
            {
                isindividualpayerDifferentPerson = true;
            }

            _tracingService.Trace($"ispayerDifferentPerson:{isindividualpayerDifferentPerson}");

            if (memberAisDeceased)
            {
                CancelDeceasedMembership(membership, _tracingService, _service);

            }

            if (payerIsDeceased && isindividualpayerDifferentPerson)
            {
                updateRecord[EntityNames.Membership.IsMembershipForSomeone] = false;
                updateRecord[EntityNames.Membership.PayerV2] = new EntityReference("contact", memberA.Id);

                if (membership.Contains(EntityNames.Membership.PaymentMethod) &&
                    (membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit ||
                    membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.Card ||
                    membership.PaymentMethod.Value == PaymentMethodType_GlobalOptionSet.CreditCard_Phone) &&
                    membership.Contains(EntityNames.Membership.IsContinuousPayment) &&
                    membership.IsContinuousPayment.Value == true && membership.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly
                    )
                {
                    updateRecord[EntityNames.Membership.Statuscode] = new OptionSetValue(120000003);
                }
            }

            try
            {
                _service.Update(updateRecord);
            }
            catch (Exception ex)
            {
                _tracingService.Trace("Failed to update individual membership record: " + ex.Message);
                _tracingService.Trace($"Stack Trace: {ex.StackTrace}");
                throw new InvalidPluginExecutionException("Failed to update membership record.", ex);
            }
        }

        public bool ValidateIfRenewalsTotalAmountShouldBeRecalculated(Entity entity)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var isRenewalProductChanged = entity.Contains(EntityNames.Membership.RenewalsMembershipProduct);
            _tracingService.Trace($"Is renewal poduct changed? {isRenewalProductChanged}");

            var isRenewalCampaignChanged = entity.Contains(EntityNames.Membership.RenewalsCampaign);
            _tracingService.Trace($"Is renewal campaign changed? {isRenewalCampaignChanged}");

            var isRenewalPaymentMethodChanged = entity.Contains(EntityNames.Membership.RenewalsPaymentMethod);
            _tracingService.Trace($"Is renewal payment method changed? {isRenewalCampaignChanged}");

            var isRenewalPaymentFrequencyChanged = entity.Contains(EntityNames.Membership.RenewalPaymentFrequency);
            _tracingService.Trace($"Is renewal payment frequency changed? {isRenewalCampaignChanged}");

            var shouldRenewalsTotalAmountGetRecalculated = isRenewalProductChanged || isRenewalCampaignChanged || isRenewalPaymentMethodChanged || isRenewalPaymentFrequencyChanged;
            _tracingService.Trace($"Has renewals campaign changed which requires the reneweals total amount to be recalculated? {shouldRenewalsTotalAmountGetRecalculated}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return shouldRenewalsTotalAmountGetRecalculated;
        }

        public Entity SetRenewalTotalAmountOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            _tracingService.Trace($"Setting renewals total amount to the renewals membership price.");
            var renewalsTotalAmount = new Money(membership.RenewalsMembershipPrice.Value);

            if (membership.RenewalGiftPackActivationCode != null)
            {
                _tracingService.Trace($"Renewal Gift Pack Activation Code exists. Setting total amount to the zero.");
                membership.TotalAmount = new Money(0);
                entity[EntityNames.Membership.TotalAmount] = new Money(0);
            }

            if (membership.RenewalsCampaign != null)
            {
                var renewalsCampaign = _campaignRepository.GetById(membership.RenewalsCampaign.Id);

                if (renewalsCampaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
                {
                    _tracingService.Trace($"Price based renewals campaign exists. Setting total amount to the renewals campaign product price.");
                    renewalsTotalAmount = GetRenewalsDiscountedPrice(membership);
                }
            }

            // Addition Rule if 'BACS Response Action' = 'Cancel Instruction' and 'In Renewal Stage'=Yes for Membership
            // If DD Payer is in Renewal Period -  If 'In Renewal Stage'=Yes and 'Renewal Status'=Pending Renewal 
            var activeTransactionCount = _transactionRepository.GetAll().Where(transaction =>
                transaction.MembershipId != null && transaction.MembershipId.Id == membership.Id && transaction.Statecode == TransactionState.Active
            ).ToList().Count();
            if (membership.InRenewalsStage == true && membership.RenewalsStatus == RenewalsStatus_GlobalOptionSet.PendingRenewal &&
                activeTransactionCount == 0 && membership.OutstandingAmount != null && membership.OutstandingAmount.Value > 0)
            {
                _tracingService.Trace($"Outstanding amount still exists even if transaction has been cancelled. Adding outstanding amount to renewal total amount.");
                renewalsTotalAmount.Value += membership.OutstandingAmount.Value;
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            entity[EntityNames.Membership.RenewalsTotalAmount] = renewalsTotalAmount;
            return entity;
        }

        public Entity SetRenewalMembershipPriceOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            //if (membership.MembershipPrice == null)
            membership.RenewalsMembershipPrice = _productService.GetProductPrice(membership.RenewalsMembershipProduct.Id, membership.RenewalsPriceList.Id);
            entity[EntityNames.Membership.RenewalsMembershipPrice] = membership.RenewalsMembershipPrice;

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return entity;
        }

        private Money GetRenewalsDiscountedPrice(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            _tracingService.Trace($"Setting renewals discounted price to campaign price.");
            var renewalsCampaign = _campaignRepository.GetById(membership.RenewalsCampaign.Id);
            var renewalsCampaignAmount = _productService.GetCampaignProductPrice(membership.RenewalsMembershipProduct.Id, renewalsCampaign.Id);
            var renewalsDiscountedPrice = new Money(renewalsCampaignAmount.Value);
            _tracingService.Trace($"Set renewals discounted price to {renewalsDiscountedPrice.Value}.");

            if (renewalsCampaign.Paymentdiscountconfiguration != null)
            {
                var paymentDiscountConfiguration = _paymentDiscountConfigurationRepository.GetById(renewalsCampaign.Paymentdiscountconfiguration.Id);
                if (membership.RenewalsPaymentMethod == (PaymentMethodType_GlobalOptionSet?)paymentDiscountConfiguration.PaymentMethodCode &&
                    (membership.RenewalsPaymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit || membership.RenewalPaymentFrequency == PaymentFrequency_GlobalOptionSet.Annually))
                {
                    _tracingService.Trace($"Payment discount configuration detected and it's payment method matches the membership payment method. Further discounts will be done to the discounted price.");

                    var renewalsMembershipPrice = new Money(membership.RenewalsMembershipPrice.Value);

                    if (paymentDiscountConfiguration.DiscountPercentage != null)
                    {
                        _tracingService.Trace($"Discount percentage detected.");
                        _tracingService.Trace($"New Discounted Price = {renewalsDiscountedPrice.Value} - ({paymentDiscountConfiguration.DiscountPercentage}% of {renewalsMembershipPrice.Value}).");
                        renewalsDiscountedPrice.Value -= ((decimal)paymentDiscountConfiguration.DiscountPercentage / 100) * renewalsMembershipPrice.Value;
                        _tracingService.Trace($"New Discounted Price = {renewalsDiscountedPrice.Value}.");
                    }
                    if (paymentDiscountConfiguration.DiscountAmount != null)
                    {
                        _tracingService.Trace($"Discount amount detected.");
                        _tracingService.Trace($"New Discounted Price = {renewalsDiscountedPrice.Value} - {paymentDiscountConfiguration.DiscountAmount.Value}.");
                        renewalsDiscountedPrice.Value -= paymentDiscountConfiguration.DiscountAmount.Value;
                    }
                }
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return renewalsDiscountedPrice;
        }

        public bool ValidateIfRenewalsPayoutDateShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var shouldRenewalsPayoutDateBeRecalculated =
                postImageMembership.Enddate != null &&
                preImageMembership.RenewalsPaymentMethod != postImageMembership.RenewalsPaymentMethod &&
                postImageMembership.RenewalsPaymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit;
            _tracingService.Trace($"Should renewals payout date be recalculated? {shouldRenewalsPayoutDateBeRecalculated}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return shouldRenewalsPayoutDateBeRecalculated;
        }

        public Entity SetPayoutDate(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var payoutDate = _recordDateCalculationService.CalculatePayoutDate((DateTime)membership.Startdate);

            membership.PaymentSchedule = payoutDate;
            entity[EntityNames.Membership.PaymentSchedule] = membership.PaymentSchedule;
            return entity;
        }

        public Entity SetRenewalsPayoutDate(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");
            DateTime? renewalPayoutDate = _recordDateCalculationService.CalculatePayoutDate(((DateTime)membership.Enddate).AddDays(1));

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            membership.RenewalPaymentSchedule = renewalPayoutDate;
            entity[EntityNames.Membership.RenewalPaymentSchedule] = renewalPayoutDate;
            return entity;
        }

        private DateTime AddBusinessDays(DateTime dt, int nDays)
        {
            int weeks = nDays / 5;
            nDays %= 5;
            while (dt.DayOfWeek == DayOfWeek.Saturday || dt.DayOfWeek == DayOfWeek.Sunday)
                dt = dt.AddDays(1);

            while (nDays-- > 0)
            {
                dt = dt.AddDays(1);
                if (dt.DayOfWeek == DayOfWeek.Saturday)
                    dt = dt.AddDays(2);
            }
            return dt.AddDays(weeks * 7);
        }

        public void ValidateRenewalCampaignInMembership(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.RenewalsCampaign != null)
            {
                _tracingService.Trace($"Renewal campaign selected for membership.");
                var renewalCampaign = _campaignRepository.GetById(membership.RenewalsCampaign.Id);

                _tracingService.Trace($"Validating if the renewal campaign is active.");
                if (renewalCampaign.StateCode != CampaignState.Active)
                    throw new InvalidPluginExecutionException("Please enter a valid Renewal Campaign Code!");

                _tracingService.Trace($"Validating if the renewal campaign is valid for selected renewal product.");
                var renewalCampaignProductIds = _campaignService.RetrieveCampaignProductIds(renewalCampaign.Id);
                if (membership.RenewalsMembershipProduct == null || !renewalCampaignProductIds.Any(id => id == membership.RenewalsMembershipProduct.Id))
                    throw new InvalidPluginExecutionException("Entered Renewal Campaign Code is not valid for selected Renewal Membership Product. Please select correct Renewal Campaign Code!");
            }
            else
                _tracingService.Trace($"No renewal campaign selected for membership.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public bool ValidateIfMembershipPackMHStatusShouldBeSetToPending(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var isActive = membership.Statuscode == MembershipStatus.Active_Active;
            _tracingService.Trace($"Is Active? {isActive}.");

            var isDeceased = membership.PayerV2?.LogicalName == EntityNames.Contact.EntityLogicalName && _contactRepository.GetById(membership.PayerV2.Id).Deceased == true;
            _tracingService.Trace($"Is Deceased? {isDeceased}.");

            var isContactGoneAway = membership.PayerV2?.LogicalName == EntityNames.Contact.EntityLogicalName && _suppressionService.DoesContactHaveGoneAwaySuppression(membership.PayerV2.Id);
            _tracingService.Trace($"Is Suppressed? {isContactGoneAway}.");

            var isUnderlyingMembershipForAPatron = membership.UnderlyingMembershipPatron == true;
            _tracingService.Trace($"Is Underlying Membership for Patron? {isUnderlyingMembershipForAPatron}.");

            var isRenewal = membership.IsRenewal == true;
            _tracingService.Trace($"Is Renewal? {isRenewal}.");

            var shouldMembershipPackMHStatusBeSetToPending = isActive && !isDeceased && !isContactGoneAway && !isUnderlyingMembershipForAPatron && !isRenewal;
            _tracingService.Trace($"Should Membership Pack MH Status be set to Pending? {shouldMembershipPackMHStatusBeSetToPending}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return shouldMembershipPackMHStatusBeSetToPending;
        }

        public Entity SetNewMembershipPackMHStatusOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");
            entity[EntityNames.Membership.NewMembershipPackMHStatus] = new OptionSetValue((int)MHStatus_GlobalOptionSet.Pending);

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public Entity SetMembershipCardDetails(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            //var membershipProduct = membership.GetAttributeValue<EntityReference>(EntityNames.Msnfp_membership.MembershipProductId);
            //var productPropertyValue = _propertyRetrievalService.GetDefaultOptionSetValueNameOfProductProperty(
            //    membershipProduct?.Id ?? Guid.Empty,
            //    "Mailing House Non-Annual Card"
            //);

            // Get member references
            var primaryMember = membership.GetAttributeValue<EntityReference>(EntityNames.Membership.Contact);
            var secondaryMember = membership.GetAttributeValue<EntityReference>(EntityNames.Membership.Member2);

            // Retrieve primary member name
            string primaryMemberName = (_service.Retrieve(Contact.EntityLogicalName, primaryMember.Id, new ColumnSet("fullname", "rhs_labelname2")) as Contact)?.LabelName2;

            // Retrieve secondary member name (if any)
            string secondaryMemberName = null;
            if (secondaryMember != null)
            {
                secondaryMemberName = (_service.Retrieve(Contact.EntityLogicalName, secondaryMember.Id, new ColumnSet("fullname", "rhs_labelname2")) as Contact)?.LabelName2;
            }
            else
            {
                _tracingService.Trace("No secondary member found.");
            }


            //if (productPropertyValue == "Yes")
            //{
            _tracingService.Trace($"Lifetime membership detected.");
            var startDate = entity.GetAttributeValue<DateTime?>(EntityNames.Membership.Startdate);
            startDate ??= membership.Startdate;
            var expiryDate = ((DateTime)startDate).AddYears(1).AddDays(-1);

            entity[EntityNames.Membership.CardExpiryDate] = expiryDate;
            entity[EntityNames.Membership.NamePrintedonCard] = primaryMemberName;


            if (secondaryMember != null)
            {
                entity[EntityNames.Membership.CardExpiryDateSecondaryMember] = expiryDate;
                entity[EntityNames.Membership.NamePrintedonCardSecondaryMember] = secondaryMemberName;
                }
            //}
            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public Entity SetPaymentMethodToCard(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            membership.PaymentMethod = PaymentMethodType_GlobalOptionSet.CreditCard_Phone;
            entity[EntityNames.Membership.PaymentMethod] = new OptionSetValue((int)PaymentMethodType_GlobalOptionSet.CreditCard_Phone);
            //membership.PaymentMethod = PaymentMethodType_GlobalOptionSet.Card;
            //entity[EntityNames.Membership.PaymentMethod] = new OptionSetValue((int)PaymentMethodType_GlobalOptionSet.Card);

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public bool ValidateIfDonationAmountShouldBeRecalculated(Membership preImageMembership, Membership postImageMembership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            var isDonationAdded = postImageMembership.CampaignDonation != null;
            _tracingService.Trace($"Is donation added? {isDonationAdded}.");

            var isTotalAmountChanged = preImageMembership.TotalAmount?.Value != postImageMembership.TotalAmount?.Value;
            _tracingService.Trace($"Is total amount changed? {isTotalAmountChanged}.");

            var shouldDonationAmountBeRecalculated = isDonationAdded && isTotalAmountChanged;
            _tracingService.Trace($"Should donation amount be recalculated? {shouldDonationAmountBeRecalculated}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return shouldDonationAmountBeRecalculated;
        }


        public void ValidatePatronTotalAmount(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var expectedTotalAmountValue = membership.CampaignAmount != null ?
                _membershipCreateService.GetDiscountedPrice(membership).Value :
                _membershipCreateService.GetMembershipPrice(membership).Value;
            _tracingService.Trace($"Expected total amount = {expectedTotalAmountValue}");

            var inputtedTotalAmountValue = membership.TotalAmount.Value;
            _tracingService.Trace($"Expected total amount = {inputtedTotalAmountValue}");

            if (inputtedTotalAmountValue < expectedTotalAmountValue)
                throw new InvalidPluginExecutionException($"The Total Amount can't be less than the expected amount to pay for the product which is £{Math.Round(expectedTotalAmountValue, 2)}.");

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
        }

        public Entity RevertTotalAmountIfMembershipContainsDonation(Entity entity, Membership postImageMembership, Money originalTotalAmount)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            if (postImageMembership.CampaignDonation != null)
            {
                _tracingService.Trace($"Membership contains donation, reverting total amount.");
                postImageMembership.TotalAmount = originalTotalAmount;
                entity[EntityNames.Membership.TotalAmount] = originalTotalAmount;
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public void PopulatePrimaryMembershipOfMembers(Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            if (membership.Contact != null)
            {
                _tracingService.Trace($"Populating primary membership of primary member");

                var primaryMemberUpdate = new Contact()
                {
                    Id = membership.Contact.Id,
                    PrimaryMembershipId = membership.ToEntityReference()
                };
                _contactRepository.Update(primaryMemberUpdate);

                _tracingService.Trace($"Populated primary membership of primary member");
            }

            if (membership.Member2 != null)
            {
                _tracingService.Trace($"Populating primary membership of secondary member");

                var secondaryMemberUpdate = new Contact()
                {
                    Id = membership.Member2.Id,
                    PrimaryMembershipId = membership.ToEntityReference()
                };
                _contactRepository.Update(secondaryMemberUpdate);

                _tracingService.Trace($"Populated primary membership of secondary member");
            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
        }

        public Entity SetDonationAmountOnMembershipEntity(Entity entity, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var expectedTotalAmountValue = membership.CampaignAmount != null ?
                _membershipCreateService.GetDiscountedPrice(membership).Value :
                _membershipCreateService.GetMembershipPrice(membership).Value;
            _tracingService.Trace($"Expected total amount = {expectedTotalAmountValue}");

            var inputtedTotalAmountValue = membership.TotalAmount.Value;
            _tracingService.Trace($"Expected total amount = {inputtedTotalAmountValue}");

            var donationAmountValue = inputtedTotalAmountValue - expectedTotalAmountValue;
            _tracingService.Trace($"Donation amount = {donationAmountValue}.");

            _tracingService.Trace($"Setting donation amount.");
            membership.DonationAmount = new Money(donationAmountValue);
            entity[EntityNames.Membership.DonationAmount] = membership.DonationAmount;

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");
            return entity;
        }

        public void ValidateIfMembershipRenewalPackMHStatusShouldBeSetToPending(Entity membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} business logic.");

            var inRenewalStage = membership.GetAttributeValue<bool?>(EntityNames.Membership.InRenewalsStage);
            var renewalPayer = membership.GetAttributeValue<EntityReference?>(EntityNames.Membership.RenewalsPayer);
            var membershipProduct = membership.GetAttributeValue<EntityReference?>(EntityNames.Membership.MembershipProductId);

            //Not in renewal stage
            if (inRenewalStage != true)
            {
                _tracingService.Trace($"Membership not in Renewal Stage.");
                return;
            }

            // Null check for payer
            if (renewalPayer == null)
            {
                _tracingService.Trace("Renewal Payer is null. Skipping processing.");
                return;
            }


            if (inRenewalStage == true)
            {
                var isDeceased = renewalPayer.LogicalName == EntityNames.Contact.EntityLogicalName && _contactRepository.GetById(renewalPayer.Id).Deceased == true;
                _tracingService.Trace($"Is Deceased? {isDeceased}.");

                var isEligible = false;

                var productPropertyValue = _propertyRetrievalService.GetDefaultOptionSetValueNameOfProductProperty(membershipProduct.Id, "Mailing House Renewal Letter");
                if (productPropertyValue == "Yes")
                {
                    isEligible = true; // Set to No if product is ineligible
                }
                if (!isDeceased && isEligible)
                {
                    var updateMembership = new Membership()
                    {
                        Id = membership.Id,
                        RenewalMembershipPackMHStatus = MHStatus_GlobalOptionSet.Pending
                    };

                    _service.Update(updateMembership);
                }

                _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} business logic.");

            }
        }
        public void SetCardIssueNumber(Membership membership)
        {
            var statusCode = membership.Statuscode;
            var issueNumber = membership.IssueNumber;
            var replacementCard = membership.ReplacementCard;
            var replacementCardRecipient = membership.ReplacementCardRecipient;
            var issueNumberSecondary = membership.IssueNumberSecondaryMember;
            var secondaryMember = membership.Member2;


            if (statusCode != MembershipStatus.Active_Active)
            {
                return;
            }
            //Check Membership status if active
            if (statusCode == MembershipStatus.Active_Active)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                //Check Issue Number
                if (issueNumber == null )
                {
                    _tracingService.Trace($"Updating Issue Number");
                    issueNumber = 1;

                    var updateIssueNumber = new Membership()
                    {
                        Id = membership.Id,
                        IssueNumber = issueNumber,
                    };

                    //Secondary Member Issue Number
                    if (secondaryMember != null)
                    {
                        issueNumberSecondary ??= "1";
                        updateIssueNumber.IssueNumberSecondaryMember = issueNumberSecondary;
                    }

                    _service.Update(updateIssueNumber);
                    _tracingService.Trace($"Updated Issue Number");
                }
                // Check Replacement Card
                if (replacementCard == true)
                {
                    _tracingService.Trace("Updating Replacement Card and Issue Number");

                    // Primary Member only
                    if (replacementCardRecipient == ReplacementCardRecipientType_GlobalOptionSet.PrimaryMember)
                    {
                        issueNumber += 1;
                    }

                    // Secondary Member only
                    else if (replacementCardRecipient == ReplacementCardRecipientType_GlobalOptionSet.SecondaryMember && secondaryMember != null)
                    {
                        int secondaryIssue = 0;
                        if (!string.IsNullOrEmpty(issueNumberSecondary))
                            secondaryIssue = int.Parse(issueNumberSecondary);
                        secondaryIssue += 1;
                        issueNumberSecondary = secondaryIssue.ToString();
                    }

                    // Both Members
                    else if (replacementCardRecipient == ReplacementCardRecipientType_GlobalOptionSet.Both && secondaryMember != null)
                    {
                        issueNumber += 1;

                        int secondaryIssue = 0;
                        if (!string.IsNullOrEmpty(issueNumberSecondary))
                            secondaryIssue = int.Parse(issueNumberSecondary);
                        secondaryIssue += 1;
                        issueNumberSecondary = secondaryIssue.ToString();
                    }

                    //replacementCard = false; // moved to Membership_OnCardReplacement_AllowRetrigger cloud flow

                    var updateIssueNumberReplacementCard = new Membership()
                    {
                        Id = membership.Id,
                        IssueNumber = issueNumber,
                        //ReplacementCard = replacementCard // moved to Membership_OnCardReplacement_AllowRetrigger cloud flow
                        IssueNumberSecondaryMember = issueNumberSecondary
                    };

                    _service.Update(updateIssueNumberReplacementCard);
                    _tracingService.Trace("Updated Replacement Card and Issue Number");
                }
                _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            }
        }

        public void RedeemGiftPack(Membership membership)
        {
            var paymentMethod = membership.PaymentMethod;
            var paymentReceived = membership.PaymentReceived;
            var contactRef = membership.Contact;
            var activationCode = membership.ActivationCode;

            if (paymentMethod != PaymentMethodType_GlobalOptionSet.GiftPack)
            {
                return;
            }


            if (paymentReceived == false)
            {
                return;
            }

            //Check Payment Method and Payment Received values
            if (paymentMethod == PaymentMethodType_GlobalOptionSet.GiftPack && paymentReceived == true)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                //Retrieve Gift Pack based on membership activation code
                string giftPackCode = activationCode;

                QueryExpression query = new QueryExpression(EntityNames.GiftPack.EntityLogicalName);
                query.Criteria.AddCondition(EntityNames.GiftPack.GiftPackCode, ConditionOperator.Equal, giftPackCode);

                EntityCollection giftPacks = _service.RetrieveMultiple(query);

                if (giftPacks.Entities.Count == 0)
                    return;

                Entity giftPack = giftPacks.Entities[0];

                _tracingService.Trace($"Updating Gift Pack");
                Entity updategiftPack = new Entity(EntityNames.GiftPack.EntityLogicalName, giftPack.Id);

                updategiftPack[EntityNames.GiftPack.RedeemedById] = contactRef;
                updategiftPack[EntityNames.GiftPack.RedeemOn] = DateTime.UtcNow;
                updategiftPack[EntityNames.GiftPack.Statecode] = new OptionSetValue((int)GiftPackState.Inactive);
                updategiftPack[EntityNames.GiftPack.Statuscode] = new OptionSetValue((int)GiftPackStatus.Inactive_Redeemed);

                _service.Update(updategiftPack);
                _tracingService.Trace($"Gift Pack updated.");

            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public void SetStatusOnMembershipEntity(Entity entity, Membership preImageMembership, Membership membership)
        {
            _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

            if (membership.PaymentReceived != true)
            {
                if (preImageMembership.Statuscode == MembershipStatus.Active_Active
                    && membership.Statuscode == MembershipStatus.Active_Prospect)
                {

                    if (membership.Statuscode != MembershipStatus.Active_PendingPayment)
                    {
                        membership.Statuscode = MembershipStatus.Active_PendingPayment;
                        entity[EntityNames.Membership.Statuscode] = new OptionSetValue((int)membership.Statuscode);
                        _tracingService.Trace($"Set membership status to {membership.Statuscode}.");
                    }
                }

            }

            _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
        }

        public void ValidateAddressInMembership(Entity entity, Membership preImageMembership)
        {
            _tracingService.Trace($"ValidateAddressInMembership Start");

            string productId = preImageMembership.MembershipProductId.Id.ToString();
            int numberOfAllowedMembers = GetNumberOfAllowedMembers(productId);

            EntityReference primaryContactRef = entity.Contains(EntityNames.Membership.Contact) ?
                (EntityReference)entity[EntityNames.Membership.Contact] : preImageMembership.Contains(EntityNames.Membership.Contact) ? preImageMembership.Contact : null;
            Entity primaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, primaryContactRef.Id, new ColumnSet(true));

            //Retrieve concatenated address for Primary Member
            string primaryMemberAddress = GetContactAddress(primaryContactRef.Id);

            EntityReference secondaryMemberRef = null;
            Entity secondaryMember = null;
            string secondaryMemberAddress = string.Empty;

            if (string.IsNullOrEmpty(primaryMemberAddress))
            {
                throw new InvalidPluginExecutionException("Primary Member Address details is empty. Please provide!");
            }
            _tracingService.Trace($"Primary Member Address: {primaryMemberAddress}");

            if (numberOfAllowedMembers == 2)
            {
                secondaryMemberRef = entity.Contains(EntityNames.Membership.Member2) ?
                    (EntityReference)entity[EntityNames.Membership.Member2] : preImageMembership.Contains(EntityNames.Membership.Member2) ? preImageMembership.Member2 : null;
                secondaryMember = _service.Retrieve(EntityNames.Contact.EntityLogicalName, secondaryMemberRef.Id, new ColumnSet(true));

                //Retrieve concatenated address for Secondary Member
                secondaryMemberAddress = GetContactAddress(secondaryMemberRef.Id);
                _tracingService.Trace($"Get ContactAddress Completed");
                if (string.IsNullOrEmpty(secondaryMemberAddress))
                {
                    Entity updateSecondaryMember = new Entity(EntityNames.Contact.EntityLogicalName, secondaryMember.Id);
                    //Update Secondary Member Address details
                    updateSecondaryMember[EntityNames.Contact.AddressSearchTypePrimary] = primaryMember.Contains(EntityNames.Contact.AddressSearchTypePrimary) ? primaryMember[EntityNames.Contact.AddressSearchTypePrimary] : null;
                    updateSecondaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] = primaryMember.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? primaryMember[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line1] = primaryMember.Contains(EntityNames.Contact.Address1_Line1) ? primaryMember[EntityNames.Contact.Address1_Line1] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line2] = primaryMember.Contains(EntityNames.Contact.Address1_Line2) ? primaryMember[EntityNames.Contact.Address1_Line2] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Line3] = primaryMember.Contains(EntityNames.Contact.Address1_Line3) ? primaryMember[EntityNames.Contact.Address1_Line3] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_StateOrProvince] = primaryMember.Contains(EntityNames.Contact.Address1_StateOrProvince) ? primaryMember[EntityNames.Contact.Address1_StateOrProvince] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_City] = primaryMember.Contains(EntityNames.Contact.Address1_City) ? primaryMember[EntityNames.Contact.Address1_City] : null;
                    updateSecondaryMember[EntityNames.Contact.LoqateAddress1County] = primaryMember.Contains(EntityNames.Contact.LoqateAddress1County) ? primaryMember[EntityNames.Contact.LoqateAddress1County] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_Country] = primaryMember.Contains(EntityNames.Contact.Address1_Country) ? primaryMember[EntityNames.Contact.Address1_Country] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1_PostalCode] = primaryMember.Contains(EntityNames.Contact.Address1_PostalCode) ? primaryMember[EntityNames.Contact.Address1_PostalCode] : null;
                    updateSecondaryMember[EntityNames.Contact.Loqate_Latitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Latitude) ? primaryMember[EntityNames.Contact.Loqate_Latitude] : null;
                    updateSecondaryMember[EntityNames.Contact.Loqate_Longitude] = primaryMember.Contains(EntityNames.Contact.Loqate_Longitude) ? primaryMember[EntityNames.Contact.Loqate_Longitude] : null;
                    updateSecondaryMember[EntityNames.Contact.Address1PAFValidated] = primaryMember.Contains(EntityNames.Contact.Address1PAFValidated) ? primaryMember[EntityNames.Contact.Address1PAFValidated] : null;
                    updateSecondaryMember[EntityNames.Contact.BusinessValidatedPrimary] = primaryMember.Contains(EntityNames.Contact.BusinessValidatedPrimary) ? primaryMember[EntityNames.Contact.BusinessValidatedPrimary] : null;

                    _service.Update(updateSecondaryMember);
                    _tracingService.Trace("Updated contact: " + secondaryMemberRef.Id.ToString());
                }

                else
                {
                    _tracingService.Trace($"Secondary Member Address: {secondaryMemberAddress}");
                    if (secondaryMemberAddress != primaryMemberAddress)
                    {
                        throw new InvalidPluginExecutionException($"Addresses don't match, Please review the address for both the members!");
                    }
                }
            }
            _tracingService.Trace($"ValidateAddressInMembership End");
        }

        public Entity SetPatronMembershipOnMembership(Entity entity, Membership membership)
        {
            if (membership.Contact != null && membership.MembershipProductId != null)
            {
                _tracingService.Trace($"Starting {MethodBase.GetCurrentMethod().Name} method logic.");

                // flag to check if new product is a patron product
                var isPatronProduct = false;

                // get environment variable default/current value
                _tracingService.Trace($"Retrieving Patron Membership Product parent id.");
                var environmentVariableValue = _commonService.GetEnvironmentVariableValue("rhs_PatronMembershipProductParentID", _service);

                // get new membership product id
                Guid MembershipProductId = ((EntityReference)membership[EntityNames.Membership.MembershipProductId]).Id;

                // get all patron products 
                _tracingService.Trace($"Checking if Membership Product has Patron Family parent.");
                QueryExpression queryPatronProducts = new QueryExpression(Product.EntityLogicalName);
                queryPatronProducts.ColumnSet = new ColumnSet("productid");
                queryPatronProducts.Criteria.AddCondition("parentproductid", ConditionOperator.Equal, environmentVariableValue);
                var patronProducts = _service.RetrieveMultiple(queryPatronProducts);

                foreach (var entityPatronProducts in patronProducts.Entities)
                {
                    // condition if new membership product is a patron product.
                    if (entityPatronProducts.Id == MembershipProductId)
                    {
                        isPatronProduct = true;
                        break;
                    }
                }

                if (isPatronProduct == true)
                {
                    _tracingService.Trace($"Patron Membership is set to Yes.");
                    entity[EntityNames.Membership.PatronMembership] = true;
                }
                else
                {
                    _tracingService.Trace($"Patron Membership is set to No.");
                    entity[EntityNames.Membership.PatronMembership] = false;
                }

                _tracingService.Trace($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            }
            return entity;
        }

        public int GetNumberOfAllowedMembers(string productId)
        {
            _tracingService.Trace($"GetNumberOfAllowedMembers Start");

            var productPropertyName = "Number of Members Allowed";
            var numberOfMembersAllowedProperty = _propertyRetrievalService.GetProductProperty(productId, productPropertyName);
            var numberOfAllowedMembers = numberOfMembersAllowedProperty.DefaultValueInteger != null ? (int)numberOfMembersAllowedProperty.DefaultValueInteger : 0;

            _tracingService.Trace($"GetNumberOfAllowedMembers End");

            return numberOfAllowedMembers;
        }

        private string GetContactAddress(Guid contactId)
        {
            Entity contact = _service.Retrieve(EntityNames.Contact.EntityLogicalName, contactId, new ColumnSet(true));

            string houseName = contact.Contains(EntityNames.Contact.LoqateHomeAddressHouseName) ? (string)contact[EntityNames.Contact.LoqateHomeAddressHouseName] : null;
            string houseLine = contact.Contains(EntityNames.Contact.Address1_Line1) ? (string)contact[EntityNames.Contact.Address1_Line1] : null;
            string city = contact.Contains(EntityNames.Contact.Address1_City) ? (string)contact[EntityNames.Contact.Address1_City] : null;
            string postalCode = contact.Contains(EntityNames.Contact.Address1_PostalCode) ? (string)contact[EntityNames.Contact.Address1_PostalCode] : null;

            string memberAddress = $"{houseName} {houseLine} {city} {postalCode}".Trim();

            return memberAddress.ToLower();
        }
    }
}