﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IdentityModel.Protocols.WSTrust;
using System.Linq;
using System.ServiceModel.Channels;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICancelDDService
    {
        (List<Guid>, List<Guid>, List<Guid>) CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(Entity entity);
        Guid? CancelDirectDebitOfEntity(Entity entity);
        List<Guid> CancelDirectDebitsOfEntity(Entity entity);
    }
    public class CancelDDService : ICancelDDService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;
        private IRepository<PaymentSchedule> _paymentScheduleRepository;
        private IRepository<Directdebitdetails> _directDebitDetailsRepository;

        public CancelDDService(ILogger logger, IOrganizationService service, IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository, IRepository<PaymentSchedule> paymentScheduleRepository, IRepository<Directdebitdetails> directDebitDetailsRepository)
        {
            _logger = logger;
            _service = service;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _paymentScheduleRepository = paymentScheduleRepository;
            _directDebitDetailsRepository = directDebitDetailsRepository;
        }

        #region Business Logics
        public (List<Guid>, List<Guid>, List<Guid>) CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            var cancelledTransactionIds = new List<Guid>();
            var cancelledPaymentScheduleIds = new List<Guid>();
            var cancelledPaymentIds = new List<Guid>();

            switch (entity.LogicalName)
            {
                case "rhs_membership":
                    cancelledTransactionIds = CancelActiveTransactionsOfMembership(entity.Id);
                    cancelledPaymentScheduleIds = CancelActivePaymentSchedulesOfMembership(entity.Id);
                    foreach (var cancelledTransactionId in cancelledTransactionIds)
                    {
                        cancelledPaymentIds.AddRange(CancelActivePaymentsOfTransaction(cancelledTransactionId));
                    }
                    break;
                case "rhs_subscription":
                    cancelledTransactionIds = CancelActiveTransactionsOfSubscription(entity.Id);
                    cancelledPaymentScheduleIds = CancelActivePaymentSchedulesOfSubscription(entity.Id);
                    foreach (var cancelledTransactionId in cancelledTransactionIds)
                    {
                        cancelledPaymentIds.AddRange(CancelActivePaymentsOfTransaction(cancelledTransactionId));
                    }
                    break;
                case "rhs_donation":
                    cancelledTransactionIds = CancelActiveTransactionsOfDonation(entity.Id);
                    cancelledPaymentScheduleIds = CancelActivePaymentSchedulesOfDonation(entity.Id);
                    foreach (var cancelledTransactionId in cancelledTransactionIds)
                    {
                        cancelledPaymentIds.AddRange(CancelActivePaymentsOfTransaction(cancelledTransactionId));
                    }
                    break;
            }

            _logger.TraceInformation($"Ending business logic.");
            return (cancelledTransactionIds, cancelledPaymentScheduleIds, cancelledPaymentIds);
        }

        public Guid? CancelDirectDebitOfEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving direct debit of entity.");
            Directdebitdetails directDebitOfEntity = null;
            switch (entity.LogicalName)
            {
                case "rhs_membership":
                    directDebitOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => directDebit.MembershipId != null && directDebit.MembershipId.Id == entity.Id).FirstOrDefault();
                    break;
                case "rhs_subscription":
                    directDebitOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => directDebit.Subscription != null && directDebit.Subscription.Id == entity.Id).FirstOrDefault();
                    break;
                case "rhs_donation":
                    directDebitOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => directDebit.Donation != null && directDebit.Donation.Id == entity.Id).FirstOrDefault();
                    break;
            }

            if (directDebitOfEntity != null && directDebitOfEntity.BACSError == null)
            {
                _logger.TraceInformation($"Cancelling direct debit of entity.");
                var directDebitUpdate = new Directdebitdetails()
                {
                    Id = directDebitOfEntity.Id,
                    Statecode = DirectdebitdetailsState.Inactive,
                    Statuscode = DirectdebitdetailsStatus.Inactive_Cancelled,
                    DDISubmissionStatus = MHStatus_GlobalOptionSet.Pending
                };
                _directDebitDetailsRepository.Update(directDebitUpdate);
            }

            _logger.TraceInformation($"Ending business logic.");
            return directDebitOfEntity?.Id;
        }

        public List<Guid> CancelDirectDebitsOfEntity(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving direct debit of entity.");
            List<Directdebitdetails> directDebitsOfEntity = null;
            switch (entity.LogicalName)
            {
                case "rhs_membership":
                    directDebitsOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => 
                        directDebit.MembershipId != null && directDebit.MembershipId.Id == entity.Id &&
                        directDebit.BACSError == null
                    ).ToList();
                    break;
                case "rhs_subscription":
                    directDebitsOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => 
                        directDebit.Subscription != null && directDebit.Subscription.Id == entity.Id &&
                        directDebit.BACSError == null
                    ).ToList();
                    break;
                case "rhs_donation":
                    directDebitsOfEntity = _directDebitDetailsRepository.GetAll().Where(directDebit => 
                        directDebit.Donation != null && directDebit.Donation.Id == entity.Id &&
                        directDebit.BACSError == null
                    ).ToList();
                    break;
            }

            _logger.TraceInformation($"Cancelling direct debits of entity.");
            foreach (var directDebitOfEntity in directDebitsOfEntity)
            {
                var directDebitUpdate = new Directdebitdetails()
                {
                    Id = directDebitOfEntity.Id,
                    Statecode = DirectdebitdetailsState.Inactive,
                    Statuscode = DirectdebitdetailsStatus.Inactive_Cancelled,
                    DDISubmissionStatus = MHStatus_GlobalOptionSet.Pending
                };
                _directDebitDetailsRepository.Update(directDebitUpdate);
            }

            _logger.TraceInformation($"Ending business logic.");
            return directDebitsOfEntity.Select(directDebit => directDebit.Id).ToList();
        }
        #endregion

        #region Helper Methods
        public List<Guid> CancelActiveTransactionsOfMembership(Guid membershipId)
        //set transactions to cancel only to those that are active
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active transactions of membership w/ Id = {membershipId}.");
            var transactionIds = _transactionRepository.GetAll().Where(trancaction =>
                trancaction.MembershipId != null && trancaction.MembershipId.Id == membershipId &&
                trancaction.Statecode == TransactionState.Active// && trancaction.Statuscode != TransactionStatus.Inactive_Paid
            ).Select(trancaction => trancaction.Id).ToList();
            _logger.TraceInformation($"Retrieved {transactionIds.Count} active transactions of membership w/ Id = {membershipId}.");

            _logger.TraceInformation($"Cancelling active transactions of membership w/ Id = {membershipId}.");
            foreach (var id in transactionIds)
            {
                _logger.TraceInformation($"Cancelling transaction w/ Id = {id}.");
                var transactionToCancel = new Transaction()
                {
                    Id = id,
                    Statecode = TransactionState.Inactive,
                    Statuscode = TransactionStatus.Inactive_Cancelled
                };
                _transactionRepository.Update(transactionToCancel);
                _logger.TraceInformation($"Cancelled transaction w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return transactionIds;
        }

        public List<Guid> CancelActivePaymentSchedulesOfMembership(Guid membershipId)
        //get active payment schedule (status either active or pending) )associated with transaction set them to cancel
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active payment schedules of membership w/ Id = {membershipId}");
            var paymentScheduleIds = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                paymentSchedule.Membership != null && paymentSchedule.Membership.Id == membershipId &&
                paymentSchedule.Statecode == PaymentScheduleState.Active
            ).Select(paymentSchedule => paymentSchedule.Id).ToList();
            _logger.TraceInformation($"Retrieved {paymentScheduleIds.Count} active payment schedules of membership w/ Id = {membershipId}");


            _logger.TraceInformation($"Cancelling active payment schedules of membership w/ Id = {membershipId}");
            foreach (var id in paymentScheduleIds)
            {
                _logger.TraceInformation($"Cancelling payment schedule w/ Id = {id}.");
                var paymentScheduleToCancel = new PaymentSchedule()
                {
                    Id = id,
                    Statecode = PaymentScheduleState.Inactive,
                    Statuscode = PaymentScheduleStatus.Inactive_Cancelled
                };
                _paymentScheduleRepository.Update(paymentScheduleToCancel);
                _logger.TraceInformation($"Cancelled payment schedule w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");

            return paymentScheduleIds;
        }

        
        public List<Guid> CancelActiveTransactionsOfSubscription(Guid subscriptionId)
        //set transactions to cancel only to those that are active
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active transactions of subscription w/ Id = {subscriptionId}.");
            var transactionIds = _transactionRepository.GetAll().Where(trancaction =>
                trancaction.SubscriptionId != null && trancaction.SubscriptionId.Id == subscriptionId &&
                trancaction.Statecode == TransactionState.Active// && trancaction.Statuscode != TransactionStatus.Inactive_Paid
            ).Select(trancaction => trancaction.Id).ToList();
            _logger.TraceInformation($"Retrieved {transactionIds.Count} active transactions of subscription w/ Id = {subscriptionId}.");

            _logger.TraceInformation($"Cancelling active transactions of subscription w/ Id = {subscriptionId}.");
            foreach (var id in transactionIds)
            {
                _logger.TraceInformation($"Cancelling transaction w/ Id = {id}.");
                var transactionToCancel = new Transaction()
                {
                    Id = id,
                    Statecode = TransactionState.Inactive,
                    Statuscode = TransactionStatus.Inactive_Cancelled
                };
                _transactionRepository.Update(transactionToCancel);
                _logger.TraceInformation($"Cancelled transaction w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return transactionIds;
        }

        public List<Guid> CancelActivePaymentSchedulesOfSubscription(Guid subscriptionId)
        //get active payment schedule (status either active or pending )associated with transaction set them to cancel
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active payment schedules of subscription w/ Id = {subscriptionId}");
            var paymentScheduleIds = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                paymentSchedule.SubscriptionId != null && paymentSchedule.SubscriptionId.Id == subscriptionId &&
                paymentSchedule.Statecode == PaymentScheduleState.Active
            ).Select(paymentSchedule => paymentSchedule.Id).ToList();
            _logger.TraceInformation($"Retrieved {paymentScheduleIds.Count} active payment schedules of subscription w/ Id = {subscriptionId}");


            _logger.TraceInformation($"Cancelling active payment schedules of subscription w/ Id = {subscriptionId}");
            foreach (var id in paymentScheduleIds)
            {
                _logger.TraceInformation($"Cancelling payment schedule w/ Id = {id}.");
                var paymentScheduleToCancel = new PaymentSchedule()
                {
                    Id = id,
                    Statecode = PaymentScheduleState.Inactive,
                    Statuscode = PaymentScheduleStatus.Inactive_Cancelled
                };
                _paymentScheduleRepository.Update(paymentScheduleToCancel);
                _logger.TraceInformation($"Cancelled payment schedule w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");

            return paymentScheduleIds;
        }

        public List<Guid> CancelActiveTransactionsOfDonation(Guid donationId)
        //set transactions to cancel only to those that are active
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active transactions of donation w/ Id = {donationId}.");
            var transactionIds = _transactionRepository.GetAll().Where(trancaction =>
              trancaction.Donation != null && trancaction.Donation.Id == donationId &&
                trancaction.Statecode == TransactionState.Active// && trancaction.Statuscode != TransactionStatus.Inactive_Paid
            ).Select(trancaction => trancaction.Id).ToList();
            _logger.TraceInformation($"Retrieved {transactionIds.Count} active transactions of donation w/ Id = {donationId}.");

            _logger.TraceInformation($"Cancelling active transactions of donation w/ Id = {donationId}.");
            foreach (var id in transactionIds)
            {
                _logger.TraceInformation($"Cancelling transaction w/ Id = {id}.");
                var transactionToCancel = new Transaction()
                {
                    Id = id,
                    Statecode = TransactionState.Inactive,
                    Statuscode = TransactionStatus.Inactive_Cancelled
                };
                _transactionRepository.Update(transactionToCancel);
                _logger.TraceInformation($"Cancelled transaction w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return transactionIds;
        }

        public List<Guid> CancelActivePaymentSchedulesOfDonation(Guid donationId)
        //get active payment schedule (status either active or pending )associated with transaction set them to cancel
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active payment schedules of donation w/ Id = {donationId}");
            var paymentScheduleIds = _paymentScheduleRepository.GetAll().Where(paymentSchedule =>
                paymentSchedule.Donationid != null && paymentSchedule.Donationid.Id == donationId &&
                paymentSchedule.Statecode == PaymentScheduleState.Active
            ).Select(paymentSchedule => paymentSchedule.Id).ToList();
            _logger.TraceInformation($"Retrieved {paymentScheduleIds.Count} active payment schedules of donation w/ Id = {donationId}");


            _logger.TraceInformation($"Cancelling active payment schedules of donation w/ Id = {donationId}");
            foreach (var id in paymentScheduleIds)
            {
                _logger.TraceInformation($"Cancelling payment schedule w/ Id = {id}.");
                var paymentScheduleToCancel = new PaymentSchedule()
                {
                    Id = id,
                    Statecode = PaymentScheduleState.Inactive,
                    Statuscode = PaymentScheduleStatus.Inactive_Cancelled
                };
                _paymentScheduleRepository.Update(paymentScheduleToCancel);
                _logger.TraceInformation($"Cancelled payment schedule w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");

            return paymentScheduleIds;
        }



        public List<Guid> CancelActivePaymentsOfTransaction(Guid paymentId)
        //get active payment associated with transaction (status either active or pending) ) set them to cancel
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active payments of transaction w/ Id = {paymentId}.");
            var paymentIdsOfTransaction = _paymentRepository.GetAll().Where(payment =>
                payment.Transaction != null && payment.Transaction.Id == paymentId &&
                payment.Statecode == PaymentState.Active
            ).Select(trancaction => trancaction.Id).ToList();
            _logger.TraceInformation($"Retrieved {paymentIdsOfTransaction.Count} active payments of transaction w/ Id = {paymentId}.");

            _logger.TraceInformation($"Cancelling active payments of transaction w/ Id = {paymentId}.");
            foreach (var id in paymentIdsOfTransaction)
            {
                _logger.TraceInformation($"Cancelling payment w/ Id = {id}.");
                var paymentToCancel = new Payment()
                {
                    Id = id,
                    Statecode = PaymentState.Inactive,
                    Statuscode = PaymentStatus.Inactive_Cancelled
                };
                _paymentRepository.Update(paymentToCancel);
                _logger.TraceInformation($"Cancelled payment w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return paymentIdsOfTransaction;
        }

        public List<Guid> CancelActivePaymentsOfPaymentSchedule(Guid paymentScheduleId)
        //get active payment associated with payment schedule(status either active or pending) ) set them to cancel
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving active payments of payment schedule w/ Id = {paymentScheduleId}.");
            var paymentIdsOfPaymentSchedule = _paymentRepository.GetAll().Where(payment =>
                payment.PaymentSchedule != null && payment.PaymentSchedule.Id == paymentScheduleId &&
                payment.Statecode == PaymentState.Active
            ).Select(trancaction => trancaction.Id).ToList();
            _logger.TraceInformation($"Retrieved {paymentIdsOfPaymentSchedule.Count} active payments of payment schedule w/ Id = {paymentScheduleId}.");

            _logger.TraceInformation($"Cancelling active payments of payment schedule w/ Id = {paymentScheduleId}.");
            foreach (var id in paymentIdsOfPaymentSchedule)
            {
                _logger.TraceInformation($"Cancelling payment w/ Id = {id}.");
                var paymentToCancel = new Payment()
                {
                    Id = id,
                    Statecode = PaymentState.Inactive,
                    Statuscode = PaymentStatus.Inactive_Cancelled
                };
                _paymentRepository.Update(paymentToCancel);
                _logger.TraceInformation($"Cancelled payment w/ Id = {id}.");
            }

            _logger.TraceInformation($"Ending business logic.");
            return paymentIdsOfPaymentSchedule;
        }
        #endregion
    }
}
