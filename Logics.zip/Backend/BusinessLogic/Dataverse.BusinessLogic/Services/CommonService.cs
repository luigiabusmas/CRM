﻿//Added by JMM  - 9/8/2025 
//Used for Reusable function that can be called from different services.

using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICommonService
    {
        bool validateName(string name);
        string capitalizeNameInput(string fieldName, bool isLastName);
        GDPRConfigurationSettings getGDPRConfiguration(OptionSetValue entityNameCode);
        string getSalutation(Guid titleId);
        string GetEnvironmentVariableValue(string environmentVariableSchemaName, IOrganizationService orgService);
        bool IsTescoVoucherPayment(Portalsession portalSession);
        bool IsContinuousPayment(Portalsession portalSession);
        Guid? GetTransactionIdFromSession(Portalsession portalSession);
        decimal GetVoucherDiscount(PortalSessionDiscount discount);
    }
    public class CommonService : ICommonService
    {
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;

        public CommonService(
           ITracingService tracingService, ILogger logger,
           IOrganizationService service,
           IPluginExecutionContext context
        )
        {
            _logger = logger;
            _service = service;
        }
        //Task #72993 and #72994 - Reusable validation to check if string only contains letters, accents, spaces, dashes and apostrophes.
        /// <summary>
        /// Validates that the specified string contains only allowed characters:
        /// letters (including accented characters), spaces, dashes, and apostrophes.
        /// This function is reusable for validating fields like first names, last names, and other similar text fields in Dynamics 365.
        /// </summary>
        public bool validateName(string name)
        {
            _logger.TraceInformation($"validateName Start");
            bool isValid = true;
            if (!string.IsNullOrWhiteSpace(name))
            {
                string pattern = @"^[a-zA-Zà-ÿÀ-ŸÐøØß\s\-\']+$";
                if (!Regex.IsMatch(name, pattern, RegexOptions.IgnoreCase))
                {
                    isValid = false;
                }
            }
            _logger.TraceInformation(string.Format("validateName isValid: {0}", isValid));
            _logger.TraceInformation($"validateName End");
            return isValid;
        }

        // Task #72993 and #72994 - Reusable function to capitalize each word in a name input string
        // This function capitalizes the first letter of each word in a provided string (fieldName), 
        // while ensuring that single-letter words are fully capitalized. It also trims any leading or 
        // trailing whitespace from the resulting string.
        public string capitalizeNameInput(string fieldName, bool isLastName)
        {
            _logger.TraceInformation($"capitalizeFirstLetter Start");
            string capitalizedName = string.Empty;
            string[] separator = { " " };
            if (!string.IsNullOrEmpty(fieldName))
            {
                string[] arrInput = fieldName.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                foreach (string s in arrInput)
                {
                    string formatted = s.ToLower();
                    if (isLastName && formatted.IndexOf("'", StringComparison.OrdinalIgnoreCase) < 0 && (formatted.StartsWith("mc", StringComparison.OrdinalIgnoreCase)|| formatted.StartsWith("mac", StringComparison.OrdinalIgnoreCase)))
                    {
                        formatted = char.ToUpper(formatted[0]) + formatted.Substring(1);
                        if (formatted.Length > 1)
                        {
                            if(formatted.IndexOf("mc", StringComparison.OrdinalIgnoreCase) >= 0)
                                formatted = char.ToUpper(formatted[0]) + formatted.Substring(1, 1) + char.ToUpper(formatted[2]) + formatted.Substring(3);
                            else if(formatted.IndexOf("mac", StringComparison.OrdinalIgnoreCase) >= 0)
                                formatted = char.ToUpper(formatted[0]) + formatted.Substring(1, 2) + char.ToUpper(formatted[3]) + formatted.Substring(4);
                            else
                                formatted = char.ToUpper(formatted[0]) + formatted.Substring(1);
                        }
                    }

                    else if (formatted.Contains("'"))
                    {
                        int apostropheIndex = formatted.IndexOf("'", StringComparison.OrdinalIgnoreCase);
                        if (apostropheIndex > 0 && formatted.Length > apostropheIndex + 1)
                        {
                            formatted = char.ToUpper(formatted[0]) +
                                        formatted.Substring(1, apostropheIndex - 1) +
                                        "'" +
                                        char.ToUpper(formatted[apostropheIndex + 1]) +
                                        formatted.Substring(apostropheIndex + 2);
                        }
                        else
                        {
                            formatted = char.ToUpper(formatted[0]) + formatted.Substring(1);
                        }
                    }
                    else
                    {
                        // Standard capitalization for other words
                        formatted = char.ToUpper(formatted[0]) + formatted.Substring(1);
                    }

                    // Append the formatted word with a leading space
                    capitalizedName += " " + formatted;
                }
            }
            _logger.TraceInformation($"capitalizeFirstLetter End");
            if (capitalizedName.Length > 0)
                capitalizedName = capitalizedName.Trim();
            return capitalizedName;
        }

        public GDPRConfigurationSettings getGDPRConfiguration(OptionSetValue entityNameCode)
        {
            _logger.TraceInformation($"getGDPRConfiguration Start");
            QueryExpression queryExpression = new QueryExpression(GDPRConfigurationSettings.EntityLogicalName);
            queryExpression.ColumnSet = new ColumnSet(EntityNames.GDPRConfigurationSettings.EntityNameCode, EntityNames.GDPRConfigurationSettings.RetentionPeriod);
            queryExpression.Criteria.AddCondition(EntityNames.GDPRConfigurationSettings.EntityNameCode, ConditionOperator.Equal, entityNameCode.Value);

            EntityCollection GDPRConfigCollection = _service.RetrieveMultiple(queryExpression);
            _logger.TraceInformation($"getGDPRConfiguration End");
            if (GDPRConfigCollection.Entities.Count == 0)
            {
                return null;
            }
            return GDPRConfigCollection[0].ToEntity<GDPRConfigurationSettings>();
        }

        public string getSalutation(Guid titleId)
        {
            _logger.TraceInformation($"contactPopulateSalutation Start");
            string salutationString = String.Empty;
            Entity Salutation = _service.Retrieve(TitleandSalutation.EntityLogicalName, titleId, new ColumnSet(EntityNames.TitleandSalutation.Salutation));
            if (Salutation != null)
            {
                return Salutation[EntityNames.TitleandSalutation.Salutation] as string;
            }
            _logger.TraceInformation($"contactPopulateSalutation End");
            return null;

        }

        /// <summary>
        /// Gets the value of an environment variable based on the provided schema name.
        /// If no matching record with a value is found, it checks for a default value.
        /// </summary>
        /// <param name="environmentVariableSchemaName">The schema name of the environment variable.</param>
        /// <param name="orgService">The IOrganizationService instance used to connect to Dataverse.</param>
        /// <returns>
        /// The value of the environment variable if found;
        /// if no matching record with a value is found, it returns the default value;
        /// otherwise, returns null.
        /// </returns>
        public string GetEnvironmentVariableValue(string environmentVariableSchemaName, IOrganizationService orgService)
        {
            string envVariableValue = null;
            var query = new QueryExpression("environmentvariabledefinition")
            {
                ColumnSet = new ColumnSet("defaultvalue", "schemaname", "environmentvariabledefinitionid")
            };

            query.Criteria.AddCondition("schemaname", ConditionOperator.Equal, environmentVariableSchemaName);

            var linkEnvironmentValue = new LinkEntity("environmentvariabledefinition", "environmentvariablevalue", "environmentvariabledefinitionid", "environmentvariabledefinitionid", JoinOperator.Inner)
            {
                EntityAlias = "EV"
            };
            linkEnvironmentValue.Columns.AddColumns("value");
            linkEnvironmentValue.LinkCriteria.AddCondition("value", ConditionOperator.NotNull);

            query.LinkEntities.Add(linkEnvironmentValue);

            var result = orgService.RetrieveMultiple(query);

            if (result.Entities.Count > 0)
            {
                Entity entity = result.Entities[0];
                if (entity.Attributes.Contains("EV.value"))
                {
                    envVariableValue = entity.GetAttributeValue<AliasedValue>("EV.value").Value.ToString();
                }
            }

            if (string.IsNullOrEmpty(envVariableValue))
            {
                // Check for 'Default Value' in 'environmentvariabledefinition'
                envVariableValue = GetDefaultEnvironmentVariableValue(environmentVariableSchemaName, orgService);
            }

            // Return envVariableValue. It will be null if no matching record with a value or default value is found.
            return envVariableValue;
        }

        /// <summary>
        /// Gets the default value of an environment variable based on the provided schema name.
        /// </summary>
        /// <param name="schemaName">The schema name of the environment variable.</param>
        /// <param name="orgService">The IOrganizationService instance used to connect to Dataverse.</param>
        /// <returns>The default value of the environment variable if found; otherwise, returns null.</returns>
        private static string GetDefaultEnvironmentVariableValue(string schemaName, IOrganizationService orgService)
        {
            var query = new QueryExpression("environmentvariabledefinition")
            {
                ColumnSet = new ColumnSet("defaultvalue", "schemaname", "environmentvariabledefinitionid")
            };

            query.Criteria.AddCondition("schemaname", ConditionOperator.Equal, schemaName);

            var result = orgService.RetrieveMultiple(query);

            if (result.Entities.Count > 0)
            {
                Entity entity = result.Entities[0];
                if (entity.Attributes.Contains("defaultvalue"))
                {
                    return entity.GetAttributeValue<string>("defaultvalue");
                }
            }

            // Return null if no matching record is found or if 'value' attribute is null.
            return null;
        }

        public bool IsTescoVoucherPayment(Portalsession portalSession) =>
        portalSession.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.TescoVoucher;

        public bool IsContinuousPayment(Portalsession portalSession) =>
        portalSession.PaymentFrequency.HasValue && portalSession.PaymentFrequency.Value == PaymentFrequency_GlobalOptionSet.Monthly;

        public Guid? GetTransactionIdFromSession(Portalsession portalSession)
        {
            if (!string.IsNullOrEmpty(portalSession.TransactionID) && portalSession.Contains(EntityNames.Portalsession.TransactionID))
            {
                return new Guid(portalSession.TransactionID);
            }
            return null;
        }

        public decimal GetVoucherDiscount(PortalSessionDiscount discount) => discount?.DiscountAmount?.Value ??0m;
    }
}
