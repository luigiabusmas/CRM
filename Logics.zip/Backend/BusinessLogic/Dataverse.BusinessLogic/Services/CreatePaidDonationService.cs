﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICreatePaidDonationService
    {
        Donation CreateStandaloneDonationFromBatchOrderLine(Guid batchOrderLineId);
        Guid CreateDonation(Entity membershipEntity, PaymentMethodType_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime? startDate, DateTime? endDate, DateTime? payoutDate, Money donationAmount);
        void CreateDonationRelatedRecords(Donation donation);
        void ActivateDonationWhenApplicable(Guid donationId, PaymentMethodType_GlobalOptionSet? paymentMethod);
        Entity GetMembershipDetails(Guid membershipId);
        void UpdateTransaction(Guid? transactionId, Guid? donationId, Money donationAmount);
        Guid ProcessDonationAndPayment(Entity membershipEntity, Guid transactionId, Money donationAmount);
        Guid ProcessUnpaidDonationAndPayment(Entity membershipEntity, Guid transactionId, Money donationAmount);
        Guid CreateDonationPayment(Entity membershipEntity, Guid transactionId, EntityReference donationRef, Money donationAmount, DateTime? startDate, DateTime? endDate, DateTime? payoutDate);
        void SetPaymentPaid(Guid? paymentId);
        Transaction RetrieveMembershipTransaction(Guid membershipId);
    }
    public class CreatePaidDonationService : ICreatePaidDonationService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRepository<Batchorderline> _batchOrderLineRepository;
        private IRepository<Donation> _donationRepository;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;
        private IRecordDateCalculationService _recordDateCalculationService;
        private ICustomAPIInvocationService _customApiInvocationService;
        private ISubmitPaymentService _submitPaymentService;

        public CreatePaidDonationService(ILogger logger, IOrganizationService service, IRepository<Batchorderline> batchOrderLineRepository, IRepository<Donation> donationRepository, IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepositry,
            IProductService productService, IRecordDateCalculationService recordDateCalculationService, ICustomAPIInvocationService customApiInvocationService, ISubmitPaymentService submitPaymentService)
        {
            _logger = logger;
            _service = service;
            _batchOrderLineRepository = batchOrderLineRepository;
            _donationRepository = donationRepository;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepositry;
            _recordDateCalculationService = recordDateCalculationService;
            _customApiInvocationService = customApiInvocationService;
            _submitPaymentService = submitPaymentService;
        }

        public Donation CreateStandaloneDonationFromBatchOrderLine(Guid batchOrderLineId)
        {
            _logger.TraceInformation("Starting business process.");

            _logger.TraceInformation("Retrieving batch order line.");
            Batchorderline batchOrderLine;
            try
            {
                batchOrderLine = _batchOrderLineRepository.GetById(batchOrderLineId);
            }
            catch(Exception ex)
            {
                var errorMessage = "Could not retrieve batch order line because this custom API is executed on post-operation of record.";
                _logger.TraceError(errorMessage);
                throw new InvalidPluginExecutionException(errorMessage);
            }

            _logger.TraceInformation("Preparing donation data for creation.");
            var donationToCreate = new Donation()
            {
                Campaign = batchOrderLine.DonationCampaign,
                Donor = batchOrderLine.Payer,
                PaymentMethodCode = batchOrderLine.PaymentMethodCode,
                PaymentFrequency = PaymentFrequency_GlobalOptionSet.Annually,
                Iscontinuouspayment = false,
                Channel = batchOrderLine.ChannelSource,
                DonationDate = DateTime.UtcNow,

                CAFAccountNumber = batchOrderLine.CAFAccountNumber,
                CAFCardExpiry = batchOrderLine.CAFCardExpiry,
                CAFCardNumber = batchOrderLine.CAFCardNumber,
                CAFPaymentType = batchOrderLine.CAFPaymentType,
                CAFTransactionReference = batchOrderLine.CAFTransactionReference,
                CAFVoucherNumber = batchOrderLine.CAFVoucherNumber,
            };
            donationToCreate.Startdate = _recordDateCalculationService.CalculateStartDateOfRecord(null);
            donationToCreate.Enddate = _recordDateCalculationService.CalculateEndDateOfRecord(donationToCreate.Startdate, null, null);
            if (donationToCreate.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                donationToCreate.OngoingDDAmount = batchOrderLine.DonationAmount;
                donationToCreate.PayoutDate = _recordDateCalculationService.CalculatePayoutDate((DateTime)donationToCreate.Startdate);
            }
            else
            {
                donationToCreate.Amount = batchOrderLine.DonationAmount;
            }

            _logger.TraceInformation("Creating donation.");
            var donation = _donationRepository.Create(donationToCreate);
            _logger.TraceInformation($"Created donation w/ id = {donation.Id}.");

            _logger.TraceInformation("Ending business process.");
            return donation;
        }

        public Guid CreateDonation(Entity membershipEntity, PaymentMethodType_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency, DateTime? startDate, DateTime? endDate, DateTime? payoutDate, Money donationAmount)
        {
            _logger.TraceInformation("Start CreateDonation");
            Guid donationId = Guid.Empty;

            try
            {
                // Calculate ongoing DD amount before creating the Donation
                Money ongoingDDAmount = null;

                if (paymentMethod != null && paymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit)
                {
                    decimal amountValue = donationAmount?.Value ?? 0m;

                    if (paymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly)
                    {
                        // Divide by 12 for monthly DDs
                        amountValue = Math.Round(amountValue / 12, 2);
                        _logger.TraceInformation($"Monthly Direct Debit detected. Calculated Ongoing DD Amount: {amountValue}");
                    }
                    else if (paymentFrequency == PaymentFrequency_GlobalOptionSet.Annually)
                    {
                        _logger.TraceInformation($"Annual Direct Debit detected. Ongoing DD Amount: {amountValue}");
                    }

                    ongoingDDAmount = new Money(amountValue);
                }

                var donation = new Donation()
                {
                    Campaign = membershipEntity.Contains("rhs_campaigndonation") ? membershipEntity.GetAttributeValue<EntityReference>("rhs_campaigndonation") : null,
                    Donor = membershipEntity.Contains("rhs_payerv2") ? membershipEntity.GetAttributeValue<EntityReference>("rhs_payerv2") : null,
                    PaymentMethodCode = paymentMethod != null ? paymentMethod.Value : null,
                    PaymentFrequency = paymentFrequency != null ? paymentFrequency.Value : null,
                    Iscontinuouspayment = membershipEntity.Contains("rhs_iscontinuouspayment") ? membershipEntity.GetAttributeValue<bool>("rhs_iscontinuouspayment") : null,
                    Amount = paymentMethod != null && paymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit ? donationAmount : null,
                    OngoingDDAmount = paymentMethod != null && paymentMethod == PaymentMethodType_GlobalOptionSet.DirectDebit ? ongoingDDAmount : null,
                    Channel = membershipEntity.Contains("rhs_channel") ? (ChannelOptionChoice_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_channel").Value : null,
                    Startdate = startDate,
                    Enddate = endDate,
                    PayoutDate = payoutDate,
                    DonationDate = DateTime.UtcNow
                };

                donationId = _service.Create(donation);
                _logger.TraceInformation($"Created donation id: {donationId}");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error CreateDonation: {0}", ex.Message));
            }

            return donationId;
        }


        public void CreateDonationRelatedRecords(Donation donation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var totalAmount = donation.Amount;
            if (donation.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                totalAmount = donation.OngoingDDAmount;
                if (donation.PaymentFrequency == PaymentFrequency_GlobalOptionSet.Monthly && donation.OngoingDDAmount != null)
                    totalAmount = new Money(donation.OngoingDDAmount.Value * 12);
            }
            var (transactionId, paymentId, paymentScheduleId) = _customApiInvocationService.InvokeSubmitPaymentCustomAPI(
                (int?)donation.PaymentMethodCode,
                (int)NewTransactionType_GlobalOptionSet.Donation,
                (int)Typetransaction_GlobalOptionSet.FullPayment,
                donation.Id,
                donation.Donor?.Id,
                donation.Donor?.LogicalName,
                totalAmount,
                (int?)donation.PaymentFrequency,
                donation.Iscontinuouspayment,
                totalAmount,
                null,
                donation.CAFTransactionReference,
                null
            );
            if (paymentId != null &&
                donation.PaymentMethodCode != PaymentMethodType_GlobalOptionSet.Card &&
                donation.PaymentMethodCode != PaymentMethodType_GlobalOptionSet.CreditCard_Phone &&
                donation.PaymentMethodCode != PaymentMethodType_GlobalOptionSet.InternalGiftPack)
            {
                var paymentUpdate = new Payment()
                {
                    Id = (Guid)paymentId,
                    Statecode = PaymentState.Inactive,
                    Statuscode = PaymentStatus.Inactive_Paid
                };
                _paymentRepository.Update(paymentUpdate);
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void ActivateDonationWhenApplicable(Guid donationId, PaymentMethodType_GlobalOptionSet? paymentMethod)
        {
            _logger.TraceInformation($"Start ActivateDonation");

            try
            {
                if (paymentMethod != PaymentMethodType_GlobalOptionSet.DirectDebit)
                {
                    var donationUpdate = new Donation()
                    {
                        Id = donationId,
                        Statecode = DonationState.Active,
                        Statuscode = DonationStatus.Active_ActivePaid
                    };
                    _donationRepository.Update(donationUpdate);
                    _logger.TraceInformation($"Updated donation id: {donationId}");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error ActivateDonation: {0}", ex.Message));
            }
        }

        public Entity GetMembershipDetails(Guid membershipId)
        {
            _logger.TraceInformation("Start GetMembershipDetails");
            var result = new Entity();

            try
            {
                result = _service.Retrieve(Membership.EntityLogicalName, membershipId, new ColumnSet("rhs_contact", "rhs_payerv2", "rhs_campaigndonation", "rhs_paymentmethod", "rhs_paymentfrequency", "rhs_channel", "rhs_iscontinuouspayment", "rhs_startdate", "rhs_enddate", "rhs_paymentschedule", "rhs_totalamount", "rhs_membershipproductid"));
                _logger.TraceInformation($"Successfully retrieved membership");
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error GetMembershipDetails: {0}", ex.Message));
            }

            return result;
        }

        public void UpdateTransaction(Guid? transactionId, Guid? donationId, Money donationAmount)
        {
            _logger.TraceInformation("Start UpdateTransaction");

            try
            {
                if (donationId.HasValue && transactionId.HasValue)
                {
                    var transaction = _transactionRepository.GetById(transactionId.Value);
                    var transactionAmount = transaction.Amount;
                    var transactionOutstandingAmount = transaction.OutstandingAmount;

                    //populate donation lookup in transaction
                    Transaction transactionUpdate = new Transaction()
                    {
                        TransactionId = transactionId,
                        Donation = new EntityReference(Donation.EntityLogicalName, donationId.Value),
                        Amount = transaction.Amount != null ? new Money(transactionAmount.Value + donationAmount.Value) : donationAmount,
                        OutstandingAmount = transaction.OutstandingAmount != null ? new Money(transactionOutstandingAmount.Value + donationAmount.Value) : donationAmount
                    };
                    _service.Update(transactionUpdate);
                    _logger.TraceInformation($"Updated transaction id: {transactionId}");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error UpdateTransaction: {0}", ex.Message));
            }
        }

        public Guid ProcessDonationAndPayment(Entity membershipEntity, Guid transactionId, Money donationAmount)
        {
            _logger.TraceInformation("Start ProcessDonationAndPayment");

            //optionsets
            PaymentMethodType_GlobalOptionSet? paymentMethod = membershipEntity.Contains("rhs_paymentmethod") ? (PaymentMethodType_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethod").Value : null;
            PaymentFrequency_GlobalOptionSet? paymentFrequency = membershipEntity.Contains("rhs_paymentfrequency") ? (PaymentFrequency_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentfrequency").Value : null;

            Guid paymentId = Guid.Empty;

            //dates
            DateTime? payoutDate = null;
            DateTime? startDate = _recordDateCalculationService.CalculateStartDateOfRecord(null);
            DateTime? endDate = ((DateTime)startDate).AddYears(1);
            if (paymentMethod != null && startDate != null && paymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit)
                payoutDate = _recordDateCalculationService.CalculatePayoutDate((DateTime)startDate);

            //Create donation
            Guid donationId = Guid.Empty;
            donationId = CreateDonation(membershipEntity, paymentMethod, paymentFrequency, startDate, endDate, payoutDate, donationAmount);
            var donationRef = new EntityReference(Donation.EntityLogicalName, donationId);

            //Associate donation to membership transaction
            UpdateTransaction(transactionId, donationId, donationAmount);

            if (donationId != Guid.Empty)
            {
                //Create payments
                paymentId = CreateDonationPayment(membershipEntity, transactionId, donationRef, donationAmount, startDate, endDate, payoutDate);
                
                //Set paid status for card payment only
                if (paymentId != Guid.Empty && paymentMethod != null && (paymentMethod.Value != PaymentMethodType_GlobalOptionSet.DirectDebit))
                    SetPaymentPaid(paymentId);
            }


            _logger.TraceInformation("End ProcessDonationAndPayment");

            return donationId;
        }

        public Guid ProcessUnpaidDonationAndPayment(Entity membershipEntity, Guid transactionId, Money donationAmount)
        {
            _logger.TraceInformation("Start ProcessDonationAndPayment");

            //optionsets
            PaymentMethodType_GlobalOptionSet? paymentMethod = membershipEntity.Contains("rhs_paymentmethod") ? (PaymentMethodType_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethod").Value : null;
            PaymentFrequency_GlobalOptionSet? paymentFrequency = membershipEntity.Contains("rhs_paymentfrequency") ? (PaymentFrequency_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentfrequency").Value : null;

            Guid paymentId = Guid.Empty;

            //dates
            DateTime? payoutDate = null;
            DateTime? startDate = _recordDateCalculationService.CalculateStartDateOfRecord(null);
            DateTime? endDate = ((DateTime)startDate).AddYears(1);
            if (paymentMethod != null && startDate != null && paymentMethod.Value == PaymentMethodType_GlobalOptionSet.DirectDebit)
                payoutDate = _recordDateCalculationService.CalculatePayoutDate((DateTime)startDate);

            //Create donation
            Guid donationId = Guid.Empty;
            donationId = CreateDonation(membershipEntity, paymentMethod, paymentFrequency, startDate, endDate, payoutDate, donationAmount);
            var donationRef = new EntityReference(Donation.EntityLogicalName, donationId);

            //Associate donation to membership transaction
            UpdateTransaction(transactionId, donationId, donationAmount);

            if (donationId != Guid.Empty)
            {
                //Create payments
                paymentId = CreateDonationPayment(membershipEntity, transactionId, donationRef, donationAmount, startDate, endDate, payoutDate);
            }


            _logger.TraceInformation("End ProcessDonationAndPayment");

            return donationId;
        }

        public Guid CreateDonationPayment(Entity membershipEntity, Guid transactionId, EntityReference donationRef, Money donationAmount, DateTime? startDate, DateTime? endDate, DateTime? payoutDate)
        {
            _logger.TraceInformation("Start CreateDonationPayment");

            //optionsets
            PaymentMethodType_GlobalOptionSet? paymentMethod = membershipEntity.Contains("rhs_paymentmethod") ? (PaymentMethodType_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentmethod").Value : null;
            PaymentFrequency_GlobalOptionSet? paymentFrequency = membershipEntity.Contains("rhs_paymentfrequency") ? (PaymentFrequency_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_paymentfrequency").Value : null;
            ChannelOptionChoice_GlobalOptionSet? channel = membershipEntity.Contains("rhs_channel") ? (ChannelOptionChoice_GlobalOptionSet)membershipEntity.GetAttributeValue<OptionSetValue>("rhs_channel").Value : null;

            //entityreference
            var transactionRef = transactionId != Guid.Empty ? new EntityReference(Transaction.EntityLogicalName, transactionId) : null;
            var payerRef = membershipEntity.Contains("rhs_payerv2") ? membershipEntity.GetAttributeValue<EntityReference>("rhs_payerv2") : null;
            EntityReference productRef = null, locationReference = null, thirdPartyPaymentTypeReference = null;

            var isContinuousPayment = membershipEntity.Contains("rhs_iscontinuouspayment") ? membershipEntity.GetAttributeValue<bool>("rhs_iscontinuouspayment") : false;
            int? payingInSlipNumber = null;
            string paymentReferenceText = string.Empty;
            Guid paymentId = Guid.Empty;

            //Create payments
            if (paymentMethod != null && donationRef != null)
            {
                //one time payment
                if (_submitPaymentService.ValidateIfInstantaneousPayment(paymentMethod, isContinuousPayment, paymentFrequency))
                {
                    _logger.TraceInformation($"Executing business process logics for instantenous payment.");
                    var payment = _submitPaymentService.CreatePaymentForInstantenousPayment(donationRef, transactionRef, payerRef, productRef, thirdPartyPaymentTypeReference, locationReference, channel, paymentMethod, payingInSlipNumber, paymentReferenceText, donationAmount, null, payoutDate);
                    paymentId = (Guid)(payment?.Id);
                }
                //monthly payments
                else if (_submitPaymentService.ValidateIfScheduledPayment(paymentMethod, isContinuousPayment, paymentFrequency) && _submitPaymentService.ValidateRequiredFieldsForScheduledPayment(startDate, endDate, payoutDate))
                {
                    _logger.TraceInformation($"Executing business process logics for scheduled payment.");
                    int numberOfPayments, startingPaymentNumber;
                    Money expectedPaymentAmount, expectedRemainderAmount, actualPaymentAmount, actualRemainderAmount;
                    DateTime startingDueDate;
                    (startingDueDate, expectedPaymentAmount, expectedRemainderAmount, actualPaymentAmount, actualRemainderAmount, numberOfPayments, startingPaymentNumber) = _submitPaymentService.PrepareDataForScheduledPayment(donationRef, donationAmount, null, paymentFrequency, payoutDate.Value, startDate.Value, endDate.Value);

                    var paymentSchedule = _submitPaymentService.CreatePaymentScheduleForScheduledPayment(transactionRef, donationRef, expectedPaymentAmount, actualPaymentAmount, numberOfPayments, paymentMethod, paymentFrequency, startingDueDate, startDate, endDate);
                    _submitPaymentService.LinkPaymentScheduleToMembershipForScheduledPayment(transactionId, paymentSchedule.ToEntityReference());
                    var paymentScheduleReference = paymentSchedule.ToEntityReference();

                    _submitPaymentService.CreateRecurringPaymentsForScheduledPayment(donationRef, transactionRef, paymentScheduleReference, payerRef, productRef, thirdPartyPaymentTypeReference, locationReference, channel, paymentMethod, paymentReferenceText, expectedPaymentAmount, expectedRemainderAmount, actualPaymentAmount, actualRemainderAmount, numberOfPayments, startingPaymentNumber, startingDueDate, (DateTime)startDate);
                }
            }
            _logger.TraceInformation("End CreateDonationPayment");

            return paymentId;
        }

        public void SetPaymentPaid(Guid? paymentId)
        {
            _logger.TraceInformation("Start SetPaymentPaid");

            try
            {
                if (paymentId.HasValue)
                {
                    Payment payment = new Payment()
                    {
                        Id = paymentId.Value,
                        Statecode = PaymentState.Inactive,
                        Statuscode = PaymentStatus.Inactive_Paid
                    };
                    _service.Update(payment);
                    _logger.TraceInformation($"Updated payment id: {paymentId.Value}");
                }
            }
            catch (Exception ex)
            {
                _logger.TraceError(string.Format("Error SetPaymentPaid: {0}", ex.Message));
            }
        }

        public Transaction RetrieveMembershipTransaction(Guid membershipId)
        {
            _logger.TraceInformation("Starting business logic.");

            var transaction = _transactionRepository.GetAll().Where(transaction =>
                transaction.TransactionType == NewTransactionType_GlobalOptionSet.Membership &&
                transaction.MembershipId != null && transaction.MembershipId.Id == membershipId &&
                transaction.Statecode == TransactionState.Active).FirstOrDefault();

            _logger.TraceInformation("Ending business logic.");
            return transaction;
        }
    }
}