﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICirrusPaymentService
    {
        Task<string> CallAzureFunctionAsync(string functionUrl);
        string? BuildCirrusURL(Entity entityId, Entity payer, string functionUrl, Money totalAmount, string CirrusUsername);
        Transaction RetrieveActiveTransactions(Entity entity);
        string? RetrieveActivePayments(Transaction transactionId);
        string? RetrieveEntityNumber(Entity entity);
    }
    public class CirrusPaymentService : ICirrusPaymentService
    {
        private readonly ILogger _logger;
        private IOrganizationService _service;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;

        public CirrusPaymentService(ILogger logger, IOrganizationService service, IRepository<Transaction> transactionRepository, IRepository<Payment> paymentRepository)
        {
            _logger = logger;
            _service = service;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
        }

        public string BuildCirrusURL(Entity entityId, Entity payer, string functionUrl, Money totalAmount, string CirrusUsername)
        {
            string response = CallAzureFunctionAsync(functionUrl).Result;
            var responseJson = JsonConvert.DeserializeObject<Dictionary<string, string>>(response);

            string CirrusPwdKey = responseJson["CirrusPwdKey"];
            string CirrusBaseUrlKey = responseJson["CirrusPCIBaseUrlKey"];
            _logger.TraceInformation($"Response result for Azure Key Vault at: {responseJson}");
            
            // Retrieve payer details
            var postalCode = payer.GetAttributeValue<string>("address1_postalcode");
            var addressLine1 = payer.GetAttributeValue<string>("address1_line1");

            if (CirrusBaseUrlKey.Substring(CirrusBaseUrlKey.Length - 1) != "?")
            CirrusBaseUrlKey += "?";

            Transaction transactionRecord = RetrieveActiveTransactions(entityId);
            var transactionId = transactionRecord.TransacID;
            _logger.TraceInformation($"Transaction ID: {transactionId}");

            var paymentID = RetrieveActivePayments(transactionRecord);
            _logger.TraceInformation($"Payment ID: {paymentID}");

            int amountInPence = (int)(totalAmount.Value * 100);
            _logger.TraceInformation($"Amount in Pence: {amountInPence}");
            
            string entityName = RetrieveEntityNumber(entityId);

            var parameters = new Dictionary<string, object>
            {
                { "usr", CirrusUsername },
                { "pwd", CirrusPwdKey },
                { "cc.description", entityName },
                { "customer.address.line1", addressLine1 },
                { "customer.address.postal_code", postalCode },
                { "cc.result.detailed.other_transaction_id", null },
                { "cc.transaction_reference", transactionId },
                { "cc.amount", amountInPence },
                { "psp.stripe.metadata.payment.id", paymentID},
                { "psp.stripe.metadata.transaction.id", transactionId },
                { "psp.stripe.metadata.POSTTXURL", null }
            };


            // Filter out nulls and encode
            string queryString = string.Join("&", parameters
                .Where(kv => kv.Value != null)
                .Select(kv => $"{Uri.EscapeDataString(kv.Key)}={Uri.EscapeDataString(kv.Value.ToString())}"));

            var finalURL = CirrusBaseUrlKey + queryString;
            _logger.TraceInformation($"Final Cirrus URL: {finalURL}");
            return finalURL;
        }
        public async Task<string> CallAzureFunctionAsync(string functionUrl)
        {
            using (HttpClient client = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
                client.Timeout = TimeSpan.FromSeconds(120);  // Timeout is 120 seconds

                try
                {
                    _logger.TraceInformation($"Making HTTP POST request to: {functionUrl}");

                    DateTime requestStartTime = DateTime.Now;
                    _logger.TraceInformation($"Request sent at: {requestStartTime}");

                    var response = await client.GetAsync(functionUrl);

                    DateTime requestEndTime = DateTime.Now;
                    _logger.TraceInformation($"Request completed at: {requestEndTime}");
                    _logger.TraceInformation($"Request duration: {(requestEndTime - requestStartTime).TotalSeconds} seconds");

                    if (!response.IsSuccessStatusCode)
                    {
                        string errorResponse = await response.Content.ReadAsStringAsync();
                        _logger.TraceInformation($"Azure Function call failed with status: {response.StatusCode}. Response: {errorResponse}");
                        throw new Exception($"Azure Function call failed with status {response.StatusCode}. Response: {errorResponse}");
                    }

                    string successfulResponse = await response.Content.ReadAsStringAsync();
                    _logger.TraceInformation($"Azure Function call succeeded with status: {response.StatusCode}. Response: {successfulResponse}");

                    return successfulResponse;
                }
                catch (Exception ex)
                {
                    _logger.TraceInformation($"Error calling Azure Function: {ex.Message}");
                    if (ex.InnerException != null)
                    {
                        _logger.TraceInformation($"Inner Exception: {ex.InnerException.Message}");
                        _logger.TraceInformation($"Inner Exception StackTrace: {ex.InnerException.StackTrace}");
                    }
                    _logger.TraceInformation($"Error StackTrace: {ex.StackTrace}");
                    throw;
                }
            }
        }

        public Transaction RetrieveActiveTransactions(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving transaction of entity.");
            List<Transaction> transactionsOfEntity = null;

            switch (entity.LogicalName)
            {
                case "rhs_membership":
                    transactionsOfEntity = _transactionRepository.GetAll().Where(transaction =>
                        transaction.MembershipId != null && transaction.MembershipId.Id == entity.Id &&
                        (transaction.Statecode == TransactionState.Active || transaction.Statuscode == TransactionStatus.Inactive_Paid)
                    ).ToList();
                    break;
                case "rhs_subscription":
                    transactionsOfEntity = _transactionRepository.GetAll().Where(transaction =>
                        transaction.SubscriptionId != null && transaction.SubscriptionId.Id == entity.Id &&
                        (transaction.Statecode == TransactionState.Active || transaction.Statuscode == TransactionStatus.Inactive_Paid)
                    ).ToList();
                    break;
                case "rhs_donation":
                    transactionsOfEntity = _transactionRepository.GetAll().Where(transaction =>
                        transaction.Donation != null && transaction.Donation.Id == entity.Id &&
                        (transaction.Statecode == TransactionState.Active || transaction.Statuscode == TransactionStatus.Inactive_Paid)
                    ).ToList();
                    break;
                case "rhs_giftpackorder":
                    transactionsOfEntity = _transactionRepository.GetAll().Where(transaction =>
                        transaction.Giftpackorder != null && transaction.Giftpackorder.Id == entity.Id &&
                        (transaction.Statecode == TransactionState.Active || transaction.Statuscode == TransactionStatus.Inactive_Paid)
                    ).ToList();
                    break;
            }

            _logger.TraceInformation($"Retrieved {transactionsOfEntity.Count} Transactions.");

            _logger.TraceInformation($"Ending business logic.");
            if (transactionsOfEntity.Count == 0)
                return null;
            else
                return transactionsOfEntity.First();
        }

        public string RetrieveActivePayments(Transaction transactionId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving payment of entity.");
            List<Payment> paymentsOfEntity = _paymentRepository.GetAll().Where(payment =>
                        payment.Transaction.Id == transactionId.Id &&
                        payment.Statecode == PaymentState.Active).OrderBy(payment => payment.DueDate).ToList();

            
            _logger.TraceInformation($"Retrieved {paymentsOfEntity.Count} Payments.");

            _logger.TraceInformation($"Ending business logic.");
            if (paymentsOfEntity.Count == 0)
                return null;
            else
                return paymentsOfEntity.First().PaymentsID;
        }

        public string RetrieveEntityNumber(Entity entity)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving details of entity.");
            string entityNumber = null;
            switch (entity.LogicalName)
            {
                case "rhs_membership":
                    entityNumber = "Payment for Membership #" + entity.GetAttributeValue<string>("msnfp_name");
                    break;
                case "rhs_subscription":
                    entityNumber = "Payment for Subscription #" + entity.GetAttributeValue<string>("rhs_number");
                    break;
                case "rhs_donation":
                    entityNumber = "Payment for Donation #" + entity.GetAttributeValue<string>("rhs_name");
                    break;
                case "rhs_giftpackorder":
                    entityNumber = "Payment for GiftPackOrder #" + entity.GetAttributeValue<string>("rhs_name");
                    break;
            }

            _logger.TraceInformation($"Retrieved {entityNumber}.");
            return entityNumber;
        }
    }
}
