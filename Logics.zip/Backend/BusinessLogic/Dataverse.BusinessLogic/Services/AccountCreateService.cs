﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;

namespace Cultivate.BusinessLogic.Services
{
    public interface IAccountCreateService
    {
        void SetRandomAccountNumber(Account account);
        void PopulateGDPRDeletionDate(Account account);
        void SetLatLongCountyAddress12(Account account);
    }

    public class AccountCreateService : IAccountCreateService
    {
        private readonly ITracingService _tracingService;
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;
        private readonly IPluginExecutionContext _context;
        private readonly IRepository<Account> _accountRepository;
        private ICommonService _commonService;

        public AccountCreateService(
           ITracingService tracingService, ILogger logger,
           IOrganizationService service,
           IPluginExecutionContext context,
           IRepository<Account> accountRepository,
           ICommonService commonService
        )
        {
            _tracingService = tracingService;
            _logger = logger;
            _service = service;
            _context = context;
            _accountRepository = accountRepository;
            _commonService = commonService;
        }

        public void SetRandomAccountNumber(Account account)
        {
            _logger.TraceInformation($"SetRandomAccountNumber Start");

            if (account != null)
            {
                // Generate random number
                Random rnd = new Random();
                int accountNumber = rnd.Next(10000000, 100000000);

                // Set Account Number
                account.AccountNumber = accountNumber.ToString();

            }

            _logger.TraceInformation($"SetRandomAccountNumber End");
        }

        public void PopulateGDPRDeletionDate(Account account)
        {
            _logger.TraceInformation($"PopulateGDPRDeletionDate Start");

            if (account != null)
            {
                // Get GDPR configuration settings
                GDPRConfigurationSettings configSettings = _commonService.getGDPRConfiguration(new OptionSetValue((int)Entitynamegdprcode_GlobalOptionSet.Accounts));

                if (configSettings != null && configSettings.RetentionPeriod != null)
                {
                    // Set GDPR Deletion Date
                    account.GDPRDeletionDate = DateTime.Now.AddDays(Convert.ToDouble(configSettings.RetentionPeriod));
                }
            }

            _logger.TraceInformation($"PopulateGDPRDeletionDate End");
        }

        public void SetLatLongCountyAddress12(Account account)
        {
            _logger.TraceInformation($"SetLatLongCountyAddress12 Start");

            if (account != null)
            {
                var updateAccount = new Entity(Account.EntityLogicalName, account.Id);

                // Address 1
                if (string.IsNullOrWhiteSpace(account.Loqate_Latitude))
                    updateAccount[EntityNames.Account.Address1_Latitude] = Convert.ToDouble(account.Loqate_Latitude);
                if (string.IsNullOrWhiteSpace(account.Loqate_Longitude))
                    updateAccount[EntityNames.Account.Address1_Longitude] = Convert.ToDouble(account.Loqate_Longitude);
                if (string.IsNullOrWhiteSpace(account.LoqateAddress1County))
                    updateAccount[EntityNames.Account.Address1_County] = account.LoqateAddress1County;
                if (string.IsNullOrWhiteSpace(account.LoqateAddress1HouseName))
                    updateAccount[EntityNames.Account.Address1_Name] = account.LoqateAddress1HouseName;

                // Address 2
                if (string.IsNullOrWhiteSpace(account.LoqateAddress2Latitude))
                    updateAccount[EntityNames.Account.Address2_Latitude] = Convert.ToDouble(account.LoqateAddress2Latitude);
                if (string.IsNullOrWhiteSpace(account.LoqateAddress2Longitude))
                    updateAccount[EntityNames.Account.Address2_Longitude] = Convert.ToDouble(account.LoqateAddress2Longitude);
                if (string.IsNullOrWhiteSpace(account.LoqateAddress2County))
                    updateAccount[EntityNames.Account.Address2_County] = account.LoqateAddress2County;
                if (string.IsNullOrWhiteSpace(account.LoqateAddress2HouseName))
                    updateAccount[EntityNames.Account.Address2_Name] = account.LoqateAddress2HouseName;

                _service.Update(updateAccount);
            }

            _logger.TraceInformation($"SetLatLongCountyAddress12 End");

        }

    }
}