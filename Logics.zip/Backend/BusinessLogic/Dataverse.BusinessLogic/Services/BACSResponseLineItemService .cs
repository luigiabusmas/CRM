﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface IBACSResponseLineItemService
    {
        Directdebitdetails RetrieveDirectDebitDetail(string reference);
        Entity RetrieveAssociatedProduct(Directdebitdetails directDebitDetail);
        Bacsreasoncodeconfiguration RetrieveBACSReasonCodeConfiguration(string bacsReasonCode, BACSFile_GlobalOptionSet? backsFile);
        void PerformBACSResponseActionForAUDDIS(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration);
        void PerformBACSResponseActionForADDACS(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration);
        void PerformBACSResponseActionForARUDD(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration);
        void PopulateProductValue(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct);
    }

    public class BACSResponseLineItemService : IBACSResponseLineItemService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRepository<BACSResponse> _bacsResponseRepository;
        private IRepository<BACSResponseLineItem> _bacsResponseLineItemRepository;
        private IRepository<Directdebitdetails> _directDebitDetailsRepository;
        private IRepository<Bacsreasoncodeconfiguration> _bacsReasonCodeConfigurationRepository;
        private IRepository<Cultivateconfigurations> _cultivateConfigurationRepository;
        private IRepository<Team> _teamRepository;
        private IRepository<Task> _taskRepository;
        private IRepository<Entities.Generated.Membership> _membershipRepository;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<PaymentSchedule> _paymentScheduleRepository;
        private IRepository<Payment> _paymentRepository;
        private IRepository<Giftaidrefund> _giftAidRefundRepository;
        private ICancelDDService _cancelDDService;

        public BACSResponseLineItemService(ILogger logger, IOrganizationService service,
            IRepository<BACSResponse> bacsResponseRepository, IRepository<BACSResponseLineItem> bacsResponseLineItemRepository, IRepository<Bacsreasoncodeconfiguration> bacsReasonCodeConfigurationRepository,
            IRepository<Cultivateconfigurations> cultivateConfigurationRepository, IRepository<Team> teamRepository, IRepository<Task> taskRepository,
            IRepository<Directdebitdetails> directDebitDetailsRepository, IRepository<Entities.Generated.Membership> membershipRepository,
            IRepository<Transaction> transactionRepository, IRepository<PaymentSchedule> paymentScheduleRepository, IRepository<Payment> paymentRepository, IRepository<Giftaidrefund> giftAidRefundRepository,
            ICancelDDService cancelDDService
        )
        {
            _logger = logger;
            _service = service;
            _bacsResponseRepository = bacsResponseRepository;
            _bacsResponseLineItemRepository = bacsResponseLineItemRepository;
            _bacsReasonCodeConfigurationRepository = bacsReasonCodeConfigurationRepository;
            _directDebitDetailsRepository = directDebitDetailsRepository;
            _cultivateConfigurationRepository = cultivateConfigurationRepository;
            _teamRepository = teamRepository;
            _taskRepository = taskRepository;
            _membershipRepository = membershipRepository;
            _transactionRepository = transactionRepository;
            _paymentScheduleRepository = paymentScheduleRepository;
            _paymentRepository = paymentRepository;
            _giftAidRefundRepository = giftAidRefundRepository;
            _cancelDDService = cancelDDService;
        }

        #region Deprecated
        /*public void PerformBACSResponseActionForAUDDISAndADDACS(Entity bacs)
        {
            try
            {
                _logger.TraceInformation($"Starting business logic.");

                var targetBACS = bacs.ToEntity<BACSResponseLineItem>();

                if (targetBACS.ErrorRejectionCode == null)
                {
                    _logger.TraceInformation($"Return : Error code is null.");

                    return;
                }

                if (targetBACS.BACSFile == null)
                {
                    _logger.TraceInformation($"Return : BACS File is null.");

                    return;
                }

                if (targetBACS.BACSFile == BACSFile_GlobalOptionSet.AUDDIS || targetBACS.BACSFile == BACSFile_GlobalOptionSet.ADDACS && targetBACS.ErrorRejectionCode != null)
                {

                    List<Entity> bacsCodeCollection = RetrieveBACSReasonCode(bacs);
                    string reasonCode;
                    int responseAction = 0;
                    int? paymentMethod = null;
                    string membershipUpdate = null;
                    bool createTask = false;
                    string description = String.Empty;

                    foreach (Entity bacsCode in bacsCodeCollection)
                    {
                        reasonCode = bacsCode[EntityNames.Bacsreasoncodeconfiguration.Name].ToString();
                        responseAction = ((OptionSetValue)bacsCode[EntityNames.Bacsreasoncodeconfiguration.BACSResponseAction]).Value;
                        paymentMethod = bacsCode.Contains(EntityNames.Bacsreasoncodeconfiguration.PaymentMethod) ? ((OptionSetValue)bacsCode[EntityNames.Bacsreasoncodeconfiguration.PaymentMethod]).Value : (int?)null;
                        membershipUpdate = bacsCode.Contains(EntityNames.Bacsreasoncodeconfiguration.MembershipStatusUpdate) ? bacsCode[EntityNames.Bacsreasoncodeconfiguration.MembershipStatusUpdate].ToString() : null;
                        createTask = (bool)bacsCode[EntityNames.Bacsreasoncodeconfiguration.CreateTask];
                    }

                    _logger.TraceInformation("Retrieving Direct Debit Record");
                    var queryDirectDebit = new QueryExpression(EntityNames.Directdebitdetails.EntityLogicalName);
                    queryDirectDebit.ColumnSet.AddColumns(EntityNames.Directdebitdetails.Membership, EntityNames.Directdebitdetails.Subscription, EntityNames.Directdebitdetails.Reference, EntityNames.Directdebitdetails.Name, EntityNames.Directdebitdetails.DDISubmissionStatus);
                    queryDirectDebit.Criteria.AddCondition(EntityNames.Directdebitdetails.Reference, ConditionOperator.Equal, targetBACS.Name);
                    var directDebitCollections = _service.RetrieveMultiple(queryDirectDebit).Entities.ToList();
                    Entity directDebitRecord = new Entity();

                    foreach (Entity directDebit in directDebitCollections)
                    {
                        string isProductType = String.Empty;
                        EntityReference membershipReference = new EntityReference();
                        EntityReference subscriptionReference = new EntityReference();
                        bool isActive = false;
                        string ddRef = String.Empty;
                        string accountHolder = String.Empty;
                        directDebitRecord = directDebit;

                        if (directDebit != null)
                        {
                            ddRef = directDebit[EntityNames.Directdebitdetails.Reference].ToString();
                            accountHolder = directDebit[EntityNames.Directdebitdetails.Name].ToString();

                            if (directDebit.GetAttributeValue<EntityReference>(EntityNames.Directdebitdetails.MembershipId) != null)
                            {
                                isProductType = "IsMembership";
                                membershipReference = (EntityReference)directDebit[EntityNames.Directdebitdetails.MembershipId];
                                isActive = CheckIfMembershipIsActive(isActive, membershipReference);
                            }
                            if (directDebit.GetAttributeValue<EntityReference>(EntityNames.Directdebitdetails.Subscription) != null)
                            {
                                isProductType = "isSubscription";
                                subscriptionReference = (EntityReference)directDebit[EntityNames.Directdebitdetails.Subscription];
                                isActive = CheckIfSubscriptionIsActive(isActive, subscriptionReference);
                            }
                        }

                        //retrieve transaction
                        var queryTransaction = new QueryExpression(EntityNames.Transaction.EntityLogicalName);
                        queryTransaction.ColumnSet.AddColumns(EntityNames.Transaction.Statecode, EntityNames.Transaction.Statuscode, EntityNames.Transaction.Product, EntityNames.Transaction.PaymentMethodCode, EntityNames.Transaction.MembershipId, EntityNames.Transaction.SubscriptionId, EntityNames.Transaction.TransactionType);
                        switch (isProductType)
                        {
                            case "IsMembership":
                                queryTransaction.Criteria.AddCondition(EntityNames.Transaction.MembershipId, ConditionOperator.Equal, membershipReference.Id);
                                break;
                            case "isSubscription":
                                queryTransaction.Criteria.AddCondition(EntityNames.Transaction.SubscriptionId, ConditionOperator.Equal, subscriptionReference.Id);
                                break;
                            default:
                                _logger.TraceInformation("product type is null");
                                break;
                        }
                        EntityCollection transactionCollections = _service.RetrieveMultiple(queryTransaction);
                        Guid transactionId = Guid.Empty;
                        int transactionType = 0;
                        Entity transactionRecord = new Entity();
                        foreach (Entity transaction in transactionCollections.Entities)
                        {
                            transactionId = transaction.Id;
                            transactionType = ((OptionSetValue)transaction[EntityNames.Transaction.TransactionType]).Value;
                            transactionRecord = transaction;
                        }

                        ////retrieve all payment records
                        var queryAllPayments = new QueryExpression(EntityNames.Payment.EntityLogicalName);
                        queryAllPayments.ColumnSet.AddColumns(EntityNames.Payment.PaymentId, EntityNames.Payment.Transaction, EntityNames.Payment.Product, EntityNames.Payment.Statuscode, EntityNames.Payment.Statecode, EntityNames.Payment.Product, EntityNames.Payment.PaymentSchedule);
                        queryAllPayments.Criteria.AddCondition(EntityNames.Payment.Transaction, ConditionOperator.Equal, transactionId);
                        List<Entity> allPaymentsCollection = _service.RetrieveMultiple(queryAllPayments).Entities.ToList<Entity>();
                        if (isActive)
                        {
                            UpdateOrCancelActiveTransactionAndPayments(responseAction, allPaymentsCollection, transactionId, targetBACS, directDebitRecord);
                            UpdatePaymentMethod(transactionRecord, targetBACS, paymentMethod, transactionType);
                            MembershipStatusUpdate(transactionRecord, membershipUpdate, transactionType);
                        }
                        else
                        {

                            description = "Required action can not be performed as associated product is already Cancelled.";
                            CreateTask(description);
                            int ddiSubmissionStatus = 0;

                            ddiSubmissionStatus = ((OptionSetValue)directDebitRecord[EntityNames.Directdebitdetails.DDISubmissionStatus]).Value;

                            var updateDirectDebit = new Entity(EntityNames.Directdebitdetails.EntityLogicalName);
                            updateDirectDebit.Id = directDebitRecord.Id;
                            updateDirectDebit[EntityNames.Directdebitdetails.BACSError] = new EntityReference(EntityNames.BACSResponseLineItem.EntityLogicalName, targetBACS.Id);
                            if (ddiSubmissionStatus == 120000001)
                            {
                                updateDirectDebit[EntityNames.Directdebitdetails.DDISubmissionStatus] = new OptionSetValue(120000002);

                            }
                            _service.Update(updateDirectDebit);
                        }

                        if (createTask)
                        {
                            var taskDescription = string.Join("\n",
                                $"Reason Code: {targetBACS.ErrorRejectionCode}",
                                $"DD Reference: {ddRef}",
                                $"Name of Account Holder: {accountHolder}",
                                $"BACS File: {targetBACS.BACSFile.Value.ToString()}");
                            CreateTask(taskDescription);
                        }
                    }
                }

                _logger.TraceInformation($"Ending business logic.");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }*/

        private bool CheckIfMembershipIsActive(bool isActive, EntityReference membershipId)
        {
            try
            {
                int statuscode = 0;
                Entity retrieveRecord = _service.Retrieve(EntityNames.Membership.EntityLogicalName, membershipId.Id, new ColumnSet(true));
                if (retrieveRecord != null)
                {
                    statuscode = ((OptionSetValue)retrieveRecord[EntityNames.Membership.Statuscode]).Value;
                    if (statuscode == 1)
                    {
                        isActive = true;
                    }
                }
                return isActive;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool CheckIfSubscriptionIsActive(bool isActive, EntityReference subscriptionId)
        {
            try
            {
                int statecode = 0;
                Entity retrieveRecord = _service.Retrieve(EntityNames.Membership.EntityLogicalName, subscriptionId.Id, new ColumnSet(true));
                if (retrieveRecord != null)
                {
                    statecode = ((OptionSetValue)retrieveRecord["rhs_subscription"]).Value;
                    if (statecode == 0)
                    {
                        isActive = true;
                    }
                }
                return isActive;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        //Commented by JMM 1/15/2026
        /*private List<Entity> RetrieveBACSReasonCode(Entity bacs)
        {
            var targetBACS = bacs.ToEntity<BACSResponseLineItem>();
            string bacsFile = targetBACS.FormattedValues[EntityNames.BACSResponseLineItem.BACSFile].ToString();
            int bacsFileOptionSetValue = 0;

            switch (bacsFile)
            {
                case "AUDDIS":
                    bacsFileOptionSetValue = 120000000;
                    break;
                case "ADDACS":
                    bacsFileOptionSetValue = 120000001;
                    break;
                case "ARUDD":
                    bacsFileOptionSetValue = 120000002;
                    break;
                default:
                    _logger.TraceInformation("bacs file is empty");
                    break;
            }

            _logger.TraceInformation("Retrieving BACS Reason Code Configuration");
            var query = new QueryExpression(EntityNames.Bacsreasoncodeconfiguration.EntityLogicalName);
            query.ColumnSet.AddColumns(EntityNames.Bacsreasoncodeconfiguration.Name, EntityNames.Bacsreasoncodeconfiguration.PaymentMethod, EntityNames.Bacsreasoncodeconfiguration.CreateTask, EntityNames.Bacsreasoncodeconfiguration.MembershipStatusUpdate, EntityNames.Bacsreasoncodeconfiguration.BACSResponseAction);
            query.Criteria.AddCondition(EntityNames.Bacsreasoncodeconfiguration.Name, ConditionOperator.Equal, targetBACS.ErrorRejectionCode);
            query.Criteria.AddCondition(EntityNames.Bacsreasoncodeconfiguration.BACSFile, ConditionOperator.Equal, bacsFileOptionSetValue);
            var bacsReasonCodeCollection = _service.RetrieveMultiple(query).Entities.ToList();

            if (bacsReasonCodeCollection.Count == 0)
                throw new InvalidPluginExecutionException($"Missing BACS Reason code value. Please reach out to an administrator to fix this.");

            return bacsReasonCodeCollection;
        }*/

        private void CreateTask(string description)
        {
            _logger.TraceInformation("Retrieving Cultivate Configurations");
            var query = new QueryExpression(EntityNames.Cultivateconfigurations.EntityLogicalName);
            query.ColumnSet.AddColumns(EntityNames.Cultivateconfigurations.Name, EntityNames.Cultivateconfigurations.Value);
            query.Criteria.AddCondition("rhs_name", ConditionOperator.Equal, "BACSTaskOwnerTeam");
            var cultivateConfigurations = _service.RetrieveMultiple(query).Entities.ToList();
            string teamName = cultivateConfigurations.First().GetAttributeValue<string>(EntityNames.Cultivateconfigurations.Value);
            Guid teamId = GetTeamIdByName(teamName);

            Entity task = new Entity("task");
            task["description"] = description;
            task["ownerid"] = new EntityReference("team", teamId);
            _service.Create(task);
        }

        private Guid GetTeamIdByName(string teamName)
        {
            _logger.TraceInformation("Retrieving Membership Team");
            var query = new QueryExpression("team");
            query.ColumnSet.AddColumns("teamid");
            query.Criteria.AddCondition("name", ConditionOperator.Equal, teamName);
            EntityCollection result = _service.RetrieveMultiple(query);

            return result.Entities[0].GetAttributeValue<Guid>("teamid");
        }

        private void UpdateOrCancelActiveTransactionAndPayments(int responseAction, List<Entity> paymentCollection, Guid transactionId, BACSResponseLineItem bacs, Entity directdebit)
        {
            try
            {
                // if Response Action is Cancel
                if (responseAction == 120000000)
                {
                    foreach (Entity payment in paymentCollection)
                    {
                        //update all payments
                        var updatePayment = new Entity(payment.LogicalName, payment.Id);
                        updatePayment[EntityNames.Payment.Statecode] = new OptionSetValue(1);
                        updatePayment[EntityNames.Payment.Statuscode] = new OptionSetValue(120000004);
                        _service.Update(updatePayment);

                        //update payment schedule
                        EntityReference paymentScheduleRef = payment.Contains(EntityNames.Payment.PaymentSchedule) ? (EntityReference)payment[EntityNames.Payment.PaymentSchedule] : null;
                        if (paymentScheduleRef != null)
                        {
                            var updatePaymentSchedule = new Entity(EntityNames.PaymentSchedule.EntityLogicalName, ((EntityReference)payment[EntityNames.Payment.PaymentSchedule]).Id);
                            updatePaymentSchedule[EntityNames.PaymentSchedule.Statecode] = new OptionSetValue(1);
                            updatePaymentSchedule[EntityNames.PaymentSchedule.Statuscode] = new OptionSetValue(120000003);
                            _service.Update(updatePaymentSchedule);
                        }
                    }

                    if (transactionId != Guid.Empty)
                    {
                        var updateTransaction = new Entity(EntityNames.Transaction.EntityLogicalName);
                        updateTransaction.Id = transactionId;
                        updateTransaction[EntityNames.Transaction.Statecode] = new OptionSetValue(1);
                        updateTransaction[EntityNames.Transaction.Statuscode] = new OptionSetValue(2);
                        _service.Update(updateTransaction);

                        var updateDirectDebit = new Entity(EntityNames.Directdebitdetails.EntityLogicalName);
                        updateDirectDebit.Id = directdebit.Id;
                        updateDirectDebit[EntityNames.Directdebitdetails.BACSError] = new EntityReference(EntityNames.BACSResponseLineItem.EntityLogicalName, bacs.Id);
                        updateDirectDebit[EntityNames.Directdebitdetails.Statuscode] = new OptionSetValue(120000004);
                        updateDirectDebit[EntityNames.Directdebitdetails.Statecode] = new OptionSetValue(1);
                        _service.Update(updateDirectDebit);
                    }
                }
                // if Response Action is Update
                else if (responseAction == 120000001)
                {
                    //do
                    if (directdebit != null)
                    {
                        var updateDirectDebit = new Entity(EntityNames.Directdebitdetails.EntityLogicalName);
                        updateDirectDebit.Id = directdebit.Id;
                        updateDirectDebit[EntityNames.Directdebitdetails.Name] = bacs.NewPayerName;
                        updateDirectDebit[EntityNames.Directdebitdetails.BranchAccountNumber] = bacs.NewAccountNumber;
                        updateDirectDebit[EntityNames.Directdebitdetails.BranchSortCode] = bacs.NewSortCode;
                        updateDirectDebit[EntityNames.Directdebitdetails.BACSError] = new EntityReference(EntityNames.BACSResponseLineItem.EntityLogicalName, bacs.Id);
                        _service.Update(updateDirectDebit);
                    }
                }

                // if response Action is Reverse Transaction
                else if (responseAction == 120000002)
                {
                    //do 
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void UpdatePaymentMethod(Entity transaction, BACSResponseLineItem bacs, int? paymentMethod, int transactionType)

        {
            try
            {
                int bacsFile = ((OptionSetValue)bacs[EntityNames.Bacsreasoncodeconfiguration.BACSFile]).Value;
                Entity membershipRecord = _service.Retrieve(EntityNames.Membership.EntityLogicalName, ((EntityReference)transaction[EntityNames.Transaction.MembershipId]).Id, new ColumnSet(true));

                //Transaction Type eq Membership
                if (transactionType == 120000002 && paymentMethod != null)
                {
                    //Update payment method to Cash
                    var updateMembership = new Entity(EntityNames.Membership.EntityLogicalName, ((EntityReference)transaction[EntityNames.Transaction.MembershipId]).Id);
                    updateMembership[EntityNames.Membership.PaymentMethod] = new OptionSetValue(844060000);
                    _service.Update(updateMembership);
                }
                //Transaction Type eq Subscription
                else if (transactionType == 120000003 && paymentMethod != null)
                {
                    //Update payment method to Cash
                    var updateMembership = new Entity(EntityNames.Membership.EntityLogicalName, ((EntityReference)transaction[EntityNames.Transaction.SubscriptionId]).Id);
                    updateMembership[EntityNames.Membership.PaymentMethod] = new OptionSetValue(844060000);
                    _service.Update(updateMembership);
                }
                //Transaction Type eq Gift Pack
                else if (transactionType == 120000001 && paymentMethod != null)
                {
                    //do
                }
                //Transaction Type eq Donation
                else if (transactionType == 120000000)
                {
                    //do
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void MembershipStatusUpdate(Entity transaction, string membershipUpdate, int transactionType)
        {
            try
            {
                if (string.IsNullOrEmpty(membershipUpdate))
                {
                    return;
                }

                Money outstandingAmt;
                Entity membershipRecord = _service.Retrieve(EntityNames.Membership.EntityLogicalName, ((EntityReference)transaction[EntityNames.Transaction.MembershipId]).Id, new ColumnSet(true));

                outstandingAmt = (Money)membershipRecord[EntityNames.Membership.OutstandingAmount];

                //Transaction Type eq Membership
                if (transactionType == 120000002 && !string.IsNullOrEmpty(membershipUpdate))
                {
                    if (membershipUpdate == "Prospect")
                    {
                        var updateMembership = new Entity(EntityNames.Membership.EntityLogicalName);
                        updateMembership.Id = membershipRecord.Id;
                        updateMembership[EntityNames.Membership.Statuscode] = new OptionSetValue(120000000);
                        _service.Update(updateMembership);
                    }
                    else if (membershipUpdate == "Pending Payment")
                    {
                        if (outstandingAmt.Value > 0)
                        {
                            var updateMembership = new Entity(EntityNames.Membership.EntityLogicalName);
                            updateMembership.Id = membershipRecord.Id;
                            updateMembership[EntityNames.Membership.Statuscode] = new OptionSetValue(120000003);
                            _service.Update(updateMembership);

                            EntityReference payerReference = (EntityReference)membershipRecord[EntityNames.Membership.PayerV2];
                            string payerName = payerReference.Name;

                            string description = $"Please follow up with the payer: {payerName}";

                            if (payerReference != null)
                            {
                                CreateTask(description);
                            }
                        }
                    }
                }
                //Transaction Type eq Subscription
                else if (transactionType == 120000003 && !string.IsNullOrEmpty(membershipUpdate))
                {
                    //Update payment method to Cash

                }
                //Transaction Type eq Gift Pack
                else if (transactionType == 120000001 && !string.IsNullOrEmpty(membershipUpdate))
                {
                    //do
                }
                //Transaction Type eq Donation
                else if (transactionType == 120000000 && !string.IsNullOrEmpty(membershipUpdate))
                {
                    //do
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        #endregion

        #region Business Logics
        public Directdebitdetails RetrieveDirectDebitDetail(string reference)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Reference = {reference}.");

            _logger.TraceInformation($"Retrieving Direct Debit Details using Reference.");
            var directDebitDetails = _directDebitDetailsRepository.GetAll().Where(directDebitDetail => directDebitDetail.Reference == reference && directDebitDetail.Statecode == DirectdebitdetailsState.Active).ToList();
            _logger.TraceInformation($"Retrieved {directDebitDetails.Count} Direct Debit Details.");

            _logger.TraceInformation($"Ending business logic.");
            if (directDebitDetails.Count == 0)
                return null;
            else
                return directDebitDetails.First();
        }

        public Entity RetrieveAssociatedProduct(Directdebitdetails directDebitDetail)
        {
            _logger.TraceInformation($"Starting business logic.");
            Entity associatedProduct = null;

            if (directDebitDetail.MembershipId != null)
            {
                associatedProduct = _service.Retrieve(directDebitDetail.MembershipId.LogicalName, directDebitDetail.MembershipId.Id, new ColumnSet(true));
            }
            else if (directDebitDetail.Subscription != null)
            {
                associatedProduct = _service.Retrieve(directDebitDetail.Subscription.LogicalName, directDebitDetail.Subscription.Id, new ColumnSet(true));
            }
            else if (directDebitDetail.Donation != null)
            {
                associatedProduct = _service.Retrieve(directDebitDetail.Donation.LogicalName, directDebitDetail.Donation.Id, new ColumnSet(true));
            }
            _logger.TraceInformation($"Associated Product Entity = {associatedProduct?.LogicalName}.");

            _logger.TraceInformation($"Ending business logic.");
            return associatedProduct;
        }

        public Bacsreasoncodeconfiguration RetrieveBACSReasonCodeConfiguration(string bacsReasonCode, BACSFile_GlobalOptionSet? backsFile)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"BACS Reason Code = {bacsReasonCode}");
            _logger.TraceInformation($"BACS File = {backsFile}.");

            _logger.TraceInformation($"Retrieving BACS Reason Code Configurations using BACS Reason Code and BACS File.");
            var bacsReasonCodeConfigurations = _bacsReasonCodeConfigurationRepository.GetAll().Where(bacsReasonCodeConfiguration =>
                bacsReasonCodeConfiguration.Name == bacsReasonCode && bacsReasonCodeConfiguration.BACSFile == backsFile).ToList();
            _logger.TraceInformation($"Retrieved {bacsReasonCodeConfigurations.Count} BACS Reason Code Configurations.");

            _logger.TraceInformation($"Ending business logic.");
            if (bacsReasonCodeConfigurations.Count == 0)
                return null;
            else
                return bacsReasonCodeConfigurations.First();
        }

        public void PerformBACSResponseActionForAUDDIS(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration)
        {
            _logger.TraceInformation($"Starting business logic.");
            var updateOnDirectDebitDetail = new Directdebitdetails() { Id = directDebitDetail.Id };
            var updateOnAssociatedProduct = new Entity(associatedProduct.LogicalName, associatedProduct.Id);

            var statusReason = associatedProduct.GetAttributeValue<OptionSetValue>("statuscode")?.Value;
            _logger.TraceInformation($"Status Reason = {statusReason}.");
            if (statusReason == 1/*Active*/)
            {
                _logger.TraceInformation($"BACS Response Action = {bacsReasonCodeConfiguration.BACSResponseAction}.");

                //Converted to Flow
                /*switch (bacsReasonCodeConfiguration.BACSResponseAction)
                {
                    case BACSResponseActions_GlobalOptionSet.CancelInstruction:
                        CancelInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail, associatedProduct);
                        break;
                    case BACSResponseActions_GlobalOptionSet.UpdateInstruction:
                        UpdateInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                        break;
                }

                SetPaymentMethod(ref updateOnAssociatedProduct, bacsReasonCodeConfiguration, associatedProduct); */
                UpdateMembershipStatus(ref updateOnAssociatedProduct, bacsResponseLineItem, directDebitDetail,associatedProduct, bacsReasonCodeConfiguration);
                CreateTask(bacsResponseLineItem, bacsReasonCodeConfiguration, directDebitDetail);
                //SetDDISubmissionStatus(ref updateOnDirectDebitDetail,bacsResponseLineItem, directDebitDetail);

                //_logger.TraceInformation($"Updating Direct Debit Detail and Associated Product.");
                //_directDebitDetailsRepository.Update(updateOnDirectDebitDetail);
                //_service.Update(updateOnAssociatedProduct);
            }
            else if (statusReason == 2/*Cancelled*/)
            {
                CreateTaskAgainstBACSTaskOwnerTeam(bacsResponseLineItem, directDebitDetail, "\n\nNote - Required action can not be performed as associated product is already Cancelled.");
                //SetDDISubmissionStatus(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                
                //_logger.TraceInformation($"Updating Direct Debit Detail");
                //_directDebitDetailsRepository.Update(updateOnDirectDebitDetail);
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void PerformBACSResponseActionForADDACS(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration)
        {
            _logger.TraceInformation($"Starting business logic.");
            var updateOnDirectDebitDetail = new Directdebitdetails() { Id = directDebitDetail.Id };
            var updateOnAssociatedProduct = new Entity(associatedProduct.LogicalName, associatedProduct.Id);

            var statusReason = associatedProduct.GetAttributeValue<OptionSetValue>("statuscode")?.Value;
            _logger.TraceInformation($"Status Reason = {statusReason}.");
            if (statusReason == 1/*Active*/)
            {
                _logger.TraceInformation($"BACS Response Action = {bacsReasonCodeConfiguration.BACSResponseAction}.");

                if (ValidateIfAdditionalADDACSRulesShouldBeApplied(associatedProduct, bacsReasonCodeConfiguration))
                {
                    //Converted to Flow
                    /*
                    switch (bacsReasonCodeConfiguration.BACSResponseAction)
                    {
                        case BACSResponseActions_GlobalOptionSet.CancelInstruction:
                            CancelInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail, associatedProduct);
                            AdditionalRuleForCancelInstruction(ref updateOnAssociatedProduct, associatedProduct);
                            break;
                        case BACSResponseActions_GlobalOptionSet.UpdateInstruction:
                            UpdateInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                            break;
                    }

                    SetPaymentMethod(ref updateOnAssociatedProduct, bacsReasonCodeConfiguration, associatedProduct); */

                    CreateTask(bacsResponseLineItem, bacsReasonCodeConfiguration, directDebitDetail);
                    //SetDDISubmissionStatus(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                }
                else
                {
                    //Converted to Flow
                    /*switch (bacsReasonCodeConfiguration.BACSResponseAction)
                    {
                        case BACSResponseActions_GlobalOptionSet.CancelInstruction:
                            CancelInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail, associatedProduct);
                            break;
                        case BACSResponseActions_GlobalOptionSet.UpdateInstruction:
                            UpdateInstruction(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                            break;
                    }

                    SetPaymentMethod(ref updateOnAssociatedProduct, bacsReasonCodeConfiguration, associatedProduct);*/

                    UpdateMembershipStatus(ref updateOnAssociatedProduct, bacsResponseLineItem, directDebitDetail, associatedProduct, bacsReasonCodeConfiguration);
                    CreateTask(bacsResponseLineItem, bacsReasonCodeConfiguration, directDebitDetail);
                    //SetDDISubmissionStatus(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                }

                _logger.TraceInformation($"Updating Direct Debit Detail and Associated Product.");
                //_directDebitDetailsRepository.Update(updateOnDirectDebitDetail);
                //_service.Update(updateOnAssociatedProduct);
            }
            else if (statusReason == 2/*Cancelled*/)
            {
                CreateTaskAgainstBACSTaskOwnerTeam(bacsResponseLineItem, directDebitDetail, "\n\nNote - Required action can not be performed as associated product is already Cancelled.");
                //SetDDISubmissionStatus(ref updateOnDirectDebitDetail, bacsResponseLineItem, directDebitDetail);
                
                //_logger.TraceInformation($"Updating Direct Debit Detail");
                //_directDebitDetailsRepository.Update(updateOnDirectDebitDetail);
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void PerformBACSResponseActionForARUDD(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration)
        {
            _logger.TraceInformation($"Starting business logic.");
            var statusReason = associatedProduct.GetAttributeValue<OptionSetValue>("statuscode")?.Value;
            _logger.TraceInformation($"Status Reason = {statusReason}.");
            if (statusReason == 1/*Active*/)
            {
                _logger.TraceInformation($"BACS Response Action = {bacsReasonCodeConfiguration.BACSResponseAction}.");

                //Converted to flow
                /*
                switch (bacsReasonCodeConfiguration.BACSResponseAction)
                {
                    case BACSResponseActions_GlobalOptionSet.ReverseTransaction:
                        ReverseTransaction(bacsResponseLineItem, directDebitDetail);
                        break;
                } */

                CreateTask(bacsResponseLineItem, bacsReasonCodeConfiguration, directDebitDetail);
            }
            else if (statusReason == 2/*Cancelled*/)
            {
                CreateTaskAgainstBACSTaskOwnerTeam(bacsResponseLineItem, directDebitDetail, "\n\nNote - Required action can not be performed as associated product is already Cancelled.");
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void PopulateProductValue(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct)
        {
            _logger.TraceInformation($"Starting business logic.");
            EntityReference productLookup = new EntityReference(associatedProduct.LogicalName, associatedProduct.Id);

            _logger.TraceInformation($"Associate Product = {associatedProduct.LogicalName}.");

            if (associatedProduct.LogicalName == EntityNames.Membership.EntityLogicalName && directDebitDetail.MembershipId != null)
            {
                bacsResponseLineItem["rhs_membership"] = productLookup;
            }
            else if(associatedProduct.LogicalName == EntityNames.Donation.EntityLogicalName && directDebitDetail.Donation != null)
            {
                bacsResponseLineItem["rhs_donationitem"] = productLookup;
            }
            else if (associatedProduct.LogicalName == "rhs_subscription" && directDebitDetail.Subscription != null)
            {
                bacsResponseLineItem["rhs_subscriptionitem"] = productLookup;
            }

            _logger.TraceInformation($"Ending business logic.");
        }
        #endregion

        #region Helper Functions
        private void CancelInstruction(ref Directdebitdetails updateOnDirectDebitDetail, BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct)
        {
            _logger.TraceInformation($"Starting business logic.");

            _cancelDDService.CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(associatedProduct);
            updateOnDirectDebitDetail.Statecode = DirectdebitdetailsState.Inactive;
            updateOnDirectDebitDetail.Statuscode = DirectdebitdetailsStatus.Inactive_Cancelled;
            updateOnDirectDebitDetail.BACSError = bacsResponseLineItem.ToEntityReference();

            _logger.TraceInformation($"Ending business logic.");

        }

        private void UpdateInstruction(ref Directdebitdetails updateOnDirectDebitDetail, BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail)
        {
            _logger.TraceInformation($"Starting business logic.");

            updateOnDirectDebitDetail.Name = bacsResponseLineItem.NewPayerName;
            updateOnDirectDebitDetail.BranchAccountNumber = bacsResponseLineItem.NewAccountNumber;
            updateOnDirectDebitDetail.BranchSortCode = bacsResponseLineItem.NewSortCode;
            updateOnDirectDebitDetail.BACSError = bacsResponseLineItem.ToEntityReference();
            
            _logger.TraceInformation($"Ending business logic.");
        }

        private void ReverseTransaction(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail)
        {
            _logger.TraceInformation($"Starting business logic.");

            var payments = _paymentRepository.GetAll().Where(payment => payment.DirectDebitDetails != null && payment.DirectDebitDetails.Id == directDebitDetail.Id);
            foreach (var payment in payments)
            {
                var updateOnPayment = new Payment()
                {
                    Id = payment.Id,
                    Statecode = PaymentState.Active,
                    Statuscode = PaymentStatus.Active_Overdue,
                    DDFailureCount = payment.DDFailureCount == null ? 1 : ((int)payment.DDFailureCount) + 1,
                    BACSErrorId = bacsResponseLineItem.ToEntityReference(),
                };

                if (payment.GiftAidStatus == PaymentGiftAidStatus_GlobalOptionSet.Submitted)
                {
                    var giftAidRefundToCreate = new Giftaidrefund()
                    {
                        Status = Paymentgiftaidrefundstatus_GlobalOptionSet.Pending,
                        Reason = GiftAidRefundReason_GlobalOptionSet.BACSError,
                        Amount = payment.GiftAidClaimAmount,
                        Payment = payment.ToEntityReference(),
                        RefundPayment = null,
                        ExporttoFinance = false,
                    };
                    _giftAidRefundRepository.Create(giftAidRefundToCreate);
                }
                else if (payment.GiftAidStatus == PaymentGiftAidStatus_GlobalOptionSet.Pending)
                {
                    updateOnPayment.GiftAidStatus = PaymentGiftAidStatus_GlobalOptionSet.NotforSubmission;
                }

                _paymentRepository.Update(updateOnPayment);
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        private bool ValidateIfAdditionalADDACSRulesShouldBeApplied(Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration)
        {
            _logger.TraceInformation($"Starting business logic.");

            var shouldAdditionalRulesBeApplied =
                bacsReasonCodeConfiguration.BACSResponseAction == BACSResponseActions_GlobalOptionSet.CancelInstruction &&
                associatedProduct.GetAttributeValue<bool?>("rhs_inrenewalsstage") == true &&
                associatedProduct.LogicalName == EntityNames.Membership.EntityLogicalName;
            _logger.TraceInformation($"Should additional rules be applied? {shouldAdditionalRulesBeApplied}");

            _logger.TraceInformation($"Ending business logic.");
            return shouldAdditionalRulesBeApplied;
        }

        private void AdditionalRuleForCancelInstruction(ref Entity updateOnAssociatedProduct, Entity associatedProduct)
        {
            _logger.TraceInformation($"Starting business logic.");
            var currentMembership = associatedProduct.ToEntity<Entities.Generated.Membership>(); //assuming addional rule only applies for memberships

            _logger.TraceInformation($"In Renewal Stage? =  {currentMembership.InRenewalsStage}");
            _logger.TraceInformation($"Renewals Status = {currentMembership.RenewalsStatus.ToString()}");
            if (currentMembership.InRenewalsStage == true && currentMembership.RenewalsStatus == RenewalsStatus_GlobalOptionSet.PendingRenewal)
            {
                _logger.TraceInformation($"Need to set associated membership product fields.");
                
                _logger.TraceInformation($"Setting associated membership product fields.");
                updateOnAssociatedProduct[EntityNames.Membership.PaymentMethod] = new OptionSetValue(844060000/*Cash*/);
                updateOnAssociatedProduct[EntityNames.Membership.RenewalsPaymentMethod] = new OptionSetValue(844060000/*Cash*/);
                if (currentMembership.OutstandingAmount != null && currentMembership.OutstandingAmount.Value > 0)
                    updateOnAssociatedProduct[EntityNames.Membership.RenewalsTotalAmount] = new Money(currentMembership.RenewalsTotalAmount.Value + currentMembership.OutstandingAmount.Value);
            }
            else if(currentMembership.InRenewalsStage == true && currentMembership.RenewalsStatus == RenewalsStatus_GlobalOptionSet.Renewed && currentMembership.Enddate > DateTime.UtcNow)
            {
                _logger.TraceInformation($"Need to set associated membership product fields and revert the associated product's renewal.");
               
                _logger.TraceInformation($"Setting current membership product fields.");
                updateOnAssociatedProduct[EntityNames.Membership.PaymentMethod] = new OptionSetValue((int)PaymentMethodType_GlobalOptionSet.Cash);
                updateOnAssociatedProduct[EntityNames.Membership.RenewalsPaymentMethod] = new OptionSetValue((int)PaymentMethodType_GlobalOptionSet.Cash);
                updateOnAssociatedProduct[EntityNames.Membership.RenewalsStatus] = new OptionSetValue((int)RenewalsStatus_GlobalOptionSet.PendingRenewal);
                if (currentMembership.OutstandingAmount != null && currentMembership.OutstandingAmount.Value > 0)
                {
                    updateOnAssociatedProduct[EntityNames.Membership.Statuscode] = new OptionSetValue((int)MembershipState.Active);
                    updateOnAssociatedProduct[EntityNames.Membership.Statuscode] = new OptionSetValue((int)MembershipStatus.Active_PendingPayment);
                }

                _logger.TraceInformation($"Cancelling future membership");
                var renewalMembership = _membershipRepository.GetAll().Where(membership =>
                    membership.LinkedMembership != null && membership.LinkedMembership.Id == currentMembership.Id &&
                    membership.Statuscode == MembershipStatus.Inactive_PaidinAdvance
                ).FirstOrDefault();
                if (renewalMembership != null)
                {
                    _cancelDDService.CancelActiveTransactionPaymentScheduleAndPaymentsOfEntity(renewalMembership);

                    _logger.TraceInformation($"Updating renewal membership fields.");
                    var updateOnRenewalMembership = new Entities.Generated.Membership()
                    {
                        Id = renewalMembership.Id,
                        Statecode = MembershipState.Inactive,
                        Statuscode = MembershipStatus.Inactive_Cancelled
                    };
                    _membershipRepository.Update(updateOnRenewalMembership);
                }
            }

            _logger.TraceInformation($"Ending business logic.");
        }
        //Commented by JMM 1/15/2026
        /*private void SetPaymentMethod(ref Entity updateOnAssociatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration, Entity associatedProduct)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Config Payment Method = {bacsReasonCodeConfiguration.PaymentMethod}.");
            if (bacsReasonCodeConfiguration.PaymentMethod != null)
            {
                _logger.TraceInformation($"Setting the payment method of Associated Product.");
                updateOnAssociatedProduct["rhs_paymentmethod"] = new OptionSetValue((int)bacsReasonCodeConfiguration.PaymentMethod.Value);
            }

            _logger.TraceInformation($"Ending business logic.");
        }*/

        private void UpdateMembershipStatus(ref Entity updateOnAssociatedProduct, BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, Entity associatedProduct, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration)
        {
            _logger.TraceInformation($"Starting business logic for Update.");
            if(updateOnAssociatedProduct.LogicalName != EntityNames.Membership.EntityLogicalName)
                return;

            var outstandingAmount = associatedProduct.GetAttributeValue<Money>("rhs_outstandingamount");
            _logger.TraceInformation($"Outstanding Amount on Associated Product = {bacsReasonCodeConfiguration.MembershipStatusUpdate}.");
            if (outstandingAmount != null && outstandingAmount.Value > 0)
            {
                _logger.TraceInformation($"Logical Name on Associated Product = {bacsReasonCodeConfiguration.LogicalName}.");
                _logger.TraceInformation($"Membership Status Update = {bacsReasonCodeConfiguration.MembershipStatusUpdate}.");

                //Converted to Flow
                /*if (bacsReasonCodeConfiguration.MembershipStatusUpdate != null && associatedProduct.LogicalName == EntityNames.Membership.EntityLogicalName)
                {
                    _logger.TraceInformation($"Setting status of Associated Product.");
                    var statusReasonName = Enum.GetNames(typeof(MembershipStatus)).Where(name => name.Contains(bacsReasonCodeConfiguration.MembershipStatusUpdate.Replace(" ", ""))).FirstOrDefault();
                    if (statusReasonName != null)
                    {
                        updateOnAssociatedProduct[EntityNames.Membership.Statecode] = new OptionSetValue((int)Enum.Parse(typeof(MembershipState), statusReasonName.Split('_').FirstOrDefault()));
                        updateOnAssociatedProduct[EntityNames.Membership.Statuscode] = new OptionSetValue((int)Enum.Parse(typeof(MembershipStatus), statusReasonName));
                        updateOnAssociatedProduct[EntityNames.Membership.PaymentReceived] = false;
                        updateOnAssociatedProduct[EntityNames.Membership.IsSubmitPayment] = false;
                    }
                } */

                CreateTaskAgainstBACSTaskOwnerTeam(bacsResponseLineItem, directDebitDetail, "\nNote - Follow up with the payer.");
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        private void CreateTask(BACSResponseLineItem bacsResponseLineItem, Bacsreasoncodeconfiguration bacsReasonCodeConfiguration, Directdebitdetails directDebitDetail)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Create Task? {bacsReasonCodeConfiguration.CreateTask}.");
            if (bacsReasonCodeConfiguration.CreateTask == true)
            {
                // Validate if BACS Response Code = 2 (Payer Deceased)
                if (bacsReasonCodeConfiguration.Payerdeceased == true)
                {
                    CreateTaskAgainstBACSTaskOwnerTeamDeceasedPayer(bacsResponseLineItem, directDebitDetail, "Note - A BACS response has been received in respect of a deceased member. Please review and take the appropriate action.");
                }
                else
                {
                    CreateTaskAgainstBACSTaskOwnerTeam(bacsResponseLineItem, directDebitDetail);
                }
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        private void CreateTaskAgainstBACSTaskOwnerTeam(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, string additionalDescription = null)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation("Preparing task description.");
            var taskDescription = string.Join("\n",
                $"Reason Code: {bacsResponseLineItem.ErrorRejectionCode}",
                $"DD Reference: {directDebitDetail.Reference}",
                $"Name of Account Holder: {directDebitDetail.Name}",
                $"BACS File: {bacsResponseLineItem.BACSFile.Value.ToString()}"
            );
            if (additionalDescription != null)
                taskDescription += $"\n\n{additionalDescription}";

            _logger.TraceInformation("Retrieving BACS Owner Team");
            var bacsOwnerTeamName = _cultivateConfigurationRepository.GetAll().Where(cultivateConfiguration => cultivateConfiguration.Name == "BACSTaskOwnerTeam").FirstOrDefault()?.Value;
            var bacsOwnerTeam = _teamRepository.GetAll().Where(team => team.Name == bacsOwnerTeamName).FirstOrDefault();

            _logger.TraceInformation("Creating task");
            var taskToCreate = new Task()
            {
                Description = taskDescription,
                Subject = $"{Category_GlobalOptionSet.BACSErrorValue.ToString()} for Account Holder {directDebitDetail.Name}",
                OwnerId = bacsOwnerTeam.ToEntityReference(),
            };

            var createdTask = _taskRepository.Create(taskToCreate);
            _logger.TraceInformation($"Created task w/ Id = {createdTask.Id}");

            _logger.TraceInformation($"Ending business logic.");
        }

        private void CreateTaskAgainstBACSTaskOwnerTeamDeceasedPayer(BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail, string additionalDescription = null)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation("Preparing task description.");
            var taskDescription = string.Join("\n",
                $"Reason Code: {bacsResponseLineItem.ErrorRejectionCode}",
                $"DD Reference: {directDebitDetail.Reference}",
                $"Name of Account Holder: {directDebitDetail.Name}",
                $"BACS File: {bacsResponseLineItem.BACSFile.Value.ToString()}"
            );

            if (additionalDescription != null)
                taskDescription += $"\n\n{additionalDescription}";

            _logger.TraceInformation("Retrieving BACS Owner Team");
            var bacsOwnerTeamName = _cultivateConfigurationRepository.GetAll().Where(cultivateConfiguration => cultivateConfiguration.Name == "BACSTaskOwnerTeam").FirstOrDefault()?.Value;
            var bacsOwnerTeam = _teamRepository.GetAll().Where(team => team.Name == bacsOwnerTeamName).FirstOrDefault();

            _logger.TraceInformation("Creating task");
            var taskToCreate = new Task()
            {
                Subject = $"{Category_GlobalOptionSet.DeceasedAlert.ToString()} for Account Holder {directDebitDetail.Name}",
                Category = Category_GlobalOptionSet.DeceasedAlert,
                ScheduledStart = DateTime.UtcNow,
                ScheduledEnd = DateTime.UtcNow.AddDays(3),
                OwnerId = bacsOwnerTeam.ToEntityReference(),
                PriorityCode = Task_PriorityCode_OptionSet.High,
                Description = taskDescription,
            };

            var createdTask = _taskRepository.Create(taskToCreate);
            _logger.TraceInformation($"Created task w/ Id = {createdTask.Id}");

            _logger.TraceInformation($"Ending business logic.");
        }

        private void SetDDISubmissionStatus(ref Directdebitdetails updateOnDirectDebitDetail, BACSResponseLineItem bacsResponseLineItem, Directdebitdetails directDebitDetail)
        {
            _logger.TraceInformation($"Starting business logic.");

            updateOnDirectDebitDetail.BACSError = bacsResponseLineItem.ToEntityReference();
            if (updateOnDirectDebitDetail.DDISubmissionStatus == MHStatus_GlobalOptionSet.Pending)
                updateOnDirectDebitDetail.DDISubmissionStatus = MHStatus_GlobalOptionSet.Submitted;

            _logger.TraceInformation($"Ending business logic.");
        }
        #endregion
    }
}