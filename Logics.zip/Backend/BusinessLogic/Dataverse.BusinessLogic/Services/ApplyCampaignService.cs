using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using System.Runtime.Serialization;

namespace Cultivate.BusinessLogic.Services
{
    public interface IApplyCampaignService
    {
        ApplyCampaignResult GetDiscountBasedOnCodeAndProduct(string code, Guid productId, int paymentMethod, Guid portalSessionId);
    }

    public class ApplyCampaignService : IApplyCampaignService
    {
        private readonly ILogger _logger;
        private readonly ICampaignRepository _campaignRepository;
        private readonly IRepository<Paymentdiscountconfiguration> _paymentdiscountconfigurationRespository;
        private readonly ICultivateConfigurationRepository _cultivateConfigurationRespository;
        private readonly IMembershipCreateService _membershipCreateService;
        private readonly IProductService _productService;
        private readonly IPortalSessionDiscountRepository _portalSessionDiscountRepository;

        public ApplyCampaignService(
            ILogger logger,
            ICampaignRepository campaignRepository,
            IRepository<Paymentdiscountconfiguration> paymentdiscountconfigurationRespository,
            ICultivateConfigurationRepository cultivateConfigurationRespository,
            IMembershipCreateService membershipCreateService,
            IProductService productService,
            IPortalSessionDiscountRepository portalSessionDiscountRepository
        )
        {
            _logger = logger;
            _campaignRepository = campaignRepository;
            _paymentdiscountconfigurationRespository = paymentdiscountconfigurationRespository;
            _cultivateConfigurationRespository = cultivateConfigurationRespository;
            _membershipCreateService = membershipCreateService;
            _productService = productService;
            _portalSessionDiscountRepository = portalSessionDiscountRepository;
        }

        public ApplyCampaignResult GetDiscountBasedOnCodeAndProduct(string code, Guid productId, int paymentMethod, Guid portalSessionId)
        {
            var result = new ApplyCampaignResult();

            var validation = ValidateCampaignAndConfig(code, productId, paymentMethod);
            if (!validation.IsValid)
            {
                HandlePortalSessionDiscountOnFailure(portalSessionId);
                result.IsValid = false;
                result.Message = validation.Message;
                return result;
            }

            var discountedPrice = CalculateDiscountedPrice(
                productId,
                validation.Campaign.Id,
                /* priceListId */ _cultivateConfigurationRespository.GetPricelIstConfig("DigitalPriceList").PriceList.Id,
                validation.DiscountConfig,
                validation.MembershipPrice
            );

            if (discountedPrice == null)
            {
                HandlePortalSessionDiscountOnFailure(portalSessionId);
                result.IsValid = false;
                result.Message = "Failed to calculate discount price.";
                return result;
            }

            result.OriginalAmount = validation.MembershipPrice;
            result.FinalAmount = discountedPrice;
            result.DiscountAmount = new Money
            {
                Value = validation.MembershipPrice.Value - discountedPrice.Value
            };
            result.IsValid = true;
            result.Message = "Campaign applied successfully.";
            result.DiscountRate = (double)(validation.DiscountConfig.DiscountPercentage ?? 0);
            result.DiscountLabel = validation.DiscountConfig.Name ?? "Discount Applied";

            HandlePortalSessionDiscountOnSuccess(portalSessionId, result, validation.Campaign, code);

            return result;
        }

        private (bool IsValid, string Message, Campaign Campaign, Paymentdiscountconfiguration DiscountConfig, Money MembershipPrice) 
            ValidateCampaignAndConfig(string code, Guid productId, int paymentMethod)
        {
            var priceListConfig = _cultivateConfigurationRespository.GetPricelIstConfig("DigitalPriceList");
            if (priceListConfig == null || !priceListConfig.Contains(EntityNames.Cultivateconfigurations.PriceList))
                return (false, "No price list configuration found for DigitalPriceList or Price List not found.", null, null, null);

            var campaign = _campaignRepository.GetByCodeAndProduct(code, productId);
            if (campaign == null)
                return (false, "No campaign found for the provided code and product.", null, null, null);

            if (!campaign.Contains(EntityNames.Campaign.Paymentdiscountconfiguration) || campaign.Paymentdiscountconfiguration == null)
                return (false, "Campaign does not have a valid payment discount configuration.", campaign, null, null);

            var paymentDiscountConfiguration = _paymentdiscountconfigurationRespository.GetById(campaign.Paymentdiscountconfiguration.Id);
            if (paymentDiscountConfiguration == null)
                return (false, "Payment discount configuration not found for the campaign.", campaign, null, null);

            if (paymentDiscountConfiguration.PaymentMethodCode == null || (int)paymentDiscountConfiguration.PaymentMethodCode != paymentMethod)
                return (false, "The code is not valid for the selected payment method.", campaign, null, null);

            var membershipPrice = _productService.GetProductPrice(productId, priceListConfig.PriceList.Id);
            if (membershipPrice == null)
                return (false, "Failed to retrieve product price.", campaign, paymentDiscountConfiguration, null);

            return (true, string.Empty, campaign, paymentDiscountConfiguration, membershipPrice);
        }

        private Money CalculateDiscountedPrice(
            Guid productId, Guid campaignId, Guid priceListId, Paymentdiscountconfiguration discountConfig, Money membershipPrice)
        {
            return _membershipCreateService.GetDiscountedPrice(
                productId,
                campaignId,
                priceListId,
                null,
                (int)discountConfig.PaymentMethodCode,
                (int)PaymentFrequency_GlobalOptionSet.Annually,
                discountConfig,
                membershipPrice
            );
        }

        private void HandlePortalSessionDiscountOnFailure(Guid portalSessionId)
        {
            var existingDiscount = _portalSessionDiscountRepository.GetByPortalSesssionId(portalSessionId);
            if (existingDiscount != null)
            {
                _portalSessionDiscountRepository.Delete(existingDiscount);
                //_portalSessionDiscountRepository.Update(new PortalSessionDiscount
                //{
                //    Id = existingDiscount.Id,
                //    Campaign = null,
                //    DiscountLabel = null,
                //    DiscountMessage = null,
                //    PromoCode = null,
                //    DiscountRate = 0
                //});
            }
        }

        private void HandlePortalSessionDiscountOnSuccess(Guid portalSessionId, ApplyCampaignResult result, Campaign campaign, string code)
        {
            var portalSessionDiscount = _portalSessionDiscountRepository.GetByPortalSesssionId(portalSessionId);

            if (portalSessionDiscount != null)
            {
                _logger.TraceInformation($"Portal session discount already exists for session {portalSessionId}. Updating existing record.");
                portalSessionDiscount.Campaign = campaign.ToEntityReference();
                portalSessionDiscount.DiscountLabel = result.DiscountLabel;
                portalSessionDiscount.DiscountMessage = result.Message;
                portalSessionDiscount.PromoCode = code;
                portalSessionDiscount.DiscountRate = result.DiscountRate;
                portalSessionDiscount.DiscountAmount = result.DiscountAmount;
                portalSessionDiscount.OriginalAmount = result.OriginalAmount;
                portalSessionDiscount.FinalAmount = result.FinalAmount;

                _portalSessionDiscountRepository.Update(portalSessionDiscount);
            }
            else
            {
                _portalSessionDiscountRepository.Create(new PortalSessionDiscount
                {
                    PortalSession = new EntityReference(Portalsession.EntityLogicalName, portalSessionId),
                    Campaign = campaign.ToEntityReference(),
                    DiscountLabel = result.DiscountLabel,
                    DiscountMessage = result.Message,
                    PromoCode = code,
                    DiscountRate = result.DiscountRate,
                    DiscountAmount = result.DiscountAmount,
                    OriginalAmount = result.OriginalAmount,
                    FinalAmount = result.FinalAmount,
                    Name = result.DiscountLabel
                });
            }
        }
    }

    public class ApplyCampaignResult
    {
        [DataMember(Name = nameof(OriginalAmount))]
        public Money OriginalAmount { get; set; }

        [DataMember(Name = nameof(FinalAmount))]
        public Money FinalAmount { get; set; }

        [DataMember(Name = nameof(DiscountAmount))]
        public Money DiscountAmount { get; set; }

        [DataMember(Name = nameof(IsValid))]
        public bool IsValid { get; set; }

        [DataMember(Name = nameof(Message))]
        public string Message { get; set; }

        [DataMember(Name = nameof(DiscountLabel))]
        public string DiscountLabel { get; set; }

        [DataMember(Name = nameof(DiscountRate))]
        public double DiscountRate { get; set; }
    }
}