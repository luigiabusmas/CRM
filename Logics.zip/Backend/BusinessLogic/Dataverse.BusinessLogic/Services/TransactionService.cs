﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Cultivate.BusinessLogic.Services
{
    public interface ITransactionService
    {
        Transaction CreateAndRetrieveTransaction();

        Membership RetrieveMembership(Transaction transaction);
        Entity RetrieveMembershipEntity(Transaction transaction);
        Entity RetrieveSubscriptionEntity(Transaction transaction);
        GiftPack RetrieveGiftPack(Transaction transaction);
        Entity RetrieveGiftPackEntity(Transaction transaction);
        GiftPackBulkPurchase RetrieveGiftPackBulkPurchase(Transaction transaction);
        Entity RetrieveGiftPackBulkPurchaseEntity(Transaction transaction);

        void SetInitialOutstandingAmount(ref Entity target, ref Transaction transaction, Entity membershipEntity, Entity subscriptionEntity);
        void SetStatusOnOutstandingAmountUpdate(ref Entity target, ref Transaction postImage);
        void PopulateOutstandingAmountOnMembership(Transaction transaction);
        void PopulateOutstandingAmountOnSubscription(Transaction transaction);
        //void UpdateGiftPackStatus(GiftPack giftPack);
        void UpdateBulkGiftPackStatus(GiftPackBulkPurchase giftPackBulkPurchase);
    }

    public class TransactionService : ITransactionService
    {
        private readonly ILogger _logger;
        private IOrganizationService _service;
        private readonly IRepository<Transaction> _transactionRepository;
        private readonly IRepository<Membership> _membershipRepository;
        private readonly IRepository<GiftPack> _giftPackRepository;
        private readonly IRepository<GiftPackBulkPurchase> _giftPackBulkPurchaseRepository;

        public TransactionService(ILogger logger, IOrganizationService service, IRepository<Transaction> transactionRepository, 
            IRepository<Membership> membershipRepository, IRepository<GiftPack> giftPackRepository, IRepository<GiftPackBulkPurchase> giftPackBulkPurchaseRepository)
        {
            _logger = logger;
            _service = service;
            _transactionRepository = transactionRepository;
            _membershipRepository = membershipRepository;
            _giftPackRepository = giftPackRepository;
            _giftPackBulkPurchaseRepository = giftPackBulkPurchaseRepository;
        }

        public Transaction CreateAndRetrieveTransaction()
        {
            _logger.TraceInformation("Starting business logic.");
            var transaction = _transactionRepository.Create(new Transaction());

            _logger.TraceInformation("Ending business logic.");
            return _transactionRepository.GetById(transaction.Id);
        }

        public Membership RetrieveMembership(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            Membership membership = null;

            if (transaction.MembershipId != null)
                membership = _membershipRepository.GetById(transaction.MembershipId.Id);
            else
                _logger.TraceInformation("Transaction does not lookup to membership.");

            _logger.TraceInformation("Ending business logic.");
            return membership;
        }

        public Entity RetrieveMembershipEntity(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            var entity = (Entity)RetrieveMembership(transaction);

            _logger.TraceInformation("Ending business logic.");
            return entity;
        }

        public Entity RetrieveSubscriptionEntity(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            Entity entity = null;

            if (transaction.SubscriptionId != null)
                entity = _service.Retrieve("rhs_subscription", transaction.SubscriptionId.Id, new ColumnSet(true));
            else
                _logger.TraceInformation("Transaction does not lookup to subscription.");

            _logger.TraceInformation("Ending business logic.");
            return entity;
        }

        public GiftPack RetrieveGiftPack(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            GiftPack giftPack = null;

            if (transaction.GiftPackId != null)
                giftPack = _giftPackRepository.GetById(transaction.GiftPackId.Id);
            else
                _logger.TraceInformation("Transaction does not lookup to gift pack.");

            _logger.TraceInformation("Ending business logic.");
            return giftPack;
        }

        public Entity RetrieveGiftPackEntity(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            var entity = (Entity)RetrieveGiftPack(transaction);

            _logger.TraceInformation("Ending business logic.");
            return entity;
        }

        public GiftPackBulkPurchase RetrieveGiftPackBulkPurchase(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            GiftPackBulkPurchase giftPackBulkPurchase = null;

            if (transaction.GiftPackBulkPurchaseId != null)
                giftPackBulkPurchase = _giftPackBulkPurchaseRepository.GetById(transaction.GiftPackBulkPurchaseId.Id);
            else
                _logger.TraceInformation("Transaction does not lookup to gift pack bulk purchase.");

            _logger.TraceInformation("Ending business logic.");
            return giftPackBulkPurchase;
        }

        public Entity RetrieveGiftPackBulkPurchaseEntity(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");
            var entity = (Entity)RetrieveGiftPackBulkPurchase(transaction);

            _logger.TraceInformation("Ending business logic.");
            return entity;
        }

        public void SetInitialOutstandingAmount(ref Entity target, ref Transaction transaction, Entity membershipEntity, Entity subscriptionEntity)
        {
            _logger.TraceInformation("Starting business logic.");

            if (transaction.OutstandingAmount == null)
            {
                if (transaction.TransactionType == NewTransactionType_GlobalOptionSet.Membership &&
                    transaction.MembershipId != null && membershipEntity != null)
                {
                    _logger.TraceInformation("Detected membership parent. Copying its total amount as the the outstanding amount of transaction.");

                    transaction.OutstandingAmount = membershipEntity.GetAttributeValue<Money>("rhs_totalamount");
                    target[EntityNames.Transaction.OutstandingAmount] = transaction.OutstandingAmount;
                }
                else if (transaction.TransactionType == NewTransactionType_GlobalOptionSet.Subscriptions &&
                    transaction.SubscriptionId != null && subscriptionEntity != null)
                {
                    _logger.TraceInformation("Detected subscription parent. Copying its total amount as the the outstanding amount of transaction.");

                    transaction.OutstandingAmount = subscriptionEntity.GetAttributeValue<Money>("rhs_totalamount");
                    target[EntityNames.Transaction.OutstandingAmount] = transaction.OutstandingAmount;
                }
            }
            else
            {
                _logger.TraceInformation("Outstanding amount already contains value");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void SetStatusOnOutstandingAmountUpdate(ref Entity target, ref Transaction postImage)
        {
            _logger.TraceInformation("Starting business logic.");

            _logger.TraceInformation($"Outstanding amount = {postImage.OutstandingAmount}.");
            if (postImage.OutstandingAmount != null && postImage.OutstandingAmount.Value <= 0)
            {
                _logger.TraceInformation("Detected that outstanding amount reached 0 or below.");
                _logger.TraceInformation("Setting transaction status to paid.");

                postImage.Statecode = TransactionState.Inactive;
                postImage.Statuscode = TransactionStatus.Inactive_Paid;

                target[EntityNames.Transaction.Statecode] = new OptionSetValue((int)postImage.Statecode.Value);
                target[EntityNames.Transaction.Statuscode] = new OptionSetValue((int)postImage.Statuscode.Value);
            }
            else if(postImage.OutstandingAmount != null && /*postImage.OutstandingAmount.Value > 0 && */
                    postImage.Statuscode == TransactionStatus.Inactive_Paid)
            {
                _logger.TraceInformation("Detected that outstanding amount still exists, but transaction status is paid.");
                _logger.TraceInformation("Setting transaction status to pending.");

                postImage.Statecode = TransactionState.Active;
                postImage.Statuscode = TransactionStatus.Active_PendingPayment;

                target[EntityNames.Transaction.Statecode] = new OptionSetValue((int)postImage.Statecode.Value);
                target[EntityNames.Transaction.Statuscode] = new OptionSetValue((int)postImage.Statuscode.Value);
            }
            else
            {
                _logger.TraceInformation("Not eligible for status update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void PopulateOutstandingAmountOnMembership(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            if (transaction.TransactionType == NewTransactionType_GlobalOptionSet.Membership &&
                transaction.MembershipId != null)
            {
                var membershipUpdate = new Membership()
                {
                    Id = transaction.MembershipId.Id,
                    OutstandingAmount = transaction.OutstandingAmount
                };
                _membershipRepository.Update(membershipUpdate);
            }
            {
                _logger.TraceInformation("Not eligible for membership outstanding amount update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void PopulateOutstandingAmountOnSubscription(Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            if (transaction.TransactionType == NewTransactionType_GlobalOptionSet.Subscriptions &&
                transaction.SubscriptionId != null)
            {
                var subscriptionUpdate = new Entity("rhs_subscription", transaction.SubscriptionId.Id);
                subscriptionUpdate["rhs_outstandingamount"] = transaction.OutstandingAmount;
                _service.Update(subscriptionUpdate);
            }
            {
                _logger.TraceInformation("Not eligible for subscription outstanding amount update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        //public void UpdateGiftPackStatus(GiftPack giftPack)
        //{
        //    _logger.TraceInformation("Starting business logic.");

        //    if (giftPack != null && giftPack.Statecode == GiftPackState.Active)
        //    {
        //        var giftPackUpdate = new GiftPack()
        //        {
        //            Id = giftPack.Id,
        //            //Statecode = GiftPackState.Inactive,
        //            //Statuscode = GiftPackStatus.Active_Purchased,
        //            //IsPaymentReceived = true
        //        };
        //        _service.Update(giftPackUpdate);
        //    }
        //    {
        //        _logger.TraceInformation("Not eligible for gift pack status update.");
        //    }

        //    _logger.TraceInformation("Ending business logic.");
        //}

        public void UpdateBulkGiftPackStatus(GiftPackBulkPurchase giftPackBulkPurchase)
        {
            _logger.TraceInformation("Starting business logic.");

            if (giftPackBulkPurchase != null && giftPackBulkPurchase.Statecode == GiftPackBulkPurchaseState.Active &&
                giftPackBulkPurchase.Statuscode != GiftPackBulkPurchaseStatus.Active_Purchased && 
                (giftPackBulkPurchase.IsPaymentReceived == null || giftPackBulkPurchase.IsPaymentReceived != true))
            {
                var giftPackBulkPurchaseUpdate = new GiftPackBulkPurchase()
                {
                    Id = giftPackBulkPurchase.Id,
                    //Statecode = GiftPackState.Active,
                    Statuscode = GiftPackBulkPurchaseStatus.Active_Purchased,
                    IsPaymentReceived = true
                };
                _service.Update(giftPackBulkPurchase);
            }
            {
                _logger.TraceInformation("Not eligible for gift pack status update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }
    }
}