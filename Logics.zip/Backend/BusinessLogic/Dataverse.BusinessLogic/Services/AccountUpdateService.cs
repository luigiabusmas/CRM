﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;

using EntityNames = Cultivate.Entities.Generated.EntityNames;

namespace Cultivate.BusinessLogic.Services
{
    public interface IAccountUpdateService
    {
        void PopulateGDPRDeletionDate(Account targetAccount);
        void SetLatLongCountyAddress12(Entity entity, Account preImageEntity, Account targetAccount);
    }

    public class AccountUpdateService : IAccountUpdateService
    {
        private readonly ITracingService _tracingService;
        private readonly ILogger _logger;
        private readonly IOrganizationService _service;
        private readonly IPluginExecutionContext _context;
        private readonly IRepository<Account> _accountRepository;
        private ICommonService _commonService;

        public AccountUpdateService(
           ITracingService tracingService, ILogger logger,
           IOrganizationService service,
           IPluginExecutionContext context,
           IRepository<Account> accountRepository,
           ICommonService commonService
        )
        {
            _tracingService = tracingService;
            _logger = logger;
            _service = service;
            _context = context;
            _accountRepository = accountRepository;
            _commonService = commonService;
        }
        public void PopulateGDPRDeletionDate(Account targetAccount)
        {
            _logger.TraceInformation($"PopulateGDPRDeletionDate Start");
            if (targetAccount != null)
            {
                //Get GDPR Configuration configuration settings
                GDPRConfigurationSettings settings = _commonService.getGDPRConfiguration(new OptionSetValue((int)Entitynamegdprcode_GlobalOptionSet.Accounts));
                if (settings != null && settings.RetentionPeriod != null)
                {
                    // Set GDPR Deletion Date
                    targetAccount.GDPRDeletionDate = DateTime.Now.AddDays(Convert.ToDouble(settings.RetentionPeriod));
                }
            }
            _logger.TraceInformation($"PopulateGDPRDeletionDate End");
        }
        public void SetLatLongCountyAddress12(Entity entity, Account preImageAccount, Account targetAccount)
        {
            _logger.TraceInformation($"SetLatLongCountyAddress12 Start");

            if (entity != null && preImageAccount != null || targetAccount != null)
            {
                var targetEntity = entity.ToEntity<Account>();

                // Address 1
                if (entity.Contains(EntityNames.Account.Loqate_Latitude) && preImageAccount.Loqate_Latitude != targetAccount.Loqate_Latitude)
                    targetAccount.Address1_Latitude = Convert.ToDouble(targetEntity.Loqate_Latitude);

                if (entity.Contains(EntityNames.Account.Loqate_Longitude) && preImageAccount.Loqate_Longitude != targetAccount.Loqate_Longitude)
                    targetAccount.Address1_Longitude = Convert.ToDouble(targetEntity.Loqate_Longitude);

                if (entity.Contains(EntityNames.Account.LoqateAddress1County) && preImageAccount.LoqateAddress1County != targetAccount.LoqateAddress1County)
                    targetAccount.Address1_County = targetEntity.LoqateAddress1County;

                if (entity.Contains(EntityNames.Account.LoqateAddress1HouseName) && preImageAccount.LoqateAddress1HouseName != targetAccount.LoqateAddress1HouseName)
                    targetAccount.Address1_Name = targetEntity.LoqateAddress1HouseName;


                // Address 2 
                if (entity.Contains(EntityNames.Account.LoqateAddress2Latitude) && preImageAccount.LoqateAddress2Latitude != targetAccount.LoqateAddress2Latitude)
                    targetAccount.Address2_Latitude = Convert.ToDouble(targetEntity.LoqateAddress2Latitude);

                if (entity.Contains(EntityNames.Account.LoqateAddress2Longitude) && preImageAccount.LoqateAddress2Longitude != targetAccount.LoqateAddress2Longitude)
                    targetAccount.Address2_Longitude = Convert.ToDouble(targetEntity.LoqateAddress2Longitude);

                if (entity.Contains(EntityNames.Account.LoqateAddress2County) && preImageAccount.LoqateAddress2County != targetAccount.LoqateAddress2County)
                    targetAccount.Address2_County = targetEntity.LoqateAddress2County;

                if (entity.Contains(EntityNames.Account.LoqateAddress2HouseName) && preImageAccount.LoqateAddress2HouseName != targetAccount.LoqateAddress2HouseName)
                    targetAccount.Address2_Name = targetEntity.LoqateAddress2HouseName;
            }
                            
            _logger.TraceInformation($"SetLatLongCountyAddress12 End");
        }
    }
}
                


