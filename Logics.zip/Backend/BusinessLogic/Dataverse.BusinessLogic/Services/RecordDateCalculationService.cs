﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface IRecordDateCalculationService
    {
        DateTime? CalculateStartDateOfRecord(EntityReference productReference);
        DateTime? CalculateEndDateOfRecord(DateTime? startDate, Guid? productId, Guid? campaignId);
        DateTime? CalculateRenewalStartDateOfRecord(DateTime? endDate);
        DateTime? CalculateRenewalEndDateOfRecord(DateTime? endDate);
        DateTime CalculatePayoutDate(DateTime startDate);
        DateTime? CalculateStartDateOfRenewalMembership(EntityReference renewalProductReference, DateTime originalMembershipEndDate);
        DateTime CalculateMembershipStartDate();
        DateTime CalculateGiftAidStartDate();
    }

    public class RecordDateCalculationService : IRecordDateCalculationService
    {
        private ILogger _logger;
        private IOrganizationService _organizationService;
        private IRepository<Product> _productRepository;
        private IRepository<Campaign> _campaignRepository;
        private IPropertyRetrievalService _propertyRetrievalService;
        private ICultivateConfigurationService _cultivateConfigurationService;

        public RecordDateCalculationService(ILogger logger, IOrganizationService organizationService, IRepository<Product> productRepository, IRepository<Campaign> campaignRepository, IPropertyRetrievalService propertyRetrievalService, ICultivateConfigurationService cultivateConfigurationService)
        {
            _logger = logger;
            _organizationService = organizationService;
            _productRepository = productRepository;
            _campaignRepository = campaignRepository;
            _propertyRetrievalService = propertyRetrievalService;
            _cultivateConfigurationService = cultivateConfigurationService;
        }

        #region Business Logics
        public DateTime? CalculateStartDateOfRecord(EntityReference productReference)
        {
            _logger.TraceInformation($"Starting business logic.");
            DateTime? startDate = null;

            var now = DateTime.UtcNow;
            var nextMonth = now.AddMonths(1);
            var paymentDate = now;
            var paymentDay = paymentDate.Day;

            if (productReference != null && productReference.Name == null)
            {
                _logger.TraceInformation($"Product Reference's Name is empty. Populating Product Reference's Name.");
                productReference.Name = _productRepository.GetById(productReference.Id).Name;
            }

            if (productReference != null && productReference.Name.Contains("Patron"))
            {
                startDate = new DateTime(nextMonth.Year, nextMonth.Month, 1, nextMonth.Hour, nextMonth.Minute, nextMonth.Second, nextMonth.Millisecond);
            }
            else
            {
                if (paymentDay >= 23 && paymentDay <= 31)
                    startDate = new DateTime(nextMonth.Year, nextMonth.Month, 1, nextMonth.Hour, nextMonth.Minute, nextMonth.Second, nextMonth.Millisecond);
                else if (paymentDay == 1)
                    startDate = new DateTime(now.Year, now.Month, 1, now.Hour, now.Minute, now.Second, now.Millisecond);
                else if (paymentDay >= 2 && paymentDay <= 7)
                    startDate = new DateTime(now.Year, now.Month, 8, now.Hour, now.Minute, now.Second, now.Millisecond);
                else if (paymentDay >= 8 && paymentDay <= 15)
                    startDate = new DateTime(now.Year, now.Month, 15, now.Hour, now.Minute, now.Second, now.Millisecond);
                else if (paymentDay >= 16 && paymentDay <= 22)
                    startDate = new DateTime(now.Year, now.Month, 22, now.Hour, now.Minute, now.Second, now.Millisecond);
            }

            _logger.TraceInformation($"Ending business logic.");
            return startDate;
        }

        public DateTime? CalculateEndDateOfRecord(DateTime? startDate, Guid? productId, Guid? campaignId)
        {
            _logger.TraceInformation($"Starting business logic.");
            DateTime? endDate = null;

            if (productId != null)
            {
                _logger.TraceInformation($"Detected that a product is selected.");

                var durationName = _propertyRetrievalService.GetDefaultOptionSetValueNameOfProductProperty((Guid)productId, "Duration");
                _logger.TraceInformation($"Membership duration = {durationName}.");

                _logger.TraceInformation($"Setting membership end date.");
                switch (durationName)
                {
                    case "3 Months":
                        endDate = startDate != null ? ((DateTime)startDate).AddMonths(3).AddDays(-1) : DateTime.UtcNow.Date.AddMonths(3).AddDays(-1);
                        break;
                    case "6 Months":
                        endDate = startDate != null ? ((DateTime)startDate).AddMonths(6).AddDays(-1) : DateTime.UtcNow.Date.AddMonths(6).AddDays(-1);
                        break;
                    case "1 Year":
                        endDate = startDate != null ? ((DateTime)startDate).AddYears(1).AddDays(-1) : DateTime.UtcNow.Date.AddYears(1).AddDays(-1);
                        break;
                    case "Lifetime":
                        //endDate = null; // Revised to 'fix' bug 81487
                        endDate = startDate != null ? ((DateTime)startDate).AddYears(100).AddDays(-1) : DateTime.UtcNow.Date.AddYears(100).AddDays(-1);
                        break;
                }
                _logger.TraceInformation($"End date = {endDate}.");

                if (campaignId != null)
                {
                    var campaign = _campaignRepository.GetById((Guid)campaignId);

                    if (endDate != null && campaign.BenefitType == CampaignBenefit_GlobalOptionSet.TimeBased && campaign.DurationBenefit != null)
                    {
                        _logger.TraceInformation($"Applying time-based campaign benefit to the membership end date.");
                        _logger.TraceInformation($"Time-based benefit = {campaign.DurationBenefit} month/s.");

                        endDate = ((DateTime)endDate).AddMonths((int)campaign.DurationBenefit);
                        _logger.TraceInformation($"Membership end date = {endDate}.");
                    }
                }
            }
            else
            {
                _logger.TraceInformation($"Detected that a product is not selected.");
                _logger.TraceInformation($"Setting membership end date.");
                endDate = startDate != null ? ((DateTime)startDate).AddYears(1).AddDays(-1) : DateTime.UtcNow.Date.AddYears(1).AddDays(-1);
            }

            _logger.TraceInformation($"Ending {MethodBase.GetCurrentMethod().Name} method logic.");
            return endDate;
        }

        public DateTime? CalculateRenewalStartDateOfRecord(DateTime? endDate)
        {
            _logger.TraceInformation($"Starting business logic.");
            DateTime? renewalStartDate = null;

            if (endDate != null)
            {
                var renewalDuration = int.Parse(_cultivateConfigurationService.GetCultivateConfigurationValue("RenewalPeriodDuration"));
                renewalStartDate = endDate?.AddMonths(-renewalDuration).AddDays(1);
            }

            _logger.TraceInformation($"Ending business logic.");
            return renewalStartDate;
        }

        public DateTime? CalculateRenewalEndDateOfRecord(DateTime? endDate)
        {
            _logger.TraceInformation($"Starting business logic.");
            DateTime? renewalEndDate = null;

            if (endDate != null)
            {
                var dormancyDuration = int.Parse(_cultivateConfigurationService.GetCultivateConfigurationValue("DormancyPeriodDuration"));
                renewalEndDate = endDate?.AddMonths(dormancyDuration);
            }

            _logger.TraceInformation($"Ending business logic.");
            return renewalEndDate;
        }

        public DateTime CalculatePayoutDate(DateTime startDate) // Set after 10 working days from start date
        {
            _logger.TraceInformation($"Starting business logic.");

            var now = DateTime.UtcNow;
            var nextPayoutDate = startDate > now ? startDate : now;
            var workingDaysAdded = 0;
            var holidayDates = GetHolidayDates();
            
            while (workingDaysAdded < 10)
            {
                nextPayoutDate = nextPayoutDate.AddDays(1);

                if (nextPayoutDate.DayOfWeek != DayOfWeek.Saturday && nextPayoutDate.DayOfWeek != DayOfWeek.Sunday)
                {
                    var isHoliday = holidayDates.Where(holiday => holiday.Date == nextPayoutDate.Date).Any();
                    if (!isHoliday)
                        workingDaysAdded++;
                }
            }

            _logger.TraceInformation($"Ending business logic.");
            return nextPayoutDate;
        }

        public DateTime? CalculateStartDateOfRenewalMembership(EntityReference renewalProductReference, DateTime originalMembershipEndDate)
        {
            _logger.TraceInformation($"Starting business logic.");
            DateTime? renewalMembershipStartDate = null;

            var now = DateTime.UtcNow;

            if (renewalProductReference != null && renewalProductReference.Name != null && renewalProductReference.Name.ToLower().Contains("patron"))
            {
                _logger.TraceInformation($"Detected patron membership.");

                if (now <= originalMembershipEndDate)
                {
                    _logger.TraceInformation($"Setting start date to 1st day of the next calendar month from the End Date of the originating membership.");
                    renewalMembershipStartDate = originalMembershipEndDate.AddDays(1 - originalMembershipEndDate.Day).AddMonths(1);
                }
                else
                {
                    _logger.TraceInformation($"Setting start date to 1st day of the next calendar month from today’s date.");
                    renewalMembershipStartDate = now.AddDays(1 - now.Day).AddMonths(1);
                }
            }
            else
            {
                _logger.TraceInformation($"Setting start date to the day after the End Date of the originating membership.");
                renewalMembershipStartDate = originalMembershipEndDate.AddDays(1);
            }

            _logger.TraceInformation($"Ending business logic.");
            return renewalMembershipStartDate;
        }

        /// <summary>
        /// Calculates the membership start date based on the current date.
        /// Membership start dates are aligned to specific days of the month:
        /// - Days 1: Start on the 1st
        /// - Days 2-7: Start on the 8th
        /// - Days 8-15: Start on the 15th
        /// - Days 16-22: Start on the 22nd
        /// - Days 23+: Start on the 1st of next month
        /// </summary>
        public DateTime CalculateMembershipStartDate()
        {
            DateTime inputDate = DateTime.UtcNow;
            int day = inputDate.Day;
            int month = inputDate.Month;
            int year = inputDate.Year;

            return day switch
            {
                >= 23 => new DateTime(year, month, 1, 0, 0, 0, DateTimeKind.Utc).AddMonths(1),
                >= 16 => new DateTime(year, month, 22, 0, 0, 0, DateTimeKind.Utc),
                >= 8 => new DateTime(year, month, 15, 0, 0, 0, DateTimeKind.Utc),
                >= 2 => new DateTime(year, month, 8, 0, 0, 0, DateTimeKind.Utc),
                _ => new DateTime(year, month, 1, 0, 0, 0, DateTimeKind.Utc),
            };
        }

        public DateTime CalculateGiftAidStartDate()
        {
            var today = DateTime.UtcNow;
            var taxYearStart = new DateTime(today.Year, 4, 6, 0, 0, 0, DateTimeKind.Utc);

            return new DateTime(
                today.AddYears(today < taxYearStart ? -5 : -4).Year,  //Set the 4 tax years ago, always starts on 6th of April
                4, 6, 0, 0, 0,
                DateTimeKind.Utc);
        }
        #endregion

        #region Helpers
        private List<DateTime> GetHolidayDates()
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression("calendar");
            query.Criteria.AddCondition("name", ConditionOperator.Equal, "UK Holidays");
            var query_calendarrule = query.AddLink("calendarrule", "calendarid", "calendarid");
            query_calendarrule.Columns.AddColumns("name", "starttime");

            var calendar_CalendarRules = _organizationService.RetrieveMultiple(query).Entities.ToList();
            var holidayDates = calendar_CalendarRules.Select(calendar_calendarrule =>
                (DateTime?)calendar_calendarrule.GetAttributeValue<AliasedValue>("calendarrule1.starttime")?.Value
            ).Where(holidayDate => holidayDate != null).Select(holidayDate => (DateTime)holidayDate).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return holidayDates;
        }
        #endregion
    }
}