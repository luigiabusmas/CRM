﻿using Avanade.BizApps.Core.Contracts;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;

namespace Cultivate.BusinessLogic.Services
{
    public interface IDirectDebitMandateService
    {
        Directdebitdetails CreateDirectDebitMandate(PortalSessionContactAccountDetails portalSessionContactAccountDetails, Transaction transaction);
    }

    public class DirectDebitMandateService : IDirectDebitMandateService
    {
        private readonly ITracingService _tracingService;
        private readonly IRepository<Directdebitdetails> _directDebitDetailRepository;

        public DirectDebitMandateService(
            ITracingService tracingService,
            IRepository<Directdebitdetails> directDebitDetailRepository
            )
        {
            _tracingService = tracingService;
            _directDebitDetailRepository = directDebitDetailRepository;
        }

        public Directdebitdetails CreateDirectDebitMandate(PortalSessionContactAccountDetails portalSessionContactAccountDetails, Transaction transaction)
        {
            _tracingService.Trace("Creating direct debit mandate");
            return _directDebitDetailRepository.Create(new Directdebitdetails()
            {
                Payer = transaction.Customer,
                Reference = transaction.TransacID,
                BranchSortCode = portalSessionContactAccountDetails.AccountSortCode,
                Name = portalSessionContactAccountDetails.Name,
                BranchAccountNumber = portalSessionContactAccountDetails.AccountNumber,
                MembershipId = transaction.MembershipId
            });
        }
    }
}