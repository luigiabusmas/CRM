using System;

namespace Cultivate.BusinessLogic.Services
{
    public interface IAccountCleanupService
    {
        void CleanUp(Guid accountId);
    }

    public class AccountCleanupService : IAccountCleanupService
    {
        public void CleanUp(Guid accountId)
        {
            // Cleanup logic
        }
    }
}