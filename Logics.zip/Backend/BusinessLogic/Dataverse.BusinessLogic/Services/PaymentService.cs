﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Security;
using System.Threading;
using System.Runtime.Remoting.Contexts;


namespace Cultivate.BusinessLogic.Services
{
    public interface IPaymentService
    {
        void RefundGiftPackPayment(Payment payment);
        void GiftAidOverrideToEligible(Entity payment);
        void SetApprovedForNavBy_PreOp(Payment payment, Guid initiatingUserId);
        void SetGiftAidEligible(Payment payment);
        //void CompareGiftAidThresholdOnUpdate(Entity payment);

        Transaction RetrieveTransaction(Payment payment);
        PaymentSchedule RetrievePaymentSchedule(Payment payment);

        void SetPaymentDateWhenPaid(ref Entity target, ref Payment postImage);
        void SetPaymentGiftAidStatus(ref Entity target, Payment preImage, ref Payment postImage);
        void UpdatePaymentDueOfPaymentScheduleWhenPartiallyPaid(Payment payment, PaymentSchedule paymentSchedule);
        void UpdateTransactionStatus(Payment payment, Transaction transaction);
        void UpdateTransactionOustandingAmountOnPay(Payment payment, Transaction transaction);
        void CancelAssociatedRecordsWhenDDPaymentCountReachThreshold(Payment payment, Transaction transaction);
        void UpdateDonationAmountOnPayOrOverdue(Payment payment, Transaction transaction);
        void SetPaymentScheduleStatus(Payment payment, PaymentSchedule paymentSchedule);
        void SetDonationAndRestrictedFundOnCreate(Payment payment);
        void SetIsRenewalOnCreate(Payment payment);

    }

    public class PaymentService : IPaymentService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRepository<Transaction> _transactionRepository;
        private IRepository<Payment> _paymentRepository;
        private IRepository<PaymentSchedule> _paymentScheduleRepository;
        private IRepository<GiftPack> _giftPackRepository;
        private IRepository<CancellationReason> _cancellationResonRepository;
        private CustomAPIInvocationService _customAPIInvocationService;
        private PropertyRetrievalService _propertyRetrievalService;
        private IRepository<Entities.Generated.Membership> _membershipRepository;
        private IRepository<UserSettings> _userSettings;

        public PaymentService(ILogger logger, IOrganizationService service,
            IRepository<Payment> paymentRepository, IRepository<PaymentSchedule> paymentScheduleRepository, IRepository<Transaction> transactionRepository, 
            IRepository<GiftPack> giftPackRepository, IRepository<CancellationReason> cancellationResonRepository,
            CustomAPIInvocationService customAPIInvocationService, PropertyRetrievalService propertyRetrievalService, IRepository<Entities.Generated.Membership> membershipRepository)
        {
            _logger = logger;
            _service = service;
            _transactionRepository = transactionRepository;
            _paymentRepository = paymentRepository;
            _paymentScheduleRepository = paymentScheduleRepository;
            _giftPackRepository = giftPackRepository;
            _cancellationResonRepository = cancellationResonRepository;
            _customAPIInvocationService = customAPIInvocationService;
            _propertyRetrievalService = propertyRetrievalService;
            _membershipRepository = membershipRepository;
        }

        public void RefundGiftPackPayment(Payment payment)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (payment.Transaction != null &&
                payment.Refund == true && (payment.PaymentMethodType == PaymentMethodType_GlobalOptionSet.Card || payment.PaymentMethodType == PaymentMethodType_GlobalOptionSet.CreditCard_Phone))
            {
                var transaction = _transactionRepository.GetById(payment.Transaction.Id);
                if (transaction.GiftPackId != null)
                {
                    _logger.TraceInformation($"Refunding gift pack payment.");
                    var giftPack = _giftPackRepository.GetById(transaction.GiftPackId.Id);

                    _logger.TraceInformation($"Invoking stripe refund for the gift pack card payment.");
                    var refundId = _customAPIInvocationService.InvokeStripeRefundCustomAPI(giftPack.PaymentIntentId);
                    if (refundId != null)
                    {
                        _logger.TraceInformation($"Stripe refund succesfful.");

                        _logger.TraceInformation($"Updating associated transaction to set Amount = Total Amount - Refund Amount.");
                        var transactionUpdate = new Transaction()
                        {
                            Id = transaction.Id,
                            Amount = new Money(transaction.Amount.Value - payment.Amount.Value)
                        };
                        _transactionRepository.Update(transactionUpdate);
                        _logger.TraceInformation($"Associated transaction updated.");

                        _logger.TraceInformation($"Setting Payment.Status = Paid on getting success from Stripe.");
                        var paymentUpdate = new Payment()
                        {
                            Id = payment.Id,
                            Statecode = PaymentState.Inactive,
                            Statuscode = PaymentStatus.Inactive_Paid,
                            RefundId = refundId,
                        };
                        _paymentRepository.Update(paymentUpdate);
                        _logger.TraceInformation($"Payment updated.");
                    }
                    else
                    {
                        var errorMessage = "Payment refund failed. Please try again.";
                        _logger.TraceError(errorMessage);
                        throw new InvalidPluginExecutionException(errorMessage);
                    }
                }
            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void GiftAidOverrideToEligible(Entity payment)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Checking if Payment.GiftAidOverrideToIneligible = true.");
            var giftAidOverrideToIneligible = payment.GetAttributeValue<bool?>("rhs_giftaidoverrideineligible");
            var giftAidEligibility = payment.GetAttributeValue<bool?>("rhs_giftaideligibility");
            _logger.TraceInformation($"Checking if Payment.GiftAidOverrideToIneligible = {giftAidOverrideToIneligible}.");

            if (giftAidOverrideToIneligible == true && giftAidEligibility == true)
            {
                var paymentUpdate = new Entity(payment.LogicalName, payment.Id);

                _logger.TraceInformation($"Checking Payment.GiftAidClaimStatus.");
                var giftAidClaimStatus = payment.GetAttributeValue<OptionSetValue?>("rhs_giftaidstatus");
                if (giftAidClaimStatus == null)
                {
                    _logger.TraceInformation($"Payment.GiftAidClaimStatus = null.");
                    _logger.TraceInformation($"Setting Payment.GiftAidEligibility = false.");

                    paymentUpdate["rhs_giftaideligibility"] = false;
                    _service.Update(paymentUpdate);
                }
                else
                {
                    switch (giftAidClaimStatus.Value)
                    {
                        case 120000003 /*Not for Submission*/:
                            _logger.TraceInformation($"Payment.GiftAidClaimStatus = Not for Submission.");
                            _logger.TraceInformation($"Setting Payment.GiftAidEligibility = false.");

                            paymentUpdate["rhs_giftaideligibility"] = false;
                            _service.Update(paymentUpdate);
                            break;
                        case 120000000 /*Pending*/:
                            _logger.TraceInformation($"Payment.GiftAidClaimStatus = Pending.");
                            _logger.TraceInformation($"Setting Payment.GiftAidEligibility = false and Payment.GiftAidClaimStatus = Not for Submission.");

                            paymentUpdate["rhs_giftaideligibility"] = false;
                            paymentUpdate["rhs_giftaidstatus"] = new OptionSetValue(120000003 /*Not for Submission*/);
                            _service.Update(paymentUpdate);
                            break;
                        case 120000001 /*Submitted*/:
                            _logger.TraceInformation($"Payment.GiftAidClaimStatus = Submitted.");
                            _logger.TraceInformation($"Setting Payment.GiftAidEligibility = false.");

                            paymentUpdate["rhs_giftaideligibility"] = false;
                            _service.Update(paymentUpdate);

                            _logger.TraceInformation($"Comparing Payment.GiftRefundClaimAmount with  Payment.GiftAidClaimAmount.");

                            var giftAidClaimAmount = payment.GetAttributeValue<Money?>("rhs_giftaidclaimamount");
                            var giftAidClaimAmountValue = giftAidClaimAmount == null ? 0 : new Money(giftAidClaimAmount.Value).Value;
                            var giftAidRefundAmount = payment.GetAttributeValue<Money?>("rhs_giftaidrefundamount");
                            var giftAidRefundAmountValue = giftAidRefundAmount == null ? 0 : new Money(giftAidRefundAmount.Value).Value;
                            if (giftAidRefundAmountValue < giftAidClaimAmountValue)
                            {
                                _logger.TraceInformation($"Payment.GiftRefundClaimAmount < Payment.GiftAidClaimAmount.");
                                _logger.TraceInformation($"Creating new GiftAidRefund record.");

                                var originalPayment = payment.GetAttributeValue<EntityReference?>("rhs_refundoriginalpayment");

                                var giftAidRefundCreate = new Entity("rhs_giftaidrefund");
                                giftAidRefundCreate["rhs_status"] = new OptionSetValue(120000001 /*Pending*/);
                                giftAidRefundCreate["rhs_reason"] = new OptionSetValue(120000003 /*Manual Override*/);
                                giftAidRefundCreate["rhs_amount"] = new Money(giftAidClaimAmountValue - giftAidRefundAmountValue);
                                giftAidRefundCreate["rhs_payment"] = originalPayment;

                                _service.Create(giftAidRefundCreate);
                            }
                            else
                            {
                                _logger.TraceInformation($"Payment.GiftRefundClaimAmount >=  Payment.GiftAidClaimAmount.");
                                _logger.TraceInformation($"Doing nothing.");
                            }
                            break;
                    }
                }
            }

            _logger.TraceInformation($"Ending business logic.");
        }
        public void SetGiftAidEligible(Payment payment)
        {
            try
            {
                _logger.TraceInformation("Starting business logic.");

                if (payment.Refund == false)
                {
                    if (payment.Transaction == null)
                    {
                        _logger.TraceInformation("No related transaction for this payment");
                        _logger.TraceInformation("Ending business logic.");
                        return;
                    }
                    _logger.TraceInformation($"SetGiftAidEligible called with PaymentId = {payment.Id}");
                    bool isGiftAidEligible = true;
                    decimal ddTotalAmount = 0;
                    Money amount = payment.GetAttributeValue<Money>(EntityNames.Payment.Amount);
                    bool isGiftAidEligibility = payment.GetAttributeValue<bool>(EntityNames.Payment.GiftAidEligibility);
                    var transaction = _transactionRepository.GetById(payment.Transaction.Id);

                    // Check if the associated Product is ineligible for Gift Aid
                    var productReference = transaction.Product;
                    if (productReference != null && payment.Product != null)
                    {
                        var productPropertyValue = _propertyRetrievalService.GetDefaultOptionSetValueNameOfProductProperty(productReference.Id, "Gift Aid Eligible");
                        if (productPropertyValue == "No")
                        {
                            _logger.TraceInformation("Product is not eligible for Gift Aid.");
                            _logger.TraceInformation($"productPropertyValue = {productPropertyValue}.");
                            isGiftAidEligible = false; // Set to No if product is ineligible
                            _logger.TraceInformation("productPropertyValue == No : Setting isGiftAidEligible = false and stopping further processing.");

                            return;
                        }
                    }

                    if (payment.PaymentType.HasValue)
                    {
                        if (payment.PaymentType == NewTransactionType_GlobalOptionSet.Membership)
                        {
                            if (transaction?.MembershipId?.Id != null)
                            {
                                // Check if associated Membership is for someone else
                                Entity membership = _service.Retrieve(EntityNames.Membership.EntityLogicalName,transaction.MembershipId.Id,new ColumnSet(EntityNames.Membership.IsMembershipForSomeone,EntityNames.Membership.Giftaidoverride));

                                bool isForSomeoneElse = membership.GetAttributeValue<bool?>(EntityNames.Membership.IsMembershipForSomeone) ?? false;
                                if (isForSomeoneElse)
                                {
                                    _logger.TraceInformation("Membership is for someone else. Setting Gift Aid eligibility to No.");
                                    isGiftAidEligible = false; // Set to No if membership is for someone else
                                    _logger.TraceInformation("isForSomeoneElse = true : Setting isGiftAidEligible = false and stopping further processing.");
                                    return;
                                }

                                bool giftAidOverride = membership.GetAttributeValue<bool?>(EntityNames.Membership.Giftaidoverride) ?? false;
                                if (giftAidOverride)
                                {
                                    _logger.TraceInformation("Membership has Gift Aid Override = Yes. Setting Gift Aid eligibility to No.");
                                    isGiftAidEligible = false; // // Set to No if Membership Gift Aid Override = YES
                                    _logger.TraceInformation("giftAidOverride = true : Setting isGiftAidEligible = false and stopping further processing.");
                                    return;
                                }

                                var transactionProductRef = transaction?.Product.Name.ToLower();
                                if (transactionProductRef.Contains("patron"))
                                {
                                    _logger.TraceInformation("Membership is patron. Setting Gift Aid eligibility to No.");
                                    isGiftAidEligible = false;
                                    _logger.TraceInformation("transactionProductRef.Contains patron : productPropertyValue == No : Setting isGiftAidEligible = false and stopping further processing.");

                                    return;
                                }
                            }
                        }
                        else if (payment.PaymentType == NewTransactionType_GlobalOptionSet.Donation)
                        {
                            _logger.TraceInformation("PaymentType is Donation");
                            if (payment.Transaction != null && transaction?.MembershipId == null)
                            {
                                //Retrieve transaction to get related donation and donation type
                                var query = new FetchExpression($@"<fetch>
                                  <entity name='rhs_transaction'>
                                    <attribute name='rhs_donation' />
                                    <filter>
                                      <condition attribute='rhs_transactionid' operator='eq' value='{payment.Transaction.Id}' />
                                    </filter>
                                    <link-entity name='rhs_donation' from='rhs_donationid' to='rhs_donation' alias='donation'>
                                      <attribute name='rhs_anonymous' />
                                      <attribute name='rhs_ineligibleforgiftaid' />
                                      <link-entity name='rhs_donationtype' from='rhs_donationtypeid' to='rhs_donationtype' alias='donationtype'>
                                        <attribute name='rhs_giftaideligible' />
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>");
                                Entity transactionRecord = _service.RetrieveMultiple(query).Entities.FirstOrDefault();

                                if (transactionRecord != null)
                                {
                                    var donation = transactionRecord.GetAttributeValue<EntityReference>("rhs_donation");
                                    _logger.TraceInformation($"Donation Id: {donation.Id}");
                                    var isDonationAnonymous = (bool)((AliasedValue)transactionRecord["donation.rhs_anonymous"]).Value;
                                    _logger.TraceInformation($"Anonymous: {isDonationAnonymous}");
                                    var isDonationIneligibleforgiftaid = (bool)((AliasedValue)transactionRecord["donation.rhs_ineligibleforgiftaid"]).Value;
                                    _logger.TraceInformation($"Ineligibleforgiftaid: {isDonationIneligibleforgiftaid}");
                                    var isDonationTypeGiftaideligible = (bool)((AliasedValue)transactionRecord["donationtype.rhs_giftaideligible"]).Value;
                                    _logger.TraceInformation($"Giftaideligible: {isDonationTypeGiftaideligible}");

                                    // Check if donation is paid by an organisation (donor = account) OR donation is anonymous = yes OR donation ineligible for gift aid = yes OR donation type - gift aid eligible = no
                                    if (payment.PayerAccountRef != null || isDonationAnonymous || isDonationIneligibleforgiftaid || !isDonationTypeGiftaideligible)
                                    {
                                        _logger.TraceInformation("Donation is not eligible. Setting Gift Aid eligibility to No.");
                                        isGiftAidEligible = false;
                                        _logger.TraceInformation("payment.PayerAccountRef != null || isDonationAnonymous || isDonationIneligibleforgiftaid || !isDonationTypeGiftaideligible: Setting isGiftAidEligible = false and stopping further processing.");

                                        return;
                                    }

                                }
                            }
                        }
                    }
                    //Check if the associated Batch Order Line has “Ineligible for Gift Aid” = Yes,  then set Gift Aid Eligible = No
                    if (payment.Batchorderline != null)
                    {
                        _logger.TraceInformation($"Payment has Batch Order Line reference. ID: {payment.Batchorderline.Id}");

                        var batchOrderLineRecord = _service.Retrieve(EntityNames.Batchorderline.EntityLogicalName, payment.Batchorderline.Id,
                            new ColumnSet(EntityNames.Batchorderline.IneligibleforGiftAid)
                        ).ToEntity<Batchorderline>();

                        if (batchOrderLineRecord == null)
                        {
                            _logger.TraceInformation("No Batch Order Line record was retrieved.");
                        }
                        else
                        {
                            bool isBatchOrderLineIneligible = batchOrderLineRecord.IneligibleforGiftAid.GetValueOrDefault();
                            _logger.TraceInformation($"Batch Order Line IneligibleForGiftAid value: {batchOrderLineRecord.IneligibleforGiftAid}");

                            if (isBatchOrderLineIneligible)
                            {
                                _logger.TraceInformation("Batch Order Line is ineligible. Setting Gift Aid eligibility to No.");
                                isGiftAidEligible = false;
                                return;
                            }
                        }
                    }

                    if (!payment.PaymentMethodType.HasValue ||
                        (payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.Cash &&
                         payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.Card &&
                         payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.CreditCard_Phone &&
                         payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.Cheque &&
                         payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.DirectDebit &&
                         payment.PaymentMethodType != PaymentMethodType_GlobalOptionSet.PWAC))
                    {
                        _logger.TraceInformation("Payment method is not an allowed type. Setting Gift Aid eligibility to No.");
                        isGiftAidEligible = false; // Set to No if payment method is not allowed types
                        return;
                    }

                    if (payment.PaymentType == NewTransactionType_GlobalOptionSet.Membership)
                    {
                        //Function for paymentmethod !=DD  is added on UpdatePreOps
                        if (payment.PaidOn.HasValue)
                        {
                            var paymentPaidon = payment.PaidOn.Value;
                            _logger.TraceInformation($"PaidOn: {paymentPaidon}");
                        }
                        else
                        {
                            _logger.TraceInformation("PaidOn is null.");
                        }



                        if (payment.PaymentMethodType == PaymentMethodType_GlobalOptionSet.DirectDebit)  
                        {
                            var totalAmountPayments = 0m;
                            DateTime ? firstPaymentDate = null;
                            _logger.TraceInformation("after RetrieveMembershipDirectDebitPayments");
                            var relatedDDPayments = RetrieveMembershipDirectDebitPayments(payment);

                            totalAmountPayments = transaction.Amount.Value;

                            if (relatedDDPayments.Count > 0)
                            {
                                var firstPayment = relatedDDPayments.First();
                                if (firstPayment.PaidOn.HasValue)
                                {
                                    if (!firstPaymentDate.HasValue || firstPayment.PaidOn.Value < firstPaymentDate.Value)
                                        firstPaymentDate = firstPayment.PaidOn.Value;
                                }
                                if (firstPayment.DueDate.HasValue)
                                {
                                    if (!firstPaymentDate.HasValue || firstPayment.DueDate.Value < firstPaymentDate.Value)
                                        firstPaymentDate = firstPayment.DueDate.Value;
                                }
                            }

                            /* Misflagging gift aid eligibility as false because not all dd payments are created yet when retrieving and using them to calculate totalAmountPayments. The firstPaymentDate calculation is also wrong.
                            foreach (var p in relatedDDPayments)
                            {
                                if (p.Amount != null)
                                    totalAmountPayments += p.Amount.Value;

                                if (p.PaidOn.HasValue)
                                {
                                    if (!firstPaymentDate.HasValue || p.PaidOn.Value < firstPaymentDate.Value)
                                        firstPaymentDate = p.PaidOn.Value;
                                }
                                if (p.DueDate.HasValue)
                                {
                                    if (!firstPaymentDate.HasValue || p.DueDate.Value < firstPaymentDate.Value)
                                        firstPaymentDate = p.DueDate.Value;
                                }
                            }
                            */

                            _logger.TraceInformation($"Total amount: {totalAmountPayments}");
                            _logger.TraceInformation(firstPaymentDate.HasValue? $"First payment date: {firstPaymentDate.Value}": "FirstPayment has no value" );

                            if (firstPaymentDate.HasValue)
                            {
                                var giftAidThreshold = FindGiftAidThreshold(payment.Product.Id, firstPaymentDate);
                                if (giftAidThreshold != null)
                                {
                                    decimal thresholdValue = giftAidThreshold.Value != null ? giftAidThreshold.Value.Value : 0m;

                                    if (totalAmountPayments < thresholdValue)
                                    {
                                        isGiftAidEligible = false;
                                        _logger.TraceInformation("Payment method = DD: totalAmountPayments < thresholdValue,setting Gift Aid eligibility to No.");
                                        return;
                                    }
                                }
                            }
                            else
                            {
                                _logger.TraceInformation("Payment method = DD: firstPaymentDate date is missing. Skipping Gift Aid Threshold check.");
                            }

                        }
                    }

                    var paymentUpdate = new Payment()
                    {
                        Id = payment.Id,
                        GiftAidEligibility = isGiftAidEligible
                    };

                    _service.Update(paymentUpdate);
                    _logger.TraceInformation($"Payment updated: Gift Aid eligibility set to {isGiftAidEligible}.");
  
                }
                else
                {
                    _logger.TraceInformation("Payment is refunded. No update made.");
                }

                _logger.TraceInformation("Ending business logic.");
            }
            catch (Exception ex)
            {
                _logger.TraceError("An error occurred in SetGiftAidEligible.", ex);
                throw;
            }
        }

        /// <summary>
        /// Sets Donation and Restricted Fund on Payment creation (for Donation-related payments).
        /// </summary>
        public void SetDonationAndRestrictedFundOnCreate(Payment payment)
        {
            _logger.TraceInformation("Starting SetDonationAndRestrictedFundOnCreate logic.");

            try
            {
                _logger.TraceInformation($"Processing Payment: {payment.Id}");

                // Proceed only if Payment Type = Donation in the Payment record
                if (payment.PaymentType != NewTransactionType_GlobalOptionSet.Donation)
                {
                    _logger.TraceInformation($"Payment Type is not Donation ({payment.PaymentType}). Skipping logic.");
                    return;
                }

                EntityReference donationRef = payment.Donation;

                // If Donation is null, try retrieving from related Transaction
                if (donationRef == null)
                {
                    if (payment.Transaction != null)
                    {
                        _logger.TraceInformation($"Donation lookup is empty. Checking linked Transaction ({payment.Transaction.Id}) for Donation...");

                        Entity transaction = _service.Retrieve(
                            EntityNames.Transaction.EntityLogicalName,
                            payment.Transaction.Id,
                            new ColumnSet(EntityNames.Transaction.Donation)
                        );

                        donationRef = transaction.GetAttributeValue<EntityReference>(EntityNames.Transaction.Donation);

                        if (donationRef != null)
                            _logger.TraceInformation($"Found Donation from Transaction: {donationRef.Id}");
                        else
                        {
                            _logger.TraceInformation("No Donation found on Transaction. Skipping update.");
                            return;
                        }
                    }
                    else
                    {
                        _logger.TraceInformation("No Transaction lookup on Payment. Skipping logic.");
                        return;
                    }
                }
                else
                {
                    _logger.TraceInformation($"Donation lookup already populated: {donationRef.Id}");
                }

                // Retrieve Donation to get its Restricted Fund
                _logger.TraceInformation($"Retrieving Restricted Fund from Donation ({donationRef.Id})...");
                Entity donationEntity = _service.Retrieve(
                    EntityNames.Donation.EntityLogicalName,
                    donationRef.Id,
                    new ColumnSet(EntityNames.Donation.RestrictedFund)
                );

                EntityReference restrictedFundRef = donationEntity.GetAttributeValue<EntityReference>(EntityNames.Donation.RestrictedFund);

                if (restrictedFundRef == null)
                {
                    _logger.TraceInformation($"Donation ({donationRef.Id}) has no Restricted Fund. Skipping Payment update.");
                    return;
                }

                // Update Payment with Donation and Restricted Fund
                Entity paymentUpdate = new Entity(EntityNames.Payment.EntityLogicalName, payment.Id)
                {
                    [EntityNames.Payment.Donation] = donationRef,
                    [EntityNames.Payment.Restrictedfund] = restrictedFundRef
                };

                _service.Update(paymentUpdate);

                _logger.TraceInformation($"Payment updated successfully with Donation ({donationRef.Id}) and Restricted Fund ({restrictedFundRef.Id}).");
            }
            catch (Exception ex)
            {
                _logger.TraceError("Error in SetDonationAndRestrictedFundOnCreate", ex);
                throw new InvalidPluginExecutionException("Failed to set Donation and Restricted Fund on Payment creation.", ex);
            }

            _logger.TraceInformation("Ending SetDonationAndRestrictedFundOnCreate logic.");
        }



        public void CompareGiftAidThresholdOnUpdate(Entity payment) 
        {
            _logger.TraceInformation($"Starting business logic.");


            var cultivateConfigurations = RetrieveGiftAidThresholdConfiguration();
            var giftAidAmount = cultivateConfigurations.First().GetAttributeValue<string>(EntityNames.Cultivateconfigurations.Value);
            var giftAidThreshold = decimal.Parse(giftAidAmount, CultureInfo.InvariantCulture);

            var paymentMethod = payment.GetAttributeValue<OptionSetValue?>(EntityNames.Payment.PaymentMethodType);
            Money amount = payment.GetAttributeValue<Money>(EntityNames.Payment.Amount);
            bool isGiftAidEligibility = payment.GetAttributeValue<bool>(EntityNames.Payment.GiftAidEligibility);
            decimal ddTotalAmount = 0;

            if (paymentMethod.Value != 120000002)
            {
                _logger.TraceInformation("Payment Method is not direct debit ");
                var paymentUpdate = new Entity(payment.LogicalName, payment.Id);
                if (amount.Value < giftAidThreshold)
                {
                    if (isGiftAidEligibility)
                    {
                        paymentUpdate[EntityNames.Payment.GiftAidEligibility] = false;
                        _service.Update(paymentUpdate);
                    }
                    _logger.TraceInformation($"Payment updated: Gift Aid eligibility set to {isGiftAidEligibility}.");

                }
            }
            else if (paymentMethod.Value == 120000002)
            {
                _logger.TraceInformation("Payment Method is direct debit ");

                var paymentCollection = RetrievePaymentRecords(payment);

                foreach (var payments in paymentCollection)
                {
                    ddTotalAmount += payments.GetAttributeValue<Money>(EntityNames.Payment.Amount).Value;
                }

                if (ddTotalAmount > giftAidThreshold)
                {
                    foreach (var paymentToUpdate in paymentCollection)
                    {
                        if (!paymentToUpdate.GetAttributeValue<bool>(EntityNames.Payment.GiftAidEligibility) &&
                            !paymentToUpdate.GetAttributeValue<bool>(EntityNames.Payment.GiftAidOverrideIneligible))
                        {
                            var updatePayment = new Entity(paymentToUpdate.LogicalName, paymentToUpdate.Id);
                            updatePayment[EntityNames.Payment.GiftAidEligibility] = true;
                            _service.Update(updatePayment);

                            _logger.TraceInformation($"Payment updated: Gift Aid eligibility set to {isGiftAidEligibility}.");

                        }
                    }
                }
                else
                {
                    foreach (var paymentToUpdate in paymentCollection)
                    {
                        if (paymentToUpdate.GetAttributeValue<bool>(EntityNames.Payment.GiftAidEligibility))
                        {
                            var updatePayment = new Entity(paymentToUpdate.LogicalName, paymentToUpdate.Id);
                            updatePayment[EntityNames.Payment.GiftAidEligibility] = false;
                            _service.Update(updatePayment);

                            _logger.TraceInformation($"Payment updated: Gift Aid eligibility set to {isGiftAidEligibility}.");
                        }
                    }
                }
            }
            _logger.TraceInformation("Ending business logic.");
        } // NOT IN USE

        public List<Entity> RetrieveGiftAidThresholdConfiguration() // NOT IN USE
        {
            _logger.TraceInformation("Retrieving Gift Aid Threshold Configuration");
            var query = new QueryExpression("rhs_cultivateconfigurations");
            query.ColumnSet.AddColumns("rhs_name", "rhs_value");
            query.Criteria.AddCondition("rhs_name", ConditionOperator.Equal, "GiftAidThreshold");
            var cultivateConfigurations = _service.RetrieveMultiple(query).Entities.ToList();

            if (cultivateConfigurations.Count == 0)
                throw new InvalidPluginExecutionException($"Missing \"GiftAidThreshold\" cultivate configuration value. Please reach out to an administrator to fix this.");

            return cultivateConfigurations;
        }

        public List<Entity> RetrievePaymentRecords(Entity payment)
        {
            _logger.TraceInformation("Retrieving payment records");
            var paymentQuery = new QueryExpression("rhs_payment");
            paymentQuery.ColumnSet.AddColumns("rhs_paymentsid", "rhs_transaction", "rhs_amount", "rhs_giftaideligibility", "rhs_giftaidoverrideineligible");
            paymentQuery.Criteria.AddCondition("rhs_transaction", ConditionOperator.Equal, payment.GetAttributeValue<EntityReference>("rhs_transaction").Id);
            var paymentCollection = _service.RetrieveMultiple(paymentQuery).Entities.ToList();

            if (paymentCollection.Count == 0)
                throw new InvalidPluginExecutionException($"No payments record found");

            return paymentCollection;
        }

        public Transaction RetrieveTransaction(Payment payment)
        {
            _logger.TraceInformation("Starting business logic.");

            if (payment.Transaction == null)
            {
                _logger.TraceInformation("Payment does not have transaction.");
                _logger.TraceInformation("Ending business logic.");
                return null;
            }
            var transaction = _transactionRepository.GetById(payment.Transaction.Id);

            _logger.TraceInformation("Ending business logic.");
            return transaction;
        }

        public PaymentSchedule RetrievePaymentSchedule(Payment payment)
        {
            _logger.TraceInformation("Starting business logic.");

            if (payment.PaymentSchedule == null)
            {
                _logger.TraceInformation("Payment does not have payment schedule.");
                _logger.TraceInformation("Ending business logic.");
                return null;
            }
            var paymentSchedule = _paymentScheduleRepository.GetById(payment.PaymentSchedule.Id);

            _logger.TraceInformation("Ending business logic.");
            return paymentSchedule;
        }

        public void SetPaymentDateWhenPaid(ref Entity target, ref Payment postImage)
        {
            _logger.TraceInformation("Starting business logic.");

            if (postImage.Statuscode == PaymentStatus.Inactive_Paid)
            {
                _logger.TraceInformation("Payment status is paid.");
                if (!(postImage.Createdfromthirdpartydonation ?? false))
                {
                    _logger.TraceInformation("Setting Paid On value to today.");
                    postImage.PaidOn = DateTime.UtcNow;
                    target[EntityNames.Payment.PaidOn] = postImage.PaidOn;
                }

                if (postImage.PaidOn.HasValue)
                {
                    _logger.TraceInformation("Calling Gift Aid logic after PaidOn is set.");
                    _logger.TraceInformation(
                        $"postImage values => " +
                        $"GiftAidEligibility: {postImage.GiftAidEligibility}, " +
                        $"PaymentType: {postImage.PaymentType}, " +
                        $"PaymentMethod: {postImage.PaymentMethodType}, " +
                        $"PaidOn: {postImage.PaidOn}, " +
                        $"Amount: {postImage.Amount?.Value}, " +
                        $"ProductId: {(postImage.Product?.Id != null ? postImage.Product.Id.ToString() : "NULL")}");

                    SetGiftAidEligibleforNonDD(ref target, ref postImage);
                }
            }
            else
            {
                _logger.TraceInformation("Payment status is not paid.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void SetGiftAidEligibleforNonDD(ref Entity target, ref Payment postImage)
        {
            _logger.TraceInformation("Entered SetGiftAidEligibleforDD.");

            // Gift Aid Logic, when Payment paymentmethod !== DD
            if (postImage.GiftAidEligibility == true)
            {
                _logger.TraceInformation("Payment is currently eligible for Gift Aid. Checking conditions...");

                if (postImage.PaymentType == NewTransactionType_GlobalOptionSet.Membership)
                {
                    _logger.TraceInformation("PaymentType == Membership.");


                    if (postImage.PaymentMethodType != PaymentMethodType_GlobalOptionSet.DirectDebit)
                    {
                        _logger.TraceInformation("PaymentMethod is != DD");

                        if (postImage.PaidOn.HasValue)
                        {
                            _logger.TraceInformation("Paid On date is available. Retrieving Gift Aid Threshold...");

                            var giftAidThreshold = FindGiftAidThreshold(postImage.Product?.Id, postImage.PaidOn);

                            if (giftAidThreshold != null)
                            {
                                decimal thresholdValue = giftAidThreshold.Value?.Value ?? 0m;
                                decimal paymentAmount = postImage.Amount?.Value ?? 0m;
                                decimal originalAmount = postImage.Amount.Value;

                                _logger.TraceInformation($"Gift Aid Threshold Value: {thresholdValue}, Payment Amount: {paymentAmount}");

                                if (paymentAmount < thresholdValue)
                                {
                                    postImage.GiftAidEligibility = false;
                                    target[EntityNames.Payment.GiftAidEligibility] = postImage.GiftAidEligibility;

                                    _logger.TraceInformation("Payment amount below threshold. Setting Gift Aid eligibility to No.");
                                    return;
                                }
                            }
                        }
                        else
                        {
                            _logger.TraceInformation("Payment != DD: PaidOn date is missing. Skipping Gift Aid Threshold check.");
                        }
                    }
                }
            }
        }

        public void SetPaymentGiftAidStatus(ref Entity target, Payment preImage, ref Payment postImage)
        {
            _logger.TraceInformation("Starting business logic.");

            if (preImage.Statuscode == PaymentStatus.Active_Overdue)
            {
                _logger.TraceInformation("Payment status changed from overdue.");

                _logger.TraceInformation("Setting Gift Aid Status value to pending.");
                postImage.GiftAidStatus = PaymentGiftAidStatus_GlobalOptionSet.Pending;
                target[EntityNames.Payment.GiftAidStatus] = new OptionSetValue((int)postImage.GiftAidStatus.Value);
            }
            else
            {
                _logger.TraceInformation("Payment status did not change from overdue.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void UpdatePaymentDueOfPaymentScheduleWhenPartiallyPaid(Payment payment, PaymentSchedule paymentSchedule)
        {
            _logger.TraceInformation("Starting business logic.");

            if (payment.Statuscode != PaymentStatus.Inactive_Paid)
            {
                _logger.TraceInformation("Payment status is not paid.");
                _logger.TraceInformation("Ending business logic.");
                return;
            }

            _logger.TraceInformation("Checking if associated payment schedule has pending payments.");
            var pendingPaymentSchedulePayments = _paymentRepository.GetAll().Where(p =>
                p.PaymentSchedule == payment.PaymentSchedule &&
                p.Statuscode == PaymentStatus.Active_PendingPayment &&
                p.Id != payment.Id
            ).ToList();
            if (pendingPaymentSchedulePayments.Any())
            {
                _logger.TraceInformation("Pending payments detected.");

                _logger.TraceInformation("Updating associated payment schedule's Payment Due value.");
                var dueDates = pendingPaymentSchedulePayments.Select(payment => payment.DueDate).OrderBy(dueDate => dueDate).ToList();
                var paymentScheduleUpdate = new PaymentSchedule()
                {
                    Id = payment.PaymentSchedule.Id,
                    PaymentDue = dueDates.FirstOrDefault()
                };
                _paymentScheduleRepository.Update(paymentScheduleUpdate);
            }
            else
            {
                _logger.TraceInformation("No pending payments.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void UpdateTransactionStatus(Payment payment, Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            #region Update Transaction as Paid?
            _logger.TraceInformation("Checking if associated transaction should be set to paid.");

            if (payment.Statuscode == PaymentStatus.Inactive_Paid)
            {
                _logger.TraceInformation("Payment overdue.");

                if (transaction.Statuscode != TransactionStatus.Inactive_Paid)
                {
                    var unpaidTransactionPayments = _paymentRepository.GetAll().Where(p =>
                        p.Id != payment.Id &&
                        p.Transaction != null && p.Transaction.Id == payment.Transaction.Id &&
                        p.Statuscode != PaymentStatus.Inactive_Paid
                    ).ToList();

                    if (!unpaidTransactionPayments.Any())
                    {
                        _logger.TraceInformation("No unpaid payments left for the transaction.");

                        _logger.TraceInformation("Updating transaction status to paid.");
                        var transactionUpdate = new Transaction()
                        {
                            Id = payment.Transaction.Id,
                            Statecode = TransactionState.Inactive,
                            Statuscode = TransactionStatus.Inactive_Paid
                        };
                        _transactionRepository.Update(transactionUpdate);
                    }
                    else
                    {
                        _logger.TraceInformation("Unpaid payments detected for the transaction.");
                    }
                }
                else
                {
                    _logger.TraceInformation("Transaction already set to paid.");
                }
            }
            else
            {
                _logger.TraceInformation("Will not update transaction to paid because payment not paid.");
            }
            #endregion

            #region Update Transaction as Overdue?
            _logger.TraceInformation("Checking if transaction should become overdue.");
            if (payment.Statuscode == PaymentStatus.Active_Overdue)
            {
                _logger.TraceInformation("Payment overdue.");

                if (transaction.Statuscode != TransactionStatus.Active_Overdue)
                {
                    _logger.TraceInformation("Updating transaction status to overdue.");
                    var transactionUpdate = new Transaction()
                    {
                        Id = payment.Transaction.Id,
                        Statecode = TransactionState.Active,
                        Statuscode = TransactionStatus.Active_Overdue
                    };
                    _transactionRepository.Update(transactionUpdate);
                }
                else
                {
                    _logger.TraceInformation("Transaction already set to overdue.");
                }
            }
            else
            {
                _logger.TraceInformation("Will not update transaction to overdue because payment not overdue.");
            }
            #endregion

            _logger.TraceInformation("Ending business logic.");
        }

        public void UpdateTransactionOustandingAmountOnPay(Payment payment, Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            if ((payment.Statuscode == PaymentStatus.Inactive_Paid && payment.Refund != true) ||
                 payment.Statuscode == PaymentStatus.Inactive_Reversed)
            {
                _logger.TraceInformation("Calculating transaction's outstanding amount.");
                var paidPaymentAmounts = _paymentRepository.GetAll().Where(p =>
                    p.Transaction != null && p.Transaction.Id == payment.Transaction.Id &&
                    p.Statuscode == PaymentStatus.Inactive_Paid &&
                    p.Refund != true &&
                    p.Amount != null
                ).Select(payment => payment.Amount).ToList();
                var remainingOutstandingAmount = new Money(transaction.Amount.Value - paidPaymentAmounts.Sum(payment => payment.Value));
                
                if (transaction.OutstandingAmount?.Value != remainingOutstandingAmount?.Value)
                {
                    _logger.TraceInformation("Updating transaction's outstaning amount.");
                    var transactionUpdate = new Transaction()
                    {
                        Id = payment.Transaction.Id,
                        OutstandingAmount = remainingOutstandingAmount
                    };
                    _transactionRepository.Update(transactionUpdate);
                }
                else
                {
                    _logger.TraceInformation("Outstaning amount amount remains the same.");
                }
            }
            else
            {
                _logger.TraceInformation("Payment's transaction not eligible for outstanding amount update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void CancelAssociatedRecordsWhenDDPaymentCountReachThreshold(Payment payment, Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            _logger.TraceInformation($"Payment Schedule = {payment.PaymentSchedule}.");
            _logger.TraceInformation($"Payment Method = {payment.PaymentMethodType}.");
            _logger.TraceInformation($"DD Failure Count = {payment.DDFailureCount}.");

            if (payment.PaymentSchedule == null && 
                payment.PaymentMethodType == PaymentMethodType_GlobalOptionSet.DirectDebit &&
                payment.DDFailureCount != null && payment.DDFailureCount >= 2)
            {
                switch (payment.PaymentType)
                {
                    case NewTransactionType_GlobalOptionSet.Membership:
                        _logger.TraceInformation("Detected membership transaction type.");

                        if (transaction.MembershipId == null)
                        {
                            _logger.TraceInformation("Cannot proceed because no membership associated to transaction.");
                            _logger.TraceInformation("Ending business logic.");
                            return;
                        }

                        _logger.TraceInformation("Retrieving DD Denied cancellation reason.");
                        var ddDeniedCancellationReasonForMembership = _cancellationResonRepository.GetAll().Where(cr =>
                            cr.Name == "DD Denied" &&
                            cr.CancellationType == Cancellationtypecode_GlobalOptionSet.Membership
                        ).FirstOrDefault();

                        _logger.TraceInformation("Preparing to cancel membership.");
                        var membershipUpdate = new Entity("rhs_membership", transaction.MembershipId.Id);
                        membershipUpdate["rhs_cancelmembership"] = true;
                        membershipUpdate["rhs_cancellationtype"] = new OptionSetValue(120000000); //Now
                        membershipUpdate["rhs_membershipcancellationreasonid"] = ddDeniedCancellationReasonForMembership.ToEntityReference();
                        membershipUpdate["statecode"] = new OptionSetValue(1); //Inactive
                        membershipUpdate["statuscode"] = new OptionSetValue(2); //Cancelled

                        _logger.TraceInformation("Canceling memberhip. This should also cancel it's associated records");
                        _service.Update(membershipUpdate);

                        break;
                    case NewTransactionType_GlobalOptionSet.Subscriptions:
                        _logger.TraceInformation("Detected subscription transaction type.");

                        if (transaction.SubscriptionId == null)
                        {
                            _logger.TraceInformation("Cannot proceed because no subscription associated to transaction.");
                            _logger.TraceInformation("Ending business logic.");
                            return;
                        }

                        _logger.TraceInformation("Retrieving DD Denied cancellation reason.");
                        var ddDeniedCancellationReasonForSubscription = _cancellationResonRepository.GetAll().Where(cr =>
                            cr.Name == "DD Denied" &&
                            cr.CancellationType == Cancellationtypecode_GlobalOptionSet.Subscription
                        ).FirstOrDefault();

                        _logger.TraceInformation("Preparing to cancel subscription.");
                        var subscriptionUpdate = new Entity("rhs_subscription", transaction.SubscriptionId.Id);
                        subscriptionUpdate["rhs_cancelsubscription"] = true;
                        subscriptionUpdate["rhs_subscriptioncancellationtype"] = new OptionSetValue(120000000); //Now
                        subscriptionUpdate["rhs_cancellationreason"] = ddDeniedCancellationReasonForSubscription.ToEntityReference();
                        subscriptionUpdate["statecode"] = new OptionSetValue(1); //Inactive
                        subscriptionUpdate["statuscode"] = new OptionSetValue(2); //Cancelled

                        _logger.TraceInformation("Canceling subscription. This should also cancel it's associated records");
                        _service.Update(subscriptionUpdate);
                        break;
                }
            }
            else
            {
                _logger.TraceInformation("Not eligible for associated record cancellation.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void UpdateDonationAmountOnPayOrOverdue(Payment payment, Transaction transaction)
        {
            _logger.TraceInformation("Starting business logic.");

            _logger.TraceInformation($"Transaction Type = {transaction.TransactionType}.");
            _logger.TraceInformation($"Payment Status = {payment.Statuscode}.");
            _logger.TraceInformation($"Is Refund = {payment.Refund}.");

            if (transaction.TransactionType == NewTransactionType_GlobalOptionSet.Donation && transaction.Donation != null &&
                (payment.Statuscode == PaymentStatus.Inactive_Paid || payment.Statuscode == PaymentStatus.Active_Overdue) && payment.Refund != true)
            {

                _logger.TraceInformation("CalculatingDonationAmount.");
                var paidDonationPaymentAmounts = _paymentRepository.GetAll().Where(p =>
                    p.Transaction != null && p.Transaction.Id == payment.Transaction.Id &&
                    p.Statuscode == PaymentStatus.Inactive_Paid &&
                    p.PaymentType == NewTransactionType_GlobalOptionSet.Donation &&
                    p.Refund != true &&
                    p.Amount != null
                ).Select(payment => payment.Amount).ToList();
                var donationAmount = new Money(paidDonationPaymentAmounts.Sum(payment => payment.Value));

                var donationUpdate = new Donation()
                {
                    Id = transaction.Donation.Id,
                    Amount = donationAmount
                };
                _service.Update(donationUpdate);
            }
            else
            {
                _logger.TraceInformation("Not eligible for donation amount update.");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public void SetPaymentScheduleStatus(Payment payment, PaymentSchedule paymentSchedule)
        {
            _logger.TraceInformation("Starting business logic.");

            _logger.TraceInformation($"Payment Status = {payment.Statuscode}.");
            _logger.TraceInformation($"Payment Schedule Status = {paymentSchedule.Statuscode}");

            if (payment.Statuscode == PaymentStatus.Inactive_Paid && paymentSchedule.Statuscode != PaymentScheduleStatus.Inactive_Paid)
            {
                _logger.TraceInformation("Checking for any unpaid payments of the payment schedule.");
                var unpaidPaymentSchedulePayments = _paymentRepository.GetAll().Where(p =>
                    p.PaymentSchedule != null && p.PaymentSchedule.Id == paymentSchedule.Id &&
                    p.Statuscode != PaymentStatus.Inactive_Paid
                ).ToList();

                if (!unpaidPaymentSchedulePayments.Any())
                {
                    _logger.TraceInformation("Updating payment schedule to paid status.");
                    var paymentScheduleUpdate = new PaymentSchedule()
                    {
                        Id = paymentSchedule.Id,
                        Statecode = PaymentScheduleState.Inactive,
                        Statuscode = PaymentScheduleStatus.Inactive_Paid
                    };
                    _paymentScheduleRepository.Update(paymentScheduleUpdate);
                }
                else
                {
                    _logger.TraceInformation("Not eligible for payment schedule status update");
                }
            }
            else if (payment.Statuscode == PaymentStatus.Active_PendingPayment && paymentSchedule.Statuscode != PaymentScheduleStatus.Active_Pending)
            {
                var paymentScheduleUpdate = new PaymentSchedule()
                {
                    Id = paymentSchedule.Id,
                    Statecode = PaymentScheduleState.Active,
                    Statuscode = PaymentScheduleStatus.Active_Pending
                };
                _paymentScheduleRepository.Update(paymentScheduleUpdate);
            }
            else if (payment.Statuscode == PaymentStatus.Active_Overdue && paymentSchedule.Statuscode != PaymentScheduleStatus.Active_Overdue)
            {
                var paymentScheduleUpdate = new PaymentSchedule()
                {
                    Id = paymentSchedule.Id,
                    Statecode = PaymentScheduleState.Active,
                    Statuscode = PaymentScheduleStatus.Active_Overdue
                };
                _paymentScheduleRepository.Update(paymentScheduleUpdate);
            }
            else
            {
                _logger.TraceInformation("Not eligible for payment schedule status update");
            }

            _logger.TraceInformation("Ending business logic.");
        }

        public Giftaidthreshold FindGiftAidThreshold(Guid? productId, DateTime? paidOn)
        {
            _logger.TraceInformation($"Looking for Gift Aid Threshold with ProductId={productId}");

            if (!productId.HasValue)
            {
                _logger.TraceInformation("productId has no value");
                return null;
            }
            _logger.TraceInformation("productId has value");

            if (!paidOn.HasValue)
            {
                _logger.TraceInformation("paidOn has no value");
                return null;
            }
            _logger.TraceInformation("paidOn has value");

             var thresholdQuery = new QueryExpression("rhs_giftaidthreshold")
            {
                ColumnSet = new ColumnSet("rhs_value", "rhs_startdate", "rhs_enddate", "rhs_product")
            };
            thresholdQuery.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0); // Active
            thresholdQuery.Criteria.AddCondition("rhs_product", ConditionOperator.Equal, productId);
            thresholdQuery.Criteria.AddCondition("rhs_startdate", ConditionOperator.LessEqual, paidOn.Value);
            thresholdQuery.Criteria.AddCondition("rhs_enddate", ConditionOperator.GreaterEqual, paidOn.Value);
            try
            {
                var thresholdEntity = _service.RetrieveMultiple(thresholdQuery).Entities.FirstOrDefault();

                if (thresholdEntity == null)
                {
                    _logger.TraceInformation("[FindGiftAidThreshold] No matching Gift Aid Threshold found.");
                    return null;
                }

                _logger.TraceInformation($"[FindGiftAidThreshold] Found Gift Aid Threshold. Id={thresholdEntity.Id}, Value={thresholdEntity.GetAttributeValue<Money>("rhs_value")?.Value ?? 0}");

                return thresholdEntity.ToEntity<Giftaidthreshold>();
            }
            catch (Exception ex)
            {
                _logger.TraceError($"[FindGiftAidThreshold] Exception occurred: {ex.Message}");
                throw;
            }
        }

        public List<Payment> RetrieveMembershipDirectDebitPayments(Payment triggeringPayment)
        {
            _logger.TraceInformation("Retrieving membership direct debit payment records.");
            var paymentQuery = new QueryExpression(Payment.EntityLogicalName);
            paymentQuery.ColumnSet = new ColumnSet(EntityNames.Payment.PaymentId, 
                EntityNames.Payment.Transaction, 
                EntityNames.Payment.PaymentType, 
                EntityNames.Payment.Product,
                EntityNames.Payment.PaymentMethodType,
                EntityNames.Payment.Statuscode,
                EntityNames.Payment.Amount,
                EntityNames.Payment.PaidOn,
                EntityNames.Payment.DueDate
                );

            paymentQuery.AddOrder("rhs_duedate", OrderType.Ascending);
            paymentQuery.Criteria.AddCondition(EntityNames.Payment.Transaction, ConditionOperator.Equal, triggeringPayment.Transaction.Id); // Transaction = Transaction (on triggering Payment)
            paymentQuery.Criteria.AddCondition(EntityNames.Payment.PaymentType, ConditionOperator.Equal, (int)NewTransactionType_GlobalOptionSet.Membership);   // Payment Type = Membership
            paymentQuery.Criteria.AddCondition(EntityNames.Payment.Product, ConditionOperator.Equal, triggeringPayment.Product.Id); // Product = Product (on triggering Payment)
            paymentQuery.Criteria.AddCondition(EntityNames.Payment.PaymentMethodType, ConditionOperator.Equal, (int)PaymentMethodType_GlobalOptionSet.DirectDebit); // Payment Method = Direct Debit
            paymentQuery.Criteria.AddCondition(EntityNames.Payment.Statuscode, ConditionOperator.NotIn,  // Status <> Cancelled or Refunded
                   new object[] { 120000004, 120000005 });//Cancelled and Refunded

            var payments = _service.RetrieveMultiple(paymentQuery).Entities.Select(e => e.ToEntity<Payment>()).ToList();
            _logger.TraceInformation($"Retrieved {payments.Count} qualifying payments.");

            foreach (var p in payments)
            {
                _logger.TraceInformation($"  -> PaymentId: {p.Id}, Transaction: {p.Transaction?.Id}, Product: {p.Product?.Id}, PaidOn: {p.PaidOn}, Status: {p.Statuscode}, Amount: {p.Amount}, DueDate: {p.DueDate}");
            }
            return payments;

        }

        public void SetIsRenewalOnCreate(Payment payment)
        {
            _logger.TraceInformation("Starting SetIsRenewalOnCreate logic.");

            try
            {
                if (payment?.Transaction == null)
                {
                    _logger.TraceInformation("Payment has no related Transaction. Skipping renewal logic.");
                    return;
                }

                Transaction transaction;
                try
                {
                    transaction = _transactionRepository.GetById(payment.Transaction.Id);
                }
                catch (Exception ex)
                {
                    _logger.TraceError(
                        $"Failed to retrieve Transaction. PaymentId={payment.Id}, TransactionId={payment.Transaction.Id}", ex);
                    return;
                }

                if (transaction?.MembershipId == null)
                {
                    _logger.TraceInformation("Transaction has no Membership associated. Skipping renewal logic.");
                    return;
                }

                Entities.Generated.Membership membership;
                try
                {
                    membership = _membershipRepository.GetById(transaction.MembershipId.Id);
                }
                catch (Exception ex)
                {
                    _logger.TraceError(
                        $"Failed to retrieve Membership. TransactionId={transaction.Id}, MembershipId={transaction.MembershipId.Id}", ex);
                    return;
                }

                if (membership == null)
                {
                    _logger.TraceInformation("Membership record could not be retrieved. Skipping renewal logic.");
                    return;
                }

                if (membership.IsRenewal == true)
                {
                    _logger.TraceInformation("Membership is in renewal stage. Marking payment as renewal.");

                    var paymentUpdate = new Payment
                    {
                        Id = payment.Id,
                        Isrenewal = true
                    };

                    _service.Update(paymentUpdate);
                }
                else
                {
                    _logger.TraceInformation("Membership is not in renewal stage. No update required.");
                }
            }
            catch (Exception ex)
            {
                // Absolute last-resort catch — never block the pipeline
                _logger.TraceError(
                    $"Unexpected error in SetIsRenewalOnCreate. PaymentId={payment?.Id}", ex);
            }

            _logger.TraceInformation("Ending SetIsRenewalOnCreate logic.");
        }
        public void SetApprovedForNavBy_PreOp(Payment payment, Guid initiatingUserId)
        {
            try
            {
                var isApproved = payment.Approvedfornav;
                var paymentUpdate = new Payment()
                {
                    Id = payment.Id
                };

                if (isApproved == true)
                {
                    paymentUpdate.Approvedfornavby = new EntityReference("systemuser", initiatingUserId);
                    paymentUpdate.Approvedfornavon = DateTime.UtcNow;
                }
                else if (isApproved == false)
                {
                    paymentUpdate.Approvedfornavby = null;
                    paymentUpdate.Approvedfornavon = null;
                }
                else
                {
                    return;
                }
                _paymentRepository.Update(paymentUpdate);
            }
            catch (Exception ex)
            {
                _logger.TraceInformation($"SetApprovedForNavBy_PreOp error: {ex.Message}");
            }
        }



    }
}