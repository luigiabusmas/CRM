﻿using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface IDonationService
    {
        void CreateRecognitionRecord(Entity donation, Entity postImageEntity);
        void CancelDonation(Entity targetDonation, Donation postImageDonation);
        void PopulateDonationTypeResrictedFund(Donation donation);
        bool ValidateIfPaymentSubmissionWasTriggered(Donation preImageDonation, Donation postImageDonation);
        bool ValidateIfActivatedWithoutStartDate(Donation preImageDonation, Donation postImageDonation);
        void SetStartDate(ref Entity targetEntity, ref Donation postImageDonation);
        void SetEndDate(ref Entity targetEntity, ref Donation postImageDonation);
        void SetPayoutDate(ref Entity targetEntity, ref Donation postImageDonation);
    }

    public class DonationService : IDonationService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private IRecordDateCalculationService _recordDateCalculationService;
        private ICustomAPIInvocationService _customAPIInvocationService;

        public DonationService(ILogger logger, IOrganizationService service,
            IRecordDateCalculationService recordDateCalculationService, ICustomAPIInvocationService customAPIInvocationService)
        {
            _logger = logger;
            _service = service;
            _recordDateCalculationService = recordDateCalculationService;
            _customAPIInvocationService = customAPIInvocationService;
        }

        public void CreateRecognitionRecord(Entity donation, Entity postImageEntity)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (postImageEntity.GetAttributeValue<EntityReference>(EntityNames.Donation.Campaign) != null)
            {
                if (postImageEntity.GetAttributeValue<OptionSetValue>(EntityNames.Donation.Statuscode).Value != 1)
                {
                    _logger.TraceInformation($"Return: Status code is not Active");
                    return;
                }

                if (postImageEntity.GetAttributeValue<Money>(EntityNames.Donation.Amount) == null)
                {
                    _logger.TraceInformation($"Return: Amount is Null");
                    return;
                }

                EntityReference campaignRef = (EntityReference)postImageEntity[EntityNames.Donation.Campaign];
                EntityReference donorRef = (EntityReference)postImageEntity[EntityNames.Donation.Donor];
                Money amount = (Money)postImageEntity[EntityNames.Donation.Amount];
                
                DateTime today = DateTime.UtcNow.Date;

                _logger.TraceInformation($"Retrieving incentive.");
                var query = new QueryExpression(EntityNames.Incentive.EntityLogicalName);
                query.ColumnSet.AddColumns(EntityNames.Incentive.IncentiveId, EntityNames.Incentive.Name, EntityNames.Incentive.MaximumDonation, EntityNames.Incentive.MinimumDonation);
                // Add conditions to query.Criteria
                query.Criteria.AddCondition(EntityNames.Incentive.MinimumDonation, ConditionOperator.LessEqual, amount.Value);
                query.Criteria.AddCondition(EntityNames.Incentive.MaximumDonation, ConditionOperator.GreaterEqual, amount.Value);
                var query_rhs_campaignincentive = query.AddLink(EntityNames.Campaignincentive.EntityLogicalName, EntityNames.Incentive.IncentiveId, EntityNames.Incentive.EntityLogicalName);
                query_rhs_campaignincentive.LinkCriteria.AddCondition(EntityNames.Campaignincentive.Campaign, ConditionOperator.Equal, campaignRef.Id);
                var incentiveCollection = _service.RetrieveMultiple(query);
                if (incentiveCollection.Entities.Count == 0)
                    return;
                var incentiveItem = incentiveCollection.Entities.First();

                _logger.TraceInformation($"Creating subscription.");
                Entity createRecognition = new Entity(EntityNames.Recognition.EntityLogicalName)
                {
                    [EntityNames.Recognition.Incentive] = incentiveItem.ToEntityReference(),
                    [EntityNames.Recognition.Donation] = donation.ToEntityReference(),
                    [EntityNames.Recognition.Campaign] = campaignRef,
                    [EntityNames.Recognition.Donor] = donorRef,
                    [EntityNames.Recognition.StartDate] = today,
                    [EntityNames.Recognition.Name] = $"{donorRef.Name} - {incentiveItem[EntityNames.Incentive.Name]}"
                };

                Guid recognitionId = _service.Create(createRecognition);

                //update Donation
                _logger.TraceInformation($"Updating donation.");
                Entity updateDonation = new Entity(EntityNames.Donation.EntityLogicalName, donation.Id)
                {
                    [EntityNames.Donation.Isrecognition] = true
                };

                _service.Update(updateDonation);

            }

            _logger.TraceInformation($"Ending business logic.");
        }

        public void CancelDonation(Entity targetEntity, Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Checking payment method.");
            if (postImageDonation.PaymentMethodCode == PaymentMethodType_GlobalOptionSet.DirectDebit)
            {
                _logger.TraceInformation($"Detected ongoing direct debit payment.");

                _logger.TraceInformation($"Checking if one or more associated DD Payments have been paid.");
                var paidPayments = RetrievePaidPayments(targetEntity.Id);
                if (paidPayments.Count > 0)
                {
                    _logger.TraceInformation($"One or more associated DD Payments have been paid.");
                    _logger.TraceInformation($"Setting donation status to Active - Paid");
                    postImageDonation.Statecode = DonationState.Active;
                    postImageDonation.Statuscode = DonationStatus.Active_ActivePaid;
                }
                else
                {
                    _logger.TraceInformation($"none of the associated DD Payments have been paid yet.");
                    _logger.TraceInformation($"Setting donation status to cancelled.");
                    postImageDonation.Statecode = DonationState.Inactive;
                    postImageDonation.Statuscode = DonationStatus.Inactive_Cancelled;
                }

                _logger.TraceInformation($"Cancelling any upcoming (unpaid) associated payments.");
                _customAPIInvocationService.InvokeCancelDDICustomAPI(targetEntity.Id, NewTransactionType_GlobalOptionSet.Donation);
            }
            else
            {
                _logger.TraceInformation($"Detected one-off payment.");

                _logger.TraceInformation($"Setting donation status to cancelled.");
                postImageDonation.Statecode = DonationState.Inactive;
                postImageDonation.Statuscode = DonationStatus.Inactive_Cancelled;
            }

            targetEntity[EntityNames.Donation.Statecode] = postImageDonation.ToEntity<Entity>()[EntityNames.Donation.Statecode];
            targetEntity[EntityNames.Donation.Statuscode] = postImageDonation.ToEntity<Entity>()[EntityNames.Donation.Statuscode];

            _logger.TraceInformation($"Ending business logic.");
        }

        private List<Payment> RetrievePaidPayments(Guid donationId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression("rhs_payment");
            query.ColumnSet.AddColumns("rhs_amount", "rhs_paymentid", "rhs_paymentsid", "statecode", "statuscode");
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 1);
            query.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 2);
            var query_rhs_transaction = query.AddLink("rhs_transaction", "rhs_transaction", "rhs_transactionid");
            query_rhs_transaction.LinkCriteria.AddCondition("rhs_donation", ConditionOperator.Equal, donationId);

            var paidPayments = _service.RetrieveMultiple(query).Entities.Select(payment => payment.ToEntity<Payment>()).ToList();

            _logger.TraceInformation($"Ending business logic.");
            return paidPayments;
        }
        public void PopulateDonationTypeResrictedFund(Donation donation)
        {
            _logger.TraceInformation($"PopulateDonationTypeResrictedFund Start");
            if (donation != null && donation.Campaign.Id != Guid.Empty)
            {
                Entity campaign = _service.Retrieve(EntityNames.Campaign.EntityLogicalName, donation.Campaign.Id, new ColumnSet(EntityNames.Campaign.DonationType, EntityNames.Campaign.RestrictedFund));
                if (campaign != null)
                {
                    var donationType = campaign.GetAttributeValue<EntityReference>(EntityNames.Campaign.DonationType);
                    var restrictedFund = campaign.GetAttributeValue<EntityReference>(EntityNames.Campaign.RestrictedFund);

                    if (donationType != null && donationType.Id != Guid.Empty &&
                        restrictedFund != null && restrictedFund.Id != Guid.Empty)
                    {
                        donation.DonationType = donationType;
                        donation.RestrictedFund = restrictedFund;
                        _logger.TraceInformation($"PopulateDonationTypeResrictedFund Updated Donation");
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException($"The selected Campaign is missing either a Donation Type or a Restricted Fund. Please update the Campaign record to proceed.");
                    }
                }
            }
            _logger.TraceInformation($"PopulateDonationTypeResrictedFund End");
        }

        public bool ValidateIfPaymentSubmissionWasTriggered(Donation preImageDonation, Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var isSubmitPayment = preImageDonation.Issubmitpayment != true && postImageDonation.Issubmitpayment == true;
            _logger.TraceInformation($"Is submit payment changed to true? {isSubmitPayment}");

            _logger.TraceInformation($"Ending business logic.");
            return isSubmitPayment;
        }

        public bool ValidateIfActivatedWithoutStartDate(Donation preImageDonation, Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var isActivatedWithoutStartDate = preImageDonation.Statuscode != postImageDonation.Statuscode && 
                (postImageDonation.Statuscode == DonationStatus.Active_ActivePaid || postImageDonation.Statuscode == DonationStatus.Active_ActiveOngoing) &&
                postImageDonation.Startdate == null;
            _logger.TraceInformation($"Is activated without start date? {isActivatedWithoutStartDate}");

            _logger.TraceInformation($"Ending business logic.");
            return isActivatedWithoutStartDate;
        }

        public void SetStartDate(ref Entity targetEntity, ref Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var startDate = _recordDateCalculationService.CalculateStartDateOfRecord(null);

            postImageDonation.Startdate = startDate;
            targetEntity[EntityNames.Donation.Startdate] = postImageDonation.Startdate;

            _logger.TraceInformation($"Ending business logic.");
        }

        public void SetEndDate(ref Entity targetEntity, ref Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var endDate = _recordDateCalculationService.CalculateEndDateOfRecord((DateTime)postImageDonation.Startdate, null, null);

            postImageDonation.Enddate = endDate;
            targetEntity[EntityNames.Donation.Enddate] = postImageDonation.Enddate;

            _logger.TraceInformation($"Ending business logic.");
        }

        public void SetPayoutDate(ref Entity targetEntity, ref Donation postImageDonation)
        {
            _logger.TraceInformation($"Starting business logic.");

            var payoutDate = _recordDateCalculationService.CalculatePayoutDate((DateTime)postImageDonation.Startdate);

            postImageDonation.PayoutDate = payoutDate;
            targetEntity[EntityNames.Donation.PayoutDate] = postImageDonation.PayoutDate;

            _logger.TraceInformation($"Ending business logic.");
        }
    }
}