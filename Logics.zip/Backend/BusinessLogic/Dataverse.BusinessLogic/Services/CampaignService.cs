using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Web.Security;

namespace Cultivate.BusinessLogic.Services
{
    public interface ICampaignService
    {
        //void ValidateCampaign(Campaign campaign, Guid productId);
        void ValidateDonationCampaign(Campaign campaign);
        List<Guid> RetrieveCampaignProductIds(Guid campaignId);
        //Money GetCampaignAmount(Campaign campaign, Guid productId, Guid priceListId, Msnfp_paymentmethodtype_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency);
    }
    public class CampaignService : ICampaignService
    {
        private ILogger _logger;
        //private IRepository<Paymentdiscountconfiguration> _paymentDiscountConfigurationRepository;
        private IOrganizationService _service;
        //private IProductService _productService;

        public CampaignService(
            ILogger logger, IOrganizationService service//,
            //IRepository<Paymentdiscountconfiguration> paymentDiscountConfigurationRepository,
            //IProductService productService
        )
        {
            _logger = logger;
            _service = service;
            //_paymentDiscountConfigurationRepository = paymentDiscountConfigurationRepository;
            //_productService = productService;
        }

        //public void ValidateCampaign(Campaign campaign, Guid productId)
        //{
        //    _logger.TraceInformation($"Starting business logic.");

        //    _logger.TraceInformation($"Validating if the campaign is active.");
        //    if (campaign.StateCode != CampaignState.Active)
        //        throw new InvalidPluginExecutionException("Please enter a valid Campaign Code!");

        //    _logger.TraceInformation($"Validating if the campaign is valid for selected product.");
        //    var campaignProductIds = RetrieveCampaignProductIds(campaign.Id);
        //    if (!campaignProductIds.Any(id => id == productId))
        //        throw new InvalidPluginExecutionException("Entered Campaign Code is not valid for selected product. Please select correct Campaign Code!");

        //    _logger.TraceInformation($"Ending business logic logic.");
        //}

        public void ValidateDonationCampaign(Campaign campaign)
        {
            _logger.TraceInformation($"Starting business logic logic.");

            if (campaign.CampaignCategory != CampaignCategory_GlobalOptionSet.Donation || 
                campaign.DonationType == null || campaign.RestrictedFund == null)
            {
                throw new InvalidPluginExecutionException("Invalid fundraising campaign selected. Please select a donation campaign with a donation type and a restricted fund.");
            }

            _logger.TraceInformation($"Ending business logic logic.");
        }

        public List<Guid> RetrieveCampaignProductIds(Guid campaignId)
        {
            _logger.TraceInformation($"Starting business logic logic.");

            var query = new QueryExpression("product");
            query.ColumnSet.AddColumn("productid");
            var query_campaignitem = query.AddLink("campaignitem", "productid", "entityid");
            query_campaignitem.LinkCriteria.AddCondition("campaignid", ConditionOperator.Equal, campaignId);

            var campaignProductIds = _service.RetrieveMultiple(query).Entities.Select(product => product.GetAttributeValue<Guid>("productid")).ToList();

            _logger.TraceInformation($"Ending business logic logic.");
            return campaignProductIds;
        }

        //public Money GetCampaignAmount(Campaign campaign, Guid productId, Guid priceListId, Msnfp_paymentmethodtype_GlobalOptionSet? paymentMethod, PaymentFrequency_GlobalOptionSet? paymentFrequency)
        //{
        //    _logger.TraceInformation($"Starting business logic logic.");

        //    Money campaignAmount = null;

        //    if (campaign.BenefitType == CampaignBenefit_GlobalOptionSet.PriceBased)
        //    {
        //        _logger.TraceInformation($"Setting campaign amount because price based campaign exists on membership.");
        //        campaignAmount = _productService.GetCampaignProductPrice(productId, campaign.Id);

        //        if (campaign.Paymentdiscountconfiguration != null)
        //        {
        //            var paymentDiscountConfiguration = _paymentDiscountConfigurationRepository.GetById(campaign.Paymentdiscountconfiguration.Id);
        //            if (paymentMethod == paymentDiscountConfiguration.PaymentMethod &&
        //                (paymentMethod != Msnfp_paymentmethodtype_GlobalOptionSet.DirectDebit || paymentFrequency == PaymentFrequency_GlobalOptionSet.Annually))
        //            {
        //                _logger.TraceInformation($"Payment discount configuration detected and it's payment method matches the membership payment method. Further discounts will be done to the discounted price.");

        //                var membershipPrice = _productService.GetProductPrice(productId, priceListId);

        //                if (paymentDiscountConfiguration.DiscountPercentage != null)
        //                {
        //                    _logger.TraceInformation($"Discount percentage detected.");
        //                    _logger.TraceInformation($"New Discounted Price = {campaignAmount.Value} - ({paymentDiscountConfiguration.DiscountPercentage}% of {membershipPrice.Value}).");
        //                    campaignAmount.Value -= ((decimal)paymentDiscountConfiguration.DiscountPercentage / 100) * membershipPrice.Value;
        //                    _logger.TraceInformation($"New Discounted Price = {campaignAmount.Value}.");
        //                }
        //                if (paymentDiscountConfiguration.DiscountAmount != null)
        //                {
        //                    _logger.TraceInformation($"Discount amount detected.");
        //                    _logger.TraceInformation($"New Discounted Price = {campaignAmount.Value} - {paymentDiscountConfiguration.DiscountAmount.Value}.");
        //                    campaignAmount.Value -= paymentDiscountConfiguration.DiscountAmount.Value;
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        campaignAmount = null;
        //        _logger.TraceInformation($"Setting campaign amount to NULL because price-based campaign was not selected or unselected on membership.");
        //    }

        //    _logger.TraceInformation($"Ending business logic logic.");
        //    return campaignAmount;
        //}
    }
}