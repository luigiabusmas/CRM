using Avanade.BizApps.Core.Contracts;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using System;
using System.Linq;

namespace Cultivate.BusinessLogic.Services
{
    /// <summary>
    /// Service for processing gift pack redemption and converting them to memberships.
    /// </summary>
    public interface IGiftPackRedemptionService
    {
        /// <summary>
        /// Processes a gift pack redemption by creating a membership without payment processing.
        /// </summary>
        /// <param name="portalSession">The portal session containing the redemption information.</param>
        void ProcessGiftPackRedemption(Portalsession portalSession);
    }

    /// <summary>
    /// Service implementation for processing gift pack redemption.
    /// </summary>
    public class GiftPackRedemptionService : IGiftPackRedemptionService
    {
        #region Fields

        private readonly ITracingService _tracingService;
        private readonly IMembershipContactCreateService _membershipContactCreateService;
        private readonly IRecordDateCalculationService _recordDateCalculationService;

        private readonly IPortalSessionContactRepository _portalSessionContactRepository;
        private readonly IMembershipRepository _membershipRepository;
        private readonly IRepository<Portalsession> _portalSessionRepository;
        private readonly IRepository<GiftPack> _giftPackRepository;
        private readonly IContactRepository _contactRepository;
        private readonly IRepository<ProductAssociation> _productAssociationRepository;

        #endregion Fields

        #region Constructor

        public GiftPackRedemptionService(
            ITracingService tracingService,
            IMembershipContactCreateService membershipContactCreateService,
            IRecordDateCalculationService recordDateCalculationService,
            IPortalSessionContactRepository portalSessionContactRepository,
            IMembershipRepository membershipRepository,
            IRepository<Portalsession> portalSessionRepository,
            IRepository<GiftPack> giftPackRepository,
            IContactRepository contactRepository,
            IRepository<ProductAssociation> productAssociationRepository)
        {
            _tracingService = tracingService ?? throw new ArgumentNullException(nameof(tracingService));
            _membershipContactCreateService = membershipContactCreateService ?? throw new ArgumentNullException(nameof(membershipContactCreateService));
            _recordDateCalculationService = recordDateCalculationService ?? throw new ArgumentNullException(nameof(recordDateCalculationService));
            _portalSessionContactRepository = portalSessionContactRepository ?? throw new ArgumentNullException(nameof(portalSessionContactRepository));
            _membershipRepository = membershipRepository ?? throw new ArgumentNullException(nameof(membershipRepository));
            _portalSessionRepository = portalSessionRepository ?? throw new ArgumentNullException(nameof(portalSessionRepository));
            _giftPackRepository = giftPackRepository ?? throw new ArgumentNullException(nameof(giftPackRepository));
            _contactRepository = contactRepository ?? throw new ArgumentNullException(nameof(contactRepository));
            _productAssociationRepository = productAssociationRepository ?? throw new ArgumentNullException(nameof(productAssociationRepository));
        }

        #endregion Constructor

        #region Public Methods

        public void ProcessGiftPackRedemption(Portalsession portalSession)
        {
            _tracingService.Trace("Starting Gift Pack Claim process.");

            // Validate the portal session
            ValidateGiftPackClaim(portalSession);

            var giftPack = _giftPackRepository.GetById(portalSession.GiftPackId.Id);
            _tracingService.Trace($"Retrieved Gift Pack with ID: {giftPack.Id}");

            // Get product and member contact
            var memberContact = GetContactFromSession(portalSession.Memberid.Id);

            // Get payer with address validation logic
            (Contact member, Contact payer) = GetMemberAndPayer(portalSession, memberContact, giftPack);

            // Get additional member if applicable
            Contact additionalMember = GetAdditionalMember(portalSession);

            if (member != null && payer != null)
            {              
                // Create membership for Gift Pack Claim
                var membership = CreateMembershipForGiftPackClaim(portalSession, member, additionalMember, payer, memberContact, null, giftPack);
                membership = _membershipRepository.GetById(membership.Id);

                _tracingService.Trace($"Gift Pack Claim membership created with ID: {membership.Id}");

                // Update Gift Pack Delivery Contact
                // UpdateGiftPackDeliveryContact(giftPack, payer, member);

                // Mark portal session as processed without creating payment
                MarkPortalSessionAsProcessedWithoutTransaction(portalSession);
            }
        }

        #endregion Public Methods

        #region Private Methods

        private (Contact member, Contact payer) GetMemberAndPayer(Portalsession portalSession, Portalsessioncontact member, GiftPack giftPack)
        {
            _tracingService.Trace("Getting payer for Gift Pack Claim with address validation.");

            // Get payer address details from gift pack (these are the payer's address stored in delivery fields)
            var purchasedByContact = _contactRepository.GetById(giftPack.PurchasedBy.Id);

            // Compare payer address from gift pack with member address (Line1 and Postcode)
            if (AreAddressesSame(purchasedByContact.Address1_Line1, purchasedByContact.Address1_PostalCode, member.Address1_line1, member.Address1_postalcode))
            {
                _tracingService.Trace("Payer address matches member address. Using purchaser as both member and payer.");
                return (member: purchasedByContact, payer: purchasedByContact);
            }

            // Addresses don't match, create new contacts for member as needed
            _tracingService.Trace("Payer address doesn't match member address. Creating new contact for member.");

            var memberContactCreated = _membershipContactCreateService.Create(member);

            return (member: memberContactCreated, payer: purchasedByContact);
        }

        private Membership CreateMembershipForGiftPackClaim(
            Portalsession portalSession,
            Contact member,
            Contact additionalMember,
            Contact payer,
            Portalsessioncontact portalSessionContact,
            EntityReference campaign,
            GiftPack giftPack)
        {
            _tracingService.Trace("Creating membership for Gift Pack Claim.");
            var startDate = _recordDateCalculationService.CalculateMembershipStartDate();
            var product = _productAssociationRepository.GetAll()
                        .FirstOrDefault(pa => pa.ProductId.Id == giftPack.Product.Id)?.AssociatedProduct;

            var membership = new Membership
            {
                MembershipProductId = product,
                IsMembershipForSomeone = member.Id != payer?.Id,
                Contact = member.ToEntityReference(),
                Member2 = additionalMember?.ToEntityReference(),
                PayerV2 = payer.ToEntityReference(),
                PaymentMethod = portalSession.PaymentMethodCode,
                IsReferredByExistingMember = false,
                GDPRRead = true,
                CancellationRead = true,
                IsRegistrationForGiftAid = portalSessionContact.ActiveGiftAidDeclaration.HasValue && portalSessionContact.ActiveGiftAidDeclaration.Value,
                Startdate = startDate,
                Enddate = _recordDateCalculationService.CalculateEndDateOfRecord(startDate, portalSession.Productid.Id, campaign?.Id),
                Channel = giftPack.Channel,
                Source = Incident_caseorigincode_GlobalOptionSet.OnlineWebPortal,
                CheckoutSessionId = portalSession.CheckoutSessionId,
                CheckoutURL = portalSession.CheckoutURL,
                PaymentIntentId = portalSession.PaymentIntentId,
                Statuscode = MembershipStatus.Active_Active,
                Statecode = MembershipState.Active,
                CampaignId = campaign,
                PriceList = giftPack.PriceListUsed,
                GardenMagazine = portalSessionContact.ReceivesPrintedMagazine.HasValue && portalSessionContact.ReceivesPrintedMagazine.Value,
                GiftPack = GetPriceListReference(portalSession) ?? giftPack.ToEntityReference(),
                RedeemGiftPack = true, // Set to true for Gift Pack Claims
                ActivationCode = giftPack.GiftPackCode
            };

            return _membershipRepository.Create(membership);
        }

        private void UpdateGiftPackDeliveryContact(GiftPack giftPack, Contact payer, Contact member)
        {
            _tracingService.Trace("Updating Gift Pack delivery contact.");

            var loadedGiftPack = _giftPackRepository.GetById(giftPack.Id);

            // Compare delivery address entered with payer address
            bool addressesMatch = AreAddressesSame(
                loadedGiftPack.DeliveryAddressLine1,
                loadedGiftPack.DeliveryAddressPostcode,
                payer.Address1_Line1,
                payer.Address1_PostalCode);

            if (addressesMatch)
            {
                _tracingService.Trace($"Delivery address matches payer address. Setting Delivery Contact to payer: {payer.Id}");
                loadedGiftPack.DeliveryContact = payer.ToEntityReference();
            }
            else
            {
                _tracingService.Trace($"Delivery address doesn't match payer address. Setting Delivery Contact to member: {member.Id}");
                loadedGiftPack.DeliveryContact = member.ToEntityReference();
            }

            _giftPackRepository.Update(loadedGiftPack);
            _tracingService.Trace("Gift Pack delivery contact updated successfully.");
        }

        private static EntityReference GetPriceListReference(Portalsession portalSession)
        {
            if (
                portalSession.Contains(EntityNames.Portalsession.PriceListID)
                && !string.IsNullOrEmpty(portalSession.PriceListID)
            )
            {
                return new EntityReference(
                    EntityNames.PriceLevel.EntityLogicalName,
                    new Guid(portalSession.PriceListID)
                );
            }
            return null;
        }

        private Contact GetAdditionalMember(Portalsession portalSession)
        {   
            if (!portalSession.Contains(EntityNames.Portalsession.Additionalmemberid) || portalSession.Additionalmemberid == null)
                return null;

            var additionalMemberContact = _portalSessionContactRepository.GetById(portalSession.Additionalmemberid.Id);
            if (additionalMemberContact == null) return null;

            var existingContact = FindExistingContact(additionalMemberContact);

            return existingContact ?? _membershipContactCreateService.Create(additionalMemberContact);
        }

        private Contact FindExistingContact(Portalsessioncontact contact)
        {
            var query = string.IsNullOrWhiteSpace(contact.Emailaddress1)
                ? _contactRepository.GetByNameEmailPostCode(contact.Firstname, contact.Lastname, null, contact.Address1_postalcode)
                : _contactRepository.GetByNameEmailPostCode(contact.Firstname, contact.Lastname, contact.Emailaddress1, contact.Address1_postalcode);

            return query.FirstOrDefault();
        }

        private void MarkPortalSessionAsProcessedWithoutTransaction(Portalsession portalSession)
        {
            _tracingService.Trace("Updating portal session to processed status without transaction (Gift Pack Claim).");

            var updatePortalSession = new Portalsession
            {
                Id = portalSession.Id,
                Statecode = PortalsessionState.Inactive,
                Statuscode = PortalsessionStatus.Inactive_Processed
            };

            _portalSessionRepository.Update(updatePortalSession);
        }

        private Portalsessioncontact GetContactFromSession(Guid contactId)
             => _portalSessionContactRepository.GetById(contactId);

        #endregion Private Methods

        #region Validation

        private static void ValidateGiftPackClaim(Portalsession portalSession)
        {
            if (portalSession == null)
                throw new ArgumentNullException(nameof(portalSession));

            if (portalSession.PaymentMethodCode != PaymentMethodType_GlobalOptionSet.GiftPack)
                throw new ArgumentException("Gift Pack Claim requires Payment Method to be Gift Pack.");

            if (portalSession.ProductType != NewTransactionType_GlobalOptionSet.Membership)
                throw new ArgumentException("Gift Pack Claim requires Product Type to be Membership.");

            if (!portalSession.Contains(EntityNames.Portalsession.Memberid))
                throw new ArgumentException("Member ID cannot be empty for Gift Pack Claim.");

            if (!portalSession.Contains(EntityNames.Portalsession.GiftPackId))
                throw new ArgumentException("Gift Pack ID cannot be empty for Gift Pack Claim.");
        }

        #endregion Validation

        #region Helper Methods

        private static bool AreAddressesSame(string address1Line1, string address1Postcode, string address2Line1, string address2Postcode)
        {
            return EqualsIgnoreCase(address1Line1, address2Line1) && EqualsIgnoreCase(address1Postcode, address2Postcode);
        }

        private static bool EqualsIgnoreCase(string a, string b)
         => string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);

        #endregion Helper Methods
    }
}