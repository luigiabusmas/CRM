﻿using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Services;

namespace Cultivate.BusinessLogic.Services
{
    public interface IProductService
    {
        bool ValidateProductIfCloned(Product product);
        bool ValidateProductIDLength(Product product);
        Money GetProductPrice(Guid productId);
        Money GetProductPrice(Guid productId, Guid priceListId);
        EntityReference GetPriceListUsedOnProduct(Guid productId);
        Money GetCampaignProductPrice(Guid productId, Guid campaignId);
        EntityReference GetProductRenewalPriceList(Guid productId);
        EntityReference GetPatronProductRenewalPriceList(Guid productId);
        EntityReference GetProductBackOfficePriceList(Guid productId);
        EntityReference GetPatronBackOfficePriceList(Guid productId);
        EntityReference GetPlantProductPriceList(bool isNonMember, bool isRenewal = false);
    }

    public class ProductService : IProductService
    {
        private ILogger _logger;
        private IOrganizationService _service;
        private ICultivateConfigurationService _cultivateConfigurationService;

        public ProductService(ILogger logger, IPluginExecutionContext context, IOrganizationService service, ICultivateConfigurationService cultivateConfigurationService)
        {
            _logger = logger;
            _service = service;
            _cultivateConfigurationService = cultivateConfigurationService;
        }

        #region Business Logics
        public bool ValidateProductIfCloned(Product product)
        {
            _logger.TraceInformation($"Starting business logic.");

            long numbers;
            var isCloned = 
                product.ProductNumber != null &&
                product.ProductNumber.Split('-').Last().Length >= 17 &&
                long.TryParse(product.ProductNumber.Split('-').Last(), out numbers);
            _logger.TraceInformation($"Is cloned? {isCloned}.");

            _logger.TraceInformation($"Ending business logic.");
            return isCloned;
        }

        public bool ValidateProductIDLength(Product product)
        {
            _logger.TraceInformation($"Starting business logic.");

            if (product.ProductNumber != null && product.ProductNumber.Length > 20)
                throw new InvalidPluginExecutionException("Product ID cannot have more than 20 characters.");

            _logger.TraceInformation($"Ending business logic.");
            return true;
        }

        public Money GetProductPrice(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression(EntityNames.ProductPriceLevel.EntityLogicalName);
            query.ColumnSet.AddColumn(EntityNames.ProductPriceLevel.Amount);
            query.Criteria.AddCondition(EntityNames.ProductPriceLevel.ProductId, ConditionOperator.Equal, productId);
            var query_pricelevel = query.AddLink(EntityNames.PriceLevel.EntityLogicalName, EntityNames.ProductPriceLevel.PriceLevelId, EntityNames.PriceLevel.PriceLevelId);
            var query_pricelevel_product = query_pricelevel.AddLink(EntityNames.Product.EntityLogicalName, EntityNames.Product.PriceLevelId, EntityNames.PriceLevel.PriceLevelId);
            query_pricelevel_product.LinkCriteria.AddCondition(EntityNames.Product.ProductId, ConditionOperator.Equal, productId);

            _logger.TraceInformation($"Retrieving price list item.");
            var priceListItems = _service.RetrieveMultiple(query);
            if (priceListItems.Entities.Count == 0)
                throw new InvalidPluginExecutionException("No price list item exists for the product.");
            var priceListItem = priceListItems.Entities.ToList().First().ToEntity<ProductPriceLevel>();

            _logger.TraceInformation($"Retrieving product price.");
            var price = priceListItem.Amount;

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return price;
        }

        public Money GetProductPrice(Guid productId, Guid priceListId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving price list item.");
            var query = new QueryExpression("productpricelevel");
            query.ColumnSet.AddColumns("amount", "pricelevelid", "productid");
            query.Criteria.AddCondition("productid", ConditionOperator.Equal, productId);
            query.Criteria.AddCondition("pricelevelid", ConditionOperator.Equal, priceListId);

            var priceListItems = _service.RetrieveMultiple(query).Entities.ToList();
            if (priceListItems.Count == 0)
                throw new InvalidPluginExecutionException("No price list item exists for the price list name.");
            var priceListItem = priceListItems.First().ToEntity<ProductPriceLevel>();
            var price = priceListItem.Amount;

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return price;
        }

        public Money GetCampaignProductPrice(Guid productId, Guid campaignId)
        {
            _logger.TraceInformation($"Starting business logic.");

            var query = new QueryExpression("productpricelevel");
            query.ColumnSet.AddColumn(EntityNames.ProductPriceLevel.Amount);
            query.Criteria.AddCondition("productid", ConditionOperator.Equal, productId);
            var query_pricelevel = query.AddLink("pricelevel", "pricelevelid", "pricelevelid");
            var query_pricelevel_campaign = query_pricelevel.AddLink("campaign", "pricelevelid", "pricelistid");
            query_pricelevel_campaign.LinkCriteria.AddCondition("campaignid", ConditionOperator.Equal, campaignId);

            _logger.TraceInformation($"Retrieving price list item.");
            var priceListItems = _service.RetrieveMultiple(query);
            if (priceListItems.Entities.Count == 0)
                throw new InvalidPluginExecutionException("No price list item exists for the campaign product.");
            var priceListItem = priceListItems.Entities.ToList().First().ToEntity<ProductPriceLevel>();

            _logger.TraceInformation($"Retrieving product price.");
            var price = priceListItem.Amount;

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return price;
        }

        public EntityReference GetProductRenewalPriceList(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving renewal price list of product w/ Id = {productId}.");
            var priceListReference = _cultivateConfigurationService.GetCultivateConfigurationPriceList("RenewalsPriceList");

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return priceListReference;
        }

        public EntityReference GetPatronProductRenewalPriceList(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving patron renewal price list of product w/ Id = {productId}.");
            var priceListReference = _cultivateConfigurationService.GetCultivateConfigurationPriceList("PatronRenewalPriceList");

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return priceListReference;
        }

        public EntityReference GetProductBackOfficePriceList(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving back office price list of product w/ Id = {productId}.");
            var priceListReference = _cultivateConfigurationService.GetCultivateConfigurationPriceList("BackOfficePriceList");

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return priceListReference;
        }

        public EntityReference GetPatronBackOfficePriceList(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving patron back office price list of product w/ Id = {productId}.");
            var priceListReference = _cultivateConfigurationService.GetCultivateConfigurationPriceList("PatronBackOfficePriceList");

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return priceListReference;
        }

        public EntityReference GetPlantProductPriceList(bool isNonMember, bool isRenewal = false)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Is recipient or payer non-member? {isNonMember}.");
            _logger.TraceInformation($"Is this for renewal? {isRenewal}.");

            var cultivateConfigurationName = string.Empty;
            if (isNonMember)
                cultivateConfigurationName = isRenewal ? "PlantUKNonMemberRenewalPriceList" : "PlantUKNonMemberPriceList";
            else
                cultivateConfigurationName = isRenewal ? "PlantUKMemberRenewalPriceList" : "PlantUKMemberPriceList";

            _logger.TraceInformation($"Retrieving plant price list from {cultivateConfigurationName}.");
            var priceListReference = _cultivateConfigurationService.GetCultivateConfigurationPriceList(cultivateConfigurationName);

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return priceListReference;
        }

        public EntityReference GetPriceListUsedOnProduct(Guid productId)
        {
            _logger.TraceInformation($"Starting business logic.");

            _logger.TraceInformation($"Retrieving price list.");
            var product = _service.Retrieve(
                EntityNames.Product.EntityLogicalName,
                productId,
                new ColumnSet(EntityNames.Product.PriceLevelId)
            ).ToEntity<Product>();

            _logger.TraceInformation($"Ending business logic. Returning value.");
            return product.PriceLevelId;
        }
        #endregion

        #region Helpers

        #endregion

    }
}