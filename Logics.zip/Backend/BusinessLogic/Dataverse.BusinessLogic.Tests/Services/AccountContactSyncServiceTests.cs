using System;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Testing;
using Cultivate.BusinessLogic.Services;
using Cultivate.Data;
using Cultivate.Entities.Generated;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Shouldly;

namespace Cultivate.BusinessLogic.Tests.Services
{
    [TestClass]
    public class AccountContactSyncServiceTests
    {
        private IContactRepository _contactRepository;
        private IRepository<Account> _accountRepository;
        private AccountContactSyncService _service;

        [TestInitialize]
        public void SetUp()
        {
            _contactRepository = Substitute.For<IContactRepository>();
            _contactRepository
                .Create(Arg.Any<Contact>())
                .Returns(c => c.Arg<Contact>()); 

            _accountRepository = Substitute.For<IRepository<Account>>();
            _service = new AccountContactSyncService(_contactRepository, _accountRepository);
        }

        [TestMethod]
        public void CanSyncAccountDetailsToPrimaryContact()
        {
            var contact = new Contact {Id = Guids.B};
            var account = new Account
            {
                Id = Guids.A,
                PrimaryContactId = contact.ToEntityReference(),
                Address1_City = "__City",
                Address1_Country = "__Country",
                Address1_County = "__County",
                Address1_StateOrProvince = "__StateOrProvince",
                Address1_PostalCode = "__PostalCode",
                Address1_Line1 = "__Line1",
                Address1_Line2 = "__Line2",
                Address1_Line3 = "__Line3",
                Address1_Name = "__Name"
            };

            _contactRepository
                .GetById(contact.Id)
                .Returns(contact);

            _service.SyncAccountDetailsToPrimaryContact(account);

            contact.Address1_City.ShouldBe(account.Address1_City);
            contact.Address1_Country.ShouldBe(account.Address1_Country);
            contact.Address1_County.ShouldBe(account.Address1_County);
            contact.Address1_StateOrProvince.ShouldBe(account.Address1_StateOrProvince);
            contact.Address1_PostalCode.ShouldBe(account.Address1_PostalCode);
            contact.Address1_Line1.ShouldBe(account.Address1_Line1);
            contact.Address1_Line2.ShouldBe(account.Address1_Line2);
            contact.Address1_Line3.ShouldBe(account.Address1_Line3);
            contact.Address1_Name.ShouldBe(account.Address1_Name);

            _contactRepository.Received().Update(contact);
        }

        [TestMethod]
        public void ShouldThrowArgumentNullExceptionWhenAccountIsNull()
        {
            Should.Throw<ArgumentNullException>(() => _service.SyncAccountDetailsToPrimaryContact(null));
        }

        [TestMethod]
        public void ShouldDoNothingIfAccountHasNoPrimaryContact()
        {
            var account = new Account {Id = Guids.A};

            _service.SyncAccountDetailsToPrimaryContact(account);
            _contactRepository.DidNotReceive().Update(Arg.Any<Contact>());
        }

        [TestMethod]
        public void CanCreateContactFromAccount()
        {
            var account = new Account
            {
                Id = Guids.A,
                Address1_City = "__City",
                Address1_Country = "__Country",
                Address1_County = "__County",
                Address1_StateOrProvince = "__StateOrProvince",
                Address1_PostalCode = "__PostalCode",
                Address1_Line1 = "__Line1",
                Address1_Line2 = "__Line2",
                Address1_Line3 = "__Line3",
                Address1_Name = "__Name",
                Name = "__AccountName"
            };

            _contactRepository
                .When(c => c.Create(Arg.Any<Contact>()))
                .Do(c => c.Arg<Contact>().Id = Guids.B);

            _service.CreateContactFromAccount(account);

            _contactRepository
                .Received()
                .Create(Arg.Is<Contact>(c =>
                    c.Address1_City == account.Address1_City &&
                    c.Address1_Country == account.Address1_Country &&
                    c.Address1_County == account.Address1_County &&
                    c.Address1_StateOrProvince == account.Address1_StateOrProvince &&
                    c.Address1_PostalCode == account.Address1_PostalCode &&
                    c.Address1_Line1 == account.Address1_Line1 &&
                    c.Address1_Line2 == account.Address1_Line2 &&
                    c.Address1_Line3 == account.Address1_Line3 &&
                    c.Address1_Name == account.Address1_Name &&
                    c.LastName == account.Name + " (Default Contact)" &&
                    c.Description == account.Description 
                ));

            account.PrimaryContactId.ShouldNotBeNull();
            account.PrimaryContactId.Id.ShouldBe(Guids.B);
        }

        [TestMethod]
        public void CanCreateContactFromAccountWithLongName()
        {
            var account = new Account
            {
                Id = Guids.A,
                Address1_City = "__City",
                Address1_Country = "__Country",
                Address1_County = "__County",
                Address1_StateOrProvince = "__StateOrProvince",
                Address1_PostalCode = "__PostalCode",
                Address1_Line1 = "__Line1",
                Address1_Line2 = "__Line2",
                Address1_Line3 = "__Line3",
                Address1_Name = "__Name",
                Name = "__VeryLongLongLongLongAccountName"
            };

            _contactRepository
                .When(c => c.Create(Arg.Any<Contact>()))
                .Do(c => c.Arg<Contact>().Id = Guids.B);

            _service.CreateContactFromAccount(account);

            var expectedLastName = account.Name.Substring(0, 50 - " (Default Contact)".Length) + " (Default Contact)";

            _contactRepository
                .ReceivedWithAnyArgs()
                .Create(Arg.Is<Contact>(c =>
                    c.Address1_City == account.Address1_City &&
                    c.Address1_Country == account.Address1_Country &&
                    c.Address1_County == account.Address1_County &&
                    c.Address1_StateOrProvince == account.Address1_StateOrProvince &&
                    c.Address1_PostalCode == account.Address1_PostalCode &&
                    c.Address1_Line1 == account.Address1_Line1 &&
                    c.Address1_Line2 == account.Address1_Line2 &&
                    c.Address1_Line3 == account.Address1_Line3 &&
                    c.Address1_Name == account.Address1_Name &&
                    c.LastName == expectedLastName &&
                    c.Description == account.Description
                ));

            account.PrimaryContactId.ShouldNotBeNull();
            account.PrimaryContactId.Id.ShouldBe(Guids.B);
        }
    }
}