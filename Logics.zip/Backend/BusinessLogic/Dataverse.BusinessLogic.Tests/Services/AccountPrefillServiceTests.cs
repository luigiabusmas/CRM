using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.BusinessLogic.Services;
using Cultivate.Entities.Generated;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Shouldly;

namespace Cultivate.BusinessLogic.Tests.Services
{
    [TestClass]
    public class AccountPrefillServiceTests
    {
        private IRepository<Account> _repository;
        private IAccountPrefillService _service;

        [TestInitialize]
        public void SetUp()
        {
            _repository = Substitute.For<IRepository<Account>>();
            _service = new AccountPrefillService(Substitute.For<ILogger>(), _repository);
        }

        [TestMethod]
        public void CanPrefillDescription()
        {
            var account = new Account();

            _service.PrefillAccount(account);

            account.Description.ShouldBe("(Prefilled)");
            _repository.Received().Update(account);
        }

        [TestMethod]
        public void CanPrefillName()
        {
            var account = new Account
            {
                Name = "TestName"
            };

            _service.PrefillAccount(account);

            account.Name.ShouldBe("TestName (Prefilled)");
            _repository.Received().Update(account);
        }
    }
}