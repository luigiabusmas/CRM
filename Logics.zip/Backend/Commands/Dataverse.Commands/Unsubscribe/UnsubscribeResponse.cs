using System.Runtime.Serialization;

namespace Cultivate.Commands.Unsubscribe
{
    [DataContract]
    public class UnsubscribeResponse
    {
    }
}