using System;
using System.Runtime.Serialization;

namespace Cultivate.Commands.Unsubscribe
{
    [DataContract]
    public class UnsubscribeRequest
    {
        [DataMember]
        public Guid AccountId { get; set; }
    }
}