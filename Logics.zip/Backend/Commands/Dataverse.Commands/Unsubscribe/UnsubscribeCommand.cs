using Avanade.BizApps.Core.CommandDispatcher;
using Avanade.BizApps.Core.CommandDispatcher.Attributes;
using Avanade.BizApps.Core.CommandDispatcher.Models;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Diagnostics;
using Cultivate.Entities.Generated;

namespace Cultivate.Commands.Unsubscribe
{
    [Command(CommandNames.Unsubscribe)]
    public class UnsubscribeCommand : JsonCommandBase<UnsubscribeRequest, UnsubscribeResponse>
    {
        private readonly IRepository<Account> _accountRepository;

        public UnsubscribeCommand(IJsonCommandSerializer commandSerializer, ILogger logger, IRepository<Account> accountRepository) : base(commandSerializer, logger)
        {
            _accountRepository = accountRepository;
        }

        public override UnsubscribeResponse Execute(UnsubscribeRequest request)
        {
            var account = _accountRepository.GetById(request.AccountId);
            
            account.DoNotEMail = true;
            _accountRepository.Update(account);

            return new UnsubscribeResponse();
        }
    }
}