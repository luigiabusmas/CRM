using System.Diagnostics.CodeAnalysis;

#pragma warning disable 1591
namespace Cultivate.Commands
{
    [ExcludeFromCodeCoverage]
    public static class CommandNames
    {
        public const string Unsubscribe = nameof(Unsubscribe);
    }
}