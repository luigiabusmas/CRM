using Avanade.BizApps.Core.CommandDispatcher;
using Avanade.BizApps.Core.Contracts;
using Avanade.BizApps.Core.Testing;
using Avanade.BizApps.Core.Testing.Mocks;
using Cultivate.Commands.Unsubscribe;
using Cultivate.Entities.Generated;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Shouldly;

namespace Cultivate.Commands.Tests
{
    [TestClass]
    public class SampleCommandTests
    {
        private IRepository<Account> _accountRepository;
        private UnsubscribeCommand _unsubscribeCommand;

        [TestInitialize]
        public void Setup()
        {
            _accountRepository = Substitute.For<IRepository<Account>>();
            _unsubscribeCommand = new UnsubscribeCommand(new JsonCommandSerializer(),
                new LoggerMock(true).Object, _accountRepository);
        }

        [TestMethod]
        public void ShouldExecute()
        {
            _accountRepository.GetById(Guids.A).Returns(new Account());
            var request = new UnsubscribeRequest { AccountId = Guids.A };

            var response = _unsubscribeCommand.Execute(request);

            _accountRepository.Received(1).Update(Arg.Is<Account>(a => a.DoNotEMail == true));
            response.ShouldNotBeNull();
        }
    }
}