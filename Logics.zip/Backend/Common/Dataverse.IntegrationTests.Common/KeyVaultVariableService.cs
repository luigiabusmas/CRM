using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using System;
using System.Configuration;

namespace Cultivate.IntegrationTests.Common
{
    public interface IKeyVaultVariableService
    {
        string GetKeyVaultVariable(string variableName);
    }

    public class KeyVaultVariablesService : IKeyVaultVariableService
    {
        public string GetKeyVaultVariable(string variableName)
        {
            var environmentVariableService = new EnvironmentVariablesService();
            var secretClient = new SecretClient(
             new Uri(ConfigurationManager.AppSettings["KeyVaultURI"] ?? environmentVariableService.GetEnvironmentVariable("KeyVaultURI")),
             new DefaultAzureCredential(
                 new DefaultAzureCredentialOptions()
                 {
                     VisualStudioTenantId = ConfigurationManager.AppSettings["TenantId"] ?? environmentVariableService.GetEnvironmentVariable("TenantId"),
                     ExcludeSharedTokenCacheCredential = true
                 })
             );

            var secret = secretClient.GetSecret(variableName);
            return secret?.Value?.Value;
        }
    }
}