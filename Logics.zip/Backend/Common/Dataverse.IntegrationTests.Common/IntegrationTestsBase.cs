using Microsoft.Xrm.Sdk;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Configuration;
using Avanade.BizApps.Core.Diagnostics;
using Avanade.BizApps.Core.Entities.Generated;
using Avanade.BizApps.Core.Plugins.DependencyInjection;
using Avanade.BizApps.Core.Plugins.Operation.ExecutionContext;

namespace Cultivate.IntegrationTests.Common
{
    public abstract class IntegrationTestsBase
    {
        private IDependencyContainer _dependencyContainer;
        private ILogger _logger;
        private ICrmConnectionService _connection;
        private string _organizationUri;

        protected IDependencyContainer DependencyContainer => _dependencyContainer;
        protected ICrmConnectionService Connection => _connection;
        protected ILogger Logger => _logger;

        [TestInitialize]
        public virtual void Initialize()
        {
            var assemblyScanner = new AssemblyScanner();
            _dependencyContainer = new DependencyContainer(assemblyScanner);
            _dependencyContainer.RegisterInstance(_dependencyContainer);
            _dependencyContainer.RegisterInstance(_dependencyContainer.UnityContainer);
            _dependencyContainer.AddDiagnostics();
            _dependencyContainer.RegisterType<IExecutionContext, IntegrationExecutionContext>();

            _logger = new DummyLogger();
            _dependencyContainer.RegisterInstance(_logger);

            _organizationUri = ConfigurationManager.AppSettings["IntegrationTestEnvironmentURI"];

            _connection = new CrmConnectionService(
                _logger,
                new EnvironmentVariablesService(),
                new KeyVaultVariablesService(),
                new IntegrationTestsEnvironment(),
                _organizationUri);

            if (_connection.TryConnectToCrm())
                _dependencyContainer.RegisterInstance((IOrganizationService)_connection.CrmService);
            else
                throw new Exception(_connection.LastCrmException);
        }
    }
}