using System;
using System.Collections.Generic;
using System.Net.Http;
using Microsoft.Xrm.Sdk.WebServiceClient;
using Microsoft.Xrm.Tooling.Connector;
using Newtonsoft.Json;
using System.Configuration;
using System.Net;
using Avanade.BizApps.Core.Diagnostics;

namespace Cultivate.IntegrationTests.Common
{
    public interface ICrmConnectionService
    {
        string LastCrmException { get; }
        CrmServiceClient CrmService { get; }
        bool TryConnectToCrm();
    }

    public class CrmConnectionService : ICrmConnectionService
    {
        private CrmServiceClient _crmServiceClient;
        private string _lastCrmException;
        private readonly string _organizationUri;
        private readonly ILogger _logger;
        private readonly IKeyVaultVariableService _keyVaultVariablesService;
        private readonly IEnvironmentVariableService _environmentVariablesService;
        private readonly ITestEnvironment _testEnvironment;

        public CrmServiceClient CrmService => _crmServiceClient;
        public string LastCrmException => _lastCrmException;

        public CrmConnectionService(
            ILogger logger,
            IEnvironmentVariableService environmentVariablesService,
            IKeyVaultVariableService keyVaultVariablesService,
            ITestEnvironment testEnvironment,
            string organizationUri)
        {
            _logger = logger;
            _environmentVariablesService = environmentVariablesService;
            _keyVaultVariablesService = keyVaultVariablesService;
            _testEnvironment = testEnvironment;
            _organizationUri = organizationUri;
        }

        public bool TryConnectToCrm()
        {
            try
            {
                return TokenAuthentication();
            }
            catch
            {
                // swallowed
            }

            try
            {
                return ConnectionStringAuthentication();
            }
            catch
            {
                return false;
            }
        }

        private bool ConnectionStringAuthentication()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var crmServiceClient = new CrmServiceClient(GetConnectionString());
            if (!crmServiceClient.IsReady)
            {
                LogLastCrmException(crmServiceClient);
                return false;
            }

            _crmServiceClient = crmServiceClient;
            return true;
        }

        private bool TokenAuthentication()
        {
            var webProxyClient = new OrganizationWebProxyClient(
                new Uri($"{_organizationUri}/XRMServices/2011/Organization.svc/web"),
                new TimeSpan(2, 0, 0),
                true)
            {
                HeaderToken = GetAuthenticationToken(),
                SdkClientVersion = "9.0"
            };

            var crmServiceClient = new CrmServiceClient(webProxyClient);
            if (!crmServiceClient.IsReady)
            {
                LogLastCrmException(crmServiceClient);
                return false;
            }

            _crmServiceClient = crmServiceClient;
            return true;
        }

        private string GetAuthenticationToken()
        {
            try
            {
                _logger.TraceInformation("Get Authentication Token...");

                var clientId = _keyVaultVariablesService.GetKeyVaultVariable("IntegrationTestClientId");
                var clientSecret = _keyVaultVariablesService.GetKeyVaultVariable("IntegrationTestClientSecret");

                var tenantId = ConfigurationManager.AppSettings["TenantId"] ?? _environmentVariablesService.GetEnvironmentVariable("TenantId");
                var oAuth2TokenProviderUrl = $"https://login.windows.net/{tenantId}/oauth2/v2.0/token";

                var form = new Dictionary<string, string>
                {
                    {"grant_type", "client_credentials"},
                    {"client_id", clientId},
                    {"client_secret", clientSecret},
                    {"scope", _organizationUri + "/.default"},
                };

                var client = new HttpClient();
                var tokenResponse = client.PostAsync(
                    oAuth2TokenProviderUrl,
                    new FormUrlEncodedContent(form))
                    .GetAwaiter()
                    .GetResult();

                var jsonContent = tokenResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                var token = JsonConvert.DeserializeObject<Token>(jsonContent);

                return token?.AccessToken;
            }
            catch (Exception ex)
            {
                _logger.TraceError(ErrorMessageService.ConstructErrorMessage(
                    ex,
                    "Error when trying to log in to the CRM system. " +
                    "Validate that configuration is correct!"));

                throw;
            }
        }

        private string GetConnectionString()
        {
            return _testEnvironment.GetJsonElement("Environment.ConnectionString");
        }

        private void LogLastCrmException(CrmServiceClient crmServiceClient)
        {
            _logger.TraceError($"Error occurred: {crmServiceClient.LastCrmError}");

            if (crmServiceClient.LastCrmException != null)
                _logger.TraceError(ErrorMessageService.ConstructErrorMessage(crmServiceClient.LastCrmException, "CrmConnectionService - LastCrmException"));

            _lastCrmException = crmServiceClient.LastCrmException?.Message;
        }
    }
}