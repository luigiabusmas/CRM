using System;

namespace Cultivate.IntegrationTests.Common
{
    public interface IEnvironmentVariableService
    {
        string GetEnvironmentVariable(string variableName);
    }

    public class EnvironmentVariablesService : IEnvironmentVariableService
    {
        public string GetEnvironmentVariable(string variableName)
        {
            var variableValue = Environment.GetEnvironmentVariable(variableName, EnvironmentVariableTarget.Process);

            return !string.IsNullOrEmpty(variableValue) 
                ? variableValue 
                : Environment.GetEnvironmentVariable(variableName, EnvironmentVariableTarget.Machine);
        }
    }
}