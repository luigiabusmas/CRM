using Newtonsoft.Json;

namespace Cultivate.IntegrationTests.Common
{
	public class Token
	{
		[JsonProperty("token_type")]
		public string TokenType;

		[JsonProperty("expires_in")]
		public int ExpiresIn;

		[JsonProperty("ext_expires_in")]
		public int ExtExpiresIn;

		[JsonProperty("access_token")]
		public string AccessToken;
	}
}