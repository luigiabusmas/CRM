﻿# Integration Tests Module

## General

Integration Testing supports us to identify mistakes and improve the utilization of the system.
It helps to identify real challenges for CRM implementation, assess robustness and ensure adherence to user requirements.

## Authentication Options

- Authenticate by using the ClientId & ClientSecret, from Azure Key Vault, to obtain Token and authenticate against CRM
- Authenticate by using CRM ConnectionString (only for local executions)

## Local Execution (Visual Studio)

### SetUp Instructions (choose one option)

### Option 1: _Authenticate against CRM via CRM Connection String_

1. Navigate to the folder: ..src\Dataverse\Backend\Common\Xrm.IntegrationTests.Common
2. Check if there already exists the file _IntegrationTestsEnvironment.json_
3. If yes, check the validity of your connection string (see 5.)
4. If not, create the json file with following content:

```json
{
   "Environment":{
      "ConnectionString":"AuthType=OAuth; Username=youruser@yourdomain.com; Password=***; Integrated Security=true; Url=https://yoururl.crm4.dynamics.com/; AppId=51f81489-12ee-4a9e-aaae-a2591f45987d; RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97; TokenCacheStorePath=c:\\MyTokenCache; LoginPrompt=Auto"
   }
}
```

5. You are all set up, you can start writing the Integration Tests

### Option 2: _Authenticate against CRM via Azure Key Vault and App Registration by obtaining the Token_

1. Authentication against Dynamics Online will happen using - KeyVault ClientId and ClientSecret to retrieve the token for authentication against CRM
2. Ensure with your Azure Team that the KeyVaults is existing in Azure, holding ClientId and ClientSecret which have permissions to your target CRM
3. For Local execution in VS, developers should have read rights to the KeyVaults, or developers should use common generic Azure account which has permissions to the Key Vault in their VS instances
4. In your VS instance navigate to the _Tools->Options->AzureServiceAuthentication_ and ensure you can see there the correct user which has right to read the Key Vault from your Azure Tenant
5. Ensure that five (5) following variables:
    - TenantId
    - KeyVaultURI
    - IntegrationTestEnvironmentURI
    - IntegrationTestRelativeFilePath
    - MainSolutionName
are created on your local Machine as Environment Variables or in AppConfig (both option are supported in code)
6. You are all set up, you can start writing the Integration Tests

## Execution in Azure DevOps

### SetUp Instructions

- Authentication against Dynamics Online will happen using - KeyVault ClientId and ClientSecret to retrieve the token for authentication against CRM.
- KeyVaults should be existing in Azure holding ClientId and ClientSecret which have permissions to the target CRM
- KeyVaults should be linked from Azure into Azure DevOps variable library group
- Azure DevOps should have ServiceConnection set up which connects to the Azure and has rights to read KeyVaults
- Three (3) Variables (TenantId, KeyVaultURI, IntegrationTestEnvironmentURI) needs to be created in Azure DevOps Library
