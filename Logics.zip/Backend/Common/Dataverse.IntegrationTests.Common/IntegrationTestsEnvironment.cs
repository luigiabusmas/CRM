using Newtonsoft.Json.Linq;
using System.Configuration;
using System.IO;
using System.Linq;

namespace Cultivate.IntegrationTests.Common
{
    public interface ITestEnvironment
    {
        string GetJsonElement(string item);
    }

    public class IntegrationTestsEnvironment : ITestEnvironment
    {
        public string GetJsonElement(string item)
        {
            var solutionPath = TryGetSolutionDirectoryInfo();
            var relativeFilePath = ConfigurationManager.AppSettings["IntegrationTestRelativeFilePath"];

            var filePath = Path.GetFullPath(solutionPath.FullName + relativeFilePath);
            if (!File.Exists(filePath)) 
                return null;

            var integrationTestsEnvironments = JObject.Parse(File.ReadAllText(filePath));
            return integrationTestsEnvironments.SelectToken(item)?.ToString();
        }

        private DirectoryInfo TryGetSolutionDirectoryInfo(string currentPath = null)
        {
            var directory = new DirectoryInfo(currentPath ?? Directory.GetCurrentDirectory());

            while (directory != null && !directory.GetFiles(ConfigurationManager.AppSettings["MainSolutionName"]).Any())
            {
                directory = directory.Parent;
            }

            return directory;
        }
    }
}