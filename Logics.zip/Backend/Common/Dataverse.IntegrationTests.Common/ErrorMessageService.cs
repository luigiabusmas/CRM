using System;

namespace Cultivate.IntegrationTests.Common
{
    public static class ErrorMessageService
    {
        public static string ConstructErrorMessage(Exception ex, string errorMsg)
        {
            var exceptionMsg = $"{errorMsg + Environment.NewLine} Exception message: {ex.Message + Environment.NewLine} Exception source: {ex.Source + Environment.NewLine} Exception Stack trace:{ex.StackTrace}";
            return ex.InnerException != null ? ConstructErrorMessage(ex.InnerException, $"{exceptionMsg} - Inner Exception: ") : exceptionMsg;
        }
    }
}
