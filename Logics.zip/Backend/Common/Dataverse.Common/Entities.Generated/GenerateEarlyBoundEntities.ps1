[CmdletBinding()]
param()

Import-Module "$PSScriptRoot\..\..\..\..\..\..\cicd\tools\core-lib.psd1" -Force -Global
Set-Preference -Invocation $PSCmdlet.MyInvocation

$crmSvcUtilPath = Install-NuGetPackageFromProject `
	-PackageName "Avanade.BizApps.Tools.EarlyboundGenerator" `
	-ToolPath "content\CrmSvcUtil.exe" `
	-CSProjectPath "$PSScriptRoot\..\..\..\..\..\Tools\Dataverse.Framework.Tools\Dataverse.Framework.Tools.csproj"

$envConfigPath = "$PSScriptRoot\..\..\..\..\..\Configuration.json"

Write-Host "CrmSvcUtil:     $crmSvcUtilPath"
Write-Host "Env:            DevelopmentLocalSettings"

$connectionString = Get-ConnectionString `
	-ConfigurationPath $envConfigPath `
	-EnvironmentName "DevelopmentLocalSettings"

Copy-Item "$PSScriptRoot\CrmSvcUtil.exe.config" "$($crmSvcUtilPath).config" -Force
[xml] $configDoc = Get-Content "$($crmSvcUtilPath).config"
$configDoc.configuration.XrmSettings.Output.outputDirectory = "$PSScriptRoot\Entities"
$configDoc.Save("$($crmSvcUtilPath).config")

Get-ChildItem -Filter "*.cs" -Path "$PSScriptRoot" -Recurse | Remove-Item -Force

$command = $crmSvcUtilPath
$command += " /connectionstring:`"$connectionString`""
$command += " /generateGlobalOptionSets"
# $command += " /il" // Enables interactive login


Invoke-Expression $command