﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace StripeAction
{
    public class StripeCheckoutSession : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var jsonInput = GetInputParameters(context, tracingService);
            string jsonString = JsonConvert.SerializeObject(jsonInput);
            tracingService.Trace("Consolidated JSON: " + jsonString);

            AZFunctionHelper aZFunctionHelper = new AZFunctionHelper();

            Guid recordId = Guid.Empty;

            // Extract requestId from the input parameters if it exists
            if (jsonInput.ContainsKey("requestid"))
            {
                recordId = IntegrationLogExists(service, jsonInput["requestid"], tracingService);

            }
            else
            {

                try
                {
                    recordId = CreateIntegrationLog(service, jsonString, tracingService);
                    tracingService.Trace("Integration log created with ID: " + recordId);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Error creating integration log: " + ex.Message);
                    // throw; 
                }

            }

            //
            try
            {
                // Get Azure Function URL
                string azureFunctionUrl = aZFunctionHelper.GetAzureFunctionUrl(service, tracingService, "FAStripeCheckoutSession");

                if (!string.IsNullOrEmpty(azureFunctionUrl))
                {
                    string azureFunctionResponse = aZFunctionHelper.CallAzureFunctionAsync(azureFunctionUrl, jsonString, tracingService).Result;
                    tracingService.Trace("Azure Function Response: " + azureFunctionResponse);

                    try
                    {
                        var responseJson = JsonConvert.DeserializeObject<Dictionary<string, string>>(azureFunctionResponse);
                        if (responseJson.TryGetValue("status", out string status) && status == "error")
                        {
                            string errorMessage = responseJson.TryGetValue("message", out string message) ? message : "Unknown error occurred.";
                            UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);
                            context.OutputParameters["rhs_stripeCheckoutSessionResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
                        }
                        else
                        {
                            // If response does not indicate failure, return the original response
                            context.OutputParameters["rhs_stripeCheckoutSessionResponse"] = azureFunctionResponse;
                        }
                    }
                    catch (JsonException jsonEx)
                    {
                        tracingService.Trace("Error deserializing Azure Function response: " + jsonEx.Message);
                        context.OutputParameters["rhs_stripeCheckoutSessionResponse"] = JsonConvert.SerializeObject(new { message = "Failed to process Azure function response", status = "error" });
                    }

                }
                else
                {
                    tracingService.Trace("Azure Function URL not found in app settings.");
                    UpdateIntegrationLog(service, recordId, "Azure Function URL not found in app settings.", 120000002, tracingService);
                }
            }
            catch (Exception ex)
            {
                // General exception handling
                string errorMessage = $"Error calling Azure Function:" + ex.Message;
                tracingService.Trace(errorMessage);
                UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);

                context.OutputParameters["rhs_stripeCheckoutSessionResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
            }
            //
        }

        private Dictionary<string, string> GetInputParameters(IPluginExecutionContext context, ITracingService tracingService)
        {
            var jsonInput = new Dictionary<string, string>();

            if (TryGetParameter(context, "rhs_stripeCustomerId", out string customerId))
            {
                jsonInput["customerId"] = customerId;
                tracingService.Trace("CustomerId: " + customerId);
            }

            if (TryGetParameter(context, "rhs_stripeCurrency", out string currency))
            {
                jsonInput["currency"] = currency;
                tracingService.Trace("currency: " + currency);
            }

            if (TryGetParameter(context, "rhs_stipeUnitAmount", out string unitAmount))
            {
                jsonInput["unitAmount"] = unitAmount;
                tracingService.Trace("unitAmount: " + unitAmount);
            }

            if (TryGetParameter(context, "rhs_stripeQuantity", out string quantity))
            {
                jsonInput["quantity"] = quantity;
                tracingService.Trace("quantity: " + quantity);
            }
            if (TryGetParameter(context, "rhs_stripeMode", out string mode))
            {
                jsonInput["mode"] = mode;
                tracingService.Trace("mode: " + mode);
            }
            if (TryGetParameter(context, "rhs_stripeProduct", out string product))
            {
                jsonInput["productName"] = product;
                tracingService.Trace("productName: " + product);
            }

            if (TryGetParameter(context, "rhs_checkoutSessionId", out string requestid))
            {
                jsonInput["requestid"] = requestid;
                tracingService.Trace("requestid: " + requestid);
            }
             if (TryGetParameter(context, "rhs_requestEnvironment", out string requestenvironment))
            {
                     jsonInput["requestenvironment"] = requestenvironment;
                    tracingService.Trace("requestenvironment: " + requestenvironment);
            }


            if (jsonInput.Count == 0)
            {
                tracingService.Trace("Required parameters are missing.");
                // throw new InvalidPluginExecutionException("Required parameters are missing.");
            }

            return jsonInput;
        }

        private bool TryGetParameter(IPluginExecutionContext context, string parameterName, out string value)
        {
            value = null;
            if (context.InputParameters.Contains(parameterName) && context.InputParameters[parameterName] is string parameterValue)
            {
                value = parameterValue;
                return true;
            }
            return false;
        }

        private Guid CreateIntegrationLog(IOrganizationService service, string jsonString, ITracingService tracingService)
        {
            var newRecord = new Entity("rhs_integrationlog")
            {
                ["rhs_name"] = "Create Checkout Session",
                ["rhs_integration_type"] = "Stripe",
                ["rhs_payload"] = jsonString,
                ["rhs_direction"] = new OptionSetValue(120000000),
                ["rhs_integrationstatus"] = new OptionSetValue(120000000)
            };

            return service.Create(newRecord);
        }

        private void UpdateIntegrationLog(IOrganizationService service, Guid recordId, string message, int status, ITracingService tracingService)
        {
            var updateRecord = new Entity("rhs_integrationlog", recordId)
            {
                ["rhs_response"] = message,  // Use message for both success and error
                ["rhs_integrationstatus"] = new OptionSetValue(status)  // Update status based on success or error
            };

            service.Update(updateRecord);
            tracingService.Trace("Integration log updated: " + message);
        }

        private Guid IntegrationLogExists(IOrganizationService service, string requestId, ITracingService tracingService)
        {
            // Check if the integration log exists for the given request ID
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_integrationlog")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_integrationlogid"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                        new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_requestid", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, requestId)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var logId = result.Entities.First().GetAttributeValue<Guid>("rhs_integrationlogid");
                tracingService.Trace($"Integration log exists with ID {logId} for request ID {requestId}");
                return logId;
            }

            tracingService.Trace($"No integration log found for request ID {requestId}");
            return Guid.Empty; // Return empty GUID if not found
        }

    }
}
