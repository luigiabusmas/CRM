﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;

namespace SendGridAction
{
    public class CreateEvents : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.MessageName == "rhs_sendgridcreateevents")
            {
                Helper helper = new Helper();
                Guid integLogId = new Guid();

                try
                {
                    if (context.InputParameters.Contains("Events") && context.InputParameters["Events"] is string events)
                    {
                        tracingService.Trace($"Events json: {events}");

                        // Check existing integration log based on payload
                        if (helper.IntegrationLogExists(service, events, tracingService))
                            return;

                        // Create integration log
                        integLogId = helper.CreateIntegrationLog(service, events, tracingService);
                        tracingService.Trace("Integration log created with ID: " + integLogId);

                        var eventsJson = JsonConvert.DeserializeObject<List<SendGridEvent>>(events);

                        // Create sendgrid reporting record for each event
                        foreach (var ev in eventsJson)
                        {

                            Entity sgReporting = new Entity("rhs_sendgridreporting");
                            sgReporting["rhs_sg_event_id"] = ev.SgEventId;
                            sgReporting["rhs_email"] = ev.Email;
                            sgReporting["rhs_domain"] = ev.Domain;
                            sgReporting["rhs_from"] = ev.From;

                            // Relate to Contact lookup
                            sgReporting["rhs_contact"] = !string.IsNullOrEmpty(ev.ContactId) ? new EntityReference("contact", new Guid(ev.ContactId)) : null;

                            // Convert timestamp to UTC
                            sgReporting["rhs_timestamp"] = ev.Timestamp;
                            DateTime? datetimeValue = ev.Timestamp.HasValue
                                ? DateTimeOffset.FromUnixTimeSeconds(ev.Timestamp.Value).UtcDateTime
                                : (DateTime?)null;
                            sgReporting["rhs_timestamputc"] = datetimeValue;

                            if (ev.Pool != null)
                            {
                                sgReporting["rhs_poolid"] = ev.Pool.Id;
                                sgReporting["rhs_poolname"] = ev.Pool.Name;
                            }

                            sgReporting["rhs_smtpid"] = ev.SmtpId;
                            sgReporting["rhs_bounce_classification"] = ev.BounceClassification;
                            sgReporting["rhs_event"] = ev.Event;
                            sgReporting["rhs_sg_machine_open"] = ev.SgMachineOpen;

                            string categoryValue = string.Join(", ", ev.Category?
                                .Where(s => !string.IsNullOrWhiteSpace(s))
                                .Select(s => s.Trim()) ?? Enumerable.Empty<string>());
                            sgReporting["rhs_category"] = categoryValue;

                            sgReporting["rhs_sg_message_id"] = ev.SgMessageId;
                            sgReporting["rhs_reason"] = ev.Reason;
                            sgReporting["rhs_status"] = ev.Status;
                            sgReporting["rhs_response"] = ev.Response;
                            sgReporting["rhs_attempt"] = ev.Attempt;
                            sgReporting["rhs_type"] = ev.Type;
                            sgReporting["rhs_useragent"] = ev.UserAgent;
                            sgReporting["rhs_ip"] = ev.Ip;
                            sgReporting["rhs_url"] = ev.Url;
                            sgReporting["rhs_message"] = ev.Message;

                            var reportId = service.Create(sgReporting);
                            tracingService.Trace($"SendGrid Report Id: {reportId}");

                        }

                        helper.UpdateIntegrationLog(service, integLogId, JsonConvert.SerializeObject(new { status = "success" }), 120000001, tracingService);
                        context.OutputParameters["Response"] = JsonConvert.SerializeObject(new { status = "success" });

                    }
                }
                catch (Exception ex)
                {
                    helper.UpdateIntegrationLog(service, integLogId, ex.Message, 120000002, tracingService);
                    context.OutputParameters["Response"] = JsonConvert.SerializeObject(new { status = "failed", message = ex.Message });

                    throw new InvalidPluginExecutionException($"Error in SendGridAction.CreateEvents:{ex.Message}");
                }
            }

        }
    }

}
