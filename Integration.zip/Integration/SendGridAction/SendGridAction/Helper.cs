﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IdentityModel.Protocols.WSTrust;
using System.ServiceModel.Channels;

namespace SendGridAction
{
    public class Helper
    {
        public Guid CreateIntegrationLog(IOrganizationService service, string jsonString, ITracingService tracingService)
        {
            Guid recordId = Guid.Empty;
            try
            {
                var newRecord = new Entity("rhs_integrationlog")
                {
                    ["rhs_name"] = "Create Events",
                    ["rhs_integration_type"] = "SendGrid",
                    ["rhs_payload"] = jsonString,
                    ["rhs_direction"] = new OptionSetValue(120000000),
                    ["rhs_integrationstatus"] = new OptionSetValue(120000000)

                };

                return service.Create(newRecord);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in CreateIntegrationLog: {ex.Message}");
            }
        }

        public void UpdateIntegrationLog(IOrganizationService service, Guid recordId, string message, int status, ITracingService tracingService)
        {
            try
            {
                var updateRecord = new Entity("rhs_integrationlog", recordId)
                {
                    ["rhs_response"] = message,  // Use message for both success and error
                    ["rhs_integrationstatus"] = new OptionSetValue(status)  // Update status based on success or error
                };

                service.Update(updateRecord);
                tracingService.Trace("Integration log updated: " + message);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in UpdateIntegrationLog: {ex.Message}");
            }
        }

        public bool IntegrationLogExists(IOrganizationService service, string payload, ITracingService tracingService)
        {
            // Check if the integration log exists for the given request ID
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_integrationlog")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_integrationlogid"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                        new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_payload", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, payload)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var logId = result.Entities.First().GetAttributeValue<Guid>("rhs_integrationlogid");
                tracingService.Trace($"Integration log exists with ID {logId}");
                return true;
            }

            tracingService.Trace($"No existing integration log found");
            return false; // Return empty GUID if not found
        }
    }
}
