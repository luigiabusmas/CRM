﻿using Newtonsoft.Json;
using System.Collections.Generic;

public class SendGridEvent
{
    [JsonProperty("email")]
    public string Email { get; set; }

    [JsonProperty("contactid")]
    public string ContactId { get; set; }

    [JsonProperty("domain")]
    public string Domain { get; set; }

    [JsonProperty("from")]
    public string From { get; set; }

    [JsonProperty("pool")]
    public PoolInfo Pool { get; set; }

    [JsonProperty("timestamp")]
    public long? Timestamp { get; set; }

    [JsonProperty("smtp-id")]
    public string SmtpId { get; set; }

    [JsonProperty("event")]
    public string Event { get; set; }

    [JsonProperty("category")]
    public List<string> Category { get; set; }

    [JsonProperty("sg_event_id")]
    public string SgEventId { get; set; }

    [JsonProperty("sg_message_id")]
    public string SgMessageId { get; set; }

    [JsonProperty("message")]
    public string Message { get; set; }

    [JsonProperty("ip")]
    public string Ip { get; set; }

    [JsonProperty("response")]
    public string Response { get; set; }

    [JsonProperty("attempt")]
    public string Attempt { get; set; }

    [JsonProperty("sg_machine_open")]
    public bool? SgMachineOpen { get; set; }

    [JsonProperty("useragent")]
    public string UserAgent { get; set; }

    [JsonProperty("url")]
    public string Url { get; set; }

    [JsonProperty("bounce_classification")]
    public string BounceClassification { get; set; }

    [JsonProperty("reason")]
    public string Reason { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("type")]
    public string Type { get; set; }
}

public class PoolInfo
{
    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("id")]
    public int Id { get; set; }
}