﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace MeracIntegration
{
    public class CRMAction
    {
        public Guid GardenVisitCreator(IOrganizationService service, ITracingService tracingService, GardenVisitPayload payload)
        {
            // Parse the date and time
            DateTime activityDate;
            if (!DateTime.TryParse(payload.ActivityDate, out activityDate))
            {
                tracingService.Trace("Invalid date format for ActivityDate: " + payload.ActivityDate);
                throw new InvalidPluginExecutionException("Invalid date format for ActivityDate.");
            }

            // Convert to UTC if necessary
            DateTime activityDateUtc = activityDate.ToUniversalTime();

            //Get the Accounts for the Source System
            Guid accountId = GetGardenAccount(service, payload.SourceSystem);

            if (accountId == Guid.Empty)
            {
                tracingService.Trace($"Account for {payload.SourceSystem} cannot be found");
            }

            var newRecord = new Entity("rhs_gardenvisit")
            {
                ["rhs_name"] = payload.Event,
                ["rhs_event"] = payload.Event,
                ["rhs_sourcesystemv2"] = accountId != Guid.Empty ? new EntityReference("account", accountId) : null,
                ["rhs_sourcesystemid"] = payload.SourceSystemId,
                ["rhs_membershipnumber"] = payload.MembershipNumber,
                ["rhs_activitydate"] = activityDateUtc,
                ["rhs_quantity"] = int.Parse(payload.Quantity),
            };

            try
            {
                // Create the record and get the GUID of the newly created record
                Guid newRecordId = service.Create(newRecord);

                // Return the GUID of the created record
                return newRecordId;
            }
            catch (Exception ex)
            {
                tracingService.Trace("Failed to create a new gardenvisit record: " + ex.Message);
                return Guid.Empty;
            }
        }

        private Guid GetGardenAccount(IOrganizationService service, string gardenName)
        {
            QueryExpression query = new QueryExpression("account")
            {
                ColumnSet = new ColumnSet("accountid", "name"),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("name", ConditionOperator.Equal, gardenName),
                        new ConditionExpression("rhs_accounttype", ConditionOperator.Equal, 120000009)
                    }
                }
            };

            EntityCollection accounts = service.RetrieveMultiple(query);
            return accounts.Entities.FirstOrDefault()?.Id ?? Guid.Empty;
        }
    }
}
