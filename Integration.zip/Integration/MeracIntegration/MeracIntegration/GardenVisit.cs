﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;

namespace MeracIntegration
{
    public class GardenVisit : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            // Check if the context is valid
            if (context.MessageName != "Create" || context.PrimaryEntityName != "rhs_integrationlog")
            {
                return;
            }

            // Get the entity being created
            Entity entity = (Entity)context.InputParameters["Target"];

            // Check for the rhs_integrationtype attribute
            if (entity.Attributes.Contains("rhs_integration_type"))
            {
                // Get the integration type value
                string integrationType = entity["rhs_integration_type"].ToString();

                // Check if the integration type is "merac"
                if (integrationType.Equals("meracvisit", StringComparison.OrdinalIgnoreCase))
                {
                    // Check for the payload attribute
                    if (entity.Attributes.Contains("rhs_payload")) // Note: make sure the spelling matches your actual schema
                    {
                        string payloadJson = entity["rhs_payload"].ToString();

                        // Deserialize the JSON payload
                        try
                        {
                            var payload = JsonConvert.DeserializeObject<GardenVisitPayload>(payloadJson);
                            var action = new CRMAction();
                            Guid recordId = action.GardenVisitCreator(service, tracingService, payload);

                            if (recordId != Guid.Empty)
                            {
                                entity["rhs_integrationstatus"] = new OptionSetValue(120000001);
                                service.Update(entity);
                                SetStateRequest setStateRequest = new SetStateRequest
                                {
                                    EntityMoniker = new EntityReference("rhs_integrationlog", entity.Id),  
                                    Status = new OptionSetValue(2),  // Set the status reason code
                                    State = new OptionSetValue(1) 
                                };
                                service.Execute(setStateRequest);
                            }
                            else {
                                entity["rhs_integrationstatus"] = new OptionSetValue(120000002);
                                service.Update(entity);
                            }
                          

                        }
                        catch (JsonException ex)
                        {
                            tracingService.Trace("Failed to parse the payload JSON.: " + ex.Message);
                            throw new InvalidPluginExecutionException("Failed to parse the payload JSON.", ex);

                        }
                    }
                }

            }
        }


    }
}

