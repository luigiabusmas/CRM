﻿namespace MeracIntegration
{
    public class GardenVisitPayload
    {
        public string Event { get; set; }
        public string SourceSystem { get; set; }
        public string SourceSystemId { get; set; }
        public string MembershipNumber { get; set; }
        public string ActivityDate { get; set; }
        public string Quantity { get; set; }
    }
}
