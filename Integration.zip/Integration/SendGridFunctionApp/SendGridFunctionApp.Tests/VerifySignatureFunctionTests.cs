using EllipticCurve;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Moq;
using SendGridFunctionApp.Helpers;
using SendGridFunctionApp.Interfaces;
using System.Net;
using System.Text;

namespace SendGridFunctionApp.Tests
{
    #region HttpRequestData
    public class FakeHttpRequestData : HttpRequestData
    {
        public FakeHttpRequestData(FunctionContext context, string body, string? signature, string? timestamp)
            : base(context)
        {
            Body = new MemoryStream(Encoding.UTF8.GetBytes(body));
            Headers = new HttpHeadersCollection();

            if (!string.IsNullOrEmpty(signature))
                Headers.Add(RequestValidator.SIGNATURE_HEADER, signature);

            if (!string.IsNullOrEmpty(timestamp))
                Headers.Add(RequestValidator.TIMESTAMP_HEADER, timestamp);
        }

        public override Stream Body { get; }

        public override HttpHeadersCollection Headers { get; }

        public override IReadOnlyCollection<IHttpCookie> Cookies => Array.Empty<IHttpCookie>();

        public override Uri Url => new Uri("http://localhost");

        public override IEnumerable<System.Security.Claims.ClaimsIdentity> Identities
            => Enumerable.Empty<System.Security.Claims.ClaimsIdentity>();

        public override string Method => "POST";

        public override HttpResponseData CreateResponse()
            => new FakeHttpResponseData(FunctionContext);
    }
    #endregion

    #region HttpResponseData
    public class FakeHttpResponseData : HttpResponseData
    {
        public FakeHttpResponseData(FunctionContext context) : base(context)
        {
            Body = new MemoryStream();
            Headers = new HttpHeadersCollection();
        }

        public override HttpStatusCode StatusCode { get; set; }

        public override HttpHeadersCollection Headers { get; set; }

        public override Stream Body { get; set; }

        public override HttpCookies Cookies { get; } = null!;
    }
    #endregion

    public class VerifySignatureFunctionTests
    {
        private readonly Mock<ILoggerFactory> _mockLoggerFactory;
        private readonly Mock<ILogger> _mockLogger;
        private readonly Mock<IRequestValidator> _mockRequestValidator;
        private readonly Mock<IKeyVaultAccess> _mockKeyVaultAccess;
        private readonly Mock<ICustomApiCaller> _mockApiCaller;

        private readonly VerifySignatureFunction _function;

        public VerifySignatureFunctionTests()
        {
            _mockLoggerFactory = new Mock<ILoggerFactory>();
            _mockLogger = new Mock<ILogger>();
            _mockLoggerFactory.Setup(f => f.CreateLogger(It.IsAny<string>()))
                              .Returns(_mockLogger.Object);

            _mockRequestValidator = new Mock<IRequestValidator>();
            _mockKeyVaultAccess = new Mock<IKeyVaultAccess>();
            _mockApiCaller = new Mock<ICustomApiCaller>();

            _function = new VerifySignatureFunction(
                _mockLoggerFactory.Object,
                _mockRequestValidator.Object,
                _mockKeyVaultAccess.Object,
                _mockApiCaller.Object
            );
        }

        #region Helper methods
        private async Task<string> GetBodyAsString(HttpResponseData response)
        {
            response.Body.Position = 0;
            using var reader = new StreamReader(response.Body, Encoding.UTF8);
            return await reader.ReadToEndAsync();
        }
        #endregion

        [Fact]
        public async Task Run_ValidSignature_CallsApiAndReturnsOk()
        {
            // Arrange
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "test-body", "valid-signature", "valid-timestamp");

            _mockKeyVaultAccess.Setup(k => k.GetSecretAsync(It.IsAny<string>()))
                               .ReturnsAsync("fake-public-key");

            _mockRequestValidator.Setup(v => v.ConvertPublicKeyToECDSA(It.IsAny<string>()))
                                 .Returns(default(PublicKey));

            _mockRequestValidator.Setup(v => v.VerifySignature(It.IsAny<PublicKey>(), "test-body", "valid-signature", "valid-timestamp"))
                                 .Returns(true); // Valid signature response

            // Act
            var response = await _function.Run(req);

            // Assert
            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode); // Function always returns 200 on error
            Assert.Contains("Signature verification: True", text, StringComparison.OrdinalIgnoreCase); // Response body contains "Signature verification: True"
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI("test-body", It.IsAny<ILogger>()), Times.Once); // API caller (CallD365SendGridCustomAPI) is invoked once
        }

        [Fact]
        public async Task Run_InvalidSignature_DoesNotCallApi()
        {
            // Arrange
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "test-body", "invalid-signature", "valid-timestamp");

            _mockKeyVaultAccess.Setup(k => k.GetSecretAsync(It.IsAny<string>()))
                               .ReturnsAsync("fake-public-key");

            _mockRequestValidator.Setup(v => v.ConvertPublicKeyToECDSA(It.IsAny<string>()))
                                 .Returns(default(PublicKey));

            _mockRequestValidator.Setup(v => v.VerifySignature(It.IsAny<PublicKey>(), "test-body", "invalid-signature", "valid-timestamp"))
                                 .Returns(false); // Invalid signature response

            // Act
            var response = await _function.Run(req);

            // Assert
            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode); // Function always returns 200 on error
            Assert.Contains("Signature verification: False", text, StringComparison.OrdinalIgnoreCase); // Response body contains "Signature verification: False"
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI(It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never); // API caller is never invoked
        }

        [Fact]
        public async Task Run_MissingHeaders_ReturnsError()
        {
            // Arrange
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "test-body", null, null); // No signature and timestamp headers

            // Act
            var response = await _function.Run(req);

            // Assert
            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode); // Function always returns 200 on error
            Assert.Contains("Internal server error", text, StringComparison.OrdinalIgnoreCase); // Response body contains "Internal server error"
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI(It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never); // API caller is never invoked
        }

        [Fact]
        public async Task Run_EmptyBody_ReturnsError()
        {
            // Arrange
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "", "valid-signature", "valid-timestamp"); // No body

            // Act
            var response = await _function.Run(req);
            
            // Assert
            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Contains("Internal server error", text, StringComparison.OrdinalIgnoreCase);
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI(It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never);
        }

        [Fact]
        public async Task Run_NoPublicKey_ReturnsError()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "test-body", "valid-signature", "valid-timestamp");

            _mockKeyVaultAccess.Setup(k => k.GetSecretAsync(It.IsAny<string>()))
                               .ReturnsAsync((string?)null); // No public key

            var response = await _function.Run(req);

            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Contains("Internal server error", text, StringComparison.OrdinalIgnoreCase);
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI(It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never);
        }

        [Fact]
        public async Task Run_SignatureVerificationThrows_ReturnsError()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "test-body", "valid-signature", "valid-timestamp");

            _mockKeyVaultAccess.Setup(k => k.GetSecretAsync(It.IsAny<string>()))
                               .ReturnsAsync("fake-public-key");

            _mockRequestValidator.Setup(v => v.ConvertPublicKeyToECDSA(It.IsAny<string>()))
                                 .Throws(new Exception("Bad key")); // Exception during signature verification

            var response = await _function.Run(req);

            var text = await GetBodyAsString(response);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Contains("Internal server error", text, StringComparison.OrdinalIgnoreCase);
            _mockApiCaller.Verify(a => a.CallD365SendGridCustomAPI(It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never);
        }
    }
}
