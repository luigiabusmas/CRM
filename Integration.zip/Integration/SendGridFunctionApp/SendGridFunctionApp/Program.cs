using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SendGridFunctionApp.Helpers;
using SendGridFunctionApp.Interfaces;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices(services =>
    {
        services.AddSingleton<IRequestValidator, RequestValidator>();
        services.AddSingleton<IKeyVaultAccess, KeyVaultAccess>();
        services.AddSingleton<ICustomApiCaller, CustomApiCaller>();
    })
    .Build();

host.Run();
