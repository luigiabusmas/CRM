using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using SendGridFunctionApp.Helpers;
using SendGridFunctionApp.Interfaces;
using System.Net;
using System.Text;

public class VerifySignatureFunction
{
    private readonly ILogger _logger;
    private readonly IRequestValidator _requestValidator;
    private readonly IKeyVaultAccess _keyVaultAccess;
    private readonly ICustomApiCaller _apiCaller;

    public VerifySignatureFunction(ILoggerFactory loggerFactory,
                                   IRequestValidator requestValidator,
                                   IKeyVaultAccess keyVaultAccess,
                                   ICustomApiCaller apiCaller)
    {
        _logger = loggerFactory.CreateLogger<VerifySignatureFunction>();
        _requestValidator = requestValidator;
        _keyVaultAccess = keyVaultAccess;
        _apiCaller = apiCaller;
    }

    [Function("VerifySignature")]
    public async Task<HttpResponseData> Run(
           [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
    {
        try
        {
            // Read raw body
            string rawBody;
            using (var reader = new StreamReader(req.Body, Encoding.UTF8))
            {
                rawBody = await reader.ReadToEndAsync();
            }
            _logger.LogInformation($"RawBody: {rawBody}");

            if (string.IsNullOrEmpty(rawBody))
                throw new Exception("Missing request body");

            // Get headers
            var signature = req.Headers.TryGetValues(RequestValidator.SIGNATURE_HEADER, out var sigValues) ? sigValues.FirstOrDefault() : null;
            _logger.LogInformation($"{RequestValidator.SIGNATURE_HEADER}: {signature}");

            var timestamp = req.Headers.TryGetValues(RequestValidator.TIMESTAMP_HEADER, out var tsValues) ? tsValues.FirstOrDefault() : null;
            _logger.LogInformation($"{RequestValidator.TIMESTAMP_HEADER}: {timestamp}");

            if (string.IsNullOrEmpty(signature) || string.IsNullOrEmpty(timestamp))
                throw new Exception("Missing required headers");

            string? publicKeyString = await _keyVaultAccess.GetSecretAsync("sendgridverificationkey");
            if (string.IsNullOrEmpty(publicKeyString))
                throw new Exception("Missing verification key");

            var publicKey = _requestValidator.ConvertPublicKeyToECDSA(publicKeyString);

            // Verify signature
            bool isValid = _requestValidator.VerifySignature(publicKey, rawBody, signature, timestamp);
            _logger.LogInformation($"Signature verification: {isValid}");

            if (isValid)
            {
                // Call Custom API
                await _apiCaller.CallD365SendGridCustomAPI(rawBody, _logger);
            }

            var response = req.CreateResponse();
            response.StatusCode = HttpStatusCode.OK;
            await response.WriteStringAsync($"Signature verification: {isValid}");
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Internal server error: {ex.Message}");
            var errorResponse = req.CreateResponse();
            errorResponse.StatusCode = HttpStatusCode.OK;
            await errorResponse.WriteStringAsync($"Internal server error: {ex.Message}");
            return errorResponse;
        }
    }
}
