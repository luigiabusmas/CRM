﻿using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace SendGridFunctionApp.Interfaces
{
    public interface ICustomApiCaller
    {
        Task CallD365SendGridCustomAPI(string jsonString, ILogger _logger);
    }
}
