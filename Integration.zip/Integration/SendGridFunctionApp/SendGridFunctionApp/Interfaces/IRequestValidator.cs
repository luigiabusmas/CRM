﻿using EllipticCurve;

namespace SendGridFunctionApp.Interfaces
{
    public interface IRequestValidator
    {
        bool VerifySignature(PublicKey publicKey, string payload, string signature, string timestamp);
        PublicKey ConvertPublicKeyToECDSA(string publicKey);
    }
}
