﻿using System.Threading.Tasks;

namespace SendGridFunctionApp.Interfaces
{
    public interface IKeyVaultAccess
    {
        Task<string?> GetSecretAsync(string secretName);
    }
}
