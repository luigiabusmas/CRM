﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Channels;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Metadata;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Runtime.Remoting.Messaging;

namespace CirrusStripeAction
{
    public class Helper
    {
        public async Task<string> CallAzureFunctionAsync(string functionUrl, string jsonInput, ITracingService tracingService)
        {
            using (HttpClient client = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
                var content = new StringContent(jsonInput, Encoding.UTF8, "application/json");
                client.Timeout = TimeSpan.FromSeconds(120);  // Timeout is 120 seconds

                try
                {
                    tracingService.Trace($"Making HTTP POST request to: {functionUrl}");
                    tracingService.Trace($"Request body: {jsonInput}");

                    DateTime requestStartTime = DateTime.Now;
                    tracingService.Trace($"Request sent at: {requestStartTime}");

                    HttpResponseMessage response = await client.PostAsync(functionUrl, content);

                    DateTime requestEndTime = DateTime.Now;
                    tracingService.Trace($"Request completed at: {requestEndTime}");
                    tracingService.Trace($"Request duration: {(requestEndTime - requestStartTime).TotalSeconds} seconds");

                    if (!response.IsSuccessStatusCode)
                    {
                        string errorResponse = await response.Content.ReadAsStringAsync();
                        tracingService.Trace($"Azure Function call failed with status: {response.StatusCode}. Response: {errorResponse}");
                        throw new Exception($"Azure Function call failed with status {response.StatusCode}. Response: {errorResponse}");
                    }

                    string successfulResponse = await response.Content.ReadAsStringAsync();
                    tracingService.Trace($"Azure Function call succeeded with status: {response.StatusCode}. Response: {successfulResponse}");

                    return successfulResponse;
                }
                catch (Exception ex)
                {
                    tracingService.Trace($"Error calling Azure Function: {ex.Message}");
                    if (ex.InnerException != null)
                    {
                        tracingService.Trace($"Inner Exception: {ex.InnerException.Message}");
                        tracingService.Trace($"Inner Exception StackTrace: {ex.InnerException.StackTrace}");
                    }
                    tracingService.Trace($"Error StackTrace: {ex.StackTrace}");
                    throw;
                }
            }
        }

        public string GetAzureFunctionUrl(IOrganizationService service, ITracingService tracingService, string settingName)
        {
            // Query the rhs_appsettings entity to get the Azure Function URL by name
            var query = new QueryExpression("rhs_appsettings")
            {
                ColumnSet = new ColumnSet("rhs_value"),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                         new ConditionExpression("rhs_name", ConditionOperator.Equal, settingName)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var functionUrl = result.Entities.First().GetAttributeValue<string>("rhs_value");
                tracingService.Trace("Azure Function URL retrieved : " + functionUrl);
                return functionUrl;
            }

            tracingService.Trace("Azure Function URL not found for setting name: " + settingName);
            return null;
        }

        public string GetInputParameters(string name, IPluginExecutionContext context, ITracingService tracingService)
        {
            var jsonInput = new Dictionary<string, string>();

            if (TryGetParameter(context, name, out string value))
            {
                jsonInput[name] = value;
                tracingService.Trace(string.Format("{0}: {1}", name, value));
            }

            if (jsonInput.Count == 0)
            {
                tracingService.Trace("Required parameters are missing.");
                throw new Exception("Required parameters are missing.");
            }

            return value;
        }

        public bool TryGetParameter(IPluginExecutionContext context, string parameterName, out string value)
        {
            value = null;
            if (context.InputParameters.Contains(parameterName) && context.InputParameters[parameterName] is string parameterValue)
            {
                value = parameterValue;
                return true;
            }
            return false;
        }

        public Guid CreateIntegrationLog(IOrganizationService service, string jsonString, ITracingService tracingService)
        {
            Guid recordId = Guid.Empty;
            try
            {
                var newRecord = new Entity("rhs_integrationlog")
                {
                    ["rhs_name"] = "StripePaymentConfirmation",
                    ["rhs_integration_type"] = "Stripe",
                    ["rhs_payload"] = jsonString,
                    ["rhs_direction"] = new OptionSetValue(120000000),
                    ["rhs_integrationstatus"] = new OptionSetValue(120000000)
                };

                recordId = service.Create(newRecord);
                tracingService.Trace("Integration log created: " + recordId);
                return recordId;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in CreateIntegrationLog: {ex.Message}");
            }
        }

        public void UpdateIntegrationLog(IOrganizationService service, Guid recordId, string message, int status, string refId, ITracingService tracingService)
        {
            try
            {
                var updateRecord = new Entity("rhs_integrationlog", recordId)
                {
                    ["rhs_response"] = message,  // Use message for both success and error
                    ["rhs_integrationstatus"] = new OptionSetValue(status),  // Update status based on success or error
                    ["rhs_referenceid"] = refId
                };

                service.Update(updateRecord);
                tracingService.Trace("Integration log updated: " + message);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in UpdateIntegrationLog: {ex.Message}");
            }
        }

        public bool IntegrationLogExists(IOrganizationService service, string refId, ITracingService tracingService)
        {
            // Check if the integration log exists for the given request ID
            QueryExpression query = new QueryExpression("rhs_integrationlog")
            {
                ColumnSet = new ColumnSet("rhs_integrationlogid"),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("rhs_referenceid", ConditionOperator.Equal, refId)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var logId = result.Entities.First().GetAttributeValue<Guid>("rhs_integrationlogid");
                tracingService.Trace($"Integration log exists with GUID {logId} for rhs_referenceid {refId}");
                return true;
            }

            tracingService.Trace($"No integration log found for ID {refId}");
            return false; // Return false if not found
        }

        public Entity GetPaymentDetails(string refId, IOrganizationService service, ITracingService tracingService)
        {
            var fetchXml = $@"
                <fetch>
                  <entity name='rhs_payment'>
                    <attribute name='rhs_paymentid' />
                    <attribute name='rhs_paymenttype' />
                    <attribute name='rhs_transaction' />
                    <filter>
                      <condition attribute='rhs_paymentsid' operator='eq' value='{refId}' />
                    </filter>
                    <link-entity name='rhs_transaction' from='rhs_transactionid' to='rhs_transaction' alias='trans'>
                      <attribute name='rhs_donation' />
                      <attribute name='rhs_giftpackorder' />
                      <attribute name='rhs_membershipid' />
                      <attribute name='rhs_subscriptionid' />
                    </link-entity>
                  </entity>
                </fetch>";

            var fetchExpression = new FetchExpression(fetchXml);

            var result = service.RetrieveMultiple(fetchExpression);

            return result != null ? result.Entities[0] : throw new Exception($"Payment record not found: {refId}");
        }

        public Entity GetTransDetails(string refId, IOrganizationService service, ITracingService tracingService)
        {
            var fetchXml = $@"
                <fetch>
                  <entity name='rhs_transaction'>
                    <attribute name='rhs_donation' />
                    <attribute name='rhs_giftpackorder' />
                    <attribute name='rhs_membershipid' />
                    <attribute name='rhs_subscriptionid' />
                    <attribute name='rhs_transactionid' />
                    <attribute name='rhs_transactiontype' />
                    <filter>
                      <condition attribute='rhs_transacid' operator='eq' value='{refId}' />
                    </filter>
                  </entity>
                </fetch>";

            var fetchExpression = new FetchExpression(fetchXml);

            var result = service.RetrieveMultiple(fetchExpression);

            return result != null ? result.Entities[0] : throw new Exception($"Transaction record not found: {refId}");
        }

        public EntityCollection GetRelatedPayments(Guid refId, IOrganizationService service, ITracingService tracingService)
        {
            var fetchXml = $@"
                <fetch>
                  <entity name='rhs_payment'>
                    <attribute name='rhs_paymentid' />
                    <filter>
                      <condition attribute='rhs_transaction' operator='eq' value='{refId}' />
                    </filter>
                  </entity>
                </fetch>";

            var fetchExpression = new FetchExpression(fetchXml);

            var result = service.RetrieveMultiple(fetchExpression);

            if (result.Entities.Count == 0)
                tracingService.Trace($"No related payments");

            return result;
        }

        public EntityCollection GetRelatedGiftPacks(Guid refId, IOrganizationService service, ITracingService tracingService)
        {
            var fetchXml = $@"
                <fetch>
                  <entity name='rhs_giftpack'>
                    <attribute name='rhs_giftpackid' />
                    <filter>
                      <condition attribute='rhs_giftpackorder' operator='eq' value='{refId}' />
                    </filter>
                  </entity>
                </fetch>";

            var fetchExpression = new FetchExpression(fetchXml);

            var result = service.RetrieveMultiple(fetchExpression);

            if (result.Entities.Count == 0)
                tracingService.Trace($"No related gift packs");

            return result;
        }

        public void UpdatePaymentStatus(string transStatus, Guid transId, out string successMessage, out bool isSuccessPayment, IOrganizationService service, ITracingService tracingService)
        {
            var paymentStatus = 0;
            var paymentState = 0;
            var msg = "";

            try
            {
                switch (transStatus)
                {
                    case StripePaymentStatus.Succeeded:
                        paymentState = (int)StateCode.Inactive;
                        paymentStatus = (int)PaymentStatusCode.Paid;
                        isSuccessPayment = true;
                        break;

                    case StripePaymentStatus.Canceled:
                        paymentState = (int)StateCode.Inactive;
                        paymentStatus = (int)PaymentStatusCode.Cancelled;
                        isSuccessPayment = false;
                        break;

                    default:
                        paymentState = (int)StateCode.Active;
                        paymentStatus = (int)PaymentStatusCode.PendingPayment;
                        isSuccessPayment = false;
                        break;
                }

                var paymentsCol = GetRelatedPayments(transId, service, tracingService);
                tracingService.Trace($"Payments count: {paymentsCol.Entities.Count}");
                if (paymentsCol.Entities.Count > 0)
                {
                    foreach (var payments in paymentsCol.Entities)
                    {
                        //update payment status
                        Entity payment = new Entity(EntityName.Payment, payments.Id);
                        payment[FieldName.State] = new OptionSetValue(paymentState);
                        payment[FieldName.Status] = new OptionSetValue(paymentStatus);
                        service.Update(payment);

                        msg += $"Updated rhs_payment status: {payments.Id}";
                        tracingService.Trace($"Updated rhs_payment status: {payments.Id}");
                    }
                }
                successMessage = msg;
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Failed to update rhs_payment: {ex.Message}");
                throw new Exception($"Failed to update rhs_payment: {ex.Message}");
            }
        }

        public void UpdatedProductStatus(string transStatus, Entity transEntity, ref string successMessage, ref int paidStatus, ref int pendingStatus, bool isSuccessPayment, IOrganizationService service, ITracingService tracingService)
        {
            var prodName = "";
            Guid prodId = Guid.Empty;

            try
            {
                var prodType = transEntity.GetAttributeValue<OptionSetValue>("rhs_transactiontype");
                tracingService.Trace($"Product Type: {prodType.Value}");

                EntityReference prodEntityRef = null;
                switch ((ProductType)prodType.Value)
                {
                    case ProductType.Donation:
                        paidStatus = (int)ProductStatus.Paid;
                        pendingStatus = (int)ProductStatus.PendingPayment;
                        prodEntityRef = transEntity.GetAttributeValue<EntityReference>("rhs_donation");
                        break;

                    case ProductType.GiftPack:
                        paidStatus = (int)ProductStatus.GPOPurchased;
                        pendingStatus = (int)ProductStatus.Prospect;
                        prodEntityRef = transEntity.GetAttributeValue<EntityReference>("rhs_giftpackorder");
                        break;

                    case ProductType.Membership:
                        paidStatus = (int)ProductStatus.Paid;
                        pendingStatus = (int)ProductStatus.PendingPayment;
                        prodEntityRef = transEntity.GetAttributeValue<EntityReference>("rhs_membershipid");
                        break;

                    case ProductType.Subscription:
                        paidStatus = (int)ProductStatus.Paid;
                        pendingStatus = (int)ProductStatus.PendingPayment;
                        prodEntityRef = transEntity.GetAttributeValue<EntityReference>("rhs_subscriptionid");
                        break;
                }

                if (prodEntityRef == null)
                    throw new Exception("No related product found");

                prodId = prodEntityRef.Id;
                prodName = prodEntityRef.LogicalName;
                tracingService.Trace($"Related product: {prodName}");

                //Update related product record
                Entity record = new Entity(prodName, prodId);
                record[FieldName.State] = new OptionSetValue((int)StateCode.Active);
                record[FieldName.Status] = new OptionSetValue(transStatus == StripePaymentStatus.Succeeded ? paidStatus : pendingStatus);

                if (prodName == EntityName.RHSMembership || prodName == EntityName.Donation)
                {
                    record[FieldName.PaymentReceived] = isSuccessPayment;
                    record[FieldName.IsSubmitPayment] = isSuccessPayment;
                }
                else if (prodName == EntityName.GiftPackOrder || prodName == EntityName.Subscription)
                {
                    record[FieldName.IsPaymentSubmitted] = isSuccessPayment;
                    record[FieldName.IsPaymentReceived] = isSuccessPayment;
                }
                service.Update(record);

                successMessage += $" Updated {prodName} status: {prodId}";
                tracingService.Trace($"Updated {prodName} status: {prodId}");

                //for gift pack order - change the related gift packs status
                if (prodName == EntityName.GiftPackOrder)
                {
                    UpdateRelatedGiftPacks(paidStatus, pendingStatus, isSuccessPayment, transStatus, prodName, prodId, service, tracingService);
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Failed to update {prodName}: {prodId} : {ex.Message}");
                throw new Exception($"Failed to update {prodName}: {prodId} : {ex.Message}");
            }
        }

        public void UpdateRelatedGiftPacks(int paidStatus, int pendingStatus, bool isSuccessPayment, string transStatus, string prodName, Guid prodId, IOrganizationService service, ITracingService tracingService)
        {
            try
            {
                var giftpacks = GetRelatedGiftPacks(prodId, service, tracingService);

                if (giftpacks.Entities.Count > 0)
                {
                    tracingService.Trace($"Gift Packs count: {giftpacks.Entities.Count}");

                    foreach (var giftpack in giftpacks.Entities)
                    {
                        Entity relatedGiftPack = new Entity(giftpack.LogicalName, giftpack.Id);
                        relatedGiftPack[FieldName.State] = new OptionSetValue((int)StateCode.Active);
                        relatedGiftPack[FieldName.Status] = new OptionSetValue(transStatus == StripePaymentStatus.Succeeded ? (int)ProductStatus.Purchased : pendingStatus);
                        relatedGiftPack[FieldName.IsPaymentSubmitted] = isSuccessPayment;
                        relatedGiftPack[FieldName.IsPaymentReceived] = isSuccessPayment;
                        service.Update(relatedGiftPack);
                        tracingService.Trace($"Updated {giftpack.LogicalName} status: {giftpack.Id}");
                    }
                }
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Failed to update related rhs_giftpack: {ex.Message}");
                throw new Exception($"Failed to update related rhs_giftpack: {ex.Message}");
            }
        }

        public void UpdateTransactionStatus(EntityReference productRef, int paidStatus, int pendingStatus, bool isSuccessPayment, string transStatus, ref string successMessage, IOrganizationService service, ITracingService tracingService)
        {
            var prodName = "";
            Guid prodId = Guid.Empty;

            try
            {
                prodName = productRef.LogicalName;
                prodId = productRef.Id;

                //Update related product record
                Entity record = new Entity(productRef.LogicalName, productRef.Id);
                record[FieldName.State] = new OptionSetValue((int)StateCode.Active);
                record[FieldName.Status] = new OptionSetValue(transStatus == StripePaymentStatus.Succeeded ? paidStatus : pendingStatus);

                if (prodName == EntityName.RHSMembership || prodName == EntityName.Donation)
                {
                    record[FieldName.PaymentReceived] = isSuccessPayment;
                    record[FieldName.IsSubmitPayment] = isSuccessPayment;
                }
                else if (prodName == EntityName.GiftPackOrder || prodName == EntityName.Subscription)
                {
                    record[FieldName.IsPaymentSubmitted] = isSuccessPayment;
                    record[FieldName.IsPaymentReceived] = isSuccessPayment;
                }
                service.Update(record);

                successMessage += $" Updated {prodName} status: {prodId}";
                tracingService.Trace($"Updated {prodName} status: {prodId}");
            }
            catch (Exception ex)
            {
                tracingService.Trace($"Failed to update related rhs_giftpack: {ex.Message}");
                throw new Exception($"Failed to update related rhs_giftpack: {ex.Message}");
            }
        }
    }

}
