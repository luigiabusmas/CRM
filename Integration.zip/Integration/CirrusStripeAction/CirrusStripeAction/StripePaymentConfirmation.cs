﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;

namespace CirrusStripeAction
{
    public class StripePaymentConfirmation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Helper helper = new Helper();
            Guid integLogId = Guid.Empty;
            var successMessage = string.Empty;
            var refId = string.Empty;
            var transStatus = string.Empty;
            var paidStatus = 0;
            var pendingStatus = 0;
            var isSuccessPayment = false;

            try
            {
                var jsonInput = helper.GetInputParameters("rhs_stripepaymentevents", context, tracingService);

                if (jsonInput == null)
                    throw new Exception("Not a valid request");

                if (jsonInput != null)
                {
                    //create integ log
                    integLogId = helper.CreateIntegrationLog(service, jsonInput, tracingService);

                    var jsonObj = JsonConvert.DeserializeObject<StripeEventsModel>(jsonInput);

                    if (jsonObj == null)
                        throw new InvalidPluginExecutionException("Invalid JSON payload.");

                    //check trans id
                    if (string.IsNullOrEmpty(jsonObj.TransactionId))
                        throw new Exception($"Transaction Id not found");

                    refId = jsonObj.TransactionId;

                    //check payment status
                    if (string.IsNullOrEmpty(jsonObj.PaymentStatus))
                        throw new Exception($"Payment Status not found");

                    transStatus = jsonObj.PaymentStatus;

                    //check if its a duplicate event
                    bool isProcessed = helper.IntegrationLogExists(service, refId, tracingService);
                    if (isProcessed)
                        throw new Exception($"Duplicate event. Transaction is already processed: {refId}");

                    //get trans details (type and related product)
                    var transEntity = helper.GetTransDetails(refId, service, tracingService);
                    var transId = transEntity.GetAttributeValue<Guid>("rhs_transactionid");
                    tracingService.Trace($"Transaction Id: {transId}");

                    //update related payments status
                    helper.UpdatePaymentStatus(transStatus, transId, out successMessage, out isSuccessPayment, service, tracingService);

                    //check product type then update product status
                    helper.UpdatedProductStatus(transStatus, transEntity, ref successMessage, ref paidStatus, ref pendingStatus, isSuccessPayment, service, tracingService);

                    //update integ log
                    helper.UpdateIntegrationLog(service, integLogId, successMessage, 120000001, refId, tracingService);

                    //output
                    context.OutputParameters["rhs_stripepaymentresponse"] = JsonConvert.SerializeObject(new { status = "success", message = successMessage });
                }
            }
            catch (Exception ex)
            {
                // General exception handling
                string errorMessage = $"An error occurred: {ex.Message}";
                tracingService.Trace(errorMessage);

                helper.UpdateIntegrationLog(service, integLogId, errorMessage, 120000002, null, tracingService);
                context.OutputParameters["rhs_stripepaymentresponse"] = JsonConvert.SerializeObject(new { status = "failed", message = errorMessage });
            }
        }
    }
}

public class StripeEventsModel
{
    [JsonProperty("stripe_eventid")]
    public string StripeEventId { get; set; }

    [JsonProperty("rhs_paymentid")]
    public string PaymentId { get; set; }

    [JsonProperty("timestamp")]
    public DateTime Timestamp { get; set; }

    [JsonProperty("payment_status")]
    public string PaymentStatus { get; set; }

    [JsonProperty("rhs_transactionid")]
    public string TransactionId { get; set; }
}

public enum StateCode
{
    Active = 0,
    Inactive = 1
}

public enum PaymentStatusCode
{
    PendingPayment = 1,
    Paid = 2,
    Cancelled = 120000004
}

public enum ProductStatus
{
    Paid = 1,
    Purchased = 120000003,
    PendingPayment = 120000003,
    Prospect = 1,
    GPOPurchased = 120000001,
}

public enum ProductType
{
    Donation = 120000000,
    GiftPack = 120000001,
    Membership = 120000002,
    Subscription = 120000003
}

public static class EntityName
{
    public const string RHSMembership = "rhs_membership";
    public const string GiftPack = "rhs_giftpack";
    public const string GiftPackOrder = "rhs_giftpackorder";
    public const string Donation = "rhs_donation";
    public const string Subscription = "rhs_subscription";
    public const string Payment = "rhs_payment";
}

public static class FieldName
{
    public const string State = "statecode";
    public const string Status = "statuscode";
    public const string IsPaymentSubmitted = "rhs_ispaymentsubmitted";
    public const string IsPaymentReceived = "rhs_ispaymentreceived";
    public const string PaymentReceived = "rhs_paymentreceived";
    public const string IsSubmitPayment = "rhs_issubmitpayment";
}

public static class StripePaymentStatus
{
    public const string Succeeded = "succeeded";
    public const string Canceled = "canceled";
    public const string Failed = "failed";
}