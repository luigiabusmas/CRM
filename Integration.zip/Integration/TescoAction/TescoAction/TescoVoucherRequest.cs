﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace TescoAction
{
    public class TescoVoucherRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Helper helper = new Helper();
            Guid integLogId = Guid.Empty;

            try
            {
                var jsonInput = helper.GetInputParameters(context, tracingService);

                if (jsonInput != null)
                {
                    string jsonString = JsonConvert.SerializeObject(jsonInput);
                    tracingService.Trace("Consolidated JSON: " + jsonString);

                    //create request log
                    integLogId = helper.CreateIntegrationLog(service, jsonString, tracingService);
                    tracingService.Trace("Integration log created with ID: " + integLogId);


                    // Get Azure Function URL
                    string azureFunctionUrl = helper.GetAzureFunctionUrl(service, tracingService, "FATescoVoucherRequest");

                    if (!string.IsNullOrEmpty(azureFunctionUrl))
                    {
                        string response = helper.CallAzureFunctionAsync(azureFunctionUrl, jsonString, tracingService).Result;
                        tracingService.Trace("Response: " + response);

                        try
                        {
                            var responseJson = JsonConvert.DeserializeObject<Dictionary<string, string>>(response);
                            if (responseJson.TryGetValue("status", out string status) && status == "error")
                            {
                                string errorMessage = responseJson.TryGetValue("message", out string message) ? message : "Unknown error occurred.";
                                tracingService.Trace(errorMessage);
                                throw new Exception(errorMessage);
                            }
                            else
                            {
                                // If response does not indicate failure, return the original response
                                string successMessage = responseJson.TryGetValue("message", out string message) ? message : response;
                                tracingService.Trace(successMessage);

                                helper.UpdateIntegrationLog(service, integLogId, successMessage, 120000001, tracingService);
                                context.OutputParameters["Response"] = successMessage;
                            }
                        }
                        catch (JsonException jsonEx)
                        {
                            tracingService.Trace($"Failed to process Azure function response: {jsonEx.Message}");
                            throw new Exception($"Failed to process Azure function response: {jsonEx.Message}");
                        }

                    }
                    else
                    {
                        tracingService.Trace("Azure Function URL not found in app settings.");
                        throw new Exception("Azure Function URL not found in app settings.");
                    }
                }
                else
                {
                    tracingService.Trace("Not a valid request");
                    throw new Exception("Not a valid request");
                }
            }
            catch (Exception ex)
            {
                // General exception handling
                string errorMessage = $"An error occurred in TescoVoucherRequest:" + ex.Message;
                tracingService.Trace(errorMessage);

                helper.UpdateIntegrationLog(service, integLogId, errorMessage, 120000002, tracingService);
                context.OutputParameters["Response"] = JsonConvert.SerializeObject(new { status = "failed", message = errorMessage });
            }
        }
    }
}
