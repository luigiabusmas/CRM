﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TescoAction
{
    public class Helper
    {
        public async Task<string> CallAzureFunctionAsync(string functionUrl, string jsonInput, ITracingService tracingService)
        {
            using (HttpClient client = new HttpClient())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.ServerCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
                var content = new StringContent(jsonInput, Encoding.UTF8, "application/json");
                client.Timeout = TimeSpan.FromSeconds(120);  // Timeout is 120 seconds

                try
                {
                    tracingService.Trace($"Making HTTP POST request to: {functionUrl}");
                    tracingService.Trace($"Request body: {jsonInput}");

                    DateTime requestStartTime = DateTime.Now;
                    tracingService.Trace($"Request sent at: {requestStartTime}");

                    HttpResponseMessage response = await client.PostAsync(functionUrl, content);

                    DateTime requestEndTime = DateTime.Now;
                    tracingService.Trace($"Request completed at: {requestEndTime}");
                    tracingService.Trace($"Request duration: {(requestEndTime - requestStartTime).TotalSeconds} seconds");

                    if (!response.IsSuccessStatusCode)
                    {
                        string errorResponse = await response.Content.ReadAsStringAsync();
                        tracingService.Trace($"Azure Function call failed with status: {response.StatusCode}. Response: {errorResponse}");
                        throw new Exception($"Azure Function call failed with status {response.StatusCode}. Response: {errorResponse}");
                    }

                    string successfulResponse = await response.Content.ReadAsStringAsync();
                    tracingService.Trace($"Azure Function call succeeded with status: {response.StatusCode}. Response: {successfulResponse}");

                    return successfulResponse;
                }
                catch (Exception ex)
                {
                    tracingService.Trace($"Error calling Azure Function: {ex.Message}");
                    if (ex.InnerException != null)
                    {
                        tracingService.Trace($"Inner Exception: {ex.InnerException.Message}");
                        tracingService.Trace($"Inner Exception StackTrace: {ex.InnerException.StackTrace}");
                    }
                    tracingService.Trace($"Error StackTrace: {ex.StackTrace}");
                    throw;
                }
            }
        }

        public string GetAzureFunctionUrl(IOrganizationService service, ITracingService tracingService, string settingName)
        {
            // Query the rhs_appsettings entity to get the Azure Function URL by name
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_appsettings")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_value"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                         new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_name", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, settingName)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var functionUrl = result.Entities.First().GetAttributeValue<string>("rhs_value");
                tracingService.Trace("Azure Function URL retrieved : " + functionUrl);
                return functionUrl;
            }

            tracingService.Trace("Azure Function URL not found for setting name: " + settingName);
            return null;
        }

        public Dictionary<string, string> GetInputParameters(IPluginExecutionContext context, ITracingService tracingService)
        {
            var jsonInput = new Dictionary<string, string>();

            if (TryGetParameter(context, "RequestType", out string requestType))
            {
                jsonInput["RequestType"] = requestType;
                tracingService.Trace("RequestType: " + requestType);
            }

            if (TryGetParameter(context, "TokenCode", out string tokenCode))
            {
                jsonInput["TokenCode"] = tokenCode;
                tracingService.Trace("TokenCode: " + tokenCode);
            }

            if (jsonInput.Count <= 1)
            {
                tracingService.Trace("Required parameters are missing.");
                throw new Exception("Required parameters are missing.");
            }

            return jsonInput;
        }

        public bool TryGetParameter(IPluginExecutionContext context, string parameterName, out string value)
        {
            value = null;
            if (context.InputParameters.Contains(parameterName) && context.InputParameters[parameterName] is string parameterValue)
            {
                value = parameterValue;
                return true;
            }
            return false;
        }

        public Guid CreateIntegrationLog(IOrganizationService service, string jsonString, ITracingService tracingService)
        {
            Guid recordId = Guid.Empty;
            try
            {
                var newRecord = new Entity("rhs_integrationlog")
                {
                    ["rhs_name"] = "Voucher Request",
                    ["rhs_integration_type"] = "Tesco",
                    ["rhs_payload"] = jsonString,
                    ["rhs_direction"] = new OptionSetValue(120000000),
                    ["rhs_integrationstatus"] = new OptionSetValue(120000000)
                };

                return service.Create(newRecord);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in CreateIntegrationLog: {ex.Message}");
            }
        }

        public void UpdateIntegrationLog(IOrganizationService service, Guid recordId, string message, int status, ITracingService tracingService)
        {
            try
            {
                var updateRecord = new Entity("rhs_integrationlog", recordId)
                {
                    ["rhs_response"] = message,  // Use message for both success and error
                    ["rhs_integrationstatus"] = new OptionSetValue(status)  // Update status based on success or error
                };

                service.Update(updateRecord);
                tracingService.Trace("Integration log updated: " + message);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in UpdateIntegrationLog: {ex.Message}");
            }
        }

        public Guid IntegrationLogExists(IOrganizationService service, string requestId, ITracingService tracingService)
        {
            // Check if the integration log exists for the given request ID
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_integrationlog")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_integrationlogid"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                        new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_requestid", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, requestId)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var logId = result.Entities.First().GetAttributeValue<Guid>("rhs_integrationlogid");
                tracingService.Trace($"Integration log exists with ID {logId} for request ID {requestId}");
                return logId;
            }

            tracingService.Trace($"No integration log found for request ID {requestId}");
            return Guid.Empty; // Return empty GUID if not found
        }
    }
}
