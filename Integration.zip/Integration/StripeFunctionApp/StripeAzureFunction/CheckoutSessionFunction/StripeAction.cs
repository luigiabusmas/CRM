﻿using Stripe;
using Stripe.Checkout;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeAzureFunction
{
    public class StripeAction
    {
        string successUrl = Environment.GetEnvironmentVariable("POWERAPPS_PORTAL_SUCCESSURL");

        public string CreateCheckoutSession(CheckoutModel model, string StripeKey)
        {
             string requestenvironment = model.requestenvironment+ "";
            if (!string.IsNullOrEmpty(requestenvironment))
                    {
                             successUrl = Environment.GetEnvironmentVariable(model.requestenvironment + "");
                    }
            StripeConfiguration.ApiKey = StripeKey; 
            var options = new SessionCreateOptions
            {
                Customer = model.customerId,
                SuccessUrl = successUrl,
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            Currency = model.currency,
                            UnitAmount = model.unitAmountLong,
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = model.productName,
                            },
                        },
                        Quantity = model.quantityInt,
                    },
                },
                Mode = model.mode,
            };

            var service = new SessionService();
            var checkoutVal = service.Create(options);
            return checkoutVal.Url;
        }

        public string CreateCustomer(CustomerModel model, string StripeKey)
        {
            StripeConfiguration.ApiKey = StripeKey;
            var customerOptions = new CustomerCreateOptions
            {
                Name = model.name,
                Email = model.email
            };

            var customerService = new CustomerService();
            var customerResponse = customerService.Create(customerOptions);
            return customerResponse.Id;
        }

        public Session getSession(string sessionid, string StripeKey)
        {
            StripeConfiguration.ApiKey = StripeKey;
            var service = new Stripe.Checkout.SessionService();
            return service.Get(sessionid);
        }

        public async Task<string> ProcessRefund(string paymentintentId, string StripeKey)
        {

            try
            {
                StripeConfiguration.ApiKey = StripeKey;
                var refundOptions = new RefundCreateOptions
                {
                    PaymentIntent = paymentintentId
                };

                var refundService = new RefundService();
                Refund refund = await refundService.CreateAsync(refundOptions);

                return refund.Id;
            }
            catch (StripeException ex)
            {
                Console.WriteLine($"Stripe error: {ex.Message}");
                return null;
            }
        }
    }
}
