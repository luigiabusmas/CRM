using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace StripeAzureFunction
{
    public class StripeRefundFunction
    {
        private readonly ILogger<StripeRefundFunction> _logger;

        public StripeRefundFunction(ILogger<StripeRefundFunction> logger)
        {
            _logger = logger;
        }

        [Function("StripeRefundFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<dynamic>(requestBody);
                string paymentintentId = data?.paymentintentId;
             
                if (string.IsNullOrEmpty(paymentintentId))
                {
                    return new BadRequestObjectResult("Session ID is required.");
                }

                var keyVaultAccess = new KeyVaultAccess();
                //string secretName = Environment.GetEnvironmentVariable("secretName");
                string stripeKey = await keyVaultAccess.GetSecretAsync("StripeOnlineApiSecretKey");

                if (stripeKey == null)
                {
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                // Retrieve session using the StripeAction class
                StripeAction stripeAction = new StripeAction();
                var refund = stripeAction.ProcessRefund(paymentintentId, stripeKey);

                if (refund != null)
                {
                    return new OkObjectResult(new
                    {
                        refundId = refund.Result,
                        status = "success"
                    });
                }
                else
                {
                    return new BadRequestObjectResult(new
                    {
                        message = "Failed to refund payment.",
                        status = "failed"
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving the sessionId.");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }

        }
    }
}
