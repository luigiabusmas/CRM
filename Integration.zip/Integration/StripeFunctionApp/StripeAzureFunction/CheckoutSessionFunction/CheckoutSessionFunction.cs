using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Stripe.Checkout;
using Stripe;
using Grpc.Core;

namespace StripeAzureFunction
{
    public class CheckoutSessionFunction
    {
        private readonly ILogger<CheckoutSessionFunction> _logger;

        public CheckoutSessionFunction(ILogger<CheckoutSessionFunction> logger)
        {
            _logger = logger;
        }

        [Function("CheckoutSessionFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequest req)
        {
            _logger.LogInformation("Stripe Checkout session creation started.");

            try
            {
                // Read the request body for customer and product details
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                CheckoutModel data = JsonConvert.DeserializeObject<CheckoutModel>(requestBody);

                // Check if all required fields are provided
                if (data?.productName == null || data?.quantity == null || data?.unitAmount == null || data?.mode == null || data?.customerId == null || data?.currency == null)
                {
                    return new BadRequestObjectResult("Missing required fields: name, email, productName, quantity, or unitAmount.");
                }

                var keyVaultAccess = new KeyVaultAccess();
                //string secretName = Environment.GetEnvironmentVariable("secretName");
                string stripeKey = await keyVaultAccess.GetSecretAsync("StripeOnlineApiSecretKey");

                if (stripeKey == null)
                {
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                StripeAction stripeAction = new StripeAction();
                string stripeCheckoutUrl = stripeAction.CreateCheckoutSession(data, stripeKey);

                return new OkObjectResult(new
                {
                    checkoutUrl = stripeCheckoutUrl,
                    status = "success"
                });
            }
            catch (StripeException stripeEx)
            {
                _logger.LogError(stripeEx, "Stripe error occurred while creating the checkout session.");
                return new ObjectResult(new
                {
                    status = "error",
                    message = $"Stripe error: {stripeEx.Message}"
                })
                {
                    StatusCode = 500
                };
            }
        }
    }
}