﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeAzureFunction
{
    public class KeyVaultAccess
    {
        private readonly SecretClient _secretClient;
        string tenantId = Environment.GetEnvironmentVariable("DATAVERSE_TENANT_ID");
        string clientId = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_ID");
        string clientSecret = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_SECRET");


        public KeyVaultAccess()
        {
            var keyVaultUrl = Environment.GetEnvironmentVariable("KEYVAULT_URL");


            var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            _secretClient = new SecretClient(new Uri(keyVaultUrl), clientSecretCredential);
        }

        public async Task<string> GetSecretAsync(string secretName)
        {
            try
            {
                KeyVaultSecret secret = await _secretClient.GetSecretAsync(secretName);
                return secret.Value;
            }
            catch (Azure.RequestFailedException ex)
            {
                Console.WriteLine($"Error retrieving secret: {ex.Message}");
                return null;
            }
        }
    }
}