using Grpc.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Stripe;

namespace StripeAzureFunction
{
    public class CustomerCreationFunction
    {
        private readonly ILogger<CustomerCreationFunction> _logger;

        public CustomerCreationFunction(ILogger<CustomerCreationFunction> logger)
        {
            _logger = logger;
        }

        [Function("CustomerCreationFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            _logger.LogInformation("Stripe customer creation started.");

            try
            {
                // Read the request body for customer details
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                CustomerModel data = JsonConvert.DeserializeObject<CustomerModel>(requestBody);

                if (data?.name == null)
                {
                    return new BadRequestObjectResult("Missing required fields: name.");
                }

                var keyVaultAccess = new KeyVaultAccess();
                //string secretName = Environment.GetEnvironmentVariable("secretName");
                string stripeKey = await keyVaultAccess.GetSecretAsync("StripeOnlineApiSecretKey");


                if (stripeKey == null)
                {
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                StripeAction stripeAction = new StripeAction();
                string stripeCustomerId = stripeAction.CreateCustomer(data, stripeKey);

                // Check if customer was created successfully
                if (!string.IsNullOrEmpty(stripeCustomerId))
                {
                    return new OkObjectResult(new
                    {
                        customerId = stripeCustomerId,
                        status = "success"
                    });
                }
                else
                {
                    return new BadRequestObjectResult(new
                    {
                        message = "Failed to create customer.",
                        status = "failed"
                    });
                }
            }
            catch (StripeException stripeEx)
            {
                //return specific error from stripe
                _logger.LogError(stripeEx, "Stripe error occurred while creating the customer.");
                return new ObjectResult(new
                {
                    status = "error",
                    message = $"Stripe error: {stripeEx.Message}"
                })
                {
                    StatusCode = 500
                
                };
            }
        }
    }
}