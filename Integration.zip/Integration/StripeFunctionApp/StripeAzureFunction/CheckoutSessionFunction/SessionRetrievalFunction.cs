using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Stripe;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace StripeAzureFunction
{
    public class SessionRetrievalFunction
    {
        private readonly ILogger<SessionRetrievalFunction> _logger;

        public SessionRetrievalFunction(ILogger<SessionRetrievalFunction> logger)
        {
            _logger = logger;
        }

        [Function("SessionRetrievalFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            _logger.LogInformation("Stripe session retrieval started.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<dynamic>(requestBody);
                string sessionid = data?.sessionid;

                if (string.IsNullOrEmpty(sessionid))
                {
                    return new BadRequestObjectResult("Session ID is required.");
                }

                var keyVaultAccess = new KeyVaultAccess();
                //string secretName = Environment.GetEnvironmentVariable("secretName");
                string stripeKey = await keyVaultAccess.GetSecretAsync("StripeOnlineApiSecretKey");

                if (stripeKey == null)
                {
                    return new StatusCodeResult(StatusCodes.Status500InternalServerError);
                }

                // Retrieve session using the StripeAction class
                StripeAction stripeAction = new StripeAction();
                var sessionId = stripeAction.getSession(sessionid, stripeKey);

                if (sessionId != null)
                {
                    return new OkObjectResult(sessionId);
                }
                else
                {
                    return new BadRequestObjectResult("Failed to retrieve sessionId.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving the sessionId.");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}