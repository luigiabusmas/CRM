﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeAzureFunction
{
    public class CheckoutModel
    {
        public string productName { get; set; }
        public string quantity { get; set; }
        public string unitAmount { get; set; }
        public string mode { get; set; }
        public string customerId { get; set; }
        public string currency { get; set; }
         public string? requestenvironment { get; set; }

        public int quantityInt => int.Parse(quantity);
        public long unitAmountLong => (long)(double.Parse(unitAmount) * 100);  // Assuming cents
    }
}
