﻿using CirrusStripeFunctionApp.Interfaces;
using CirrusStripeFunctionApp.Services;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using Stripe;
using System.Net;
using System.Text;

namespace CirrusStripeFunctionApp.Tests
{
    public class StripeWebhookServiceTests
    {
        #region HttpRequestData
        public class FakeHttpRequestData : HttpRequestData
        {
            public FakeHttpRequestData(FunctionContext context, string body, string? signature)
                : base(context)
            {
                Body = new MemoryStream(Encoding.UTF8.GetBytes(body));
                Headers = new HttpHeadersCollection();

                if (!string.IsNullOrEmpty(signature))
                    Headers.Add("Stripe-Signature", signature);
            }

            public override Stream Body { get; }

            public override HttpHeadersCollection Headers { get; }

            public override IReadOnlyCollection<IHttpCookie> Cookies => Array.Empty<IHttpCookie>();

            public override Uri Url => new Uri("http://localhost");

            public override IEnumerable<System.Security.Claims.ClaimsIdentity> Identities
                => Enumerable.Empty<System.Security.Claims.ClaimsIdentity>();

            public override string Method => "POST";

            public override HttpResponseData CreateResponse()
                => new FakeHttpResponseData(FunctionContext);
        }
        #endregion

        #region HttpResponseData
        public class FakeHttpResponseData : HttpResponseData
        {
            public FakeHttpResponseData(FunctionContext context) : base(context)
            {
                Body = new MemoryStream();
                Headers = new HttpHeadersCollection();
            }

            public override HttpStatusCode StatusCode { get; set; }

            public override HttpHeadersCollection Headers { get; set; }

            public override Stream Body { get; set; }

            public override HttpCookies Cookies { get; } = null!;
        }
        #endregion

        private readonly Mock<IKeyVaultAccess> _mockKeyVault;
        private readonly Mock<IApiCaller> _mockApiCaller;
        private readonly Mock<IStripeEventUtility> _mockStripeEventUtility;
        private readonly Mock<ILogger<StripeWebhookService>> _mockLogger;
        private readonly StripeWebhookService _service;
        private readonly Mock<IDelayProvider> _mockDelayProvider;

        public StripeWebhookServiceTests()
        {
            _mockKeyVault = new Mock<IKeyVaultAccess>();
            _mockApiCaller = new Mock<IApiCaller>();
            _mockStripeEventUtility = new Mock<IStripeEventUtility>();
            _mockLogger = new Mock<ILogger<StripeWebhookService>>();
            _mockDelayProvider = new Mock<IDelayProvider>();

            _service = new StripeWebhookService(
                _mockLogger.Object,
                _mockKeyVault.Object,
                _mockApiCaller.Object,
                _mockStripeEventUtility.Object,
                _mockDelayProvider.Object
            );
        }

        [Fact]
        public async Task ProcessWebhookAsync_ShouldReturn500_WhenSecretsMissing()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "{}", "valid-signature");

            _mockKeyVault.Setup(k => k.GetSecretAsync("StripePhoneApiSecretKey")).ReturnsAsync((string?)null);
            _mockKeyVault.Setup(k => k.GetSecretAsync("StripePhoneWebhookSecret")).ReturnsAsync((string?)null);

            var result = await _service.ProcessStripeEventAsync(req);

            Assert.Equal(HttpStatusCode.InternalServerError, result.status);
            Assert.Equal("Missing required configuration.", result.message);
        }

        [Fact]
        public async Task ProcessWebhookAsync_ShouldReturn400_WhenSignatureHeaderMissing()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "{}", null);

            _mockKeyVault.Setup(k => k.GetSecretAsync(It.IsAny<string>())).ReturnsAsync("secret");

            var result = await _service.ProcessStripeEventAsync(req);

            Assert.Equal(HttpStatusCode.BadRequest, result.status);
            Assert.Equal("Missing Stripe-Signature header.", result.message);
        }

        [Fact]
        public async Task ProcessWebhookAsync_ShouldReturn400_WhenSignatureVerificationFails()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "{}", "invalid-signature");

            _mockKeyVault.Setup(k => k.GetSecretAsync(It.IsAny<string>())).ReturnsAsync("secret");
            _mockStripeEventUtility
                .Setup(s => s.ConstructEvent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new StripeException("Invalid signature"));

            var result = await _service.ProcessStripeEventAsync(req);

            Assert.Equal(HttpStatusCode.BadRequest, result.status);
            Assert.Equal("Invalid Stripe signature.", result.message);
        }

        [Fact]
        public async Task ProcessWebhookAsync_ShouldReturn200_WhenUnhandledEventType()
        {
            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, "{}", "valid-signature");

            _mockKeyVault.Setup(k => k.GetSecretAsync(It.IsAny<string>())).ReturnsAsync("secret");

            var mockCustomer = new Customer { Id = "cus_789" };

            var mockEvent = new Event
            {
                Id = "evt_123",
                Type = "customer.created",
                Data = new EventData
                {
                    Object = mockCustomer
                }
            };

            _mockStripeEventUtility
                .Setup(s => s.ConstructEvent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockEvent);

            var result = await _service.ProcessStripeEventAsync(req);

            Assert.Equal(HttpStatusCode.OK, result.status);
            Assert.Equal("Received", result.message);

            // Should NOT call D365 API
            _mockApiCaller.Verify(a => a.CallD365CustomAPI(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<ILogger>()), Times.Never);
        }

        [Fact]
        public async Task ProcessWebhookAsync_ShouldCallD365_WhenPaymentIntentSuccess()
        {

            // Arrange
            var stripeEvent = new Event
            {
                Id = "evt_456",
                Type = EventTypes.PaymentIntentSucceeded,
                Data = new EventData
                {
                    Object = new PaymentIntent
                    {
                        Id = "pi_456",
                        Status = "succeeded"
                    }
                }
            };

            var jsonBody = JsonConvert.SerializeObject(stripeEvent);
            var bodyStream = new MemoryStream(Encoding.UTF8.GetBytes(jsonBody));

            var context = new Mock<FunctionContext>();
            var req = new FakeHttpRequestData(context.Object, jsonBody, "valid-signature");

            _mockKeyVault.Setup(k => k.GetSecretAsync("StripePhoneApiSecretKey"))
                .ReturnsAsync("sk_test_123");
            _mockKeyVault.Setup(k => k.GetSecretAsync("StripePhoneWebhookSecret"))
                .ReturnsAsync("whsec_test_123");

            _mockStripeEventUtility
                .Setup(s => s.ConstructEvent(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(stripeEvent);


            // Act
            var (status, message) = await _service.ProcessStripeEventAsync(req);

            // Assert
            Assert.Equal(HttpStatusCode.OK, status);
            Assert.Equal("Received", message);

            _mockApiCaller.Verify(a =>
                a.CallD365CustomAPI(
                    "rhs_stripepaymentconfirmation",
                    It.Is<string>(json => json.Contains("\"payment_status\": \"succeeded\"")),
                    It.IsAny<ILogger>()),
                Times.Once);
        }

    }
}