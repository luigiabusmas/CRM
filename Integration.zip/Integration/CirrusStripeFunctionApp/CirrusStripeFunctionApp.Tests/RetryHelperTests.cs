﻿using CirrusStripeFunctionApp.Helper;
using CirrusStripeFunctionApp.Interfaces;
using Moq;
using Xunit;
using Microsoft.Extensions.Logging;

namespace CirrusStripeFunctionApp.Tests
{
    public class RetryHelperTests
    {
        private readonly Mock<IDelayProvider> _delayProvider = new();
        private readonly Mock<ILogger> _logger = new();

        [Fact]
        public async Task Retries_Action_Three_Times_Then_Succeeds()
        {
            int callCount = 0;

            // Mock delay to skip actual waiting
            _delayProvider.Setup(d => d.Delay(It.IsAny<int>()))
                          .Returns(Task.CompletedTask);

            Func<Task> failingThenSucceedingAction = () =>
            {
                callCount++;
                if (callCount < 3)
                    throw new Exception("Fail");

                return Task.CompletedTask; // success at 3rd call
            };

            await RetryHelper.ExecuteWithExponentialBackoffAsync(
                failingThenSucceedingAction,
                _logger.Object,
                _delayProvider.Object,
                maxRetries: 5
            );

            Assert.Equal(3, callCount);
        }

        [Fact]
        public async Task Throws_After_Max_Retries()
        {
            int callCount = 0;

            _delayProvider.Setup(d => d.Delay(It.IsAny<int>()))
                          .Returns(Task.CompletedTask);

            Func<Task> alwaysFailingAction = () =>
            {
                callCount++;
                throw new Exception("Always fail");
            };

            await Assert.ThrowsAsync<Exception>(async () =>
                await RetryHelper.ExecuteWithExponentialBackoffAsync(
                    alwaysFailingAction,
                    _logger.Object,
                    _delayProvider.Object,
                    maxRetries: 3
                )
            );

            Assert.Equal(4, callCount);
            // 3 retries + 1 initial attempt
        }

        [Fact]
        public async Task No_Retry_When_Action_Succeeds_Immediately()
        {
            int callCount = 0;

            Func<Task> action = () =>
            {
                callCount++;
                return Task.CompletedTask;
            };

            await RetryHelper.ExecuteWithExponentialBackoffAsync(
                action,
                _logger.Object,
                _delayProvider.Object
            );

            Assert.Equal(1, callCount);
        }
    }
}
