﻿using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace CirrusStripeFunctionApp.Interfaces
{
    public interface IApiCaller
    {
        Task CallD365CustomAPI(string customApiName, string jsonString, ILogger _logger);
    }
}
