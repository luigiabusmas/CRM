﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CirrusStripeFunctionApp.Interfaces
{
    public interface IDelayProvider
    {
        Task Delay(int milliseconds);
    }

}
