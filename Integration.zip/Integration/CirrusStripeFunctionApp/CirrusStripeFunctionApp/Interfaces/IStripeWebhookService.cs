﻿using Microsoft.Azure.Functions.Worker.Http;
using System.Net;

namespace CirrusStripeFunctionApp.Interfaces
{
    public interface IStripeWebhookService
    {
        Task<(HttpStatusCode status, string message)> ProcessStripeEventAsync(HttpRequestData req);
    }
}
