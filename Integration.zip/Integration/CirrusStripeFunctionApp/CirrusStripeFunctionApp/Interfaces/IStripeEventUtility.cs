﻿using Stripe;

namespace CirrusStripeFunctionApp.Interfaces
{
    public interface IStripeEventUtility
    {
        Event ConstructEvent(string json, string signature, string secret);
    }
}
