﻿using System.Threading.Tasks;

namespace CirrusStripeFunctionApp.Interfaces
{
    public interface IKeyVaultAccess
    {
        Task<string?> GetSecretAsync(string secretName);
    }
}
