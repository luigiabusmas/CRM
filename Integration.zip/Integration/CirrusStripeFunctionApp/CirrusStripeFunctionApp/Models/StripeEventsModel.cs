﻿using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace CirrusStripeFunctionApp.Models
{
    [ExcludeFromCodeCoverage]
    public class StripeEventsModel
    {
        [JsonProperty("stripe_eventid")]
        public string StripeEventId { get; set; }

        [JsonProperty("rhs_paymentid")]
        public string PaymentId { get; set; }

        [JsonProperty("timestamp")]
        public DateTime Timestamp { get; set; }

        [JsonProperty("payment_status")]
        public string PaymentStatus { get; set; }

        [JsonProperty("rhs_transactionid")]
        public string TransactionId { get; set; }
    }
}
