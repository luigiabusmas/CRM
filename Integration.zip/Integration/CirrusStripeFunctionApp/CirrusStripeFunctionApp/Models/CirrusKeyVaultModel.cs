﻿using System.Diagnostics.CodeAnalysis;

namespace CirrusStripeFunctionApp.Models
{
    [ExcludeFromCodeCoverage]
    public class CirrusKeyVaultModel
    {
        public string CirrusPCIBaseUrlKey { get; set; }
        public string CirrusPwdKey { get; set; }
    }
}
