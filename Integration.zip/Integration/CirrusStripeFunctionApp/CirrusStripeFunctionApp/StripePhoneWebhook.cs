﻿using CirrusStripeFunctionApp.Interfaces;
using CirrusStripeFunctionApp.Models;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;


public class StripePhoneWebhook
{
    private readonly ILogger _logger;
    private readonly IKeyVaultAccess _keyVaultAccess;
    private readonly IStripeWebhookService _stripeService;

    public StripePhoneWebhook(ILoggerFactory loggerFactory, IKeyVaultAccess keyVaultAccess, IStripeWebhookService stripeService)
    {
        _logger = loggerFactory.CreateLogger<StripePhoneWebhook>();
        _stripeService = stripeService;
        _keyVaultAccess = keyVaultAccess;
    }

    [Function("StripePhoneWebhook")]
    public async Task<HttpResponseData> RunStripePhoneWebhook(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
    {
        try
        {
            _logger.LogInformation("StripePhoneWebhook triggered");

            var result = await _stripeService.ProcessStripeEventAsync(req);

            var response = req.CreateResponse(result.status);
            await response.WriteStringAsync(result.message);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Internal server error.");
            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync($"Internal server error: {ex.Message}");
            return errorResponse;
        }
    }

    [Function("CirrusKeyVault")]
    public async Task<HttpResponseData> RunCirrusKeyVault(
        [HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
    {
        try
        {
            _logger.LogInformation("CirrusKeyVault triggered");

            string? cirrusPCIBaseUrlKeySecret = await _keyVaultAccess.GetSecretAsync("CirrusPCIBaseUrl");
            string? cirrusPwdKeySecret = await _keyVaultAccess.GetSecretAsync("CirrusPwd");

            if (string.IsNullOrEmpty(cirrusPwdKeySecret) ||
                string.IsNullOrEmpty(cirrusPCIBaseUrlKeySecret))
            {
                _logger.LogWarning("One or more required secrets are missing from Key Vault.");
                var missingResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                await missingResponse.WriteStringAsync("Missing one or more Key Vault secrets.");
                return missingResponse;
            }

            var cirrusKeyVaultEvents = new CirrusKeyVaultModel
            {
                CirrusPwdKey = cirrusPwdKeySecret,
                CirrusPCIBaseUrlKey = cirrusPCIBaseUrlKeySecret
            };

            var cirrusEventsString = JsonConvert.SerializeObject(cirrusKeyVaultEvents);

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteStringAsync(cirrusEventsString);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Internal server error while accessing Key Vault.");

            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync($"Internal server error: {ex.Message}");
            return errorResponse;
        }
    }

}