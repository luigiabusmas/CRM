﻿using CirrusStripeFunctionApp.Interfaces;
using CirrusStripeFunctionApp.Services;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;

namespace CirrusStripeFunctionApp.Helper
{
    [ExcludeFromCodeCoverage]
    public static class RetryHelper
    {
        public static async Task ExecuteWithExponentialBackoffAsync(
            Func<Task> action,
            ILogger logger,
            IDelayProvider? delayProvider = null,
            int maxRetries = 5,
            int baseDelayMilliseconds = 500)
        {
            delayProvider ??= new DelayProvider(); // fallback to real delay

            int attempt = 0;

            while (true)
            {
                try
                {
                    await action();
                    return;
                }
                catch (Exception ex)
                {
                    attempt++;

                    if (attempt > maxRetries)
                    {
                        logger.LogError(ex, $"Max retry attempts exceeded ({maxRetries}). Aborting.");
                        throw;
                    }

                    int delay = (int)(baseDelayMilliseconds * Math.Pow(2, attempt));
                    delay += Random.Shared.Next(0, 250);

                    logger.LogWarning(ex, $"Retry {attempt} in {delay}ms");
                    await delayProvider.Delay(delay);
                }
            }
        }
    }

}
