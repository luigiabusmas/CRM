﻿using CirrusStripeFunctionApp.Helper;
using CirrusStripeFunctionApp.Interfaces;
using CirrusStripeFunctionApp.Models;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Stripe;
using System.Net;

namespace CirrusStripeFunctionApp.Services
{
    public class StripeWebhookService : IStripeWebhookService
    {
        private readonly ILogger<StripeWebhookService> _logger;
        private readonly IKeyVaultAccess _keyVaultAccess;
        private readonly IApiCaller _apiCaller;
        private readonly IStripeEventUtility _stripeUtility;
        private readonly IDelayProvider _delayProvider;

        public StripeWebhookService(
            ILogger<StripeWebhookService> logger,
            IKeyVaultAccess keyVaultAccess,
            IApiCaller apiCaller,
            IStripeEventUtility stripeUtility,
            IDelayProvider delayProvider)
        {
            _logger = logger;
            _keyVaultAccess = keyVaultAccess;
            _apiCaller = apiCaller;
            _stripeUtility = stripeUtility;
            _delayProvider = delayProvider;
        }

        public async Task<(HttpStatusCode status, string message)> ProcessStripeEventAsync(HttpRequestData req)
        {
            _logger.LogInformation("Processing Stripe event...");

            // Get KeyVault secrets
            string? stripeApiKey = await _keyVaultAccess.GetSecretAsync("StripePhoneApiSecretKey");
            string? webhookSecret = await _keyVaultAccess.GetSecretAsync("StripePhoneWebhookSecret");

            if (string.IsNullOrEmpty(stripeApiKey) || string.IsNullOrEmpty(webhookSecret))
            {
                _logger.LogError("Missing required Key Vault secrets.");
                return (HttpStatusCode.InternalServerError, "Missing required configuration.");
            }

            StripeConfiguration.ApiKey = stripeApiKey;
            const string customApiName = "rhs_stripepaymentconfirmation";

            var json = await new StreamReader(req.Body).ReadToEndAsync();
            _logger.LogInformation($"Received Stripe Event: {json}");

            if (!req.Headers.TryGetValues("Stripe-Signature", out var signatureHeaderValues))
            {
                _logger.LogWarning("Missing Stripe-Signature header.");
                return (HttpStatusCode.BadRequest, "Missing Stripe-Signature header.");
            }

            var signatureHeader = string.Join(",", signatureHeaderValues);
            _logger.LogInformation($"Signature Header: {signatureHeader}");

            var stripeEvent = VerifyStripeSignature(json, signatureHeader, webhookSecret);
            if (stripeEvent == null)
            {
                return (HttpStatusCode.BadRequest, "Invalid Stripe signature.");
            }

            await HandleStripeEventAsync(stripeEvent, customApiName);

            return (HttpStatusCode.OK, "Received");
        }

        private Event? VerifyStripeSignature(string json, string signatureHeader, string webhookSecret)
        {
            try
            {
                var stripeEvent = _stripeUtility.ConstructEvent(json, signatureHeader, webhookSecret);
                _logger.LogInformation("Stripe signature verification succeeded.");
                return stripeEvent;
            }
            catch (StripeException ex)
            {
                _logger.LogError($"Stripe signature verification failed: {ex.Message}");
                return null;
            }
        }

        private async Task HandleStripeEventAsync(Event stripeEvent, string customApiName)
        {
            PaymentIntent? paymentIntent = null;
            // Handle event types
            switch (stripeEvent.Type)
            {
                case EventTypes.PaymentIntentSucceeded:
                    paymentIntent = stripeEvent.Data.Object as PaymentIntent;
                    _logger.LogInformation($"Payment succeeded: {paymentIntent?.Id}");
                    break;

                case EventTypes.PaymentIntentPaymentFailed:
                    paymentIntent = stripeEvent.Data.Object as PaymentIntent;
                    _logger.LogWarning($"Payment failed: {paymentIntent?.Id}");
                    break;

                case EventTypes.PaymentIntentCanceled:
                    paymentIntent = stripeEvent.Data.Object as PaymentIntent;
                    _logger.LogWarning($"Payment canceled: {paymentIntent?.Id}");
                    break;

                default:
                    _logger.LogInformation($"Unhandled Stripe event type: {stripeEvent.Type}");
                    break;
            }

            if (paymentIntent == null)
                return;

            _logger.LogInformation($"Processing Event: {stripeEvent.Type}, PaymentIntent: {paymentIntent.Id}, Status: {paymentIntent.Status}");

            // Safely extract metadata values
            string? paymentId = (paymentIntent.Metadata != null && paymentIntent.Metadata.ContainsKey("payment.id")) ? paymentIntent.Metadata["payment.id"] : string.Empty;
            string? transId = (paymentIntent.Metadata != null && paymentIntent.Metadata.ContainsKey("transaction.id")) ? paymentIntent.Metadata["transaction.id"] : string.Empty;

            // Create event model
            var stripeEvents = new StripeEventsModel
            {
                StripeEventId = paymentIntent.Id,
                PaymentId = paymentId,
                PaymentStatus = paymentIntent.Status ?? string.Empty,
                TransactionId = transId,
                Timestamp = DateTime.UtcNow
            };

            var payload = JsonConvert.SerializeObject(stripeEvents, Formatting.Indented);

            _logger.LogInformation($"Calling D365 Custom API '{customApiName}' with payload: {payload}");

            await RetryHelper.ExecuteWithExponentialBackoffAsync(
                async () => await _apiCaller.CallD365CustomAPI(customApiName, payload, _logger),
                _logger
            );

        }
    }
}