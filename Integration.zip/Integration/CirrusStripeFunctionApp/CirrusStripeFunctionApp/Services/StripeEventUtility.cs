﻿using CirrusStripeFunctionApp.Interfaces;
using Stripe;
using System.Diagnostics.CodeAnalysis;

namespace CirrusStripeFunctionApp.Services
{
    [ExcludeFromCodeCoverage]
    public class StripeEventUtilityWrapper : IStripeEventUtility
    {
        public Event ConstructEvent(string json, string signature, string secret)
            => EventUtility.ConstructEvent(json, signature, secret);
    }
}