﻿using CirrusStripeFunctionApp.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CirrusStripeFunctionApp.Services
{
    [ExcludeFromCodeCoverage]
    public class DelayProvider : IDelayProvider
    {
        public Task Delay(int milliseconds) => Task.Delay(milliseconds);
    }

}
