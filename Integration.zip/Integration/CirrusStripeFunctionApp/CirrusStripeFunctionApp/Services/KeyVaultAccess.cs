﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using CirrusStripeFunctionApp.Interfaces;
using System.Diagnostics.CodeAnalysis;

namespace CirrusStripeFunctionApp.Services
{
    [ExcludeFromCodeCoverage]
    public class KeyVaultAccess : IKeyVaultAccess
    {
        private readonly SecretClient _secretClient;
        string? keyVaultUrl = Environment.GetEnvironmentVariable("KEYVAULT_URL");
        string? tenantId = Environment.GetEnvironmentVariable("DATAVERSE_TENANT_ID");
        string? clientId = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_ID");
        string? clientSecret = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_SECRET");

        public KeyVaultAccess()
        {
            if (string.IsNullOrEmpty(tenantId) || string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret) || string.IsNullOrEmpty(keyVaultUrl))
                throw new Exception("Missing environment variables");

            var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            _secretClient = new SecretClient(new Uri(keyVaultUrl), clientSecretCredential);
        }

        public async Task<string?> GetSecretAsync(string name)
        {
            try
            {
                Console.WriteLine($"Retrieving secret, {name} from key vault.");
                KeyVaultSecret secret = await _secretClient.GetSecretAsync(name);
                return secret.Value;
            }
            catch (Azure.RequestFailedException ex)
            {
                Console.WriteLine($"Error retrieving {name}: {ex.Message}");
                return null;
            }
        }
    }
}