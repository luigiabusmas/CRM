﻿using CirrusStripeFunctionApp.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http.Headers;
using System.Text;

namespace CirrusStripeFunctionApp.Services
{
    [ExcludeFromCodeCoverage]
    public class ApiCaller : IApiCaller
    {
        private readonly HttpClient httpClient = new HttpClient();

        public async Task CallD365CustomAPI(string customApiName, string jsonString, ILogger _logger)
        {
            var tenantId = Environment.GetEnvironmentVariable("DATAVERSE_TENANT_ID");
            var clientId = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_ID");
            var clientSecret = Environment.GetEnvironmentVariable("DATAVERSE_CLIENT_SECRET");
            var dataverseUrl = Environment.GetEnvironmentVariable("DATAVERSE_URL");

            if (string.IsNullOrEmpty(tenantId) || string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret) || string.IsNullOrEmpty(dataverseUrl))
                throw new Exception("Missing environment variables");

            // Get Access Token
            var token = await GetAccessToken(tenantId, clientId, clientSecret, dataverseUrl);

            // Call Custom API
            var requestUrl = $"{dataverseUrl}/api/data/v9.2/{customApiName}";

            var request = new HttpRequestMessage(HttpMethod.Post, requestUrl);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Body for Custom API
            var body = new
            {
                rhs_stripepaymentevents = jsonString
            };

            request.Content = new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json");

            var response = await httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"Successful call to {customApiName} custom API");
            }
            else
            {
                _logger.LogError($"Error calling Custom API: {response.StatusCode}, {await response.Content.ReadAsStringAsync()}");
            }
        }

        private async Task<string?> GetAccessToken(string tenantId, string clientId, string clientSecret, string resource)
        {
            var tokenUrl = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";

            var body = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("client_id", clientId),
            new KeyValuePair<string, string>("scope", $"{resource}/.default"),
            new KeyValuePair<string, string>("client_secret", clientSecret),
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
        });

            var response = await httpClient.PostAsync(tokenUrl, body);
            var json = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Token request failed: {json}");

            dynamic result = JsonConvert.DeserializeObject(json);
            return result?.access_token;
        }
    }
}
