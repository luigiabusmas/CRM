using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using CirrusStripeFunctionApp.Interfaces;
using CirrusStripeFunctionApp.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices(services =>
    {
        services.AddSingleton<IKeyVaultAccess, KeyVaultAccess>();
        services.AddSingleton<IApiCaller, ApiCaller>();
        services.AddSingleton<IStripeEventUtility, StripeEventUtilityWrapper>();
        services.AddSingleton<IStripeWebhookService, StripeWebhookService>();
        services.AddSingleton<IDelayProvider, DelayProvider>();

    })
    .Build();

host.Run();
