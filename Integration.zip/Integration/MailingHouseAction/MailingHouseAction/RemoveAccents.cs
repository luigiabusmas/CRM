﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace MailingHouseAction
{
    public class RemoveAccents : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (context.MessageName == "rhs_MHRemoveAccents")
            {
                try
                {
                    // Retrieve input parameters
                    if (context.InputParameters.Contains("InputColumns") && context.InputParameters["InputColumns"] is string inputColumns)
                    {
                        tracingService.Trace($"InputColumns: {inputColumns}");
                        List<GiftPack> entries;

                        entries = JsonConvert.DeserializeObject<List<GiftPack>>(inputColumns);

                        // Apply accent removal
                        foreach (var entry in entries)
                        {
                            CleanAccents(entry);
                        }

                        // Convert cleaned list back to JSON string
                        string cleanedJson = JsonConvert.SerializeObject(entries);
                        tracingService.Trace($"OutputColumns: {cleanedJson}");

                        context.OutputParameters["OutputColumns"] = cleanedJson;
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException($"Error in MailingHouseAction.RemoveAccents:{ex.Message}");
                }
            }

        }

        public static string RemoveDiacritics(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            var normalized = input.Normalize(NormalizationForm.FormD);
            var chars = normalized
                .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                .ToArray();

            return new string(chars).Normalize(NormalizationForm.FormC);
        }

        public static void CleanAccents(GiftPack entry)
        {
            var props = typeof(GiftPack).GetProperties()
                .Where(p => p.PropertyType == typeof(string));

            foreach (var prop in props)
            {
                var value = prop.GetValue(entry) as string;
                if (!string.IsNullOrEmpty(value))
                {
                    prop.SetValue(entry, RemoveDiacritics(value));
                }
            }
        }
    }

    public class GiftPack
    {
        public string delContactNumber { get; set; }
        public string delLabelName { get; set; }
        public string delAddress1 { get; set; }
        public string delAddress2 { get; set; }
        public string delAddress3 { get; set; }
        public string delCity { get; set; }
        public string delCounty { get; set; }
        public string delPostcode { get; set; }
        public string delCountry { get; set; }
        public string giftMessage { get; set; }
        public string campaign { get; set; }

        public string payerLabelName { get; set; }
        public string payerSalutation { get; set; }
        public string payerAddress1 { get; set; }
        public string payerAddress2 { get; set; }
        public string payerAddress3 { get; set; }
        public string payerCity { get; set; }
        public string payerCounty { get; set; }
        public string payerPostcode { get; set; }
        public string payerCountry { get; set; }

        public string activationCode { get; set; }
        public string productDescription { get; set; }
    }

}
