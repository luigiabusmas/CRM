using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using TescoFunctionApp.Helper;
using TescoFunctionApp.Interface;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices(services =>
    {
        // Register KeyVaultAccess
        services.AddSingleton<IKeyVaultAccess, KeyVaultAccess>();

        // Register HttpClient for use in ApiCaller
        services.AddHttpClient();

        // Register ApiCaller
        services.AddSingleton<IApiCaller, ApiCaller>();

        // Add other services here if needed
    })
    .Build();

host.Run();
