using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Text;
using TescoFunctionApp.Interface;
using TescoFunctionApp.Model;
using static TescoFunctionApp.Model.TokenResponse;

namespace TescoFunctionApp;

public class TescoVoucherFunction
{
    private readonly ILogger<TescoVoucherFunction> _logger;
    private readonly IKeyVaultAccess _keyVaultAccess;
    private readonly IApiCaller _apiCaller;

    public TescoVoucherFunction(
        ILogger<TescoVoucherFunction> logger,
        IKeyVaultAccess keyVaultAccess,
        IApiCaller apiCaller)
    {
        _logger = logger;
        _keyVaultAccess = keyVaultAccess;
        _apiCaller = apiCaller;
    }

    [Function("VoucherRequest")]
    public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
    {
        try
        {
            string supplierCode = await _keyVaultAccess.GetSecretAsync("SupplierCode");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var requestData = JsonConvert.DeserializeObject<TescoVoucherRequest>(requestBody);
            _logger.LogInformation(requestBody);
            if (string.IsNullOrEmpty(requestData?.RequestType) || string.IsNullOrEmpty(requestData.TokenCode))
            {
                return new BadRequestObjectResult(new ErrorResponse{ Status = "error", Message = "RequestType and TokenCode are required." });
            }

            var tokenRequest = new TokenRequest(requestData.RequestType, requestData.TokenCode, supplierCode);
            var responseJson = await _apiCaller.CallTescoAPI(tokenRequest);
            _logger.LogInformation(responseJson);
            if (string.IsNullOrEmpty(responseJson))
            {
                return new BadRequestObjectResult(new ErrorResponse { Status = "error", Message = "No response from Tesco API." });
            }

            var tescoResponse = JsonConvert.DeserializeObject<TokenResponse>(responseJson);

            if (tescoResponse?.TokenDetailsList == null || !tescoResponse.TokenDetailsList.Any())
            {
                return new BadRequestObjectResult(new ErrorResponse { Status = "error", Message = "Token details missing in response." });
            }

            var voucherResponse = BuildResponse(tescoResponse);

            return new OkObjectResult(voucherResponse);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Voucher processing failed.");
            return new BadRequestObjectResult(new ErrorResponse { Status = "error", Message = ex.Message });
        }
    }


    private static TescoVoucherResponse BuildResponse(TokenResponse tokenResponse)
    {
        string tokenStatus = string.Empty;
        if (tokenResponse?.TokenDetailsList == null || !tokenResponse.TokenDetailsList.Any())
        {
            throw new Exception("Invalid response from API: Token details are missing.");
        }

        switch (tokenResponse.TokenDetailsList[0].ResponseCode)
        {
            case 0:
                tokenStatus = tokenResponse.TokenDetailsList[0].TokenStatus;
                break;
            case 112:
                if (tokenResponse.TokenDetailsList[0].TokenStatus == "Redeemed")
                    tokenStatus = "TokenAlreadyRedeemed";
                else if (tokenResponse.TokenDetailsList[0].TokenStatus == "Active")
                    tokenStatus = "Expired";
                else
                    tokenStatus = tokenResponse.TokenDetailsList[0].TokenStatus;
                break;
            case 104:
                tokenStatus = "NoTokenCodeInRequest";
                break;
            case 102:
                tokenStatus = "NotFound";
                break;
            case 114:
                tokenStatus = "TokenAlreadyInvoiced";
                break;
        }

        TescoVoucherResponse tescoVoucherResponse = new TescoVoucherResponse()
        {
            TokenCode = tokenResponse.TokenDetailsList[0].TokenCode,
            TokenStatus = tokenStatus,
            TokenExpiryDate = tokenResponse.TokenDetailsList[0].TokenExpiryDate,
            TokenValue = tokenResponse.TokenDetailsList[0].TokenValue,
            Lastname = tokenResponse.TokenDetailsList[0].Lastname,
            Postcode = tokenResponse.TokenDetailsList[0].Postcode
        };
        return tescoVoucherResponse;
    }
}