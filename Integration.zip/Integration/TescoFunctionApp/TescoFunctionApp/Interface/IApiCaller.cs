﻿using TescoFunctionApp.Helper;
using TescoFunctionApp.Model;

namespace TescoFunctionApp.Interface
{
    public interface IApiCaller
    {
        Task<string> CallTescoAPI(TokenRequest request);
    }

}