﻿namespace TescoFunctionApp.Interface
{
    public interface IKeyVaultAccess
    {
        Task<string> GetSecretAsync(string secretName);
    }
}