﻿namespace TescoFunctionApp.Interfaces
{
    public interface IKeyVaultAccess
    {
        Task<string?> GetSecretAsync(string secretName);
    }
}
