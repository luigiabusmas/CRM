﻿using Azure;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using TescoFunctionApp.Interface;

namespace TescoFunctionApp.Helper
{
    [ExcludeFromCodeCoverage]
    public class KeyVaultAccess : IKeyVaultAccess
    {
        private readonly SecretClient _secretClient;
        private readonly ILogger<KeyVaultAccess> _logger;

        public KeyVaultAccess(ILogger<KeyVaultAccess> logger)
        {
            _logger = logger;

            string keyVaultUrl = Environment.GetEnvironmentVariable("KEYVAULT_URL");
            string tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
            string clientId = Environment.GetEnvironmentVariable("CLIENT_ID");
            string clientSecret = Environment.GetEnvironmentVariable("CLIENT_SECRET");

            if (string.IsNullOrEmpty(keyVaultUrl) || string.IsNullOrEmpty(tenantId) ||
                string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret))
            {
                throw new InvalidOperationException("Missing Key Vault configuration in environment variables.");
            }

            var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
            _secretClient = new SecretClient(new Uri(keyVaultUrl), credential);
        }

        public async Task<string> GetSecretAsync(string name)
        {
            try
            {
                _logger.LogInformation("Retrieving secret {SecretName} from Key Vault.", name);
                KeyVaultSecret secret = await _secretClient.GetSecretAsync(name);
                return secret.Value;
            }
            catch (RequestFailedException ex)
            {
                _logger.LogError(ex, "Failed to retrieve secret {SecretName}", name);
                throw new InvalidOperationException($"Could not retrieve secret: {name}", ex);
            }

        }
    }
}
