﻿using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TescoFunctionApp.Interface;
using TescoFunctionApp.Model;

namespace TescoFunctionApp.Helper
{
    [ExcludeFromCodeCoverage]
    public class ApiCaller : IApiCaller
    {
        private readonly IKeyVaultAccess _keyVaultAccess;
        private readonly HttpClient _httpClient;

        public ApiCaller(IKeyVaultAccess keyVaultAccess, HttpClient httpClient)
        {
            _keyVaultAccess = keyVaultAccess;
            _httpClient = httpClient;
        }

        public async Task<string> CallTescoAPI(TokenRequest tescoRequest)
        {
            string? appKey = await _keyVaultAccess.GetSecretAsync("Appkey");
            string? appKeyToken = await _keyVaultAccess.GetSecretAsync("AppkeyToken");
            string? apiUrl = await _keyVaultAccess.GetSecretAsync("ApiURL");

            if (string.IsNullOrEmpty(appKey) || string.IsNullOrEmpty(appKeyToken) || string.IsNullOrEmpty(apiUrl))
            {
                throw new Exception("Missing required secrets from Key Vault.");
            }

            string authHeader = $"appKeyToken={appKeyToken}&appKey={appKey}";
            string jsonPayload = JsonConvert.SerializeObject(tescoRequest);

            var request = new HttpRequestMessage(HttpMethod.Post, apiUrl)
            {
                Content = new StringContent(jsonPayload, Encoding.UTF8, "application/json")
            };
            request.Headers.TryAddWithoutValidation("Authorization", authHeader);

            try
            {
                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Tesco API returned status code: {response.StatusCode}");
                }

                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("API call failed.", ex);
            }
        }
    }
}
