using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.Text;
using TescoFunctionApp.Interface;
using TescoFunctionApp.Model;
using static TescoFunctionApp.Model.TokenResponse;

namespace TescoFunctionApp.Tests
{
    public class TescoVoucherFunctionTests
    {
        private readonly Mock<ILogger<TescoVoucherFunction>> _loggerMock;
        private readonly Mock<IKeyVaultAccess> _keyVaultMock;
        private readonly Mock<IApiCaller> _apiCallerMock;

        public TescoVoucherFunctionTests()
        {
            _loggerMock = new Mock<ILogger<TescoVoucherFunction>>();
            _keyVaultMock = new Mock<IKeyVaultAccess>();
            _apiCallerMock = new Mock<IApiCaller>();
        }

        private static HttpRequest CreateHttpRequest(string body)
        {
            var context = new DefaultHttpContext();
            var request = context.Request;
            request.Body = new MemoryStream(Encoding.UTF8.GetBytes(body));
            request.ContentLength = request.Body.Length;
            request.Body.Position = 0;
            request.Headers["Content-Type"] = "application/json";
            return request;
        }

        [Fact]
        public async Task Run_ShouldReturnOkResult_WhenValidRequest()
        {
            // Arrange
            var function = new TescoVoucherFunction(
                _loggerMock.Object,
                _keyVaultMock.Object,
                _apiCallerMock.Object
            );

            var requestModel = new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "ABC123"
            };

            var httpRequest = CreateHttpRequest(JsonConvert.SerializeObject(requestModel));

            _keyVaultMock
                .Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var mockedTokenResponse = new TokenResponse
            {
                TransactionID = System.Guid.NewGuid(),
                TransactionDateTime = "15/09/2025 10:10:10",
                TransactionResponseCode = 0,
                TokenDetailsList = new PartnerTokenDetails[]
                {
                    new PartnerTokenDetails
                    {
                        ResponseCode = 0,
                        RequestId = System.Guid.NewGuid(),
                        TokenCode = "ABC123",
                        TokenStatus = "Active",
                        TokenStatusDate = "2025-09-10",
                        TokenExpiryDate = "2025-12-31",
                        TokenValue = 10.00m,
                        Lastname = "Smith",
                        Postcode = "AB12CD"
                    }
                }
            };

            _apiCallerMock
                .Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(mockedTokenResponse));

            // Act
            var result = await function.Run(httpRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);

            var voucherResponse = Assert.IsType<TescoVoucherResponse>(okResult.Value);

            Assert.Equal("ABC123", voucherResponse.TokenCode);
            Assert.Equal("Active", voucherResponse.TokenStatus);
            Assert.Equal(10.00m, voucherResponse.TokenValue);
            Assert.Equal("Smith", voucherResponse.Lastname);
            Assert.Equal("AB12CD", voucherResponse.Postcode);
            Assert.Equal("2025-12-31", voucherResponse.TokenExpiryDate);
        }

        [Fact]
        public async Task Run_ShouldReturnTokenAlreadyRedeemed_WhenResponseCodeIs112_AndStatusIsRedeemed()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);

            var request = CreateHttpRequest(JsonConvert.SerializeObject(new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "XYZ789"
            }));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var response = new TokenResponse
            {
                TokenDetailsList = new[]
                {
                    new PartnerTokenDetails
                    {
                        ResponseCode = 112,
                        TokenCode = "XYZ789",
                        TokenStatus = "Redeemed",
                        TokenExpiryDate = "2025-12-31",
                        TokenValue = 15.00m,
                        Lastname = "Brown",
                        Postcode = "ZZ99ZZ"
                    }
                }
            };

            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(response));

            // Act
            var result = await function.Run(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var value = Assert.IsType<TescoVoucherResponse>(okResult.Value);

            Assert.Equal("TokenAlreadyRedeemed", value.TokenStatus);
        }

        [Fact]
        public async Task Run_ShouldReturnNoTokenCodeInRequest_WhenResponseCodeIs104()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);

            var request = CreateHttpRequest(JsonConvert.SerializeObject(new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "XYZ789"
            }));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var response = new TokenResponse
            {
                TokenDetailsList = new[]
                {
                    new PartnerTokenDetails
                    {
                        ResponseCode = 112,
                        TokenCode = "XYZ789",
                        TokenStatus = "NoTokenCodeInRequest",
                        TokenExpiryDate = "2025-12-31",
                        TokenValue = 15.00m,
                        Lastname = "Brown",
                        Postcode = "ZZ99ZZ"
                    }
                }
            };

            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(response));

            // Act
            var result = await function.Run(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var value = Assert.IsType<TescoVoucherResponse>(okResult.Value);

            Assert.Equal("NoTokenCodeInRequest", value.TokenStatus);
        }

        [Fact]
        public async Task Run_ShouldReturnNotFound_WhenResponseCodeIs102()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);

            var request = CreateHttpRequest(JsonConvert.SerializeObject(new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "XYZ789"
            }));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var response = new TokenResponse
            {
                TokenDetailsList = new[]
                {
                    new PartnerTokenDetails
                    {
                        ResponseCode = 112,
                        TokenCode = "XYZ789",
                        TokenStatus = "NotFound",
                        TokenExpiryDate = "",
                        TokenValue = 0.00m,
                        Lastname = "",
                        Postcode = ""
                    }
                }
            };

            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(response));

            // Act
            var result = await function.Run(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var value = Assert.IsType<TescoVoucherResponse>(okResult.Value);

            Assert.Equal("NotFound", value.TokenStatus);
        }

        [Fact]
        public async Task Run_ShouldReturnBadRequest_WhenTokenDetailsMissingInResponse()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);
            var requestModel = new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "MISSING123"
            };
            var request = CreateHttpRequest(JsonConvert.SerializeObject(requestModel));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var tokenResponse = new TokenResponse
            {
                TokenDetailsList = null // Simulate missing token details
            };

            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(tokenResponse));

            // Act
            var result = await function.Run(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var errorObj = Assert.IsType<ErrorResponse>(badRequestResult.Value);

            Assert.Equal("error", errorObj.Status);
            Assert.Contains("Token details missing in response.", errorObj.Message);

        }

        [Fact]
        public async Task Run_ShouldMapStatus_WhenTokenAlreadyRedeemed()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);
            var requestModel = new TescoVoucherRequest
            {
                RequestType = "redeem",
                TokenCode = "REDEEMED123"
            };
            var request = CreateHttpRequest(JsonConvert.SerializeObject(requestModel));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var tokenResponse = new TokenResponse
            {
                TokenDetailsList = new PartnerTokenDetails[]
                {
                    new PartnerTokenDetails
                    {
                        ResponseCode = 112,
                        TokenCode = "REDEEMED123",
                        TokenStatus = "Redeemed",
                        TokenExpiryDate = "2025-12-31",
                        TokenValue = 10m,
                        Lastname = "Doe",
                        Postcode = "ZZ99 1ZZ"
                    }
                }
            };

            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(tokenResponse));

            // Act
            var result = await function.Run(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var response = Assert.IsType<TokenResponse.TescoVoucherResponse>(okResult.Value);

            Assert.Equal("TokenAlreadyRedeemed", response.TokenStatus);
            Assert.Equal("REDEEMED123", response.TokenCode);
        }

        [Fact]
        public async Task Run_ShouldReturnBadRequest_WhenApiReturnsInvalidJson()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);
            var requestModel = new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "INVALIDJSON"
            };
            var request = CreateHttpRequest(JsonConvert.SerializeObject(requestModel));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            // Simulate invalid JSON string
            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync("{ invalid json }");

            // Act
            var result = await function.Run(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var errorObj = Assert.IsType<ErrorResponse>(badRequestResult.Value);

            Assert.Equal("error", errorObj.Status);
            Assert.Contains("Invalid character after parsing property", errorObj.Message);

        }

        [Fact]
        public async Task Run_ShouldReturnBadRequest_WhenKeyVaultThrowsException()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);
            var requestModel = new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "ABC123"
            };
            var request = CreateHttpRequest(JsonConvert.SerializeObject(requestModel));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ThrowsAsync(new Exception("KeyVault unreachable"));

            // Act
            var result = await function.Run(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var errorObj = Assert.IsType<ErrorResponse>(badRequestResult.Value);

            Assert.Equal("error", errorObj.Status);
            Assert.Contains("KeyVault unreachable", errorObj.Message);

        }

        [Fact]
        public async Task Run_ShouldReturnBadRequest_WhenTokenDetailsListIsEmpty()
        {
            // Arrange
            var function = new TescoVoucherFunction(_loggerMock.Object, _keyVaultMock.Object, _apiCallerMock.Object);

            var request = CreateHttpRequest(JsonConvert.SerializeObject(new TescoVoucherRequest
            {
                RequestType = "validate",
                TokenCode = "XYZ789"
            }));

            _keyVaultMock.Setup(k => k.GetSecretAsync("SupplierCode"))
                .ReturnsAsync("SUPP001");

            var emptyResponse = new TokenResponse
            {
                TokenDetailsList = null
            };


            _apiCallerMock.Setup(a => a.CallTescoAPI(It.IsAny<TokenRequest>()))
                .ReturnsAsync(JsonConvert.SerializeObject(emptyResponse));

            // Act
            var result = await function.Run(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var errorObj = Assert.IsType<ErrorResponse>(badRequestResult.Value);

            Assert.Equal("error", errorObj.Status);
            Assert.Contains("Token details missing", errorObj.Message);
        }

    }
}
