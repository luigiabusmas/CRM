﻿using System;

namespace PTXIntegration
{
    public class DirectDebitPayload
    {
        public string Id { get; set; }
        public string Created { get; set; }
        public string LastUpdated { get; set; }
        public string Stage { get; set; }
        public string Company { get; set; }
        public string verification { get; set; }
        public string VerificationStatus { get; set; }
        public string CurrentAddressRecomendedStatus { get; set; }
        public string PrevAddressRecomendedStatus { get; set; }
        public string FormId { get; set; }
        public string FormTypeId { get; set; }
        public string FormType { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string ApplyingAsCompany { get; set; }
        public string CompanyName { get; set; }
        public string CurrentHouseNameNumber { get; set; }
        public string CurrentStreet1 { get; set; }
        public string CurrentStreet2 { get; set; }
        public string CurrentTown { get; set; }
        public string CurrentPostcode { get; set; }
        public string CurrentCountry { get; set; }
        public string PrevHouseNameNumber { get; set; }
        public string PrevStreet1 { get; set; }
        public string PrevStreet2 { get; set; }
        public string PrevTown { get; set; }
        public string PrevPostcode { get; set; }
        public string PrevCountry { get; set; }
        public string BankAccountName { get; set; }
        public string SortCode { get; set; }
        public string AccountNumber { get; set; }
        public string PtxProfileName { get; set; }
        public string DdDebtorReference { get; set; }
        public string DdPlanReference { get; set; }
        public string DdPlanSpecification { get; set; }
        public string DdNoOfCollections { get; set; }
        public string DdRegularAmount { get; set; }
        public string DdFirstAmount { get; set; }
        public string DdLastAmount { get; set; }
        public string DdStartDate { get; set; }
        public string DdPlanEndByDate { get; set; }
        public string CustomData { get; set; }
        public string FormName { get; set; }
        public string GiftAid { get; set; }
        public string BankName { get; set; }
        public string CompanyRegistrationNumber { get; set; }
        public string RegistrationMatch { get; set; }
        public string AccountStatus { get; set; }
        public string RegistrationPassValue { get; set; }
        public string status { get; set; }
        public string VerificationApplied { get; set; }
    }

}
