﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Util;

namespace PTXIntegration
{
    public class CRMAction
    {
        public Guid CreateDirectDebit(IOrganizationService service, ITracingService tracingService, DirectDebitPayload payload)
        {

            var directDebitId = Guid.Empty;
            var membershipDonationDirectDebitId = Guid.Empty;

            //Don't create direct debit detail when verification fails
            if (payload.verification != "passed")
            {
                tracingService.Trace($"Webform submission failed for direct debit with {payload.DdPlanReference} reference");
                return directDebitId;
            }

            //Get Transaction Details based from DD Plan Reference
            var transactionDetails = GetTransactionDetails(service, payload.DdPlanReference);

            if (transactionDetails == null || !transactionDetails.Attributes.ContainsKey("rhs_customer"))
            {
                tracingService.Trace($"Transaction details for transaction {payload.DdPlanReference} cannot be found");
                return directDebitId;
            }

            //Get PayerId
            var payerId = transactionDetails.GetAttributeValue<EntityReference>("rhs_customer");
            //var membershipReference = transactionDetails.GetAttributeValue<EntityReference>("rhs_membershiprecord");
            var newMembershipReference = transactionDetails.GetAttributeValue<EntityReference>("rhs_membershipid");
            var subscriptionReference = transactionDetails.GetAttributeValue<EntityReference>("rhs_subscriptionid");
            var donationReference = transactionDetails.GetAttributeValue<EntityReference>("rhs_donation");

            //check for existing direct debit mandate record with existing ddplanref
            var debitEntity = RetrieveExistingDirectDebit(service, payload.DdPlanReference);
            var membershipDonationDebitEntity = RetrieveExistingMembershipDonationDirectDebit(service, payload.DdPlanReference, transactionDetails.Id);

            try
            {
                #region Direct debit setup for record
                // Create/Update Direct Debit record
                if (debitEntity == null)
                {
                    var newRecord = new Entity("rhs_directdebitdetails")
                    {
                        ["rhs_payer"] = payerId,
                        ["rhs_reference"] = payload.DdPlanReference,
                        ["rhs_branchsortcode"] = payload.SortCode,
                        ["rhs_name"] = payload.BankAccountName,
                        ["rhs_branchaccountnumber"] = payload.AccountNumber,
                        //["rhs_membership"] = membershipReference,
                        ["rhs_membershipid"] = newMembershipReference,
                        ["rhs_subscription"] = subscriptionReference,
                        ["rhs_donation"] = donationReference,
                    };

                    // Create the record and get the GUID of the newly created record
                    directDebitId = service.Create(newRecord);
                }
                else
                {
                    var updateRecord = new Entity("rhs_directdebitdetails")
                    {
                        ["rhs_payer"] = payerId,
                        ["rhs_directdebitdetailsid"] = debitEntity.Id,
                        ["rhs_branchsortcode"] = payload.SortCode,
                        ["rhs_name"] = payload.BankAccountName,
                        ["rhs_branchaccountnumber"] = payload.AccountNumber,
                        //["rhs_membership"] = membershipReference,
                        ["rhs_membershipid"] = newMembershipReference,
                        ["rhs_subscription"] = subscriptionReference,
                        ["rhs_donation"] = donationReference,
                    };

                    directDebitId = debitEntity.Id;

                    //update record 
                    service.Update(updateRecord);
                }
                
                //Update Transaction Record and Payment records
                if (directDebitId != Guid.Empty)
                {
                    var directDebitDetailsReference = new EntityReference("rhs_directdebitdetails", directDebitId);
                    UpdateTransactionDirectDebitDetail(service, transactionDetails.Id, directDebitDetailsReference);
                    UpdatePaymentDirectDebitDetail(service, transactionDetails.Id, directDebitDetailsReference);  // not yet required
                }
                #endregion

                #region Direct debit setup for membership donation
                // Create/Update Direct Debit record for membership donation (if applicable)
                if (newMembershipReference != null && donationReference != null)
                {
                    if (membershipDonationDebitEntity == null)
                    {
                        var newRecord = new Entity("rhs_directdebitdetails")
                        {
                            ["rhs_payer"] = payerId,
                            ["rhs_reference"] = GenerateRandom12DigitNumber(),
                            ["rhs_branchsortcode"] = payload.SortCode,
                            ["rhs_name"] = payload.BankAccountName,
                            ["rhs_branchaccountnumber"] = payload.AccountNumber,
                            //["rhs_membership"] = membershipReference,
                            ["rhs_membershipid"] = newMembershipReference,
                            ["rhs_subscription"] = subscriptionReference,
                            ["rhs_donation"] = donationReference,
                        };

                        // Create the record and get the GUID of the newly created record
                        membershipDonationDirectDebitId = service.Create(newRecord);
                    }
                    else
                    {
                        var updateRecord = new Entity("rhs_directdebitdetails")
                        {
                            ["rhs_payer"] = payerId,
                            ["rhs_directdebitdetailsid"] = membershipDonationDebitEntity.Id,
                            ["rhs_branchsortcode"] = payload.SortCode,
                            ["rhs_name"] = payload.BankAccountName,
                            ["rhs_branchaccountnumber"] = payload.AccountNumber,
                            //["rhs_membership"] = membershipReference,
                            ["rhs_membershipid"] = newMembershipReference,
                            ["rhs_subscription"] = subscriptionReference,
                            ["rhs_donation"] = donationReference,
                        };

                        membershipDonationDirectDebitId = membershipDonationDebitEntity.Id;

                        //update record 
                        service.Update(updateRecord);
                    }
                }

                //Update Transaction Record and Payment records for membership donation (if applicable)
                if (membershipDonationDirectDebitId != Guid.Empty)
                {
                    var directDebitDetailsReference = new EntityReference("rhs_directdebitdetails", membershipDonationDirectDebitId);
                    UpdateMembershipDonationPaymentDirectDebitDetail(service, transactionDetails.Id, directDebitDetailsReference);  // not yet required
                }
                #endregion

                return directDebitId;
            }
            catch (Exception ex)
            {
                tracingService.Trace("Failed to create a new Direct Debit Mandate record: " + ex.Message);
                return Guid.Empty;
            }
        }

        private Entity GetTransactionDetails(IOrganizationService service, string ddPlanReference)
        {
            QueryExpression query = new QueryExpression("rhs_transaction")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("rhs_transacid", ConditionOperator.Equal, ddPlanReference),
                    }
                }
            };

            EntityCollection transactions = service.RetrieveMultiple(query);

            if (transactions.Entities.Count <= 1)
            {
                return transactions.Entities.FirstOrDefault();

            }

            return null;
        }

        private Entity RetrieveExistingDirectDebit(IOrganizationService service, string ddPlanReference)
        {

            try
            {
                QueryExpression query = new QueryExpression("rhs_directdebitdetails")
                {
                    ColumnSet = new ColumnSet(true),
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                             new ConditionExpression("rhs_reference", ConditionOperator.Equal, ddPlanReference),
                        }
                    }
                };

                EntityCollection debitmandates = service.RetrieveMultiple(query);

                Entity debitDetails = debitmandates.Entities.FirstOrDefault();

                return debitDetails;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private Entity RetrieveExistingMembershipDonationDirectDebit(IOrganizationService service, string ddPlanReference, Guid transactionId)
        {
            var query = new QueryExpression("rhs_directdebitdetails");
            query.ColumnSet.AllColumns = true;
            query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0/*Active*/);
            query.Criteria.AddCondition("rhs_transaction", "rhs_transactionid", ConditionOperator.Equal, transactionId);
            query.Criteria.AddCondition("rhs_reference", ConditionOperator.NotEqual, ddPlanReference);
            query.AddLink("rhs_transaction", "rhs_directdebitdetailsid", "rhs_directdebitmandate");

            var debitmandates = service.RetrieveMultiple(query).Entities;
            var debitDetails = debitmandates.FirstOrDefault();
            return debitDetails;
        }

        public void UpdateTransactionDirectDebitDetail(IOrganizationService service, Guid transactionId, EntityReference directDebitReference)
        {
            var updateRecord = new Entity("rhs_transaction", transactionId)
            {
                ["rhs_directdebitmandate"] = directDebitReference,
            };

            service.Update(updateRecord);
        }

        public void UpdatePaymentDirectDebitDetail(IOrganizationService service, Guid transactionId, EntityReference directDebitReference)
        {
            //Payment record retrieval
            var query = new QueryExpression("rhs_payment");
            query.ColumnSet.AddColumn("rhs_transaction");
            query.Criteria.AddCondition("rhs_transaction", ConditionOperator.Equal, transactionId);

            var payments = service.RetrieveMultiple(query).Entities;

            //Payment record update
            foreach (var payment in payments)
            {
                var updateRecord = new Entity("rhs_payment", payment.Id)
                {
                    ["rhs_directdebitdetails"] = directDebitReference,
                };

                service.Update(updateRecord);
            }
        }

        public void UpdateMembershipDonationPaymentDirectDebitDetail(IOrganizationService service, Guid transactionId, EntityReference directDebitReference)
        {
            //Payment record retrieval
            var query = new QueryExpression("rhs_payment");
            query.ColumnSet.AddColumn("rhs_transaction");
            query.Criteria.AddCondition("rhs_transaction", ConditionOperator.Equal, transactionId);
            query.Criteria.AddCondition("rhs_paymenttype", ConditionOperator.Equal, 120000000/*Donation*/);

            var payments = service.RetrieveMultiple(query).Entities;

            //Payment record update
            foreach (var payment in payments)
            {
                var updateRecord = new Entity("rhs_payment", payment.Id)
                {
                    ["rhs_directdebitdetails"] = directDebitReference,
                };

                service.Update(updateRecord);
            }
        }

        private string GenerateRandom12DigitNumber()
        {
            var random = new Random();
            var digitNumber = string.Empty;

            for (var ctr = 1; ctr <= 12; ctr++)
                digitNumber += random.Next(0, 9);

            return digitNumber;
        }
    }
}
