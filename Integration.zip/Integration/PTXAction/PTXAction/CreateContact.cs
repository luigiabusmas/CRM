﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PTXAction
{
    public class CreateContact :IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            CRMAction crmaction = new CRMAction();

            var jsonInput = GetInputParameters(context, tracingService);
            string jsonString = JsonConvert.SerializeObject(jsonInput);
            tracingService.Trace("Consolidated JSON: " + jsonString);

            Guid recordId = Guid.Empty;

            // Extract requestId from the input parameters if it exists
            if (jsonInput.TryGetValue("requestid", out var requestIdObj) && requestIdObj != null)
            {
                var requestId = requestIdObj.ToString();
                recordId = crmaction.IntegrationLogExists(service, requestId, tracingService);
                tracingService.Trace(string.IsNullOrEmpty(requestId) ? "Request ID is null or empty." : $"Request ID: {requestId}");
            }
            else
            {
                try
                {
                    recordId = crmaction.CreateIntegrationLog(service, jsonString, tracingService,"Create PTX Contact");
                    tracingService.Trace("Integration log created with ID: " + recordId);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Error creating integration log: " + ex.Message);
                }
            }


            //
            try
            {
                AzureHelper azhelper = new AzureHelper();
                // Get Azure Function URL
                string azureFunctionUrl = azhelper.GetAzureFunctionUrl(service, tracingService, "FAPTXCreateContact");

                if (!string.IsNullOrEmpty(azureFunctionUrl))
                {
                    string azureFunctionResponse = azhelper.CallAzureFunctionAsync(azureFunctionUrl, jsonString).Result;
                    tracingService.Trace("Azure Function Response: " + azureFunctionResponse);

                    try
                    {
                        var responseObj = JsonConvert.DeserializeObject<CreateContactAzureFunctionResponse>(azureFunctionResponse);

                        if (responseObj.Status == "error")
                        {
                            string errorMessage = responseObj.Message ?? "Unknown error occurred.";
                            crmaction.UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);
                            context.OutputParameters["rhs_ptxCustomerResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
                        }
                        else
                        {
                            // If response does not indicate failure, return the original response
                            context.OutputParameters["rhs_ptxCustomerResponse"] = azureFunctionResponse;
                        }
                    }
                    catch (JsonException jsonEx)
                    {
                        tracingService.Trace("Error deserializing Azure Function response: " + jsonEx.Message);
                        context.OutputParameters["rhs_ptxCustomerResponse"] = JsonConvert.SerializeObject(new { message = "Failed to process Azure function response", status = "error" });
                    }
                

                }
                else
                {
                    tracingService.Trace("Azure Function URL not found in app settings.");
                    crmaction.UpdateIntegrationLog(service, recordId, "Azure Function URL not found in app settings.", 120000002, tracingService);
                }
            }
            catch (Exception ex)
            {
                // General exception handling
                string errorMessage = $"Error calling Azure Function:" + ex.Message;
                tracingService.Trace(errorMessage);
                crmaction.UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);

                context.OutputParameters["rhs_stripeCheckoutSessionResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
            }
            //
        }

        private Dictionary<string, object> GetInputParameters(IPluginExecutionContext context, ITracingService tracingService)
        {
            var jsonInput = new Dictionary<string, object>();

            // First name and last name
            if (TryGetParameter(context, "rhs_ptxTitle", out string title))
            {
                jsonInput["title"] = title;
                tracingService.Trace("title: " + title);
            }

            if (TryGetParameter(context, "rhs_ptxFirstName", out string firstName))
            {
                jsonInput["firstName"] = firstName;
                tracingService.Trace("firstName: " + firstName);
            }

            if (TryGetParameter(context, "rhs_ptxLastName", out string lastName))
            {
                jsonInput["lastName"] = lastName;
                tracingService.Trace("lastName: " + lastName);
            }

            if (TryGetParameter(context, "rhs_ptxEmail", out string email))
            {
                jsonInput["email"] = email;
                tracingService.Trace("email: " + email);
            }

            if (TryGetParameter(context, "rhs_ptxIsAttachmentUsed", out string isAttachmentUsed))
            {
                jsonInput["isAttachmentUsed"] = bool.Parse(isAttachmentUsed);  
                tracingService.Trace("isAttachmentUsed: " + isAttachmentUsed);
            }

            if (TryGetParameter(context, "rhs_stripeProduct", out string communicationPref))
            {
                jsonInput["communicationPref"] = communicationPref;
                tracingService.Trace("communicationPref: " + communicationPref);
            }

            // Address is a nested object, so we'll need to handle it separately
            var address = new Dictionary<string, string>();
            if (TryGetParameter(context, "rhs_ptxAddress_Lines", out string address_lines))
            {
                address["lines"] = address_lines;
                tracingService.Trace("address_lines: " + address_lines);
            }

            if (TryGetParameter(context, "rhs_ptxAddress_Town", out string town))
            {
                address["town"] = town;
                tracingService.Trace("town: " + town);
            }

            if (TryGetParameter(context, "rhs_ptxAddress_County", out string county))
            {
                address["county"] = county;
                tracingService.Trace("county: " + county);
            }

            if (TryGetParameter(context, "rhs_ptxAddress_Code", out string code))
            {
                address["code"] = code;
                tracingService.Trace("code: " + code);
            }

            if (TryGetParameter(context, "rhs_ptxAddress_Country", out string country))
            {
                address["country"] = country;
                tracingService.Trace("country: " + country);
            }

            // Add the address to the main dictionary
            if (address.Count > 0)
            {
                jsonInput["address"] = address;
            }

            // Company and reference
            if (TryGetParameter(context, "rhs_ptxCompanyName", out string companyName))
            {
                jsonInput["companyName"] = companyName;
                tracingService.Trace("companyName: " + companyName);
            }

            if (TryGetParameter(context, "rhs_ptxReference", out string reference))
            {
                jsonInput["reference"] = reference;
                tracingService.Trace("reference: " + reference);
            }

            if (TryGetParameter(context, "rhs_ptxPhone", out string phone))
            {
                jsonInput["phone"] = phone;
                tracingService.Trace("phone: " + phone);
            }

            if (TryGetParameter(context, "rhs_ptxCreateContactId", out string requestid))
            {
                jsonInput["requestid"] = requestid;
                tracingService.Trace("requestid: " + requestid);
            }

            // Handle missing or empty parameters
            if (jsonInput.Count == 0)
            {
                tracingService.Trace("Required parameters are missing.");
                // Optionally, throw an exception or return a default response
            }

            return jsonInput;
        }


        private bool TryGetParameter(IPluginExecutionContext context, string parameterName, out string value)
        {
            value = null;
            if (context.InputParameters.Contains(parameterName) && context.InputParameters[parameterName] is string parameterValue)
            {
                value = parameterValue;
                return true;
            }
            return false;
        }

    }
}
