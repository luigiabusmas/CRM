﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace PTXAction
{
    public class CRMAction
    {
        public Guid CreateIntegrationLog(IOrganizationService service, string jsonString, ITracingService tracingService,string name)
        {
            var newRecord = new Entity("rhs_integrationlog")
            {
                ["rhs_name"] = name,
                ["rhs_integration_type"] = "PTX",
                ["rhs_payload"] = jsonString,
                ["rhs_direction"] = new OptionSetValue(120000000),
                ["rhs_integrationstatus"] = new OptionSetValue(120000000)
            };

            return service.Create(newRecord);
        }

        public void UpdateIntegrationLog(IOrganizationService service, Guid recordId, string message, int status, ITracingService tracingService)
        {
            var updateRecord = new Entity("rhs_integrationlog", recordId)
            {
                ["rhs_response"] = message,  // Use message for both success and error
                ["rhs_integrationstatus"] = new OptionSetValue(status)  // Update status based on success or error
            };

            service.Update(updateRecord);
            tracingService.Trace("Integration log updated: " + message);
        }

        public Guid IntegrationLogExists(IOrganizationService service, string requestId, ITracingService tracingService)
        {
            // Check if the integration log exists for the given request ID
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_integrationlog")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_integrationlogid"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                        new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_requestid", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, requestId)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var logId = result.Entities.First().GetAttributeValue<Guid>("rhs_integrationlogid");
                tracingService.Trace($"Integration log exists with ID {logId} for request ID {requestId}");
                return logId;
            }

            tracingService.Trace($"No integration log found for request ID {requestId}");
            return Guid.Empty; // Return empty GUID if not found
        }

    }
}
