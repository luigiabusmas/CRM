﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTXAction
{
    public class CreateContactAzureFunctionResponse
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public ContactDetails ContactDetails { get; set; }
    }
    public class Address
    {
        public string Lines { get; set; }
        public string Town { get; set; }
        public string County { get; set; }
        public string Code { get; set; }
        public string Country { get; set; }
    }

    public class ContactDetails
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool IsAttachmentUsed { get; set; }
        public string CommunicationPref { get; set; }
        public Address Address { get; set; }
        public string CompanyName { get; set; }
        public string Reference { get; set; }
        public string Phone { get; set; }
    }

  

}
