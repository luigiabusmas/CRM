﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTXAction.Model
{
    public class GetAllMandatesAzureFunctionResponse
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public List<PTXMandates> PTXMandates { get; set; }
    }
    public class PTXMandates
    {
        public int PayerId { get; set; }
        public int ProfileId { get; set; }
        public string Reference { get; set; }
        public string SortCode { get; set; }
        public string AccountNumber { get; set; }
        public int Id { get; set; }
        public string AltReference { get; set; }
        public string AccountName { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public DateTime Created { get; set; }
        public string ValidationStatus { get; set; }
        public List<PaymentPlan> PaymentPlans { get; set; }
    }
    public class PaymentPlan
    {
        public WeeklyPaymentPlan WeeklyPaymentPlan { get; set; }
        public MonthlyPaymentPlan MonthlyPaymentPlan { get; set; }
        public MonthlyPickPaymentPlan MonthlyPickPaymentPlan { get; set; }
        public YearlyPaymentPlan YearlyPaymentPlan { get; set; }
    }

    public class WeeklyPaymentPlan
    {
        public string Type { get; set; } = "WeeklyPaymentPlan";
        public int AmountType { get; set; }
        public string RegularAmount { get; set; }
        public int FirstAmount { get; set; }
        public int LastAmount { get; set; }
        public int TotalAmount { get; set; }
        public int Id { get; set; }
        public int MandateId { get; set; }
        public int ProfileId { get; set; }
        public int TemplateId { get; set; }
        public int ParentPlanId { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime RestrictedDate { get; set; }
        public DateTime LastCollection { get; set; }
        public int Extracted { get; set; }
        public DateTime Created { get; set; }
        public string Description { get; set; }
        public Schedule Schedule { get; set; }
        public int ForecastExtracted { get; set; }
        public DateTime LastForecastDate { get; set; }
        public string ForecastAction { get; set; }
        public List<Forecast> Forecasts { get; set; }
        public int EveryNthWeek { get; set; }
        public List<string> WeekDays { get; set; }
    }

    public class MonthlyPaymentPlan
    {
        public string Type { get; set; } = "MonthlyPaymentPlan";
        public int AmountType { get; set; }
        public string RegularAmount { get; set; }
        public int FirstAmount { get; set; }
        public int LastAmount { get; set; }
        public int TotalAmount { get; set; }
        public int Id { get; set; }
        public int MandateId { get; set; }
        public int ProfileId { get; set; }
        public int TemplateId { get; set; }
        public int ParentPlanId { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime RestrictedDate { get; set; }
        public DateTime LastCollection { get; set; }
        public int Extracted { get; set; }
        public DateTime Created { get; set; }
        public string Description { get; set; }
        public Schedule Schedule { get; set; }
        public int ForecastExtracted { get; set; }
        public DateTime LastForecastDate { get; set; }
        public string ForecastAction { get; set; }
        public List<Forecast> Forecasts { get; set; }
        public int EveryNthMonth { get; set; }
        public List<string> MonthDays { get; set; }
    }

    public class MonthlyPickPaymentPlan
    {
        public string Type { get; set; } = "MonthlyPickPaymentPlan";
        public int AmountType { get; set; }
        public string RegularAmount { get; set; }
        public int FirstAmount { get; set; }
        public int LastAmount { get; set; }
        public int TotalAmount { get; set; }
        public int Id { get; set; }
        public int MandateId { get; set; }
        public int ProfileId { get; set; }
        public int TemplateId { get; set; }
        public int ParentPlanId { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime RestrictedDate { get; set; }
        public DateTime LastCollection { get; set; }
        public int Extracted { get; set; }
        public DateTime Created { get; set; }
        public string Description { get; set; }
        public Schedule Schedule { get; set; }
        public int ForecastExtracted { get; set; }
        public DateTime LastForecastDate { get; set; }
        public string ForecastAction { get; set; }
        public List<Forecast> Forecasts { get; set; }
        public int EveryNthMonth { get; set; }
        public string Sequence { get; set; }
        public string WeekDaySequence { get; set; }
    }

    public class YearlyPaymentPlan
    {
        public string Type { get; set; } = "YearlyPaymentPlan";
        public int AmountType { get; set; }
        public string RegularAmount { get; set; }
        public int FirstAmount { get; set; }
        public int LastAmount { get; set; }
        public int TotalAmount { get; set; }
        public int Id { get; set; }
        public int MandateId { get; set; }
        public int ProfileId { get; set; }
        public int TemplateId { get; set; }
        public int ParentPlanId { get; set; }
        public string Status { get; set; }
        public DateTime LastUpdated { get; set; }
        public DateTime RestrictedDate { get; set; }
        public DateTime LastCollection { get; set; }
        public int Extracted { get; set; }
        public DateTime Created { get; set; }
        public string Description { get; set; }
        public Schedule Schedule { get; set; }
        public int ForecastExtracted { get; set; }
        public DateTime LastForecastDate { get; set; }
        public string ForecastAction { get; set; }
        public List<Forecast> Forecasts { get; set; }
        public List<string> MonthOfYear { get; set; }
        public List<string> MonthDays { get; set; }
    }

    public class Schedule
    {
        public int NumberOfOccurrences { get; set; }
        public string SchedulePattern { get; set; }
        public string FrequencyEnd { get; set; }
        public string Comments { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class Forecast
    {
        public int Amount { get; set; }
        public int Id { get; set; }
        public int MandateId { get; set; }
        public int ProfileId { get; set; }
        public int PlanId { get; set; }
        public DateTime CollectionDate { get; set; }
        public int CollectionNumber { get; set; }
        public string TransactionCode { get; set; }
    }
}
