﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PTXAction
{
   public class AzureHelper
    {
        private static readonly HttpClient _httpClient = new HttpClient();
        public string GetAzureFunctionUrl(IOrganizationService service, ITracingService tracingService, string settingName)
        {
            // Query the rhs_appsettings entity to get the Azure Function URL by name
            var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("rhs_appsettings")
            {
                ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("rhs_value"),
                Criteria = new Microsoft.Xrm.Sdk.Query.FilterExpression
                {
                    Conditions =
                    {
                         new Microsoft.Xrm.Sdk.Query.ConditionExpression("rhs_name", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, settingName)
                    }
                }
            };

            var result = service.RetrieveMultiple(query);
            if (result.Entities.Any())
            {
                var functionUrl = result.Entities.First().GetAttributeValue<string>("rhs_value");
                tracingService.Trace("Azure Function URL retrieved: " + functionUrl);
                return functionUrl;
            }

            tracingService.Trace("Azure Function URL not found for setting name: " + settingName);
            return null;
        }

        public async Task<string> CallAzureFunctionAsync(string functionUrl, string jsonInput)
        {
            using (HttpClient client = new HttpClient())
            {

                var content = new StringContent(jsonInput, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync(functionUrl, content);

                // Read the response content
                string responseContent = await response.Content.ReadAsStringAsync();

                return responseContent;
            }
        }
        public async Task<string> CallAzureFunctionGetAsync(string functionUrl, string jsonInput)
        {
            try
            {
                // Add the query parameter to the URL if needed
                var uriBuilder = new UriBuilder(functionUrl);

                // Deserialize the JSON to extract contactId
                var deserializedJson = JsonConvert.DeserializeObject<dynamic>(jsonInput);
                string contactId = deserializedJson.contactId;

                var query = System.Web.HttpUtility.ParseQueryString(uriBuilder.Query);
                query["contactId"] = contactId;  // Adding contactId to the query string
                uriBuilder.Query = query.ToString();

                // Send the GET request asynchronously
                HttpResponseMessage response = await _httpClient.GetAsync(uriBuilder.ToString());

                // Ensure the response is successful (status code 2xx)
                response.EnsureSuccessStatusCode();

                // Read and return the response content
                string responseContent = await response.Content.ReadAsStringAsync();

                return responseContent;
            }
            catch (HttpRequestException httpEx)
            {
                // Handle HTTP-specific errors (e.g., network issues, bad responses)
                Console.WriteLine($"Request failed: {httpEx.Message}");
                throw;  // Rethrow the exception for further handling or logging
            }
            catch (Exception ex)
            {
                // Handle other general exceptions (e.g., timeout, unexpected errors)
                Console.WriteLine($"An error occurred: {ex.Message}");
                throw;  // Rethrow the exception
            }
        }
    }
}
