﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using PTXAction.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTXAction
{
   public class ListAllMandates : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider) 
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            var serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            CRMAction crmaction = new CRMAction();

            var jsonInput = GetInputParameters(context, tracingService);
            string jsonString = JsonConvert.SerializeObject(jsonInput);
            tracingService.Trace("Consolidated JSON: " + jsonString);

            Guid recordId = Guid.Empty;

            // Extract requestId from the input parameters if it exists
            if (jsonInput.TryGetValue("requestid", out var requestIdObj) && requestIdObj != null)
            {
                var requestId = requestIdObj.ToString();
                recordId = crmaction.IntegrationLogExists(service, requestId, tracingService);
                tracingService.Trace(string.IsNullOrEmpty(requestId) ? "Request ID is null or empty." : $"Request ID: {requestId}");
            }
            else
            {
                try
                {
                    recordId = crmaction.CreateIntegrationLog(service, jsonString, tracingService, "PTX Get All Mandates");
                    tracingService.Trace("Integration log created with ID: " + recordId);
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Error creating integration log: " + ex.Message);
                }
            }


            //
            try
            {
                AzureHelper azhelper = new AzureHelper();
                // Get Azure Function URL
                string azureFunctionUrl = azhelper.GetAzureFunctionUrl(service, tracingService, "FAPTXGetAllMandates");

                if (!string.IsNullOrEmpty(azureFunctionUrl))
                {
                    string azureFunctionResponse = azhelper.CallAzureFunctionGetAsync(azureFunctionUrl, jsonString).Result;
                    tracingService.Trace("Azure Function Response: " + azureFunctionResponse);

                    try
                    {
                        var responseObj = JsonConvert.DeserializeObject<GetAllMandatesAzureFunctionResponse>(azureFunctionResponse);

                        if (responseObj.Status == "error")
                        {
                            string errorMessage = responseObj.Message ?? "Unknown error occurred.";
                            crmaction.UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);
                            context.OutputParameters["rhs_ptxGetAllMandatesResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
                        }
                        else
                        {
                            // If response does not indicate failure, return the original response
                            context.OutputParameters["rhs_ptxGetAllMandatesResponse"] = azureFunctionResponse;
                        }
                    }
                    catch (JsonException jsonEx)
                    {
                        tracingService.Trace("Error deserializing Azure Function response: " + jsonEx.Message);
                        context.OutputParameters["rhs_ptxGetAllMandatesResponse"] = JsonConvert.SerializeObject(new { message = "Failed to process Azure function response", status = "error" });
                    }


                }
                else
                {
                    tracingService.Trace("Azure Function URL not found in app settings.");
                    crmaction.UpdateIntegrationLog(service, recordId, "Azure Function URL not found in app settings.", 120000002, tracingService);
                }
            }
            catch (Exception ex)
            {
                // General exception handling
                string errorMessage = $"Error calling Azure Function:" + ex.Message;
                tracingService.Trace(errorMessage);
                crmaction.UpdateIntegrationLog(service, recordId, errorMessage, 120000002, tracingService);

                context.OutputParameters["rhs_ptxGetAllMandatesResponse"] = JsonConvert.SerializeObject(new { message = errorMessage, status = "failed" });
            }
            //        
        }
        private Dictionary<string, object> GetInputParameters(IPluginExecutionContext context, ITracingService tracingService)
        {
            var jsonInput = new Dictionary<string, object>();

            // First name and last name
            if (TryGetParameter(context, "rhs_ptxContactId", out string title))
            {
                jsonInput["contactId"] = title;
                tracingService.Trace("contactId: " + title);
            }


            if (TryGetParameter(context, "rhs_ptxGetAllMandateId", out string requestid))
            {
                jsonInput["requestid"] = requestid;
                tracingService.Trace("requestid: " + requestid);
            }

            // Handle missing or empty parameters
            if (jsonInput.Count == 0)
            {
                tracingService.Trace("Required parameters are missing.");
                // Optionally, throw an exception or return a default response
            }

            return jsonInput;
        }


        private bool TryGetParameter(IPluginExecutionContext context, string parameterName, out string value)
        {
            value = null;
            if (context.InputParameters.Contains(parameterName) && context.InputParameters[parameterName] is string parameterValue)
            {
                value = parameterValue;
                return true;
            }
            return false;
        }
    }
}
