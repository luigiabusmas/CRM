using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using PTXFunctionApp.Models;
using PTXFunctionApp.Services;
using System.Text.Json;

namespace PTXFunctionApp.Functions
{
    public class ValidateBankAccount
    {
        private readonly ILogger<ValidateBankAccount> _logger;
        private readonly IBankAccountValidator _bankAccountValidator;

        public ValidateBankAccount(ILogger<ValidateBankAccount> logger, IBankAccountValidator bankAccountValidator)
        {
            _logger = logger;
            _bankAccountValidator = bankAccountValidator;
        }

        [Function(nameof(ValidateBankAccount))]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            _logger.LogInformation("Bank account validation request received.");

            BankAccountModel? account;
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                account = JsonSerializer.Deserialize<BankAccountModel>(requestBody);

                if (account == null)
                    return new BadRequestObjectResult("Invalid request payload.");
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Failed to deserialize request body.");
                return new BadRequestObjectResult("Malformed JSON.");
            }

            try
            {
                ValidationResult result = await _bankAccountValidator.ValidateBankAccountAsync(account);
                if (result.Success != null && result.Success.Match)
                {
                    _logger.LogWarning("Valid Account");
                    return new OkObjectResult(result);
                }
                else if (result.Error != null)
                {
                    _logger.LogError("Validation error: {Error}", result.Error);
                    return new BadRequestObjectResult(result.Error) { StatusCode = result.StatusCode };
                }
                else
                {
                    _logger.LogWarning("Invalid Account");
                    return new BadRequestObjectResult(new { error = "Invalid response" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during bank account validation.");
                return new StatusCodeResult(StatusCodes.Status500InternalServerError);
            }
        }
    }
}