using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PTXFunctionApp
{
    public class MandatesListFunction
    {
        private readonly ILogger<MandatesListFunction> _logger;

        public MandatesListFunction(ILogger<MandatesListFunction> logger)
        {
            _logger = logger;
        }

        [Function("MandatesListFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest req)
        {
            _logger.LogInformation("PTX retrieval started.");

            try
            {
                string contactId = req.Query["contactId"];

                if (string.IsNullOrEmpty(contactId))
                {
                    return new BadRequestObjectResult("Contact ID is required.");
                }
                var weeklyPlan = new WeeklyPaymentPlan
                {
                    Type = "Weekly",
                    AmountType = 0,
                    RegularAmount = "12.00",
                    FirstAmount = 0,
                    LastAmount = 0,
                    TotalAmount = 0,
                    Id = 109,
                    MandateId = 64,
                    ProfileId = 3,
                    TemplateId = 17,
                    ParentPlanId = 25,
                    Status = "ACTIVE",
                    LastUpdated = DateTime.Now,
                    RestrictedDate = DateTime.Now,
                    LastCollection = DateTime.Now,
                    Extracted = 0,
                    Created = DateTime.Now,
                    Description = "Weekly Payment Plan",
                    Schedule = new Schedule
                    {
                        NumberOfOccurrences = 10,
                        SchedulePattern = "Fixed",
                        FrequencyEnd = "2025-12-31",
                        Comments = "Weekly payment plan",
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now.AddMonths(3)
                    },
                    EveryNthWeek = 1,
                    WeekDays = new List<string> { "MONDAY", "FRIDAY" }
                };

                var monthlyPlan = new MonthlyPaymentPlan
                {
                    Type = "Monthly",
                    AmountType = 0,
                    RegularAmount = "25.00",
                    FirstAmount = 0,
                    LastAmount = 0,
                    TotalAmount = 0,
                    Id = 104,
                    MandateId = 104,
                    ProfileId = 8,
                    TemplateId = 14,
                    ParentPlanId = 26,
                    Status = "ACTIVE",
                    LastUpdated = DateTime.Now,
                    RestrictedDate = DateTime.Now,
                    LastCollection = DateTime.Now,
                    Extracted = 0,
                    Created = DateTime.Now,
                    Description = "Monthly Payment Plan",
                    Schedule = new Schedule
                    {
                        NumberOfOccurrences = 12,
                        SchedulePattern = "Fixed",
                        FrequencyEnd = "2025-12-31",
                        Comments = "Monthly payment plan",
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now.AddYears(1)
                    },
                    EveryNthMonth = 1,
                    MonthDays = new List<string> { "DAY1", "DAY15", "DAY30" }
                };

                var monthlyPickPlan = new MonthlyPickPaymentPlan
                {
                    Type = "MonthlyPick",
                    AmountType = 0,
                    RegularAmount = "30.00",
                    FirstAmount = 0,
                    LastAmount = 0,
                    TotalAmount = 0,
                    Id = 106,
                    MandateId = 98,
                    ProfileId = 6,
                    TemplateId = 12,
                    ParentPlanId = 23,
                    Status = "ACTIVE",
                    LastUpdated = DateTime.Now,
                    RestrictedDate = DateTime.Now,
                    LastCollection = DateTime.Now,
                    Extracted = 0,
                    Created = DateTime.Now,
                    Description = "Monthly Pick Payment Plan",
                    Schedule = new Schedule
                    {
                        NumberOfOccurrences = 6,
                        SchedulePattern = "Flexible",
                        FrequencyEnd = "2025-12-31",
                        Comments = "Monthly pick payment plan",
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now.AddMonths(6)
                    },
                    EveryNthMonth = 1,
                    Sequence = "FIRST",
                    WeekDaySequence = "WORKING_DAY"
                };

                var yearlyPlan = new YearlyPaymentPlan
                {
                    Type = "Yearly",
                    AmountType = 0,
                    RegularAmount = "120.00",
                    FirstAmount = 0,
                    LastAmount = 0,
                    TotalAmount = 0,
                    Id = 101,
                    MandateId = 10,
                    ProfileId = 1,
                    TemplateId = 11,
                    ParentPlanId = 24,
                    Status = "ACTIVE",
                    LastUpdated = DateTime.Now,
                    RestrictedDate = DateTime.Now,
                    LastCollection = DateTime.Now,
                    Extracted = 0,
                    Created = DateTime.Now,
                    Description = "Yearly Payment Plan",
                    Schedule = new Schedule
                    {
                        NumberOfOccurrences = 1,
                        SchedulePattern = "Fixed",
                        FrequencyEnd = "2025-12-31",
                        Comments = "Yearly payment plan",
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now.AddYears(1)
                    },
                    MonthOfYear = new List<string> { "JUNE", "JULY", "AUGUST" },
                    MonthDays = new List<string> { "DAY10", "DAY20" }
                };

                // Create the PaymentInfo object
                var ptxMandates = new List<MandatesListModel>
                {
                    new MandatesListModel
                    {
                         PayerId = 52,
                         ProfileId = 101,
                         Reference = "RFID-22012018-24",
                         SortCode = "200000",
                         AccountNumber = "42222222",
                         Id = 101,
                         AltReference = "ALT/22012018-24",
                         AccountName = "CARLOS SANTANA",
                         Status = "ACTIVE",
                         Comments = "Mandate was received as a hard copy.",
                         Created = DateTime.Now,
                         ValidationStatus = "string",
                         PaymentPlans = new List<PaymentPlan>
                         {
                                new PaymentPlan 
                                {
                                    WeeklyPaymentPlan = weeklyPlan,
                                    MonthlyPaymentPlan = monthlyPlan,
                                    MonthlyPickPaymentPlan = monthlyPickPlan,
                                    YearlyPaymentPlan = yearlyPlan
                                }
                                

                         }
                    }
                };    
                
                if (contactId != null)
                {
                    return new ObjectResult(new
                    {
                        status = "success",
                        mandates = ptxMandates
                    });
                }
                else
                {
                    return new BadRequestObjectResult("Failed to retrieve contactId.");
                }
            }
            catch (Exception ex)
            {
                // Log error and return specific error message
                _logger.LogError(ex, "Error occurred while creating the contact.");

                return new ObjectResult(new
                {
                    status = "error",
                    message = $"Error: {ex.Message}"
                })
                {
                    StatusCode = 500
                };
            }

        }
    }
}
