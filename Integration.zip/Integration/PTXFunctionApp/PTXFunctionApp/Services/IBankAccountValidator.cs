﻿using PTXFunctionApp.Models;

namespace PTXFunctionApp.Services
{
   public interface IBankAccountValidator
    {
       public Task<ValidationResult> ValidateBankAccountAsync(BankAccountModel account);
    }
}
