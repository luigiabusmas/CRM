﻿using Microsoft.Extensions.Options;
using PTXFunctionApp.Configuration;
using PTXFunctionApp.Models;
using System.Net.Http.Json;
using System.Text.Json;

namespace PTXFunctionApp.Services
{
    public class BankAccountValidator : IBankAccountValidator
    {
        private readonly HttpClient _httpClient;
        private readonly AuthSettings _authSettings;
        private string? _cachedToken;
        private DateTime _tokenExpiry;

        public BankAccountValidator(HttpClient httpClient, IOptions<AuthSettings> authOptions)
        {
            _httpClient = httpClient;
            _authSettings = authOptions.Value;
        }

        private async Task<string> GetAuthTokenAsync()
        {
            if (!string.IsNullOrEmpty(_cachedToken) && _tokenExpiry > DateTime.UtcNow.AddMinutes(1))
            {
                return _cachedToken;
            }

            var request = new HttpRequestMessage(HttpMethod.Post, _authSettings.TokenUrl)
            {
                Content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "grant_type", "client_credentials" },
                    { "client_id", _authSettings.ClientId },
                    { "client_secret", _authSettings.ClientSecret }
                })
            };

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var tokenResponse = await response.Content.ReadFromJsonAsync<TokenResponse>();

            if (tokenResponse == null || string.IsNullOrEmpty(tokenResponse.AccessToken))
            {
                throw new InvalidOperationException("Failed to retrieve access token.");
            }

            _cachedToken = tokenResponse.AccessToken;
            _tokenExpiry = DateTime.UtcNow.AddSeconds(tokenResponse.ExpiresIn);

            return _cachedToken;
        }

        public async Task<ValidationResult> ValidateBankAccountAsync(BankAccountModel account)
        {
            var token = await GetAuthTokenAsync();

            var request = new HttpRequestMessage(HttpMethod.Post, _authSettings.ValidationUrl)
            {
                Headers = { { "Authorization", $"Bearer {token}" } },
                Content = JsonContent.Create(account)
            };

            var response = await _httpClient.SendAsync(request);
            string content = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                var error = JsonSerializer.Deserialize<BankAccountValidationErrorResponse>(content);
                return new ValidationResult
                {
                    StatusCode = (int)response.StatusCode,
                    Error = error
                };
            }

            var success = JsonSerializer.Deserialize<BankAccountValidationResponse>(content);
            return new ValidationResult
            {
                StatusCode = 200,
                Success = success
            };
        }
    }
}