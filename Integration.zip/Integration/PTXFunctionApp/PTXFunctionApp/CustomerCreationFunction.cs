using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using PTXFunctionApp;
using Microsoft.Azure.Functions.Worker;

namespace PTXAzureFunction
{

    public class CustomerCreationFunction
    {
        private readonly ILogger<CustomerCreationFunction> _logger;

        public CustomerCreationFunction(ILogger<CustomerCreationFunction> logger)
        {
            _logger = logger;
        }

        [Function("ContactCreationFunction")]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            _logger.LogInformation("Received a request to create a new contact.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            ContactModel contact;

            try
            {
                // Attempt to deserialize the request body into ContactModel
                contact = JsonConvert.DeserializeObject<ContactModel>(requestBody);

                // If deserialization is successful, proceed
                if (contact == null)
                {
                    _logger.LogWarning("Deserialized contact is null.");
                    return new BadRequestObjectResult(new
                    {
                        status = "error",
                        message = "Request body is invalid. Contact cannot be null."
                    });
                }

                // Placeholder for processing the contact
                // Add logic to save the contact or call another service here
                var contactDetails = new
                {
                    type = "PERSON", // Static value
                    title = contact.title,
                    firstName = contact.firstName,
                    lastName = contact.lastName,
                    email = contact.email,
                    isAttachmentUsed = contact.isAttachmentUsed,
                    communicationPref = contact.communicationPref,
                    address = contact.address,
                    contactId = Guid.NewGuid().ToString(), // Generate a unique ID
                    companyName = contact.companyName,
                    reference = contact.reference,
                    phone = contact.phone
                };

                return new OkObjectResult(new
                {
                    status = "success",
                    message = "Contact processed successfully.",
                    contactDetails = contactDetails

                });
            }
            catch (Exception ex)
            {
                // Log error and return specific error message
                _logger.LogError(ex, "Error occurred while creating the contact.");

                return new ObjectResult(new
                {
                    status = "error",
                    message = $"Error: {ex.Message}"
                })
                {
                    StatusCode = 500
                };
            }
        }
    }
}


