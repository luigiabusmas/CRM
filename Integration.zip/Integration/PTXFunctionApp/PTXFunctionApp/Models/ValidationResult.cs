﻿namespace PTXFunctionApp.Models
{
    public class ValidationResult
    {
        public bool IsSuccess => Success != null;
        public BankAccountValidationResponse? Success { get; set; }
        public BankAccountValidationErrorResponse? Error { get; set; }
        public int StatusCode { get; set; } 
    }
}
