﻿using System.Text.Json.Serialization;

namespace PTXFunctionApp.Models
{
    public class BankAccountModel
    {
        [JsonPropertyName("accountNumber")]
        public required string AccountNumber { get; set; }

        [JsonPropertyName("sortCode")]
        public required string SortCode { get; set; }

        [JsonPropertyName("name")]
        public required string Name { get; set; }

        [JsonPropertyName("checkType")]
        public string CheckType { get; set; } = "Payee"; // Default value

        [JsonPropertyName("accountType")]
        public string AccountType { get; set; } = "Personal"; // Default value
    }
}