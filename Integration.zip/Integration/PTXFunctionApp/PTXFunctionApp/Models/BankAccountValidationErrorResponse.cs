﻿using System.Text.Json.Serialization;

namespace PTXFunctionApp.Models
{
    public class BankAccountValidationErrorResponse
    {
        [JsonPropertyName("correlationId")]
        public string? CorrelationId { get; set; }

        [JsonPropertyName("errors")]
        public List<ErrorDetail>? Errors { get; set; }

        [JsonPropertyName("instance")]
        public string? Instance { get; set; }

        [JsonPropertyName("timestamp")]
        public string? Timestamp { get; set; }
    }

    public class ErrorDetail
    {
        [JsonPropertyName("code")]
        public string? Code { get; set; }

        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
    }
}