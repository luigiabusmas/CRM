﻿using System.Text.Json.Serialization;

namespace PTXFunctionApp.Models
{
    public class BankAccountValidationResponse
    {
        [JsonPropertyName("match")]
        public bool Match { get; set; }

        [JsonPropertyName("originalName")]
        public string? OriginalName { get; set; }

        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("reasonCode")]
        public string? ReasonCode { get; set; }

        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
    }
}