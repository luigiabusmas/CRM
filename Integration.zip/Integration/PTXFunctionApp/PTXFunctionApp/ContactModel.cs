﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PTXFunctionApp
{
    
        public class Address
        {
            public string lines { get; set; }
            public string town { get; set; }
            public string county { get; set; }
            public string code { get; set; }
            public string country { get; set; }
        }

        public class ContactModel
        {
            public string type { get; set; }
            public string title { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string email { get; set; }
            public bool isAttachmentUsed { get; set; }
            public string communicationPref { get; set; }
            public Address address { get; set; }
            public string contactId { get; set; }
            public string companyName { get; set; }
            public string reference { get; set; }
            public string phone { get; set; }
        }
    }

