﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PTXFunctionApp.Configuration;
using PTXFunctionApp.Services;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWebApplication();

builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

var config = builder.Configuration;

builder.Services.AddHttpClient<BankAccountValidator>();
builder.Services.Configure<AuthSettings>(config.GetSection("AuthSettings"));
builder.Services.AddSingleton<IBankAccountValidator, BankAccountValidator>();

await builder.Build().RunAsync();
