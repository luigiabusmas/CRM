﻿namespace PTXFunctionApp.Configuration
{
    public class AuthSettings
    {
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        public string TokenUrl { get; set; } = string.Empty;
        public string ValidationUrl { get; set; } = string.Empty;
    }
}
